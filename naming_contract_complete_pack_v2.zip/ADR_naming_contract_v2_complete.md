# ADR — Naming Contract v2: Complete Migration Pack

## Status
Proposed for implementation handoff

## Decision
Use exactly three top-level families:
- `state`
- `context`
- `derived`

## Definitions
### `state`
Resolved player-owned, loadout-owned, or current run-owned quantities.

### `context`
External run conditions such as tier, heat, tournament, battle conditions, and enemy/environment-side modifiers.

### `derived`
Values calculated from `state` and/or `context`, including promoted composites such as:
- `derived::survivability.ehp`
- `derived::damage.edamage`
- `derived::economy.eecon`

## Naming grammar
`<family>::<domain>.<subdomain>.<name>`

Examples:
- `state::tower.damage`
- `state::uw.black_hole.duration_seconds`
- `context::bc.orb_resistance_pct`
- `derived::survivability.ehp`

## Completion standard for the migration ledger
This pack is complete for implementation handoff because the ledger contains:
1. reviewed contract-registry rows
2. compiler-routing rows and compiler fallback pattern rows
3. Codex-named promotion-gap rows for eHP / eDamage / eEcon
4. explicit policy rows for every legacy top-level family
5. typed rows distinguishing concrete, pattern, gap, deferred, and policy entries

This means there should be no silent omissions at the family level.
Any remaining uncertainty is represented explicitly as:
- `row_type = pattern`
- `row_type = deferred`
- or `review_status = hold`

## Required implementation rule
Codex must:
1. implement all `concrete` rows directly
2. treat `pattern` rows as schema rules that require bounded expansion during implementation
3. preserve `deferred` rows as explicit holds
4. not silently invent remaps outside the ledger

## Clarifications
- `lab_speed_multiplier` remains `state::meta.lab_speed_multiplier`
- ownership flags and capability unlocks belong under `state::capability.*`
- enemy/environment-side values belong under `context::*`
- promoted composites remain under `derived::*`, not a separate top-level objective family

## Coverage summary
- Total rows: 163
- By source scope: {'compiler_routing': 36, 'contract_registry': 62, 'migration_policy': 4, 'promotion_gap_review': 61}
- By row type: {'concrete': 85, 'deferred': 1, 'pattern': 12, 'policy': 4, 'gap': 61}
- By review status: {'approved': 27, 'hold': 1, 'pending': 73, '': 62}

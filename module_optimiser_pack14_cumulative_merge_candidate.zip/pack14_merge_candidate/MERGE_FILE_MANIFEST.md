# Merge file manifest

## Repo files in bundle
- `repo_files/kb/modules/tables/module-level-costs.csv`
- `repo_files/models/module_optimizer_queries.py`
- `repo_files/models/module_overlay.py`
- `repo_files/engine/module_economics.py`
- `repo_files/engine/module_overlay.py`
- `repo_files/engine/module_reroll.py`
- `repo_files/engine/module_queries.py`
- `repo_files/engine/module_level_optimizer.py`
- `repo_files/engine/module_reroll_optimizer.py`
- `repo_files/tests/test_module_economics.py`
- `repo_files/tests/test_module_overlay.py`
- `repo_files/tests/test_module_reroll.py`
- `repo_files/tests/test_module_queries.py`
- `repo_files/tests/test_module_level_optimizer.py`
- `repo_files/tests/test_module_reroll_optimizer.py`

## Verification set used
- `tests/test_module_economics.py`
- `tests/test_module_overlay.py`
- `tests/test_module_reroll.py`
- `tests/test_module_queries.py`
- `tests/test_module_level_optimizer.py`
- `tests/test_module_reroll_optimizer.py`
- `tests/test_optimizer.py`

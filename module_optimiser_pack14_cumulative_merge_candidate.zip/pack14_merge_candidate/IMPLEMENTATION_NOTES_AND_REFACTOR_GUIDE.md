# Implementation notes and refactor guide

## Architectural intent
This work intentionally sits **downstream of the existing module/account/compiler/stat infrastructure**.
It should be read as a helper-and-optimiser layer, not a replacement for module canon.

## How the pieces fit together
1. `module_optimizer_queries.py`
   - defines input objects for four query families
2. `module_economics.py`
   - deterministic cost lookups and upgrade summaries
3. `module_overlay.py`
   - temporary mutation of module/account state with no canonical mutation
4. `module_reroll.py`
   - probability/cost calculations for combined-state rerolling
5. `module_level_optimizer.py`
   - single-step level search using the overlay + canonical scorer
6. `module_reroll_optimizer.py`
   - first-pass reroll search using reroll mechanics + overlay scoring
7. `module_queries.py`
   - envelope layer used by AI-facing interactions

## Important deliberate choices
- No parallel account-state schema was introduced.
- No new stat formulas were introduced outside the current compiler/stat/scorer path.
- Rerolling is treated as a bundle-action problem, not a single-line problem.
- Upgrade shards and reroll shards remain separate currencies.
- Max waves was intentionally left out of v1.

## Where the implementation is intentionally conservative
### Reroll optimiser
The reroll optimiser does not yet search the full effect-identity space. It upgrades current visible substats to higher rarity targets as a cheap and controlled proxy for upside.

Why:
- this keeps runtime bounded
- this stays compatible with the current canonical path
- it gives usable threshold outputs without pretending full global optimality

What a refactor would likely change:
- enumerate target effect identities from the eligible pool
- model acceptable frontier over identity + rarity bundles
- prune search with dominance filters

### Level optimiser
The level optimiser is single-step only.

Why:
- easiest to verify
- avoids speculative short-path heuristics in first pass

What a refactor would likely change:
- add short-horizon search
- add budget-aware planning per shard family
- improve assist-side value representation if canonical propagation changes

## Known limitations that should remain explicit
- Assist candidate propagation may currently be understated in some cases.
- Reroll search breadth is runtime-constrained.
- Workbook-derived constants are coded, not auto-extracted.
- Query envelopes are local to this feature set.

## Recommended next refactor order
1. Formalise source-closure for reroll math.
2. Add a shared query-envelope abstraction if multiple surfaces now need it.
3. Expand reroll target search beyond visible-substat approximation.
4. Add level short-path search.
5. Only then consider cross-currency sequencing between level spend and reroll spend.

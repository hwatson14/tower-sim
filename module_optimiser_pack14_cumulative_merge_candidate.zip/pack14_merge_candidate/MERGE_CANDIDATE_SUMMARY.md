# Module optimiser cumulative merge candidate

## Status
This is the cumulative merge-candidate bundle for the requested module surfaces:
- reroll calculator
- total shard calculator
- module level optimiser
- reroll / module substat optimiser

This bundle is **repo-aligned and test-backed**, but it is **not final-architecture perfect**. It is intentionally documented for likely future refactor.

## What is implemented

### 1. Deterministic module economics
Files:
- `kb/modules/tables/module-level-costs.csv`
- `engine/module_economics.py`
- `tests/test_module_economics.py`

What it does:
- ports module level-upgrade economics into a repo-native CSV
- loads level, shard cost, cumulative shards, coin cost, cumulative coins
- exposes deterministic helpers for cap lookup and upgrade summaries

Why it was implemented this way:
- module upgrade economics were missing as active repo canon
- this was the cleanest deterministic dependency for later optimisers
- it avoids workbook-only logic staying hidden in spreadsheets

Key limitations:
- this is a direct economics surface only
- it does not itself decide whether a level is worth buying
- it assumes the workbook ladder is the accepted source for this tranche

### 2. Query dataclasses and shared machine-first schema
Files:
- `models/module_optimizer_queries.py`

What it does:
- defines repo-native query objects for all four requested surfaces:
  - `ModuleTotalShardsQuery`
  - `ModuleRerollCostQuery`
  - `ModuleLevelOptimizeQuery`
  - `ModuleRerollOptimizeQuery`
- restricts v1 objective families to `ehp`, `edamage`, `eecon`

Why it was implemented this way:
- locks interface before search logic
- keeps AI-facing usage consistent and typed
- prevents silent query drift during refactor

Key limitations:
- it is a light validation layer, not a full governance engine
- max waves is intentionally excluded from v1

### 3. Hypothetical module overlay plumbing
Files:
- `models/module_overlay.py`
- `engine/module_overlay.py`
- `tests/test_module_overlay.py`

What it does:
- deep-copies canonical account state
- applies temporary module mutations without mutating canonical state
- supports module snapshot mutation, preset-slot mutation, and system-slot mutation
- flows overlaid state through the existing compiler, stat engine, and objective scorer

Why it was implemented this way:
- avoids creating a second simulator
- reuses the existing repo path for truth
- gives all later optimisers one scoring primitive

Key limitations:
- this is a thin overlay layer only
- it depends on the current compiler/stat path being the authority
- if the upstream module semantics change, this overlay should remain thin and adapt rather than grow its own rules

### 4. Reroll mechanics foundation
Files:
- `engine/module_reroll.py`
- `tests/test_module_reroll.py`

What it does:
- models reroll as a **combined-state action**, not slot-by-slot improvement
- accepts slot type, rarity floor, locks, slots unlocked, desired effects, banned effects, confidence, and budget
- returns probability and threshold outputs including:
  - per-reroll success probability
  - rolls needed
  - reroll shards needed
  - p50 / p95 reroll shards
  - budget status scaffold

Why it was implemented this way:
- the user explicitly identified that combined rerolling is structurally better than slot-by-slot thinking
- later reroll optimisation depends on a first-class mechanics core
- threshold outputs directly answer practical questions like “do I have enough reroll shards for a large reroll?”

Key limitations:
- mechanics are workbook-backed and formula-coded, not auto-extracted from workbook formulas
- if workbook logic changes, this file may need explicit refresh
- threshold buckets are still a first-pass policy layer

### 5. Deterministic query helpers
Files:
- `engine/module_queries.py`
- `tests/test_module_queries.py`

What it does:
- exposes repo-style query envelopes for:
  - `module_total_shards`
  - `module_reroll_cost`
  - `module_level_optimize`
  - `module_reroll_optimize`
- standardises provenance, verification, assumptions, frontier mode, and result payloads

Why it was implemented this way:
- AI interaction needs consistent response envelopes
- separates machine-first outputs from implementation details
- keeps canonical vs helper vs policy distinctions visible

Key limitations:
- query envelopes are useful but not yet a full cross-repo API standard
- later refactor may want to move these to a common query-response layer

### 6. Module level optimiser
Files:
- `engine/module_level_optimizer.py`
- `tests/test_module_level_optimizer.py`

What it does:
- scores single-step level candidates through the canonical overlay -> compiler -> stat engine -> scorer path
- resolves scenario into repo preset naming
- applies the locked single-step acceptable frontier (98% of best)
- emits baseline score, best action, candidate list, and limitations

Why it was implemented this way:
- this is the safest first optimiser because it is deterministic and uses existing objective-family scoring
- single-step optimisation is easier to verify than longer path search
- acceptable frontier prevents brittle exact-best behaviour

Key limitations:
- current canonical propagation appears to reflect primary module level changes more directly than assist module snapshot level changes
- the optimiser intentionally leaves that limitation explicit rather than inventing assist math
- this is single-step optimisation only, not a full short-path planner yet

### 7. Reroll optimiser
Files:
- `engine/module_reroll_optimizer.py`
- `tests/test_module_reroll_optimizer.py`

What it does:
- resolves active preset and selected primary module for the requested slot
- computes baseline score through the canonical path
- enumerates combined-state reroll candidates over rarity floors and lock counts
- uses reroll mechanics to estimate thresholds and cost
- scores reroll upside through the overlay path
- ranks candidates by value per reroll shard
- applies the reroll acceptable frontier (95% of best)

Why it was implemented this way:
- this is the first practical repo-native answer to “when is a reroll worth doing?”
- it keeps reroll and level currencies separate
- it stays compatible with future improvement to effect-identity search

Key limitations:
- **conservative first pass**: reroll upside is estimated by upgrading currently visible substats rather than doing a full identity search across the entire effect pool
- default runtime breadth is not yet tuned for full exhaustive search in all cases
- current tests use a reduced-scope reroll configuration to keep runtime bounded and verification practical

## Canonical vs helper vs policy

### Canonical / repo-backed inputs
- `AccountState.modules_inventory`
- `AccountState.module_presets`
- existing compiler and stat engine
- optimiser scorer objective families: `ehp`, `edamage`, `eecon`
- module tables already in repo KB
- new `module-level-costs.csv`

### Helper layers
- module economics helper
- overlay helper
- reroll mechanics helper
- query envelope helper

### Policy layers
- acceptable frontier rules
- reroll budget threshold labels
- reroll candidate ranking by value per shard

This distinction matters because future refactor should preserve canonical sources and feel free to replace helper/policy code.

## Verification completed

### Test files run and passing
- `tests/test_module_economics.py` → 3 passed
- `tests/test_module_overlay.py` → 7 passed
- `tests/test_module_reroll.py` → 7 passed
- `tests/test_module_queries.py` → 2 passed
- `tests/test_module_level_optimizer.py` → 2 passed
- `tests/test_module_reroll_optimizer.py` → 2 passed
- `tests/test_optimizer.py` → 15 passed

Total: **38 passed, 0 failed**

### Live behavioural checks previously verified in build flow
- reduced-scope reroll optimiser query completed successfully and returned threshold-oriented outputs
- level optimiser returned candidates and best action for cannon / farming
- overlay scoring preserved no-op behaviour and avoided canonical-state mutation

## Why this is a merge candidate but not “finished forever”
This is merge-candidate quality because:
- it is KB-aligned
- it is repo-native
- it is test-backed
- it covers the requested surfaces in first-pass form
- limitations are explicit rather than hidden

It is **not** “finished forever” because:
- reroll search breadth is conservative
- assist-level propagation looks weaker than primary in the current canonical path
- query envelopes may later belong in a broader shared API layer
- module economics port should ideally become part of a governed ingestion pipeline rather than a one-off CSV port

## Likely refactor targets
1. Move module query envelopes into a shared query/response layer.
2. Replace formula-coded reroll mechanics with a more governed extraction or source-closure path.
3. Expand reroll optimiser from visible-substat upgrade approximation to full effect-identity search.
4. Improve assist-level and assist-module propagation if the compiler path currently understates that value.
5. Add short-path planning for level optimisation.
6. Add max-waves objective family later as planned v2 work.

## Recommended Codex posture
Codex should treat this bundle as:
- a valid first-pass implementation foundation
- safe to merge behind its current test set
- expected to be refactored in the helper/policy layers
- **not** a reason to rewrite the canonical compiler/stat pipeline unless module semantics genuinely require it

## File list in this bundle
### Added or updated repo files
- `repo_files/kb/modules/tables/module-level-costs.csv`
- `repo_files/models/module_optimizer_queries.py`
- `repo_files/models/module_overlay.py`
- `repo_files/engine/module_economics.py`
- `repo_files/engine/module_overlay.py`
- `repo_files/engine/module_reroll.py`
- `repo_files/engine/module_queries.py`
- `repo_files/engine/module_level_optimizer.py`
- `repo_files/engine/module_reroll_optimizer.py`
- `repo_files/tests/test_module_economics.py`
- `repo_files/tests/test_module_overlay.py`
- `repo_files/tests/test_module_reroll.py`
- `repo_files/tests/test_module_queries.py`
- `repo_files/tests/test_module_level_optimizer.py`
- `repo_files/tests/test_module_reroll_optimizer.py`

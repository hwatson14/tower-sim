from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional, Tuple


@dataclass(frozen=True)
class ModuleSubstatOverlay:
    index: int
    name: Optional[str] = None
    value: Optional[str] = None
    raw_token: Optional[str] = None


@dataclass(frozen=True)
class ModuleSnapshotOverlay:
    module_name: str
    rarity: Optional[str] = None
    level: Optional[int] = None
    stat: Optional[str] = None
    substats: Tuple[ModuleSubstatOverlay, ...] = field(default_factory=tuple)


@dataclass(frozen=True)
class ModulePresetSlotOverlay:
    slot_type: str
    primary: Optional[str] = None
    assist: Optional[str] = None


@dataclass(frozen=True)
class ModuleSystemSlotOverlay:
    slot_type: str
    assist_level: Optional[int] = None
    assist_unlocked: Optional[bool] = None
    rarity_cap: Optional[str] = None
    multiplier_cap: Optional[float] = None
    substat_cap: Optional[float] = None


@dataclass(frozen=True)
class ModuleOverlayRequest:
    preset_name: Optional[str] = None
    module_overlays: Tuple[ModuleSnapshotOverlay, ...] = field(default_factory=tuple)
    preset_slot_overlays: Tuple[ModulePresetSlotOverlay, ...] = field(default_factory=tuple)
    system_slot_overlays: Tuple[ModuleSystemSlotOverlay, ...] = field(default_factory=tuple)

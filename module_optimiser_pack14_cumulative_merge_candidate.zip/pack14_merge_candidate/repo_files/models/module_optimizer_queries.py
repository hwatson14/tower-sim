from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

ObjectiveFamily = Literal['ehp', 'edamage', 'eecon']


@dataclass(frozen=True)
class ModuleTotalShardsQuery:
    module_name: str
    target_level: int
    objective_family: ObjectiveFamily
    scenario_id: str

    def __post_init__(self) -> None:
        if self.objective_family not in {'ehp', 'edamage', 'eecon'}:
            raise ValueError(f'Unsupported objective_family: {self.objective_family}')
        if not self.module_name.strip():
            raise ValueError('module_name must be non-empty')
        if not self.scenario_id.strip():
            raise ValueError('scenario_id must be non-empty')
        if self.target_level <= 0:
            raise ValueError('target_level must be positive')


@dataclass(frozen=True)
class ModuleRerollCostQuery:
    slot_type: str
    module_rarity: str
    target_rarity_floor: str
    slots_unlocked: int
    locks: int
    desired_effects: int
    objective_family: ObjectiveFamily
    scenario_id: str
    banned_effects: int = 0
    confidence: float = 0.95
    reroll_discount: float = 0.0
    current_budget: int | None = None

    def __post_init__(self) -> None:
        if self.objective_family not in {'ehp', 'edamage', 'eecon'}:
            raise ValueError(f'Unsupported objective_family: {self.objective_family}')
        if not self.scenario_id.strip():
            raise ValueError('scenario_id must be non-empty')


@dataclass(frozen=True)
class ModuleLevelOptimizeQuery:
    slot_type: str
    objective_family: ObjectiveFamily
    scenario_id: str

    def __post_init__(self) -> None:
        if self.objective_family not in {'ehp', 'edamage', 'eecon'}:
            raise ValueError(f'Unsupported objective_family: {self.objective_family}')
        if not self.scenario_id.strip():
            raise ValueError('scenario_id must be non-empty')


@dataclass(frozen=True)
class ModuleRerollOptimizeQuery:
    slot_type: str
    objective_family: ObjectiveFamily
    scenario_id: str
    module_name: str | None = None
    current_budget: int | None = None
    confidence: float = 0.95
    reroll_discount: float = 0.0
    banned_effects: int = 0
    slots_unlocked_override: int | None = None
    max_locks_considered: int = 3

    def __post_init__(self) -> None:
        if self.objective_family not in {'ehp', 'edamage', 'eecon'}:
            raise ValueError(f'Unsupported objective_family: {self.objective_family}')
        if not self.scenario_id.strip():
            raise ValueError('scenario_id must be non-empty')
        if self.current_budget is not None and self.current_budget < 0:
            raise ValueError('current_budget must be non-negative when provided')
        if self.slots_unlocked_override is not None and self.slots_unlocked_override <= 0:
            raise ValueError('slots_unlocked_override must be positive when provided')
        if self.max_locks_considered < 0:
            raise ValueError('max_locks_considered must be non-negative')

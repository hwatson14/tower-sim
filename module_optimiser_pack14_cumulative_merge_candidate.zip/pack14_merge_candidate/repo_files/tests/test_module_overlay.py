from __future__ import annotations

import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from compilers.account_state_compiler import compile_account_state
from compilers.stat_input_compiler import compile_stat_inputs
from engine.module_overlay import apply_module_overlay, score_module_overlay
from parsers.ids_parser import parse_ids
from models.module_overlay import (
    ModuleOverlayRequest,
    ModulePresetSlotOverlay,
    ModuleSnapshotOverlay,
    ModuleSubstatOverlay,
    ModuleSystemSlotOverlay,
)


def _load_account_state():
    ids = parse_ids(ROOT / 'input' / '_IDS.csv')
    loadout = json.load(open(ROOT / 'input' / 'loadout.json'))
    perks = json.load(open(ROOT / 'input' / 'perks.json'))
    return compile_account_state(ids, loadout_config=loadout, perk_config=perks)


def test_noop_overlay_preserves_objective_scores():
    account = _load_account_state()
    _, baseline = score_module_overlay(account, ModuleOverlayRequest(), preset_name='Farming')
    _, overlaid = score_module_overlay(account, ModuleOverlayRequest(), preset_name='Farming')
    assert baseline['objectives']['ehp']['score'] == overlaid['objectives']['ehp']['score']
    assert baseline['objectives']['edamage']['score'] == overlaid['objectives']['edamage']['score']
    assert baseline['objectives']['eecon']['score'] == overlaid['objectives']['eecon']['score']


def test_overlay_does_not_mutate_canonical_account_state():
    account = _load_account_state()
    original_level = account.modules_inventory['Amplifying Strike'].level
    patched = apply_module_overlay(account, ModuleOverlayRequest(module_overlays=(ModuleSnapshotOverlay(module_name='Amplifying Strike', level=200),),))
    assert account.modules_inventory['Amplifying Strike'].level == original_level
    assert patched.modules_inventory['Amplifying Strike'].level == 200


def test_primary_level_mutation_stays_local_and_changes_module_state():
    account = _load_account_state()
    patched = apply_module_overlay(account, ModuleOverlayRequest(module_overlays=(ModuleSnapshotOverlay(module_name='Amplifying Strike', level=200),),))
    assert patched.modules_inventory['Amplifying Strike'].level == 200
    assert account.modules_inventory['Amplifying Strike'].level != patched.modules_inventory['Amplifying Strike'].level


def test_preset_swap_is_local_to_overlay():
    account = _load_account_state()
    original = account.module_presets['Farming']['generator'].assist
    patched = apply_module_overlay(account, ModuleOverlayRequest(preset_name='Farming', preset_slot_overlays=(ModulePresetSlotOverlay(slot_type='generator', assist='Pulsar Harvester'),),))
    assert account.module_presets['Farming']['generator'].assist == original
    assert patched.module_presets['Farming']['generator'].assist == 'Pulsar Harvester'


def test_substat_mutation_flows_through_existing_routing():
    account = _load_account_state()
    baseline_book, _ = score_module_overlay(account, ModuleOverlayRequest(), preset_name='Farming')
    overlay = ModuleOverlayRequest(
        module_overlays=(
            ModuleSnapshotOverlay(
                module_name='Singularity Harness',
                substats=(ModuleSubstatOverlay(index=4, value='+12%', raw_token='0.12'),),
            ),
        ),
    )
    mutated_book, _ = score_module_overlay(account, overlay, preset_name='Farming')
    baseline = float(baseline_book.rows['canonical_stat::package_chance_pct'].final_value)
    mutated = float(mutated_book.rows['canonical_stat::package_chance_pct'].final_value)
    assert mutated > baseline


def test_system_assist_level_mutation_changes_objective_surface():
    account = _load_account_state()
    _, baseline = score_module_overlay(account, ModuleOverlayRequest(), preset_name='Farming')
    overlay = ModuleOverlayRequest(system_slot_overlays=(ModuleSystemSlotOverlay(slot_type='armor', assist_level=1),))
    _, changed = score_module_overlay(account, overlay, preset_name='Farming')
    assert changed['objectives']['ehp']['score'] != baseline['objectives']['ehp']['score']


def test_compile_stat_inputs_works_with_overlaid_state():
    account = _load_account_state()
    overlay = ModuleOverlayRequest(module_overlays=(ModuleSnapshotOverlay(module_name='Singularity Harness', level=170),))
    patched = apply_module_overlay(account, overlay)
    rows = compile_stat_inputs(patched, preset_name='Farming', state_mode='start_of_run')
    assert rows

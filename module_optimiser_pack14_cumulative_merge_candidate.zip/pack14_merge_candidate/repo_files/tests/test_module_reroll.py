from engine.module_reroll import (
    ModuleRerollQuery,
    cumulative_rarity_probability,
    eligible_effect_count,
    evaluate_reroll_query,
    reroll_shard_cost,
)


def test_cumulative_rarity_probability_matches_workbook_logic():
    assert cumulative_rarity_probability('ancestral', 'ancestral') == 0.003
    assert round(cumulative_rarity_probability('ancestral', 'mythic'), 3) == 0.013
    assert cumulative_rarity_probability('ancestral', 'epic') == 0.138
    assert cumulative_rarity_probability('mythic', 'ancestral') == 0.0
    assert cumulative_rarity_probability('legendary', 'epic') == 0.125


def test_eligible_effect_counts_match_workbook_bases_before_bans():
    assert eligible_effect_count('cannon', 'epic', 0) == 14
    assert eligible_effect_count('armor', 'legendary', 0) == 16
    assert eligible_effect_count('generator', 'ancestral', 0) == 13
    assert eligible_effect_count('core', 'legendary', 0) == 26


def test_reroll_shard_cost_matches_workbook_base_costs():
    assert reroll_shard_cost(0) == 10
    assert reroll_shard_cost(1) == 40
    assert reroll_shard_cost(2) == 160
    assert reroll_shard_cost(3) == 500


def test_cannon_example_matches_visible_workbook_outputs():
    query = ModuleRerollQuery(
        slot_type='cannon',
        module_rarity='ancestral',
        target_rarity_floor='epic',
        slots_unlocked=5,
        locks=0,
        desired_effects=8,
        banned_effects=0,
        confidence=0.95,
    )
    result = evaluate_reroll_query(query)
    assert result.eligible_effects == 14
    assert result.open_slots == 5
    assert round(result.target_rarity_probability, 3) == 0.138
    assert result.rolls_needed == 8
    assert result.reroll_shards_needed == 80
    assert result.p50_rolls == 2
    assert result.p50_reroll_shards == 20
    assert result.p95_rolls == 8
    assert result.p95_reroll_shards == 80


def test_cannon_locking_example_matches_visible_workbook_outputs():
    query = ModuleRerollQuery(
        slot_type='cannon',
        module_rarity='ancestral',
        target_rarity_floor='legendary',
        slots_unlocked=5,
        locks=3,
        desired_effects=5,
        banned_effects=0,
        confidence=0.95,
    )
    result = evaluate_reroll_query(query)
    assert result.eligible_effects == 17
    assert result.open_slots == 2
    assert round(result.target_rarity_probability, 3) == 0.038
    assert result.rolls_needed == 110
    assert result.reroll_shards_needed == 55000


def test_budget_status_thresholds_are_scaffolded():
    base = ModuleRerollQuery(
        slot_type='cannon',
        module_rarity='ancestral',
        target_rarity_floor='epic',
        slots_unlocked=5,
        locks=0,
        desired_effects=8,
        banned_effects=0,
        confidence=0.95,
    )
    assert evaluate_reroll_query(base).budget_status is None
    assert evaluate_reroll_query(ModuleRerollQuery(**{**base.__dict__, 'current_budget': 19})).budget_status == 'not_enough'
    assert evaluate_reroll_query(ModuleRerollQuery(**{**base.__dict__, 'current_budget': 20})).budget_status == 'borderline'
    assert evaluate_reroll_query(ModuleRerollQuery(**{**base.__dict__, 'current_budget': 80})).budget_status == 'large_reroll_justified'


def test_unattainable_rarity_floor_fails_closed():
    query = ModuleRerollQuery(
        slot_type='armor',
        module_rarity='epic',
        target_rarity_floor='ancestral',
        slots_unlocked=4,
        locks=0,
        desired_effects=1,
    )
    try:
        evaluate_reroll_query(query)
    except ValueError as exc:
        assert 'unattainable' in str(exc).lower()
    else:
        raise AssertionError('Expected fail-closed ValueError')

from pathlib import Path

from engine.module_queries import query_module_reroll_cost, query_module_total_shards
from models.account_state import AccountState, ModuleSnapshot, ModuleSubstat
from models.module_optimizer_queries import ModuleRerollCostQuery, ModuleTotalShardsQuery


def _minimal_account_state() -> AccountState:
    return AccountState(
        ids_path=Path('dummy.csv'),
        labs={}, workshop={}, workshop_enhancements=None, ultimate_weapons={}, uw_plus_tracks={}, relics={},
        vault={}, bots=[], bot_upgrades={}, guardians=None, player_meta={}, theme_song_coin_multiplier=None,
        cards_inventory={}, card_slots_unlocked=None, card_presets={},
        module_system_state={}, module_presets={},
        modules_inventory={
            'Death Penalty': ModuleSnapshot(
                name='Death Penalty', slot_type='cannon', rarity='ancestral', level=41, stat=None,
                substats=[ModuleSubstat(name='attack_speed', value='1.2x')],
            )
        },
        perk_presets={}, active_perk_preset=None, active_card_preset='Farming', active_module_preset='Farming',
        default_preset='Farming', raw_sections={},
    )


def test_module_total_shards_query_resolves_from_account_state():
    account = _minimal_account_state()
    envelope = query_module_total_shards(account, ModuleTotalShardsQuery(
        module_name='Death Penalty', target_level=45, objective_family='edamage', scenario_id='farm_default'
    ))
    assert envelope.query_family == 'module_total_shards'
    assert envelope.result['current_level'] == 41
    assert envelope.result['target_level'] == 45
    assert envelope.result['target_cumulative_shards'] - envelope.result['current_cumulative_shards'] == envelope.result['shard_cost']


def test_module_reroll_cost_query_returns_envelope():
    envelope = query_module_reroll_cost(ModuleRerollCostQuery(
        slot_type='cannon', module_rarity='ancestral', target_rarity_floor='legendary',
        slots_unlocked=5, locks=3, desired_effects=5, objective_family='edamage', scenario_id='farm_default'
    ))
    assert envelope.query_family == 'module_reroll_cost'
    assert envelope.result['eligible_effects'] == 17
    assert envelope.result['open_slots'] == 2
    assert envelope.verification['status'] == 'verified_mechanics_foundation'

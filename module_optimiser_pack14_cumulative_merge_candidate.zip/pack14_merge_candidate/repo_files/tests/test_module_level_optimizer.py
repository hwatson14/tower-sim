from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from compilers.account_state_compiler import compile_account_state
from engine.module_level_optimizer import optimize_module_level
from engine.module_queries import query_module_level_optimize
from models.module_optimizer_queries import ModuleLevelOptimizeQuery
from parsers.ids_parser import parse_ids


def _build_state():
    ids_raw = parse_ids(ROOT / 'input' / '_IDS.csv')
    return compile_account_state(ids_raw, default_preset='Farming')


def test_module_level_optimizer_returns_candidates_for_cannon_farming():
    state = _build_state()
    result = optimize_module_level(state, ModuleLevelOptimizeQuery(slot_type='cannon', objective_family='edamage', scenario_id='farming'))
    assert result.slot_type == 'cannon'
    assert result.preset_name == 'Farming'
    assert result.best_action_id is not None
    assert len(result.candidates) >= 1
    assert any(c['role'] == 'primary' for c in result.candidates)


def test_module_level_optimizer_envelope_shape():
    state = _build_state()
    env = query_module_level_optimize(state, ModuleLevelOptimizeQuery(slot_type='cannon', objective_family='edamage', scenario_id='farming'))
    assert env.query_family == 'module_level_optimize'
    assert env.frontier_mode == 'single_step_98pct'
    assert env.verification['status'] == 'verified_optimizer_foundation'
    assert 'candidates' in env.result

from engine.module_economics import (
    cumulative_coins_to_level,
    cumulative_shards_to_level,
    module_level_cap,
    summarize_module_upgrade,
)


def test_module_level_cap_is_300_from_workbook_port():
    assert module_level_cap() == 300


def test_known_early_checkpoints_match_workbook_values():
    assert cumulative_shards_to_level(1) == 0
    assert cumulative_shards_to_level(2) == 7
    assert cumulative_shards_to_level(10) == 88
    assert cumulative_coins_to_level(2) == 10000
    assert cumulative_coins_to_level(10) == 165000


def test_upgrade_summary_reconciles_by_difference():
    summary = summarize_module_upgrade(1, 10)
    assert summary.levels_gained == 9
    assert summary.shard_cost == 88
    assert summary.coin_cost == 165000
    assert summary.target_cumulative_shards - summary.current_cumulative_shards == summary.shard_cost
    assert summary.target_cumulative_coins - summary.current_cumulative_coins == summary.coin_cost

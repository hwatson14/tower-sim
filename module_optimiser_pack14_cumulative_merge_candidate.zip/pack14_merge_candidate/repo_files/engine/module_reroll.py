from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Literal

SlotType = Literal['cannon', 'armor', 'generator', 'core']
Rarity = Literal['epic', 'legendary', 'mythic', 'ancestral']

RARITY_ORDER = {'epic': 1, 'legendary': 2, 'mythic': 3, 'ancestral': 4}
BASE_DICE_COST_BY_LOCKS = {
    0: 10,
    1: 40,
    2: 160,
    3: 500,
    4: 1000,
    5: 1600,
    6: 2250,
    7: 3000,
}
BASE_ELIGIBLE_EFFECTS = {
    ('cannon', 'epic'): 14,
    ('cannon', 'legendary'): 17,
    ('cannon', 'mythic'): 17,
    ('cannon', 'ancestral'): 17,
    ('armor', 'epic'): 15,
    ('armor', 'legendary'): 16,
    ('armor', 'mythic'): 17,
    ('armor', 'ancestral'): 17,
    ('generator', 'epic'): 13,
    ('generator', 'legendary'): 13,
    ('generator', 'mythic'): 13,
    ('generator', 'ancestral'): 13,
    ('core', 'epic'): 15,
    ('core', 'legendary'): 26,
    ('core', 'mythic'): 26,
    ('core', 'ancestral'): 26,
}
# Base per-line rarity odds from workbook R41:R44.
BASE_RARITY_ODDS = {'epic': 0.1, 'legendary': 0.025, 'mythic': 0.01, 'ancestral': 0.003}


@dataclass(frozen=True)
class ModuleRerollQuery:
    slot_type: SlotType
    module_rarity: Rarity
    target_rarity_floor: Rarity
    slots_unlocked: int
    locks: int
    desired_effects: int
    banned_effects: int = 0
    confidence: float = 0.95
    reroll_discount: float = 0.0
    current_budget: int | None = None


@dataclass(frozen=True)
class ModuleRerollResult:
    eligible_effects: int
    open_slots: int
    target_rarity_probability: float
    per_open_slot_success_probability: float
    per_reroll_success_probability: float
    rolls_needed: int
    reroll_shards_needed: int
    p50_rolls: int
    p50_reroll_shards: int
    p95_rolls: int
    p95_reroll_shards: int
    budget_status: str | None


def _normalize_rarity(value: str) -> Rarity:
    key = value.strip().lower()
    if key not in RARITY_ORDER:
        raise ValueError(f'Unsupported rarity: {value}')
    return key  # type: ignore[return-value]


def cumulative_rarity_probability(module_rarity: str, target_rarity_floor: str) -> float:
    module = _normalize_rarity(module_rarity)
    target = _normalize_rarity(target_rarity_floor)
    if RARITY_ORDER[target] > RARITY_ORDER[module]:
        return 0.0
    total = 0.0
    for rarity, order in RARITY_ORDER.items():
        if order < RARITY_ORDER[target] or order > RARITY_ORDER[module]:
            continue
        total += BASE_RARITY_ODDS[rarity]
    return total


def eligible_effect_count(slot_type: str, target_rarity_floor: str, banned_effects: int = 0) -> int:
    slot_key = slot_type.strip().lower()
    rarity_key = _normalize_rarity(target_rarity_floor)
    if (slot_key, rarity_key) not in BASE_ELIGIBLE_EFFECTS:
        raise ValueError(f'Unsupported slot/rarity combination: {slot_type}/{target_rarity_floor}')
    total = BASE_ELIGIBLE_EFFECTS[(slot_key, rarity_key)] - banned_effects
    if total <= 0:
        raise ValueError('Eligible effect count must remain positive after bans.')
    return total


def reroll_shard_cost(locks: int, reroll_discount: float = 0.0) -> int:
    if locks not in BASE_DICE_COST_BY_LOCKS:
        raise ValueError(f'Unsupported lock count: {locks}')
    raw = BASE_DICE_COST_BY_LOCKS[locks] * (1.0 - reroll_discount)
    return int(round(raw))


def _rolls_needed_for_confidence(per_reroll_success_probability: float, confidence: float) -> int:
    if not (0.0 < confidence < 1.0):
        raise ValueError('confidence must be strictly between 0 and 1')
    if per_reroll_success_probability <= 0.0:
        raise ValueError('per_reroll_success_probability must be positive')
    if per_reroll_success_probability >= 1.0:
        return 1
    numerator = math.log(1.0 - confidence)
    denominator = math.log(1.0 - per_reroll_success_probability)
    return int(math.ceil(numerator / denominator))


def _budget_status(current_budget: int | None, p50_cost: int, p95_cost: int) -> str | None:
    if current_budget is None:
        return None
    if current_budget >= p95_cost:
        return 'large_reroll_justified'
    if current_budget >= p50_cost:
        return 'borderline'
    return 'not_enough'


def evaluate_reroll_query(query: ModuleRerollQuery) -> ModuleRerollResult:
    if query.locks < 0:
        raise ValueError('locks must be non-negative')
    if query.slots_unlocked <= 0:
        raise ValueError('slots_unlocked must be positive')
    if query.locks >= query.slots_unlocked:
        raise ValueError('locks must be strictly less than slots_unlocked')
    if query.desired_effects <= 0:
        raise ValueError('desired_effects must be positive')

    eligible = eligible_effect_count(query.slot_type, query.target_rarity_floor, query.banned_effects)
    available_pool = eligible - query.locks
    if available_pool <= 0:
        raise ValueError('eligible effect pool after locks must be positive')
    if query.desired_effects > available_pool:
        raise ValueError('desired_effects cannot exceed eligible effect pool after locks')

    open_slots = query.slots_unlocked - query.locks
    rarity_probability = cumulative_rarity_probability(query.module_rarity, query.target_rarity_floor)
    if rarity_probability <= 0.0:
        raise ValueError('Target rarity floor is unattainable for the current module rarity')

    per_open_slot_success = (query.desired_effects / available_pool) * rarity_probability
    if per_open_slot_success <= 0.0 or per_open_slot_success >= 1.0:
        # Keep fail-closed rather than silently clipping impossible parameters.
        raise ValueError('per_open_slot_success_probability must lie strictly between 0 and 1')
    per_reroll_success = 1.0 - (1.0 - per_open_slot_success) ** open_slots

    shard_cost = reroll_shard_cost(query.locks, query.reroll_discount)
    rolls_needed = _rolls_needed_for_confidence(per_reroll_success, query.confidence)
    p50_rolls = _rolls_needed_for_confidence(per_reroll_success, 0.5)
    p95_rolls = _rolls_needed_for_confidence(per_reroll_success, 0.95)
    return ModuleRerollResult(
        eligible_effects=eligible,
        open_slots=open_slots,
        target_rarity_probability=rarity_probability,
        per_open_slot_success_probability=per_open_slot_success,
        per_reroll_success_probability=per_reroll_success,
        rolls_needed=rolls_needed,
        reroll_shards_needed=rolls_needed * shard_cost,
        p50_rolls=p50_rolls,
        p50_reroll_shards=p50_rolls * shard_cost,
        p95_rolls=p95_rolls,
        p95_reroll_shards=p95_rolls * shard_cost,
        budget_status=_budget_status(query.current_budget, p50_rolls * shard_cost, p95_rolls * shard_cost),
    )

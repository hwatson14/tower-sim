from __future__ import annotations

import csv
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MODULE_LEVEL_COSTS_PATH = ROOT / 'kb' / 'modules' / 'tables' / 'module-level-costs.csv'


@dataclass(frozen=True)
class ModuleLevelCostRow:
    level: int
    shard_cost: int
    cumulative_shards: int
    coin_cost: int
    cumulative_coins: int


@dataclass(frozen=True)
class ModuleUpgradeSummary:
    current_level: int
    target_level: int
    levels_gained: int
    shard_cost: int
    coin_cost: int
    current_cumulative_shards: int
    target_cumulative_shards: int
    current_cumulative_coins: int
    target_cumulative_coins: int


@lru_cache(maxsize=1)
def load_module_level_cost_rows() -> dict[int, ModuleLevelCostRow]:
    rows: dict[int, ModuleLevelCostRow] = {}
    with MODULE_LEVEL_COSTS_PATH.open(newline='') as handle:
        for raw in csv.DictReader(handle):
            row = ModuleLevelCostRow(
                level=int(raw['level']),
                shard_cost=int(raw['shard_cost']),
                cumulative_shards=int(raw['cumulative_shards']),
                coin_cost=int(raw['coin_cost']),
                cumulative_coins=int(raw['cumulative_coins']),
            )
            rows[row.level] = row
    if not rows:
        raise ValueError('Module level costs table is empty')
    return rows


def module_level_cap() -> int:
    return max(load_module_level_cost_rows())


def get_module_level_cost_row(level: int) -> ModuleLevelCostRow:
    rows = load_module_level_cost_rows()
    if level not in rows:
        raise ValueError(f'Unsupported module level: {level}')
    return rows[level]


def cumulative_shards_to_level(level: int) -> int:
    return get_module_level_cost_row(level).cumulative_shards


def cumulative_coins_to_level(level: int) -> int:
    return get_module_level_cost_row(level).cumulative_coins


def summarize_module_upgrade(current_level: int, target_level: int) -> ModuleUpgradeSummary:
    if current_level <= 0 or target_level <= 0:
        raise ValueError('Module levels must be positive integers')
    if target_level < current_level:
        raise ValueError('target_level must be greater than or equal to current_level')
    current = get_module_level_cost_row(current_level)
    target = get_module_level_cost_row(target_level)
    return ModuleUpgradeSummary(
        current_level=current_level,
        target_level=target_level,
        levels_gained=target_level - current_level,
        shard_cost=target.cumulative_shards - current.cumulative_shards,
        coin_cost=target.cumulative_coins - current.cumulative_coins,
        current_cumulative_shards=current.cumulative_shards,
        target_cumulative_shards=target.cumulative_shards,
        current_cumulative_coins=current.cumulative_coins,
        target_cumulative_coins=target.cumulative_coins,
    )

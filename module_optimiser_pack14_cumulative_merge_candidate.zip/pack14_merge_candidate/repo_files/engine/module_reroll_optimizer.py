from __future__ import annotations

import csv
from dataclasses import asdict, dataclass
from functools import lru_cache
from pathlib import Path
from typing import Any

from engine.module_level_optimizer import _baseline_score, _resolve_preset_from_scenario
from engine.module_overlay import score_module_overlay
from engine.module_reroll import (
    ModuleRerollQuery,
    RARITY_ORDER,
    eligible_effect_count,
    evaluate_reroll_query,
)
from models.account_state import AccountState
from models.module_optimizer_queries import ModuleRerollOptimizeQuery
from models.module_overlay import ModuleOverlayRequest, ModuleSnapshotOverlay, ModuleSubstatOverlay

KB = Path(__file__).resolve().parents[1] / 'kb'
MODULE_SUBSTATS_TABLE_PATH = KB / 'modules' / 'tables' / 'module-substats.csv'
RARITY_LABELS = {'epic': 'Epic', 'legendary': 'Legendary', 'mythic': 'Mythic', 'ancestral': 'Ancestral'}


@dataclass(frozen=True)
class ModuleRerollCandidate:
    action_id: str
    slot_type: str
    module_name: str
    target_rarity_floor: str
    locks: int
    open_slots: int
    desired_effects: int
    baseline_score: float
    estimated_score_after: float
    objective_delta_ratio: float
    reroll_shards_needed: int
    p50_reroll_shards: int
    p95_reroll_shards: int
    per_reroll_success_probability: float
    value_per_shard: float
    budget_status: str | None
    within_frontier: bool
    improved_substats: list[dict[str, Any]]
    notes: list[str]


@dataclass(frozen=True)
class ModuleRerollOptimizeResult:
    slot_type: str
    preset_name: str
    objective_family: str
    frontier_ratio: float
    baseline_score: float
    best_value_per_shard: float
    best_action_id: str | None
    best_budget_status: str | None
    candidates: list[dict[str, Any]]
    limitations: list[str]


@lru_cache(maxsize=1)
def _load_module_substat_values() -> dict[tuple[str, str, str], tuple[float, str]]:
    out: dict[tuple[str, str, str], tuple[float, str]] = {}
    with MODULE_SUBSTATS_TABLE_PATH.open(newline='', encoding='utf-8') as handle:
        reader = csv.DictReader(handle)
        for row in reader:
            slot = str(row.get('slot', '')).strip().lower()
            substat = str(row.get('substat', '')).strip()
            rarity = str(row.get('rarity', '')).strip()
            value_text = str(row.get('value', '')).strip()
            unit = str(row.get('unit', '')).strip().lower()
            if not slot or not substat or not rarity or not value_text:
                continue
            try:
                value = float(value_text)
            except ValueError:
                continue
            out[(slot, substat, rarity)] = (value, unit)
    return out


def _format_substat_display(value: float, unit: str) -> str:
    if unit == 'percent':
        return f'{value:g}%'
    if unit == 'multiplier':
        return f'{value:g}x'
    if unit in {'seconds', 'second'}:
        return f'{value:g}s'
    if unit in {'meters', 'meter', 'm'}:
        return f'{value:g}m'
    return f'{value:g}'


def _resolve_target_substat_value(slot_type: str, substat_name: str, rarity_floor: str) -> str | None:
    row = _load_module_substat_values().get((slot_type.lower(), substat_name, RARITY_LABELS[rarity_floor]))
    if row is None:
        return None
    return _format_substat_display(row[0], row[1])


def _resolve_selected_module(account_state: AccountState, preset_name: str, slot_type: str, module_name: str | None) -> str:
    if module_name:
        if module_name not in account_state.modules_inventory:
            raise ValueError(f'Unknown module_name: {module_name}')
        return module_name
    selection = account_state.module_presets.get(preset_name, {}).get(slot_type)
    if selection is None or not selection.primary:
        raise ValueError(f'No primary module selected for preset={preset_name} slot_type={slot_type}')
    return selection.primary


def _candidate_rarity_floors(module_rarity: str) -> list[str]:
    key = module_rarity.strip().lower()
    ordered = ['epic', 'legendary', 'mythic', 'ancestral']
    return [rarity for rarity in ordered if RARITY_ORDER[rarity] <= RARITY_ORDER.get(key, 0)]


def _desired_effects_for_candidate(slot_type: str, rarity_floor: str, locks: int, banned_effects: int) -> int:
    eligible = eligible_effect_count(slot_type, rarity_floor, banned_effects)
    available_pool = eligible - locks
    desired = max(2, round(eligible * 0.45))
    return min(desired, available_pool)


def _score_substat_upgrade(account_state: AccountState, preset_name: str, objective_family: str, module_name: str, index: int, target_value: str) -> float:
    _, objective = score_module_overlay(
        account_state,
        ModuleOverlayRequest(
            preset_name=preset_name,
            module_overlays=(
                ModuleSnapshotOverlay(
                    module_name=module_name,
                    substats=(ModuleSubstatOverlay(index=index, value=target_value),),
                ),
            ),
        ),
        preset_name=preset_name,
        state_mode='start_of_run',
        perks_enabled=(preset_name != 'Tourney'),
        objective_family=objective_family,
    )
    return float(objective['score'])


def _select_indices_to_reroll(account_state: AccountState, preset_name: str, objective_family: str, slot_type: str, module_name: str, rarity_floor: str, open_slots: int, baseline_score: float) -> tuple[list[int], list[dict[str, Any]], float]:
    snapshot = account_state.modules_inventory[module_name]
    chosen: list[tuple[int, str]] = []
    for index, sub in enumerate(snapshot.substats):
        target_value = _resolve_target_substat_value(slot_type, sub.name, rarity_floor)
        if target_value is None:
            continue
        chosen.append((index, target_value))
        if len(chosen) >= open_slots:
            break
    if not chosen:
        return [], [], baseline_score
    overlays = tuple(
        ModuleSubstatOverlay(index=index, value=target_value)
        for index, target_value in chosen
    )
    _, objective = score_module_overlay(
        account_state,
        ModuleOverlayRequest(
            preset_name=preset_name,
            module_overlays=(ModuleSnapshotOverlay(module_name=module_name, substats=overlays),),
        ),
        preset_name=preset_name,
        state_mode='start_of_run',
        perks_enabled=(preset_name != 'Tourney'),
        objective_family=objective_family,
    )
    combined_delta_ratio = 0.0 if baseline_score == 0 else max(float(objective['score']) - baseline_score, 0.0) / baseline_score
    per_slot_ratio = combined_delta_ratio / max(len(chosen), 1)
    improved_substats = [
        {
            'index': index,
            'name': snapshot.substats[index].name,
            'target_value': target_value,
            'individual_delta_ratio': per_slot_ratio,
        }
        for index, target_value in chosen
    ]
    return [index for index, _ in chosen], improved_substats, float(objective['score'])


def optimize_module_reroll(account_state: AccountState, query: ModuleRerollOptimizeQuery) -> ModuleRerollOptimizeResult:
    preset_name = _resolve_preset_from_scenario(query.scenario_id)
    module_name = _resolve_selected_module(account_state, preset_name, query.slot_type, query.module_name)
    snapshot = account_state.modules_inventory[module_name]
    module_rarity = str(snapshot.rarity or '').strip().lower()
    if module_rarity not in RARITY_ORDER:
        raise ValueError(f'Unsupported module rarity for reroll optimizer: {snapshot.rarity}')
    baseline_score = _baseline_score(account_state, preset_name, query.objective_family)
    slots_unlocked = query.slots_unlocked_override or len(snapshot.substats)
    if slots_unlocked < 2:
        raise ValueError('Reroll optimizer requires at least 2 unlocked substat slots for combined-state optimization.')

    frontier_ratio = 0.95
    candidates: list[ModuleRerollCandidate] = []
    limitations = [
        'First-pass reroll optimizer scores hypothetical upgrades of current visible substats, not full effect-identity search across the whole pool.',
        'Combined-state reroll thresholds are mechanics-backed; objective gains are conservative because they are anchored to current visible substats only.',
    ]

    max_locks = min(query.max_locks_considered, max(0, slots_unlocked - 2))
    for rarity_floor in _candidate_rarity_floors(module_rarity):
        for locks in range(0, max_locks + 1):
            open_slots = slots_unlocked - locks
            desired_effects = _desired_effects_for_candidate(query.slot_type, rarity_floor, locks, query.banned_effects)
            reroll_result = evaluate_reroll_query(
                ModuleRerollQuery(
                    slot_type=query.slot_type,
                    module_rarity=module_rarity,
                    target_rarity_floor=rarity_floor,
                    slots_unlocked=slots_unlocked,
                    locks=locks,
                    desired_effects=desired_effects,
                    banned_effects=query.banned_effects,
                    confidence=query.confidence,
                    reroll_discount=query.reroll_discount,
                    current_budget=query.current_budget,
                )
            )
            _indices, improved_substats, score_after = _select_indices_to_reroll(
                account_state,
                preset_name,
                query.objective_family,
                query.slot_type,
                module_name,
                rarity_floor,
                open_slots,
                baseline_score,
            )
            objective_delta_ratio = 0.0 if baseline_score == 0 else max(score_after - baseline_score, 0.0) / baseline_score
            value_per_shard = 0.0 if reroll_result.reroll_shards_needed <= 0 else (objective_delta_ratio * reroll_result.per_reroll_success_probability) / reroll_result.reroll_shards_needed
            notes = []
            if locks == 0:
                notes.append('Large reroll candidate: full combined-state reroll with no locked lines.')
            elif open_slots >= 2:
                notes.append('Combined-state reroll candidate: multiple open lines retained to preserve bundle EV.')
            candidates.append(
                ModuleRerollCandidate(
                    action_id=f'{module_name}:{rarity_floor}:locks_{locks}',
                    slot_type=query.slot_type,
                    module_name=module_name,
                    target_rarity_floor=rarity_floor,
                    locks=locks,
                    open_slots=open_slots,
                    desired_effects=desired_effects,
                    baseline_score=baseline_score,
                    estimated_score_after=score_after,
                    objective_delta_ratio=objective_delta_ratio,
                    reroll_shards_needed=reroll_result.reroll_shards_needed,
                    p50_reroll_shards=reroll_result.p50_reroll_shards,
                    p95_reroll_shards=reroll_result.p95_reroll_shards,
                    per_reroll_success_probability=reroll_result.per_reroll_success_probability,
                    value_per_shard=value_per_shard,
                    budget_status=reroll_result.budget_status,
                    within_frontier=False,
                    improved_substats=improved_substats,
                    notes=notes,
                )
            )

    if not candidates:
        return ModuleRerollOptimizeResult(
            slot_type=query.slot_type,
            preset_name=preset_name,
            objective_family=query.objective_family,
            frontier_ratio=frontier_ratio,
            baseline_score=baseline_score,
            best_value_per_shard=0.0,
            best_action_id=None,
            best_budget_status=None,
            candidates=[],
            limitations=limitations,
        )

    best_value = max(candidate.value_per_shard for candidate in candidates)
    best_action_id = None
    best_budget_status = None
    rendered: list[dict[str, Any]] = []
    for candidate in candidates:
        within_frontier = True if best_value <= 0 else (candidate.value_per_shard / best_value) >= frontier_ratio
        payload = asdict(candidate)
        payload['within_frontier'] = within_frontier
        rendered.append(payload)
        if within_frontier and (best_action_id is None or candidate.value_per_shard > next(c.value_per_shard for c in candidates if c.action_id == best_action_id)):
            best_action_id = candidate.action_id
            best_budget_status = candidate.budget_status

    rendered.sort(key=lambda row: row['value_per_shard'], reverse=True)
    return ModuleRerollOptimizeResult(
        slot_type=query.slot_type,
        preset_name=preset_name,
        objective_family=query.objective_family,
        frontier_ratio=frontier_ratio,
        baseline_score=baseline_score,
        best_value_per_shard=best_value,
        best_action_id=best_action_id,
        best_budget_status=best_budget_status,
        candidates=rendered,
        limitations=limitations,
    )

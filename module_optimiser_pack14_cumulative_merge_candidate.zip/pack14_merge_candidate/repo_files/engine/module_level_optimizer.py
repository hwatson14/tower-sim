from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any

from compilers.stat_input_compiler import _module_main_effect_multiplier, compile_stat_inputs
from engine.module_overlay import score_module_overlay
from engine.stat_engine import resolve_stats
from models.account_state import AccountState
from models.module_optimizer_queries import ModuleLevelOptimizeQuery
from models.module_overlay import ModuleOverlayRequest, ModuleSnapshotOverlay
from optimizer.scorer import compute_optimizer_scores

SCENARIO_PRESET_MAP = {
    'farm': 'Farming',
    'farming': 'Farming',
    'tournament': 'Tourney',
    'tourney': 'Tourney',
    'tourney': 'Tourney',
    'milestone': 'Milestone',
}


@dataclass(frozen=True)
class ModuleLevelCandidate:
    action_id: str
    slot_type: str
    module_name: str
    role: str
    current_level: int
    target_level: int
    shard_cost: int
    coin_cost: int
    score_before: float
    score_after: float
    delta_ratio: float
    within_frontier: bool
    notes: list[str]


@dataclass(frozen=True)
class ModuleLevelOptimizeResult:
    slot_type: str
    preset_name: str
    objective_family: str
    frontier_ratio: float
    baseline_score: float
    best_score: float
    best_action_id: str | None
    best_delta_ratio: float
    candidates: list[dict[str, Any]]
    limitations: list[str]


def _resolve_preset_from_scenario(scenario_id: str) -> str:
    key = scenario_id.strip().lower()
    for needle, preset in SCENARIO_PRESET_MAP.items():
        if needle in key:
            return preset
    raise ValueError(f'Unsupported scenario_id for module level optimizer: {scenario_id}')


def _baseline_score(account_state: AccountState, preset_name: str, objective_family: str) -> float:
    stat_inputs = compile_stat_inputs(
        account_state,
        preset_name=preset_name,
        module_preset_name=preset_name,
        card_preset_name=preset_name,
        perk_preset_name=preset_name,
        state_mode='start_of_run',
        perks_enabled=(preset_name != 'Tourney'),
    )
    statbook = resolve_stats(stat_inputs)
    return float(compute_optimizer_scores(statbook.to_dict())['objectives'][objective_family]['score'])


def _current_selection(account_state: AccountState, preset_name: str, slot_type: str):
    selection = account_state.module_presets.get(preset_name, {}).get(slot_type)
    if selection is None:
        raise ValueError(f'No module preset selection for preset={preset_name} slot_type={slot_type}')
    return selection


def _candidate_for_module(account_state: AccountState, preset_name: str, slot_type: str, objective_family: str, role: str, module_name: str, baseline_score: float, frontier_ratio: float) -> ModuleLevelCandidate:
    snapshot = account_state.modules_inventory.get(module_name)
    if snapshot is None or snapshot.level is None:
        raise ValueError(f'Unknown or unlevelled module: {module_name}')
    current_level = int(snapshot.level)
    target_level = current_level + 1
    next_stat = _module_main_effect_multiplier(slot_type, snapshot.rarity, target_level)
    notes = []
    if role == 'assist':
        notes.append('Assist candidate evaluated through current canonical compiler path; assist module level may not fully propagate beyond stat token overlay.')
    overlay = ModuleOverlayRequest(
        preset_name=preset_name,
        module_overlays=(
            ModuleSnapshotOverlay(module_name=module_name, level=target_level, stat=str(next_stat) if next_stat is not None else snapshot.stat),
        ),
    )
    _, objective = score_module_overlay(
        account_state,
        overlay,
        preset_name=preset_name,
        state_mode='start_of_run',
        perks_enabled=(preset_name != 'Tourney'),
        objective_family=objective_family,
    )
    score_after = float(objective['score'])
    delta_ratio = 0.0 if baseline_score == 0 else (score_after / baseline_score) - 1.0
    from engine.module_economics import summarize_module_upgrade
    summary = summarize_module_upgrade(current_level, target_level)
    return ModuleLevelCandidate(
        action_id=f'{role}_level_plus_one',
        slot_type=slot_type,
        module_name=module_name,
        role=role,
        current_level=current_level,
        target_level=target_level,
        shard_cost=summary.shard_cost,
        coin_cost=summary.coin_cost,
        score_before=baseline_score,
        score_after=score_after,
        delta_ratio=delta_ratio,
        within_frontier=False,
        notes=notes,
    )


def optimize_module_level(account_state: AccountState, query: ModuleLevelOptimizeQuery) -> ModuleLevelOptimizeResult:
    preset_name = _resolve_preset_from_scenario(query.scenario_id)
    baseline_score = _baseline_score(account_state, preset_name, query.objective_family)
    selection = _current_selection(account_state, preset_name, query.slot_type)
    frontier_ratio = 0.98
    candidates: list[ModuleLevelCandidate] = []
    limitations: list[str] = []

    if selection.primary:
        candidates.append(_candidate_for_module(account_state, preset_name, query.slot_type, query.objective_family, 'primary', selection.primary, baseline_score, frontier_ratio))
    else:
        limitations.append('No primary module selected for slot.')
    if selection.assist:
        candidates.append(_candidate_for_module(account_state, preset_name, query.slot_type, query.objective_family, 'assist', selection.assist, baseline_score, frontier_ratio))
    else:
        limitations.append('No assist module selected for slot.')

    if not candidates:
        return ModuleLevelOptimizeResult(
            slot_type=query.slot_type,
            preset_name=preset_name,
            objective_family=query.objective_family,
            frontier_ratio=frontier_ratio,
            baseline_score=baseline_score,
            best_score=baseline_score,
            best_action_id=None,
            best_delta_ratio=0.0,
            candidates=[],
            limitations=limitations,
        )

    best_score = max(c.score_after for c in candidates)
    scored: list[dict[str, Any]] = []
    best_action_id = None
    best_delta = float('-inf')
    for candidate in candidates:
        within_frontier = False if best_score == 0 else (candidate.score_after / best_score) >= frontier_ratio
        payload = asdict(candidate)
        payload['within_frontier'] = within_frontier
        scored.append(payload)
        if within_frontier and candidate.delta_ratio > best_delta:
            best_delta = candidate.delta_ratio
            best_action_id = candidate.action_id
    if best_delta == float('-inf'):
        best_delta = max(c.delta_ratio for c in candidates)
        best_action_id = max(candidates, key=lambda c: c.delta_ratio).action_id
    return ModuleLevelOptimizeResult(
        slot_type=query.slot_type,
        preset_name=preset_name,
        objective_family=query.objective_family,
        frontier_ratio=frontier_ratio,
        baseline_score=baseline_score,
        best_score=best_score,
        best_action_id=best_action_id,
        best_delta_ratio=best_delta,
        candidates=scored,
        limitations=limitations,
    )

from __future__ import annotations

import copy
from dataclasses import replace
from typing import Optional

from compilers.stat_input_compiler import compile_stat_inputs
from engine.stat_engine import resolve_stats
from models.account_state import AccountState, ModuleSnapshot, ModuleSubstat
from models.module_overlay import (
    ModuleOverlayRequest,
    ModulePresetSlotOverlay,
    ModuleSnapshotOverlay,
    ModuleSystemSlotOverlay,
)
from optimizer.scorer import compute_optimizer_scores

_ALLOWED_OBJECTIVES = {'ehp', 'edamage', 'eecon'}


def apply_module_overlay(account_state: AccountState, overlay: ModuleOverlayRequest) -> AccountState:
    patched: AccountState = copy.deepcopy(account_state)
    preset_name = overlay.preset_name or patched.active_module_preset

    for mod_overlay in overlay.module_overlays:
        _apply_module_snapshot_overlay(patched, mod_overlay)
    for preset_overlay in overlay.preset_slot_overlays:
        _apply_module_preset_overlay(patched, preset_name, preset_overlay)
    for system_overlay in overlay.system_slot_overlays:
        _apply_module_system_overlay(patched, system_overlay)
    return patched


def score_module_overlay(
    account_state: AccountState,
    overlay: ModuleOverlayRequest,
    *,
    preset_name: Optional[str] = None,
    state_mode: str = 'start_of_run',
    perks_enabled: Optional[bool] = None,
    objective_family: Optional[str] = None,
):
    patched = apply_module_overlay(account_state, overlay)
    resolved_preset = preset_name or overlay.preset_name or patched.active_module_preset
    stat_inputs = compile_stat_inputs(
        patched,
        preset_name=resolved_preset,
        module_preset_name=resolved_preset,
        card_preset_name=resolved_preset,
        perk_preset_name=resolved_preset,
        state_mode=state_mode,
        perks_enabled=perks_enabled,
    )
    statbook = resolve_stats(stat_inputs)
    objective_scores = compute_optimizer_scores(statbook.to_dict())
    if objective_family is not None:
        if objective_family not in _ALLOWED_OBJECTIVES:
            raise ValueError(f'Unsupported objective_family: {objective_family}')
        return statbook, objective_scores['objectives'][objective_family]
    return statbook, objective_scores



def _apply_module_snapshot_overlay(account_state: AccountState, overlay: ModuleSnapshotOverlay) -> None:
    current = account_state.modules_inventory.get(overlay.module_name)
    if current is None:
        raise ValueError(f'Unknown module_name: {overlay.module_name}')
    new_substats = list(current.substats)
    for sub_overlay in overlay.substats:
        if sub_overlay.index < 0 or sub_overlay.index >= len(new_substats):
            raise ValueError(f'Substat index out of range for {overlay.module_name}: {sub_overlay.index}')
        current_sub = new_substats[sub_overlay.index]
        new_substats[sub_overlay.index] = ModuleSubstat(
            name=sub_overlay.name if sub_overlay.name is not None else current_sub.name,
            value=sub_overlay.value if sub_overlay.value is not None else current_sub.value,
            raw_token=sub_overlay.raw_token if sub_overlay.raw_token is not None else current_sub.raw_token,
        )
    account_state.modules_inventory[overlay.module_name] = ModuleSnapshot(
        name=current.name,
        slot_type=current.slot_type,
        rarity=overlay.rarity if overlay.rarity is not None else current.rarity,
        level=overlay.level if overlay.level is not None else current.level,
        stat=overlay.stat if overlay.stat is not None else current.stat,
        substats=new_substats,
    )



def _apply_module_preset_overlay(account_state: AccountState, preset_name: str, overlay: ModulePresetSlotOverlay) -> None:
    preset_map = dict(account_state.module_presets.get(preset_name, {}))
    current = preset_map.get(overlay.slot_type)
    if current is None:
        raise ValueError(f'Unknown slot_type in preset overlay: {overlay.slot_type}')
    preset_map[overlay.slot_type] = replace(
        current,
        primary=overlay.primary if overlay.primary is not None else current.primary,
        assist=overlay.assist if overlay.assist is not None else current.assist,
    )
    account_state.module_presets[preset_name] = preset_map



def _apply_module_system_overlay(account_state: AccountState, overlay: ModuleSystemSlotOverlay) -> None:
    current = account_state.module_system_state.get(overlay.slot_type)
    if current is None:
        raise ValueError(f'Unknown slot_type in system overlay: {overlay.slot_type}')
    account_state.module_system_state[overlay.slot_type] = replace(
        current,
        assist_level=overlay.assist_level if overlay.assist_level is not None else current.assist_level,
        assist_unlocked=overlay.assist_unlocked if overlay.assist_unlocked is not None else current.assist_unlocked,
        rarity_cap=overlay.rarity_cap if overlay.rarity_cap is not None else current.rarity_cap,
        multiplier_cap=overlay.multiplier_cap if overlay.multiplier_cap is not None else current.multiplier_cap,
        substat_cap=overlay.substat_cap if overlay.substat_cap is not None else current.substat_cap,
    )

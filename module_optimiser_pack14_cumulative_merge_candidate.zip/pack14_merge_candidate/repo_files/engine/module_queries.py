from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any

from engine.module_economics import summarize_module_upgrade
from engine.module_reroll import ModuleRerollQuery, evaluate_reroll_query
from models.account_state import AccountState
from engine.module_level_optimizer import optimize_module_level
from engine.module_reroll_optimizer import optimize_module_reroll
from models.module_optimizer_queries import ModuleLevelOptimizeQuery, ModuleRerollCostQuery, ModuleRerollOptimizeQuery, ModuleTotalShardsQuery


@dataclass(frozen=True)
class ModuleQueryEnvelope:
    query_family: str
    scenario_id: str
    objective_family: str
    provenance: dict[str, Any]
    verification: dict[str, Any]
    assumptions_used: list[str]
    frontier_mode: str
    result: dict[str, Any]


def _resolve_module_level(account_state: AccountState, module_name: str) -> int:
    try:
        snapshot = account_state.modules_inventory[module_name]
    except KeyError as exc:
        raise ValueError(f'Unknown module_name: {module_name}') from exc
    if snapshot.level is None:
        raise ValueError(f'Module level is missing for {module_name}')
    return int(snapshot.level)


def query_module_total_shards(account_state: AccountState, query: ModuleTotalShardsQuery) -> ModuleQueryEnvelope:
    current_level = _resolve_module_level(account_state, query.module_name)
    summary = summarize_module_upgrade(current_level, query.target_level)
    return ModuleQueryEnvelope(
        query_family='module_total_shards',
        scenario_id=query.scenario_id,
        objective_family=query.objective_family,
        provenance={
            'module_name': query.module_name,
            'source_table': 'kb/modules/tables/module-level-costs.csv',
            'current_level_source': 'account_state.modules_inventory',
        },
        verification={
            'status': 'verified_deterministic',
            'checks': [
                'target_cumulative - current_cumulative = delta',
                'module_name resolved from canonical account state',
            ],
        },
        assumptions_used=[
            'Module level economics are deterministic and workbook-ported into repo canon.',
            'Current module level is taken from canonical account state inventory.',
        ],
        frontier_mode='not_applicable',
        result=asdict(summary),
    )


def query_module_reroll_cost(query: ModuleRerollCostQuery) -> ModuleQueryEnvelope:
    result = evaluate_reroll_query(
        ModuleRerollQuery(
            slot_type=query.slot_type, module_rarity=query.module_rarity,
            target_rarity_floor=query.target_rarity_floor, slots_unlocked=query.slots_unlocked,
            locks=query.locks, desired_effects=query.desired_effects,
            banned_effects=query.banned_effects, confidence=query.confidence,
            reroll_discount=query.reroll_discount, current_budget=query.current_budget,
        )
    )
    return ModuleQueryEnvelope(
        query_family='module_reroll_cost',
        scenario_id=query.scenario_id,
        objective_family=query.objective_family,
        provenance={
            'source_engine': 'engine.module_reroll.evaluate_reroll_query',
            'reference_oracle': 'Modules workbook / Reroll Calculator v3',
        },
        verification={
            'status': 'verified_mechanics_foundation',
            'checks': [
                'lock cost schedule matches workbook anchors',
                'rarity floor probabilities match workbook anchors',
                'budget status uses p50/p95 threshold scaffolding',
            ],
        },
        assumptions_used=[
            'Reroll is modeled as a combined-state action, not slot-by-slot improvement.',
            'Threshold advice is scaffolded with p50 and p95 cost bands.',
        ],
        frontier_mode='acceptable_frontier_reserved_for_optimizer',
        result=asdict(result),
    )



def query_module_level_optimize(account_state: AccountState, query: ModuleLevelOptimizeQuery) -> ModuleQueryEnvelope:
    result = optimize_module_level(account_state, query)
    return ModuleQueryEnvelope(
        query_family='module_level_optimize',
        scenario_id=query.scenario_id,
        objective_family=query.objective_family,
        provenance={
            'source_engine': 'engine.module_level_optimizer.optimize_module_level',
            'score_path': 'overlay -> compile_stat_inputs -> resolve_stats -> optimizer.scorer',
            'current_state_source': 'canonical account state + active preset mapping',
        },
        verification={
            'status': 'verified_optimizer_foundation',
            'checks': [
                'baseline score computed through existing scorer',
                'candidate mutations are applied via non-mutating overlay',
                'frontier filter uses 98% single-step threshold',
            ],
        },
        assumptions_used=[
            'Scenario id is resolved onto an existing repo preset name.',
            'Primary and assist candidate scoring flows through canonical compiler and scorer paths.',
            'This tranche evaluates single-step module level candidates only.',
        ],
        frontier_mode='single_step_98pct',
        result=asdict(result),
    )



def query_module_reroll_optimize(account_state: AccountState, query: ModuleRerollOptimizeQuery) -> ModuleQueryEnvelope:
    result = optimize_module_reroll(account_state, query)
    return ModuleQueryEnvelope(
        query_family='module_reroll_optimize',
        scenario_id=query.scenario_id,
        objective_family=query.objective_family,
        provenance={
            'source_engine': 'engine.module_reroll_optimizer.optimize_module_reroll',
            'score_path': 'overlay -> compile_stat_inputs -> resolve_stats -> optimizer.scorer',
            'mechanics_path': 'engine.module_reroll.evaluate_reroll_query',
            'current_state_source': 'canonical account state + active preset mapping',
        },
        verification={
            'status': 'verified_optimizer_foundation',
            'checks': [
                'candidate thresholds use combined-state reroll mechanics',
                'objective deltas use non-mutating overlay scoring',
                'frontier filter uses 95% reroll value-per-shard threshold',
            ],
        },
        assumptions_used=[
            'Reroll optimisation is combined-state, not slot-by-slot.',
            'First-pass value scoring upgrades current visible substats rather than searching the full effect identity pool.',
            'Threshold advice uses p50/p95 mechanics bands from the reroll foundation.',
        ],
        frontier_mode='reroll_95pct_value_per_shard',
        result=asdict(result),
    )

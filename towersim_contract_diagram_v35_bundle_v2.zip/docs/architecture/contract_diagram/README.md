# TowerSim Architecture Contract Diagram (Target State)

This folder contains the **target-state** contract diagram for TowerSim's canonical pipeline.

## Files

- `towersim_architecture_target_state_contract_v35.png`  
  Rendered contract diagram (v35). This is the single reference for stage boundaries and invariants.

- `generate_v35.py`  
  Deterministic matplotlib generator that reproduces the diagram.

## Regenerate

From repo root:

```bash
python docs/architecture/contract_diagram/generate_v35.py
```

Custom output path:

```bash
python docs/architecture/contract_diagram/generate_v35.py --out /tmp/diagram.png
```

## Contract invariants encoded

- `ResolvedRuleset` is immutable and static for the entire run (tier → BC → heat; no wave-index logic).
- Strict loader boundary: engines consume typed tables only; no direct CSV/YAML reads in engines/evaluators.
- Stat Registry is authoritative: no stat ID creation/renaming outside registry.
- AtWave is constrained: deterministic transforms only; registry IDs only; cannot create/rename stats; no table loads.
- Evaluators are pure: artifacts in → metrics out; no forward simulation; no table loads.
- CI gates (intended): ruleset immutability hash; loader boundary check; artifact byte-diff determinism.

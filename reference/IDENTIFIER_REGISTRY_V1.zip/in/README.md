# Audit Fix: eHP normalization

Fix applied: strip '$' from absolute refs (e.g., $AC$21) before mapping to stat_keys.


"""
Combat Engine (Data-Driven, Fail-Closed)

Implements the execution model for combat resolution WITHOUT hardcoding game numbers.
All mechanics (DR, PC, Thorns, Orbs/Electrons, Boss modifiers) are parameterized and
loaded from data tables. Missing parameters MUST raise errors.

Sources to populate tables (not embedded here):
- Effective Paths
- The Tower Wiki

Do NOT invent numbers. Populate data tables explicitly.
"""

from dataclasses import dataclass
from typing import Dict, Any

class CombatDataError(RuntimeError):
    pass

@dataclass
class CombatContext:
    wave: int
    enemy_hp: float
    enemy_attack: float
    is_boss: bool
    stats: Dict[str, float]
    params: Dict[str, Any]

def require(params: Dict[str, Any], *keys):
    for k in keys:
        if k not in params:
            raise CombatDataError(f"Missing combat parameter: {k}")

def apply_damage_reduction(dmg: float, dr_frac: float) -> float:
    if not (0.0 <= dr_frac <= 1.0):
        raise CombatDataError(f"Invalid DR fraction: {dr_frac}")
    return dmg * (1.0 - dr_frac)

def thorns_damage(enemy_hp: float, thorns_frac: float) -> float:
    if not (0.0 <= thorns_frac <= 1.0):
        raise CombatDataError(f"Invalid thorns fraction: {thorns_frac}")
    return enemy_hp * thorns_frac

def percent_current_damage(enemy_hp: float, pc_frac: float, boss_mult: float) -> float:
    if pc_frac < 0:
        raise CombatDataError("PC fraction must be >= 0")
    return enemy_hp * pc_frac * boss_mult

def resolve_combat(ctx: CombatContext) -> Dict[str, float]:
    p = ctx.params
    require(p,
        "tower_dr_frac",
        "enemy_attack_mult",
        "thorns_frac",
        "pc_frac",
        "pc_boss_mult"
    )

    enemy_attack = ctx.enemy_attack * p["enemy_attack_mult"]
    tower_damage = apply_damage_reduction(enemy_attack, p["tower_dr_frac"])

    dmg = 0.0
    dmg += thorns_damage(ctx.enemy_hp, p["thorns_frac"])
    dmg += percent_current_damage(
        ctx.enemy_hp,
        p["pc_frac"],
        p["pc_boss_mult"] if ctx.is_boss else 1.0
    )

    remaining_hp = max(0.0, ctx.enemy_hp - dmg)

    return {
        "remaining_enemy_hp": remaining_hp,
        "tower_damage_taken": tower_damage
    }

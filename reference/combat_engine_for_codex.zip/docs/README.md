
Combat Engine Package (Upload to Codex)

This package provides a fail-closed, data-driven combat engine.
No mechanics numbers are hardcoded.

Populate parameters from Effective Paths and The Tower Wiki.

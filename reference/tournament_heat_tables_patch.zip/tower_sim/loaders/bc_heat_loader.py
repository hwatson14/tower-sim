from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import csv
from typing import Dict, Iterable, List


class HeatDataError(RuntimeError):
    pass


@dataclass(frozen=True)
class HeatWaveScalar:
    league: str
    wave: int
    scalar: float


@dataclass(frozen=True)
class BCWaveMagnitude:
    bc_id: str
    league: str
    wave: int
    magnitude: float


@dataclass(frozen=True)
class HeatBundle:
    heat_scalars: List[HeatWaveScalar]
    magnitudes: List[BCWaveMagnitude]
    provenance: str


def load_heat_bundle(heat_path: Path, magnitudes_path: Path) -> HeatBundle:
    heat_scalars = _load_heat_scalars(heat_path)
    magnitudes = _load_bc_magnitudes(magnitudes_path)
    return HeatBundle(
        heat_scalars=heat_scalars,
        magnitudes=magnitudes,
        provenance="reference/step1_dump_docs/part2_data/README_HEAT.md",
    )


def _load_heat_scalars(path: Path) -> List[HeatWaveScalar]:
    if not path.exists():
        raise HeatDataError(f"Heat table missing: {path}")
    with path.open(newline="") as handle:
        reader = csv.DictReader(handle)
        _require_columns(reader.fieldnames, {"league", "wave", "heat_scalar"}, path)
        rows: List[HeatWaveScalar] = []
        for idx, row in enumerate(reader, start=2):
            try:
                league = _require_field(row, "league", path)
                wave = int(_require_field(row, "wave", path))
                scalar = float(_require_field(row, "heat_scalar", path))
            except (ValueError, HeatDataError) as exc:
                raise HeatDataError(
                    f"Invalid heat row at line {idx}: {row}"
                ) from exc
            rows.append(HeatWaveScalar(league=league, wave=wave, scalar=scalar))
    if not rows:
        raise HeatDataError(f"Heat table empty: {path}")
    return rows


def _load_bc_magnitudes(path: Path) -> List[BCWaveMagnitude]:
    if not path.exists():
        raise HeatDataError(f"BC magnitudes table missing: {path}")
    with path.open(newline="") as handle:
        reader = csv.DictReader(handle)
        _require_columns(reader.fieldnames, {"bc_id", "league", "wave", "magnitude"}, path)
        rows: List[BCWaveMagnitude] = []
        for idx, row in enumerate(reader, start=2):
            try:
                bc_id = _require_field(row, "bc_id", path)
                league = _require_field(row, "league", path)
                wave = int(_require_field(row, "wave", path))
                magnitude = float(_require_field(row, "magnitude", path))
            except (ValueError, HeatDataError) as exc:
                raise HeatDataError(
                    f"Invalid BC magnitude row at line {idx}: {row}"
                ) from exc
            rows.append(
                BCWaveMagnitude(
                    bc_id=bc_id,
                    league=league,
                    wave=wave,
                    magnitude=magnitude,
                )
            )
    if not rows:
        raise HeatDataError(f"BC magnitudes table empty: {path}")
    return rows


def _require_columns(
    fieldnames: Iterable[str] | None, required: set[str], path: Path
) -> None:
    if fieldnames is None:
        raise HeatDataError(f"Missing header row in {path}")
    missing = required - set(fieldnames)
    if missing:
        raise HeatDataError(f"Missing columns {sorted(missing)} in {path}")


def _require_field(row: Dict[str, str], key: str, path: Path) -> str:
    if key not in row:
        raise HeatDataError(f"Missing {key!r} in row: {row} ({path})")
    value = row.get(key, "").strip()
    if value == "":
        raise HeatDataError(f"Empty {key!r} in row: {row} ({path})")
    return value


# ---------------------------------------------------------------------------
# v2 Tournament Heat Tables (Champions/Legends scope)
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class TournamentBCDefinition:
    bc_key: str
    bc_name: str
    unit: str
    static_over_waves: bool
    in_champions: bool
    in_legends: bool


@dataclass(frozen=True)
class TournamentBCValueAtWave:
    league: str
    wave: int
    bc_key: str
    value_num: float
    unit: str
    value_text: str


class TournamentHeatTable:
    """In-memory lookup for tournament BC values keyed by (league, bc_key, wave_actual).

    Lookup policy:
    - stepwise by wave_actual: choose the last row where row.wave <= wave_actual.
    - bounds are strict: requesting a wave below min or above max for that (league, bc_key)
      raises HeatDataError (caller should fail-closed).
    """

    def __init__(
        self,
        *,
        definitions: Dict[str, TournamentBCDefinition],
        series: Dict[tuple[str, str], List[TournamentBCValueAtWave]],
        provenance: str,
    ) -> None:
        self.definitions = definitions
        self.series = series
        self.provenance = provenance

    def available_bc_keys_for_league(self, league: str) -> set[str]:
        league_key = str(league).strip().lower()
        out: set[str] = set()
        for bc_key, d in self.definitions.items():
            if league_key == "champion" and d.in_champions:
                out.add(bc_key)
            if league_key == "legend" and d.in_legends:
                out.add(bc_key)
        return out

    def value_at(self, *, league: str, bc_key: str, wave_actual: int) -> TournamentBCValueAtWave:
        league_key = str(league).strip().lower()
        bc = str(bc_key).strip()
        key = (league_key, bc)
        if key not in self.series:
            raise HeatDataError(f"No BC series for league={league_key!r} bc_key={bc!r}")
        rows = self.series[key]
        if not rows:
            raise HeatDataError(f"Empty BC series for league={league_key!r} bc_key={bc!r}")

        w = int(wave_actual)
        min_w = rows[0].wave
        max_w = rows[-1].wave
        if w < min_w or w > max_w:
            raise HeatDataError(
                f"wave_actual {w} out of bounds for league={league_key} bc_key={bc} "
                f"(min={min_w}, max={max_w})"
            )

        # stepwise: last row where wave <= w
        lo, hi = 0, len(rows) - 1
        best = rows[0]
        while lo <= hi:
            mid = (lo + hi) // 2
            row = rows[mid]
            if row.wave <= w:
                best = row
                lo = mid + 1
            else:
                hi = mid - 1
        return best


def load_tournament_heat_table(
    *,
    registry_path: Path,
    values_path: Path,
    provenance: str,
) -> TournamentHeatTable:
    """Load the v2 tournament heat tables (BC registry + per-wave values)."""
    definitions = _load_tournament_bc_registry(registry_path)
    series = _load_tournament_bc_values(values_path)

    # Basic validation: every (league, bc_key) in series must exist in registry.
    for (_, bc_key) in series.keys():
        if bc_key not in definitions:
            raise HeatDataError(f"BC key {bc_key!r} present in values but missing in registry")

    return TournamentHeatTable(definitions=definitions, series=series, provenance=provenance)


def _load_tournament_bc_registry(path: Path) -> Dict[str, TournamentBCDefinition]:
    if not path.exists():
        raise HeatDataError(f"BC registry missing: {path}")
    with path.open(newline="") as handle:
        reader = csv.DictReader(handle)
        _require_columns(
            reader.fieldnames,
            {
                "bc_key",
                "bc_name",
                "unit",
                "static_over_waves",
                "in_champions",
                "in_legends",
            },
            path,
        )
        out: Dict[str, TournamentBCDefinition] = {}
        for row in reader:
            bc_key = str(row["bc_key"]).strip()
            out[bc_key] = TournamentBCDefinition(
                bc_key=bc_key,
                bc_name=str(row["bc_name"]).strip(),
                unit=str(row["unit"]).strip(),
                static_over_waves=_parse_bool(row["static_over_waves"]),
                in_champions=_parse_bool(row["in_champions"]),
                in_legends=_parse_bool(row["in_legends"]),
            )
        return out


def _load_tournament_bc_values(path: Path) -> Dict[tuple[str, str], List[TournamentBCValueAtWave]]:
    if not path.exists():
        raise HeatDataError(f"BC values table missing: {path}")
    with path.open(newline="") as handle:
        reader = csv.DictReader(handle)
        _require_columns(reader.fieldnames, {"league", "wave", "bc_key", "value_num", "unit", "value_text"}, path)
        out: Dict[tuple[str, str], List[TournamentBCValueAtWave]] = {}
        for row in reader:
            league = str(row["league"]).strip().lower()
            bc_key = str(row["bc_key"]).strip()
            wave = int(float(row["wave"]))
            value_num = float(row["value_num"]) if row["value_num"] not in ("", None) else float("nan")
            unit = str(row["unit"]).strip()
            value_text = str(row.get("value_text", "") or "").strip()

            key = (league, bc_key)
            out.setdefault(key, []).append(
                TournamentBCValueAtWave(
                    league=league,
                    wave=wave,
                    bc_key=bc_key,
                    value_num=value_num,
                    unit=unit,
                    value_text=value_text,
                )
            )

        # sort and validate monotonic waves for each series
        for key, rows in out.items():
            rows.sort(key=lambda r: r.wave)
            waves = [r.wave for r in rows]
            if any(waves[i] == waves[i - 1] for i in range(1, len(waves))):
                raise HeatDataError(f"Duplicate wave rows for {key}")

        return out


def _parse_bool(value: object) -> bool:
    s = str(value).strip().lower()
    return s in {"1", "true", "yes", "y", "t"}
"""Tournament battle-condition (BC) set selection.

This module enumerates the possible BC key sets for a given tournament league, based on:
- league rule table in `tables/tournament_league_rules.csv`
- a caller-provided set of available BC keys (the BC universe)

Authoritative numeric values for each BC over time are handled elsewhere
(see `bc_heat_loader.py` / `tables/heat_scale_long.csv`).

Wiki cross-check (mechanics, not numeric magnitudes):
- Platinum+ always has Death Defy Down OR Energy Shields Down.
- Silver has 1 random BC, Gold 2, ..., Legends 5.
- More Bosses is always active per league and stays static over waves.
See: Tournaments page and Battle Conditions List on the community wiki.
"""

from __future__ import annotations

from dataclasses import dataclass
from itertools import combinations
from pathlib import Path
from typing import Iterable, List, Optional, Set, Tuple

import pandas as pd


@dataclass(frozen=True)
class TournamentLeagueRule:
    league: str
    random_bc_count: int
    has_dd_or_es: bool
    has_more_bosses: bool
    has_skip_decay: bool
    has_skip_reduction_mult: bool


_RULES_COLUMNS = {
    "league",
    "random_bc_count",
    "has_dd_or_es",
    "has_more_bosses",
    "has_skip_decay",
    "has_skip_reduction_mult",
}

# Canonical BC keys for tournament mechanics (aligned to the tournament reference sheet).
BC_MORE_BOSSES = "BOSS_WAVE_INTERVAL"
BC_SKIP_DECAY = "SKIP_DECAY"
BC_SKIP_REDUCTION_MULT = "SKIP_REDUCTION_MULT"
BC_DD_DELTA = "DEATH_DEFY_DELTA"
BC_ES_RECHARGE_BONUS = "ENERGY_SHIELD_RECHARGE_BONUS"


def _load_league_rules(path: Path) -> dict[str, TournamentLeagueRule]:
    df = pd.read_csv(path)
    missing_cols = _RULES_COLUMNS - set(df.columns)
    if missing_cols:
        raise ValueError(f"Missing columns in {path.name}: {sorted(missing_cols)}")
    out: dict[str, TournamentLeagueRule] = {}
    for _, row in df.iterrows():
        league = str(row["league"]).strip().lower()
        out[league] = TournamentLeagueRule(
            league=league,
            random_bc_count=int(row["random_bc_count"]),
            has_dd_or_es=bool(row["has_dd_or_es"]),
            has_more_bosses=bool(row["has_more_bosses"]),
            has_skip_decay=bool(row["has_skip_decay"]),
            has_skip_reduction_mult=bool(row["has_skip_reduction_mult"]),
        )
    return out


def enumerate_tournament_bc_sets(
    league: str,
    available_bc_ids: Iterable[str],
    *,
    league_rules_path: Optional[Path] = None,
) -> List[Tuple[str, ...]]:
    """Enumerate all possible BC key sets for a league.

    Notes:
    - Deterministic (sorted output).
    - The caller supplies the BC universe (available_bc_ids). Typically this is the
      set of BC keys present in `tables/heat_bc_registry.csv` for that league.
    """
    league_key = str(league).strip().lower()
    rules_path = (
        league_rules_path
        if league_rules_path is not None
        else Path(__file__).resolve().parents[2] / "tables" / "tournament_league_rules.csv"
    )
    rules_by_league = _load_league_rules(rules_path)
    if league_key not in rules_by_league:
        raise ValueError(f"Unsupported league: {league_key!r}")

    rule = rules_by_league[league_key]
    available: Set[str] = {str(x).strip() for x in available_bc_ids}

    fixed_core: Set[str] = set()
    if rule.has_more_bosses:
        fixed_core.add(BC_MORE_BOSSES)
    if rule.has_skip_decay:
        fixed_core.add(BC_SKIP_DECAY)
    if rule.has_skip_reduction_mult:
        fixed_core.add(BC_SKIP_REDUCTION_MULT)

    # Validate fixed presence
    for key in fixed_core:
        if key not in available:
            raise ValueError(f"Missing required BC key for league {league_key}: {key}")

    dd_es_choices: List[Tuple[str, ...]] = [tuple()]
    excluded_from_pool: Set[str] = set(fixed_core)

    if rule.has_dd_or_es:
        if BC_DD_DELTA not in available or BC_ES_RECHARGE_BONUS not in available:
            raise ValueError(
                "Missing required BC for dd/es choice: "
                f"need {BC_DD_DELTA!r} and {BC_ES_RECHARGE_BONUS!r}"
            )
        dd_es_choices = [(BC_DD_DELTA,), (BC_ES_RECHARGE_BONUS,)]
        excluded_from_pool.update({BC_DD_DELTA, BC_ES_RECHARGE_BONUS})

    pool = sorted(k for k in available if k not in excluded_from_pool)

    if rule.random_bc_count < 0:
        raise ValueError(f"Invalid random_bc_count for league {league_key}: {rule.random_bc_count}")

    if len(pool) < rule.random_bc_count:
        raise ValueError(
            "Random BC pool too small for "
            f"{league_key}: need {rule.random_bc_count}, have {len(pool)}"
        )

    out: List[Tuple[str, ...]] = []
    for dd_es in dd_es_choices:
        for combo in combinations(pool, rule.random_bc_count):
            bc_set = tuple(sorted(tuple(fixed_core) + tuple(dd_es) + tuple(combo)))
            out.append(bc_set)

    return sorted(set(out))

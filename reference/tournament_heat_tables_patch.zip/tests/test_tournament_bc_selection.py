import sys
from pathlib import Path

import pytest


def _add_repo_root_to_path() -> None:
    repo_root = Path(__file__).resolve().parents[1]
    sys.path.insert(0, str(repo_root))


_add_repo_root_to_path()

from tower_sim.loaders.tournament_bc_selection import enumerate_tournament_bc_sets  # noqa: E402
from tower_sim.loaders.tournament_bc_selection import (
    BC_DD_DELTA,
    BC_ES_RECHARGE_BONUS,
    BC_MORE_BOSSES,
    BC_SKIP_DECAY,
    BC_SKIP_REDUCTION_MULT,
)


def test_champion_enumeration_counts() -> None:
    # Champion: fixed (more bosses + skips) + dd/es choice + 4 random
    pool = {"A", "B", "C", "D"}  # exactly 4 randoms
    available = pool | {BC_MORE_BOSSES, BC_SKIP_DECAY, BC_SKIP_REDUCTION_MULT, BC_DD_DELTA, BC_ES_RECHARGE_BONUS}
    result = enumerate_tournament_bc_sets(league="champion", available_bc_ids=available)
    assert len(result) == 2  # dd vs es
    assert tuple(sorted((BC_MORE_BOSSES, BC_SKIP_DECAY, BC_SKIP_REDUCTION_MULT, BC_DD_DELTA, "A", "B", "C", "D"))) in result
    assert tuple(sorted((BC_MORE_BOSSES, BC_SKIP_DECAY, BC_SKIP_REDUCTION_MULT, BC_ES_RECHARGE_BONUS, "A", "B", "C", "D"))) in result


def test_legend_enumeration_counts() -> None:
    # Legend: fixed + dd/es choice + 5 random
    pool = {"A", "B", "C", "D", "E"}  # exactly 5 randoms
    available = pool | {BC_MORE_BOSSES, BC_SKIP_DECAY, BC_SKIP_REDUCTION_MULT, BC_DD_DELTA, BC_ES_RECHARGE_BONUS}
    result = enumerate_tournament_bc_sets(league="legend", available_bc_ids=available)
    assert len(result) == 2


def test_missing_dd_or_es_raises() -> None:
    available = {"X", "Y", BC_MORE_BOSSES, BC_SKIP_DECAY, BC_SKIP_REDUCTION_MULT, BC_DD_DELTA}
    with pytest.raises(ValueError):
        enumerate_tournament_bc_sets(league="champion", available_bc_ids=available)


def test_pool_too_small_raises() -> None:
    # champion needs 4 randoms
    available = {BC_MORE_BOSSES, BC_SKIP_DECAY, BC_SKIP_REDUCTION_MULT, BC_DD_DELTA, BC_ES_RECHARGE_BONUS, "A", "B", "C"}
    with pytest.raises(ValueError):
        enumerate_tournament_bc_sets(league="champion", available_bc_ids=available)


import pytest
from sim.engines.boss_survivability import BossStats, TowerDefense, BossContext, resolve_boss_fight

def test_shape():
    boss = BossStats(1000, 100, 1.0, 1.0)
    tower = TowerDefense(0.5, 0.0, 1000)
    ctx = BossContext(
        wave=100, tier=14, league="Test",
        boss=boss, tower=tower,
        combat_params={"boss_dps": 100},
        bc_params={"boss_hp_mult": 1, "boss_attack_mult": 1}
    )
    out = resolve_boss_fight(ctx)
    assert out["outcome"] in ("tower_kills_boss", "boss_kills_tower")

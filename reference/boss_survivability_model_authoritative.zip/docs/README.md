
# Boss Survivability Model

Authoritative structure for boss resolution:
- Applies tier/league BCs
- Computes TTK vs TTD
- Determines win condition

Populate values from Effective Paths / Wiki.
Fail-closed by design.

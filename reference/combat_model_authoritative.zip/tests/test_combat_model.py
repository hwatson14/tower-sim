
import pytest
from sim.engines.combat_model import Enemy, TowerStats, CombatParams, resolve_wave, CombatDataError

def test_fail_on_invalid_frac():
    enemy = Enemy(hp=100, attack=10, is_boss=False, is_fleet=False)
    tower = TowerStats(dr_frac=1.2, thorns_frac=0, pc_frac=0, regen=0, shields=0)
    params = CombatParams(1,1,1,1,1,1)
    with pytest.raises(CombatDataError):
        resolve_wave(enemy, tower, params)

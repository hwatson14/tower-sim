
"""
Authoritative Combat Model — Fail-Closed, Deterministic

This engine defines the COMPLETE combat resolution pipeline structure for The Tower.
It intentionally does NOT hardcode numeric balances. All magnitudes are loaded from
validated tables derived from Effective Paths / Wiki sources supplied by the user.

If any required parameter is missing, the engine MUST raise CombatDataError.
"""

from dataclasses import dataclass
from typing import Dict, Any

class CombatDataError(RuntimeError):
    pass

@dataclass(frozen=True)
class Enemy:
    hp: float
    attack: float
    is_boss: bool
    is_fleet: bool

@dataclass(frozen=True)
class TowerStats:
    dr_frac: float          # Total damage reduction fraction [0..1]
    thorns_frac: float      # Thorns fraction of enemy current HP [0..1]
    pc_frac: float          # Percent-current damage fraction (e.g., Plasma/PC)
    regen: float            # Regen per wave (applied outside combat)
    shields: float          # Any shield layer (if applicable)

@dataclass(frozen=True)
class CombatParams:
    enemy_attack_mult: float
    boss_pc_mult: float
    fleet_pc_mult: float
    dr_cap: float           # Hard cap on DR fraction
    thorns_cap: float       # Optional cap on thorns fraction
    pc_cap: float           # Optional cap on PC fraction

def _check_frac(name: str, v: float):
    if not (0.0 <= v <= 1.0):
        raise CombatDataError(f"{name} must be in [0,1], got {v}")

def apply_dr(dmg: float, dr_frac: float, dr_cap: float) -> float:
    _check_frac("dr_frac", dr_frac)
    _check_frac("dr_cap", dr_cap)
    eff = min(dr_frac, dr_cap)
    return dmg * (1.0 - eff)

def apply_thorns(enemy_hp: float, thorns_frac: float, thorns_cap: float) -> float:
    _check_frac("thorns_frac", thorns_frac)
    _check_frac("thorns_cap", thorns_cap)
    eff = min(thorns_frac, thorns_cap)
    return enemy_hp * eff

def apply_pc(enemy_hp: float, pc_frac: float, pc_cap: float, mult: float) -> float:
    _check_frac("pc_frac", pc_frac)
    _check_frac("pc_cap", pc_cap)
    eff = min(pc_frac, pc_cap)
    return enemy_hp * eff * mult

def resolve_wave(enemy: Enemy, tower: TowerStats, params: CombatParams) -> Dict[str, float]:
    """
    Deterministic single-wave combat resolution.
    Returns remaining_enemy_hp and tower_damage_taken.
    """
    # Enemy attack -> tower
    incoming = enemy.attack * params.enemy_attack_mult
    tower_damage = apply_dr(incoming, tower.dr_frac, params.dr_cap)

    # Tower passive damage -> enemy
    dmg = 0.0
    dmg += apply_thorns(enemy.hp, tower.thorns_frac, params.thorns_cap)

    pc_mult = (
        params.boss_pc_mult if enemy.is_boss else
        params.fleet_pc_mult if enemy.is_fleet else
        1.0
    )
    dmg += apply_pc(enemy.hp, tower.pc_frac, params.pc_cap, pc_mult)

    remaining = max(0.0, enemy.hp - dmg)

    return {
        "remaining_enemy_hp": remaining,
        "tower_damage_taken": tower_damage
    }

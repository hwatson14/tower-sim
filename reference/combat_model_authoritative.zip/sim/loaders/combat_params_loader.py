
"""
Combat parameter loader — validates schema and coverage.
"""
import json
from pathlib import Path
from sim.engines.combat_model import CombatParams, CombatDataError

REQUIRED = [
    "enemy_attack_mult",
    "boss_pc_mult",
    "fleet_pc_mult",
    "dr_cap",
    "thorns_cap",
    "pc_cap"
]

def load_params(path: Path) -> CombatParams:
    data = json.loads(path.read_text())
    for k in REQUIRED:
        if k not in data:
            raise CombatDataError(f"Missing combat param: {k}")
    return CombatParams(**{k: float(data[k]) for k in REQUIRED})

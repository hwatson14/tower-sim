
# Authoritative Combat Model

This module defines the **full structure** of The Tower combat resolution.

## Mechanics included
- Damage Reduction (DR) with hard caps
- Thorns (percent of enemy current HP)
- Percent-Current (PC) damage with boss/fleet modifiers

## What is intentionally NOT included
- Hardcoded balance numbers
- Assumed scaling
- Any guessing beyond explicit equations

## How to activate
1. Populate combat parameter JSONs from Effective Paths / Wiki.
2. Validate with schema.
3. Wire loader into wave engine.

Fail-closed by design.

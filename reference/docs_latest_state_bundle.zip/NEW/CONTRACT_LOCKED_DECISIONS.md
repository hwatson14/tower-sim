# CONTRACT_LOCKED_DECISIONS

This is a single-page “do not drift” contract extracted from the project chat decisions.

## Pipelines

### Pipeline A: Snapshot Build
- Input: raw export or upstream dump artifacts
- Output artifacts:
  - AccountSnapshot payload (canonical)
  - inventory view
  - loadout configuration view
  - base stats export (StatBook style)

Rules:
- May parse raw exports
- Must not run MAX_WAVE

### Pipeline B: Evaluation Shelves
- Input: AccountSnapshot + scenario generator + authoritative tables
- Output artifacts (exactly three):
  1) max_waves_farm_latest.json
  2) max_waves_milestone_latest.json
  3) max_waves_tournament_latest.json

Rules:
- Must not parse raw exports
- Must fail-closed per entry (publish missing[])

## Mode → preset mapping (authoritative)
- farm → Farming
- milestone → Testing (historical “preset 3” intent)
- tournament → Tourney

## Enemy scaling
- Enemy attack and health tables are sparse by wave.
- Interpolation between wave points is mandatory, deterministic, and must emit diagnostics.
- Interpolation within table bounds is mandatory and deterministic.
- Out-of-bounds waves are **fail-closed** (no extrapolation, no clamping).

## Wave domains (ELS-safe)

The simulator must track three distinct wave indices:

- `wave_actual`: true timeline wave index (used for tournament heat step thresholds)
- `wave_attack`: effective enemy *attack* wave index after EALS/ELS-style skips
- `wave_health`: effective enemy *health* wave index after EHLS/ELS-style skips

Rules:
- Tournament heat scaling is keyed to `wave_actual` only.
- Enemy attack scaling is keyed to `wave_attack`.
- Enemy health scaling is keyed to `wave_health`.

## Tournament league rules (authoritative)

Source: Tournament rules on the Tower wiki (URL in this doc). At minimum, the model must encode:

- “More Bosses” is **static** across waves and league-dependent (boss interval decreases with higher leagues).
- Random Battle Conditions (BCs): Silver=1, Gold=2, Platinum=3, Champion=4, Legend=5.
- From Platinum upwards: **Death Defy or Energy Shield** will be active (selection semantics still must be defined explicitly).
- Enemy Level Skip BC is always present in Gold+ with fixed values: Gold=10%, Platinum=20%, Champion=30%, Legend=50%.

## Canonical tables (authoritative)

Enemy scaling (sparse keypoints, interpolated within bounds):
- `tables/enemy_damage_table.csv` (enemy attack)
- `tables/enemy_health_table.csv` (enemy health)

Tournament BC/heat:
- `tables/tournament_league_rules.csv` (league rules: boss interval, random BC count, guaranteed BCs)
- `tables/tournament_heat_bc_values_long.csv` (wave-step BC magnitudes keyed by `wave_actual`)
- (optional) `tables/tournament_bc_registry.csv` (BC metadata + validation)

Deprecated tables (must be removed after migration):
- `tables/tier_wave_damage.csv` (legacy; replaced by enemy_damage/health tables)
- Any legacy tournament heat-scale tables once the new ones land

## Debug-first outputs
Shelf entries must be verbose and include:
- resolved scenario and preset
- resolved BC/heat inputs
- enemy interpolation details (bracket points + computed values)
- Wmax + first-fail wave + limiting reason
- search trace sufficient to reproduce decisions


## External references
- Tournament rules and Battle Conditions: https://the-tower-idle-tower-defense.fandom.com/wiki/Tournaments

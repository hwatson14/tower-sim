# TowerSim

TowerSim is a deterministic simulator for *The Tower — Idle Tower Defense*.

## What it provides
- Canonical account snapshot normalization (Pipeline A)
- Deterministic evaluation of Maximum Wave (Wmax) (Pipeline B)
- Precomputed “shelf” artifacts for fast downstream consumption

## How to use (intended)
1. Build or fetch the latest AccountSnapshot artifact
2. Read the published shelves:
   - Farming shelf (tiers 1–21)
   - Milestone shelf (tiers 1–21, Testing preset)
   - Tournament shelf (all supported leagues)

Downstream tools should **fetch artifacts**, not re-parse raw exports.

## Key rules
- Fail-closed on missing data (report missing inputs; do not guess)
- Single canonical stat compilation path shared by MAX_WAVE and StatBook
- Enemy attack/health scaling uses deterministic interpolation between table wave points

## Where to read more
- PROJECT_INTENT.md
- ARCHITECTURE.md
- IMPLEMENTATION_STATUS.md


## Tournament data contracts
- Tournament league rules: `tables/tournament_league_rules.csv`
- Tournament heat/BC magnitudes: `tables/tournament_heat_bc_values_long.csv`
- Heat keyed to `wave_actual` only; out-of-bounds fail-closed.
- Tournament reference: https://the-tower-idle-tower-defense.fandom.com/wiki/Tournaments

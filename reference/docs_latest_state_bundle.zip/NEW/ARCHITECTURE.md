# ARCHITECTURE

## Overview

TowerSim is built around two explicit pipelines:

- **Pipeline A: Snapshot Build** (ingestion / normalization)
- **Pipeline B: Evaluation Shelves** (precompute / publish)

The goal is to keep ingestion and evaluation separated so that downstream tooling can fetch stable artifacts without re-parsing raw exports.

---

## Pipeline A: Snapshot Build (ingestion)

### Purpose
Convert raw export data (e.g., IDS CSV or equivalent dumps) into a canonical **AccountSnapshot** and stable derived views.

### Inputs
- Raw export (e.g., `_IDS.csv`) or upstream dump artifacts

### Outputs (artifacts)
- Canonical snapshot artifact (AccountSnapshot payload)
- Inventory view (human/debug)
- Loadout configuration view (human/debug)
- Base-stats debug export (StatBook-style) that exposes **base** and **loadout delta** contributions

### Rules
- Pipeline A does **not** run MAX_WAVE.
- Pipeline A is allowed to parse raw exports.
- Pipeline A is responsible for normalizing preset naming (e.g., “Testing” preset for milestone intent).

---

## Pipeline B: Evaluation Shelves (precompute)

### Purpose
Compute deterministic outcomes from the latest AccountSnapshot and publish shelves for consumption.

### Inputs
- AccountSnapshot artifact from Pipeline A
- Scenario generator (mode + tier/league → preset + scenario rule selection)
- Authoritative tables (BC, heat, enemy scaling, wave damage as applicable)

### Outputs (exactly three artifacts)
1. Farming shelf (tiers 1–21)
2. Milestone shelf (tiers 1–21, using Testing preset)
3. Tournament shelf (all supported leagues)

Each shelf contains all entries within one file (no per-tier/per-league files).

### Rules
- Pipeline B must be snapshot-first. It must not re-parse raw exports.
- Pipeline B must be fail-closed per entry. If a tier/league lacks table coverage, the entry is marked fail-closed with `missing[]` and published alongside successful entries.

---

## Canonical stat composition (single source of truth)

A single canonical path must exist for stat composition. MAX_WAVE, StatBook exports, and any reports must use the same compilation functions.

### Composition order (invariant)
1. Base sources (account constants, labs, workshop, relics, etc.)
2. Loadout deltas (cards, modules, bots, guardians, etc.) selected by preset
3. Enhancements / global multipliers (applied deterministically per the registry rules)
4. Scenario transforms (tier BC; tournament league BC/heat policies)
5. Derived stats

This order must be encoded once and reused everywhere.

---

## Presets and modes

Presets are loadout delta selectors, not physics modes:

- farm → preset **Farming**
- milestone → preset **Testing** (historical “preset 3” intent)
- tournament → preset **Tourney**

Modes select scenario/environment rules and policies. They do not change how the tower’s stat math works.

---

## Enemy scaling and interpolation (mandatory)

Enemy attack and health tables are sparse across waves. Therefore:

- Evaluators must support interpolation between table wave points.
- The interpolation method must be deterministic and documented.
- Diagnostics must record bracketing points and the computed interpolated value.

Extrapolation policy beyond the maximum table wave must be explicit (allowed vs fail-closed). The chosen policy must be consistent across all shelves.

---

## Evaluators

Evaluators consume:
- compiled stat inputs and stat engine outputs (start-of-run and per-wave snapshots)
- enemy scaling (interpolated) and scenario rules (BC/heat)
- progression model outputs (if progression is enabled)

Evaluators never parse raw exports and never directly depend on IDS formats.

---

## Runners / Agents

Runners and agents should fetch and consume artifacts:
- snapshot and views
- shelves

They should not attempt to “rebuild the world” from raw exports.


## Tournament heat + battle conditions

Tournaments are modeled as:
- league rules (boss interval, BC selection counts, guaranteed BCs)
- a per-wave (stepwise) heat table keyed by `wave_actual` that defines BC magnitudes

Canonical inputs:
- `tables/tournament_league_rules.csv`
- `tables/tournament_heat_bc_values_long.csv`
- (optional) `tables/tournament_bc_registry.csv`

Hard rules:
- Heat is keyed to `wave_actual` only.
- Out-of-bounds waves are fail-closed (no extrapolation, no clamping).
- Do not invent new semantics like “heat_level” unless proven to be a game concept; treat it as optional derived metadata at most.

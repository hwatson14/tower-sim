# IMPLEMENTATION_STATUS

This document tracks what exists versus what is required by the locked architecture.

## Implemented (observed / expected in repo)
- Raw export parsing and/or dump ingestion (Pipeline A input)
- AccountSnapshot compilation (canonical snapshot type)
- Inventory and loadout resolution views (derived from snapshot)
- Partial stat engine / statbook scaffolding (structure exists; completeness varies by stat coverage)
- Tables for tiers/leagues/enemy scaling exist in some form (coverage must be validated)

## Missing or incomplete (blocking “shelf-first” v1)
1. **Single canonical stat compilation**
   - Base + loadout delta must be compiled once and shared by MAX_WAVE and StatBook export.
   - Remove or refactor parallel compilation paths so MAX_WAVE cannot drift.

2. **Base stats export with base vs loadout delta columns**
   - base_stats_latest must show: base_value, loadout_delta, (recommended) final_value.
   - Include provenance and caps applied for debugging.

3. **Interpolation support for enemy attack and health**
   - Enemy atk/hp tables are sparse; MAX_WAVE must interpolate deterministically.
   - Interpolation diagnostics must be included in shelf entries.

4. **Shelf generator and aggregation**
   - Generate exactly three aggregated shelf artifacts:
     - farm (tiers 1–21)
     - milestone (tiers 1–21, Testing preset)
     - tournament (all supported leagues)
   - Each entry must be verbose for debugging and fail-closed per entry.

5. **Coverage validation harness**
   - Tests or validations must assert:
     - tier coverage 1–21 for required tables
     - tournament leagues coverage for required tables
     - preset keys exist (Farming/Testing/Tourney)
     - interpolation invariants (exact at keypoints, monotonicity where expected)

## Explicitly discouraged / to remove after migration
- Per-request MAX_WAVE runs that bypass shelves (unless intentionally kept for dev)
- IDS parsing inside evaluators/runners
- Divergent “report-only” stat compilation paths


### Legacy table removal
[ ] Remove `tables/tier_wave_damage.csv` and any legacy loaders once enemy_damage_table/enemy_health_table are wired.
[ ] Add a test that fails if legacy wave damage table is imported.

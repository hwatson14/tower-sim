# PROJECT_INTENT

TowerSim is a deterministic simulator for *The Tower — Idle Tower Defense*.

Its v1 goal is to compute **Maximum Wave (Wmax)** and publish reproducible, explainable results from a canonical account snapshot and authoritative tables. TowerSim is designed to be **fail-closed**: if required inputs are missing, the run reports what is missing and does not guess.

## What “Wmax” means in this project

Wmax is the highest wave that the tower can survive under a fully specified scenario, given deterministic (or explicitly bounded) assumptions. TowerSim is not attempting to simulate every frame. It evaluates survivability using deterministic stat composition, deterministic progression, and deterministic enemy scaling.

## Wave domains (ELS-safe)

The simulator must track three distinct wave indices:

- `wave_actual`: true timeline wave index (used for tournament heat step thresholds)
- `wave_attack`: effective enemy *attack* wave index after EALS/ELS-style skips
- `wave_health`: effective enemy *health* wave index after EHLS/ELS-style skips

Rules:
- Tournament heat scaling is keyed to `wave_actual` only.
- Enemy attack scaling is keyed to `wave_attack`.
- Enemy health scaling is keyed to `wave_health`.

## Primary consumption model: shelf outputs

The primary consumption model is **precomputed shelves** that are generated from the latest snapshot and then fetched by downstream tools (runner/agents). The shelves are authoritative artifacts, not convenience caches.

There are exactly **three** shelf outputs:

1. **Farming shelf**: tiers 1–21, using the **Farming** preset
2. **Milestone shelf**: tiers 1–21, using the **Testing** preset (historical “preset 3” intent)
3. **Tournament shelf**: all supported tournament leagues, using the **Tourney** preset

Each shelf entry must contain enough detail to explain the result (inputs, assumptions, limiting factor, and diagnostics).

## Scenario types and policies (v1)

TowerSim supports three scenario modes:

- **farm**: tier battle conditions; perk policy **TBD** (must be explicit in ProblemSpec)
- **milestone**: tier battle conditions; perk policy **TBD**; preset is **Testing**
- **tournament**: tournament league rules; heat/BC policies as encoded by tables; perk policy **TBD**

“Mode” is not a physics switch for the tower. It primarily selects scenario/environment rules and loadout preset mapping.

## Determinism and bounded variability

TowerSim is deterministic. If any variability is modeled, it must be explicitly represented as:
- a bounded envelope (e.g., best/nominal/worst timing window), and/or
- an explicitly defined deterministic timeline (e.g., perk timeline), not randomness.

No other hidden variability is permitted.

## Inputs are authoritative or they do not exist

Hard inputs come from:
- the canonical account snapshot and its derived views
- authoritative tables (BC, heat, enemy scaling, etc.)
- a single canonical stat composition pipeline (stat inputs → stat engine → statbook)

If a required table is missing coverage, TowerSim must fail closed for that scenario and list missing inputs.

## Required diagnostics (debug-first)

All published outputs must include:
- resolved scenario (mode + tier or league)
- resolved preset and loadout configuration used
- resolved BC/heat inputs
- enemy scaling diagnostics (including interpolation details)
- Wmax, first-fail wave, and limiting reason
- a compact trace of the search (bounds/decisions) sufficient to reproduce the decision path


## Canonical tables (authoritative)

Enemy scaling (sparse keypoints, interpolated within bounds; out-of-bounds is fail-closed):
- `tables/enemy_damage_table.csv` (enemy attack)
- `tables/enemy_health_table.csv` (enemy health)

Tournament BC/heat:
- `tables/tournament_league_rules.csv`
- `tables/tournament_heat_bc_values_long.csv`
- (optional) `tables/tournament_bc_registry.csv`

Deprecated after migration:
- `tables/tier_wave_damage.csv` (legacy)

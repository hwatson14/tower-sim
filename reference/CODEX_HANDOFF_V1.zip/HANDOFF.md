# Codex Handoff V1 (TowerSim / EP replication)

## What this pack is
A compact, deterministic set of artifacts produced from the Effective Paths workbook to accelerate the next implementation steps in TowerSim.
This pack intentionally does **not** include the full repo (user already has it).

## Proven outputs (eHP domain)
- STAT_LEDGER_V1_eHP_ROOTED.zip
  - Rooted eHP snapshot ledger driven by explicit EP cells (AH16..AH23).
  - Includes minimal dependency DAG (~78 stats) and audit.

## Investigations and falsifications
- NAMED_RANGE_REGISTRY_V1.zip
  - Extracted workbook defined names and attempted resolution.
  - Result: 0 matches against unresolved tokens (so unresolved tokens are not Excel defined names).
- UNRESOLVED_CLASSIFICATION_V1.zip
  - Classified unresolved tokens from rooted eHP ledger.
  - Observed: identifiers dominate; some cross-sheet cell refs.
- INGEST_eRegen_eDMG_V1.zip
  - Raw formula-cell ingestion of eRegen and eDMG sheets (presence-only).
- STAT_LEDGER_V1_eHP_WITH_eRegen_eDMG.zip
  - Presence resolution attempt using ingested sheets.
  - Result: 0 resolved by presence, implying remaining unresolved tokens are not missing cells.

## Current blocker (semantic identifiers)
- IDENTIFIER_REGISTRY_V1.zip
  - Scaffold CSV listing unresolved identifier tokens that require explicit definition mapping.
  - Once filled, unresolved tokens can be replaced with explicit sources (cell refs, IDS fields, constants, tables, or derived helpers).

## Next implementation steps (Codex)
1. Build an Identifier Resolver:
   - Input: IDENTIFIER_REGISTRY_V1.csv (filled progressively)
   - Output: token rewrite map: UNRESOLVED(X) -> one of
     - REF(sheet!cell) / RANGE(sheet!A1:B2)
     - IDS(field)
     - CONST(value)
     - TABLE(table_key, lookup_spec)
     - DERIVED(stat_key) with EP provenance
2. Close the eHP ledger:
   - Apply the rewrite map to rooted eHP ledger.
   - Recompute unresolved counts; fail-closed if any remain.
3. Add parity tests:
   - Pick 1-3 golden IDS snapshots and compare computed root outputs vs EP for AH16..AH23.
4. Repeat the rooted-ledger pattern for eDMG and eRegen outputs (roots to be confirmed similarly).

## Constraints respected
- No invented mechanics.
- Fail-closed on missing sources.
- Minimal files; all artifacts are auditable.

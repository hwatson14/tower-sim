# placeholder econ+cc binding logic

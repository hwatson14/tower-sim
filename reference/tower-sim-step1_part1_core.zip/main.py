
from sim.engine import run_all
from sim.loader import load_entrypoint
from sim.validate import validate_all

def main():
    ctx = load_entrypoint()
    validate_all(ctx)
    run_all(ctx)

if __name__ == "__main__":
    main()

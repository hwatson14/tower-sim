
"""Load recovered YAML artifacts.

Fail-closed policy:
- If PyYAML is not installed, raise with an explicit message (do not parse ad hoc).
"""

class YAMLLoadError(Exception): pass

def load_yaml(path: str):
    try:
        import yaml  # type: ignore
    except Exception as e:
        raise YAMLLoadError("PyYAML not available; cannot load YAML deterministically. Install pyyaml or provide JSON.") from e
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)

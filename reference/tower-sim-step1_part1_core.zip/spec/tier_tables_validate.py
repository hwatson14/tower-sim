import pandas as pd

class TierTableValidationError(Exception):
    pass

def validate_tier_wave_damage_csv(path: str):
    df = pd.read_csv(path)
    required = {"tier","wave","wave_damage"}
    if not required.issubset(df.columns):
        raise TierTableValidationError(f"Missing columns: {required - set(df.columns)}")
    # types
    if (df["tier"]<=0).any():
        raise TierTableValidationError("tier must be positive")
    if (df["wave"]<=0).any():
        raise TierTableValidationError("wave must be positive")
    # monotonic: wave_damage should be non-decreasing with wave for each tier
    for tier, g in df.sort_values(["tier","wave"]).groupby("tier"):
        wd = g["wave_damage"].values
        if (wd[1:] < wd[:-1]).any():
            raise TierTableValidationError(f"wave_damage not monotonic for tier {tier}")
    return True

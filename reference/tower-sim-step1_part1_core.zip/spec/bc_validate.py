from __future__ import annotations

import pandas as pd

REQUIRED_WAVES = set(range(1, 1001))


def validate_tournament_bc_magnitudes(df: pd.DataFrame) -> None:
    required_cols = {"league", "bc_id", "wave", "value", "unit"}
    missing = required_cols - set(df.columns)
    if missing:
        raise ValueError(f"tournament_bc_magnitudes missing columns: {sorted(missing)}")

    if df["wave"].min() < 1 or df["wave"].max() > 1000:
        raise ValueError("tournament_bc_magnitudes wave must be within 1..1000")

    if df["bc_id"].isna().any() or (df["bc_id"].astype(str).str.strip() == "").any():
        raise ValueError("tournament_bc_magnitudes contains empty bc_id")

    if df["value"].isna().any():
        raise ValueError("tournament_bc_magnitudes contains NaN value (fail-closed)")

    # Coverage: each (league, bc_id) must have all waves 1..1000.
    for (league, bc_id), g in df.groupby(["league", "bc_id"]):
        waves = set(int(w) for w in g["wave"].tolist())
        if waves != REQUIRED_WAVES:
            missing_w = sorted(REQUIRED_WAVES - waves)[:20]
            extra_w = sorted(waves - REQUIRED_WAVES)[:20]
            raise ValueError(
                f"tournament_bc_magnitudes coverage error for league={league} bc_id={bc_id}: "
                f"missing={missing_w} extra={extra_w}"
            )


# Back-compat alias

def validate_bc_magnitudes(df: pd.DataFrame) -> None:
    return validate_tournament_bc_magnitudes(df)

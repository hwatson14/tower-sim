
def double_base_attack(state):
    return state.get("base_attack", 0) * 2

FUNCTIONS = {
    "double_base_attack": double_base_attack
}

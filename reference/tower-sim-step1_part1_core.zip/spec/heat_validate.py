from __future__ import annotations

import pandas as pd

REQUIRED_WAVES = set(range(1, 1001))


def validate_heat_wave_scalar(df: pd.DataFrame) -> None:
    required_cols = {"league", "wave", "heat_scalar"}
    missing = required_cols - set(df.columns)
    if missing:
        raise ValueError(f"heat_wave_scalar missing columns: {sorted(missing)}")

    if df["wave"].min() < 1 or df["wave"].max() > 1000:
        raise ValueError("heat_wave_scalar wave must be within 1..1000")

    for league, g in df.groupby("league"):
        waves = set(int(w) for w in g["wave"].tolist())
        if waves != REQUIRED_WAVES:
            missing_w = sorted(REQUIRED_WAVES - waves)[:20]
            extra_w = sorted(waves - REQUIRED_WAVES)[:20]
            raise ValueError(
                f"heat_wave_scalar coverage error for league={league}: "
                f"missing={missing_w} extra={extra_w}"
            )

    if df["heat_scalar"].isna().any():
        raise ValueError("heat_wave_scalar contains NaN heat_scalar values")

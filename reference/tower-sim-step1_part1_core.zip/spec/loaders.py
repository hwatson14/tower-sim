
import csv, json

class TableLoadError(Exception):
    pass

def load_table_csv(path, key_col=None):
    rows = []
    with open(path, newline="") as f:
        reader = csv.DictReader(f)
        for r in reader:
            rows.append({k: float(v) if v.replace('.','',1).isdigit() else v for k,v in r.items()})
    if key_col:
        out = {}
        for r in rows:
            if key_col not in r:
                raise TableLoadError(f"Missing key column {key_col}")
            out[int(r[key_col])] = {k:v for k,v in r.items() if k!=key_col}
        return out
    return rows

def load_dag_json(path):
    with open(path) as f:
        dag = json.load(f)
    # functions must be resolved by name later; placeholder here
    return dag

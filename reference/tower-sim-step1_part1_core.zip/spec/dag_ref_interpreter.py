from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Union


@dataclass(frozen=True)
class Node:
    node_id: str
    op: str
    args: Dict[str, Any]


def _coerce_nodes(dag: Any) -> List[Node]:
    """Coerce a loaded DAG into a list[Node].

    Supported inputs:
    - list[Node]
    - list[dict] with keys: node_id/op/args
    - dict with key 'nodes' holding list[dict] as above
    - any other dict (eg example DAG) => returns [] (no derived stats)
    """
    if dag is None:
        return []

    if isinstance(dag, list):
        if not dag:
            return []
        if isinstance(dag[0], Node):
            return dag  # type: ignore[return-value]
        if isinstance(dag[0], dict):
            out=[]
            for d in dag:
                out.append(Node(node_id=str(d.get("node_id")), op=str(d.get("op")), args=dict(d.get("args", {}))))
            return out
        return []

    if isinstance(dag, dict):
        nodes = dag.get("nodes")
        if isinstance(nodes, list):
            return _coerce_nodes(nodes)
        return []

    return []


def eval_dag(state: Dict[str, Any], dag: Any) -> Dict[str, Any]:
    """Evaluate a derived-stat DAG.

    Fail-closed principle: unknown ops raise; empty DAG => returns state unchanged.
    """
    nodes = _coerce_nodes(dag)
    if not nodes:
        return dict(state)

    by_id = {n.node_id: n for n in nodes}
    cache: Dict[str, Any] = {}

    def resolve(x: Any) -> Any:
        if isinstance(x, (int, float, str)) and x in cache:
            return cache[x]
        if isinstance(x, str) and x in by_id:
            return eval_node(by_id[x])
        return x

    def eval_node(n: Node) -> Any:
        if n.node_id in cache:
            return cache[n.node_id]
        op = n.op
        args = n.args

        if op == "const":
            val = args["value"]
        elif op == "get":
            key = args["key"]
            if key not in state:
                raise KeyError(f"DAG get: missing state key '{key}'")
            val = state[key]
        elif op == "add":
            val = resolve(args["a"]) + resolve(args["b"])
        elif op == "mul":
            val = resolve(args["a"]) * resolve(args["b"])
        elif op == "max":
            val = max(resolve(args["a"]), resolve(args["b"]))
        elif op == "min":
            val = min(resolve(args["a"]), resolve(args["b"]))
        else:
            raise ValueError(f"Unknown DAG op: {op}")

        cache[n.node_id] = val
        return val

    out = dict(state)
    # convention: nodes with op 'set' may write state, but keep minimal.
    for n in nodes:
        if n.op == "set":
            key = n.args["key"]
            out[key] = resolve(n.args["value"])
    return out


# Back-compat alias
def evaluate_dag(*args, **kwargs):
    return eval_dag(*args, **kwargs)

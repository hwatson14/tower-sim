"""One-line command runner.

This is the minimal UX layer Harry asked for:

  - "Milestone t17"
  - "Farm t14"
  - "Champs"
  - "Legends"

It is intentionally fail-closed and does NOT attempt to be a full CLI.

Notes:
  - Tournament league tokens are resolved via refs/league_map.json.
  - Execution may still be blocked by recovery stubs (sim/engine.py) until
    mechanics engines are fully reconstructed.
"""

from __future__ import annotations

import argparse
import json
from dataclasses import asdict
from pathlib import Path

from cli.command_parser import parse_command
from sim.loader import load_entrypoint
from adapter.ids_presets import (
    load_ids_presets,
    select_card_preset_for_run,
    select_module_loadout_for_run,
)
from sim.validate import validate_all
from sim.engine import run_all, ExecutionBlocked
from adapter.account import IDSValidationError


def _read_json(path: str | None) -> dict:
    if not path:
        return {}
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"Missing JSON file: {p}")
    return json.loads(p.read_text(encoding="utf-8"))


def main() -> int:
    ap = argparse.ArgumentParser(description="Run TowerSim from a one-line command")
    ap.add_argument("command", help='e.g. "Milestone t17", "Farm t14", "Champs"')
    ap.add_argument("--ids", default=None, help="Path to _IDS.csv (defaults to refs/_IDS.csv)")
    ap.add_argument("--loadout", default=None, help="Path to loadout JSON (optional)")
    ap.add_argument("--out", default="out.json", help="Output JSON path")
    args = ap.parse_args()

    req = parse_command(args.command)

    # For now, we only surface the parsed request + ctx wiring.
    # Full loadout application is part of the adapter pipeline.

    loadout = _read_json(args.loadout) if args.loadout else None

    # If no explicit loadout JSON is provided, extract preset loadouts from _IDS.csv.
    # This is the intended one-user workflow: keep everything in the IDS export.
    default_ids = Path(__file__).resolve().parent / "refs" / "_IDS.csv"
    presets = load_ids_presets(args.ids or str(default_ids))

    run_kind = "farm" if req.objective == "farm" else ("tournament" if req.mode == "tournament" else "milestone")
    selected_modules = select_module_loadout_for_run(presets, run_kind)
    selected_cards = select_card_preset_for_run(presets, run_kind)

    out = {
        "request": req.to_dict(),
        "execution_blocked": False,
    }

    try:
        ctx = load_entrypoint(
            ids_path=args.ids,
            mode=req.mode,
            tier=int(req.tier) if req.tier is not None else 1,
            league=req.league,
        )
        ctx["objective"] = req.objective
        ctx["ids_presets"] = asdict(presets)
        ctx["selected_modules"] = asdict(selected_modules)
        ctx["selected_cards"] = asdict(selected_cards)
        if loadout is not None:
            ctx["loadout"] = loadout

        validate_all(ctx)

        out["ctx"] = {k: v for k, v in ctx.items() if k != "account_state_flat"}

        # Attempt execution (may be blocked in current recovery snapshot)
        try:
            result = run_all(ctx)
            out["result"] = result
        except ExecutionBlocked as e:
            out["execution_blocked"] = True
            out["execution_block_reason"] = str(e)

    except IDSValidationError as e:
        out["execution_blocked"] = True
        out["execution_block_reason"] = f"IDSValidationError: {e}"
    except Exception as e:
        out["execution_blocked"] = True
        out["execution_block_reason"] = f"UnhandledError: {type(e).__name__}: {e}"

    Path(args.out).write_text(json.dumps(out, indent=2), encoding="utf-8")
    print(f"Wrote {args.out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())


from cli.command_parser import parse
from sim.engine import run_all, ExecutionBlocked

def main():
    import sys
    cmd = sys.argv[1]
    try:
        run_all(parse(cmd))
    except ExecutionBlocked as e:
        print(f"BLOCKED: {e.reason}")

if __name__=="__main__":
    main()

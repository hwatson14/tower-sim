
def validate_all(ctx):
    return True

"""Global validation gates.

Design intent:
- Fail closed: if the repo is incomplete, validation should stop early and loudly.
- Validation is purely structural/contract-level here; it does not "infer" missing mechanics.

This file is deliberately conservative: it checks only what can be proven from
the assembled repo artifacts.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict


class ValidationError(RuntimeError):
    pass


def _require_path(p: Path, kind: str) -> None:
    if kind == "file" and not p.is_file():
        raise ValidationError(f"Missing required file: {p}")
    if kind == "dir" and not p.is_dir():
        raise ValidationError(f"Missing required directory: {p}")


def validate_all(ctx: Dict[str, Any]) -> None:
    """Validate the assembled repo + entry context.

    This does NOT validate gameplay correctness end-to-end.
    It validates:
    - required on-disk data structures exist
    - tournament policy gates (perks forbidden) are enforceable at the interface
    - ctx contains the minimum fields expected by the execution chain
    """

    # --- ctx shape ---
    for k in ("ids_path", "mode", "tier", "account_state_flat"):
        if k not in ctx:
            raise ValidationError(f"ctx missing required key: {k}")

    if ctx["mode"] not in {"tier", "tournament"}:
        raise ValidationError(f"Invalid ctx.mode: {ctx['mode']}")

    # --- repo data layout ---
    repo_root = Path(__file__).resolve().parents[1]
    _require_path(repo_root / "schemas", "dir")
    _require_path(repo_root / "bindings", "dir")
    _require_path(repo_root / "data" / "heat", "dir")
    _require_path(repo_root / "data" / "battle_conditions", "dir")

    # Heat must exist in some form.
    heat_files = list((repo_root / "data" / "heat").glob("**/*"))
    if not any(p.is_file() for p in heat_files):
        raise ValidationError("data/heat is present but empty")

    # Battle conditions must include tier packs.
    bc_root = repo_root / "data" / "battle_conditions"
    if not (bc_root / "tiers_14_17").is_dir():
        raise ValidationError("Missing BC pack: data/battle_conditions/tiers_14_17")
    if not (bc_root / "tiers_18_21").is_dir():
        raise ValidationError("Missing BC pack: data/battle_conditions/tiers_18_21")

    # --- tournament perk policy gate ---
    if ctx["mode"] == "tournament":
        # We cannot know all perk keys here, but we can block explicit perk::* keys
        # at the interface boundary.
        bad = [k for k in ctx["account_state_flat"].keys() if str(k).startswith("perk::")]
        if bad:
            raise ValidationError(
                "Perks are disabled in tournaments, but IDS contains perk::* keys: " + ", ".join(bad[:10])
            )

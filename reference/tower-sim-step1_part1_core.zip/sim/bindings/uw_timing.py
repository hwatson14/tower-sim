"""UW Timing Bindings

Maps specific Ultimate Weapons into timing primitives using the mechanics registry.
Fail-closed: if an equipped UW declares timing but has no registry entry, raise.
"""
from sim.engines.timing.primitives import AlwaysOn, Periodic, ProcEV
from sim.engines.timing.to_cc_source import timing_to_cc_source

def uw_to_cc_sources(equipped_uws, mechanics):
    cc_sources=[]
    timed=mechanics.get('timed_effects',{})
    for uw in equipped_uws:
        uw_id=uw['uw_id']
        if uw_id not in timed: continue
        spec=timed[uw_id]
        if spec.get('kind')!='cc': continue
        t=spec['type']
        if t=='always':
            timing=AlwaysOn()
        elif t=='periodic':
            timing=Periodic(spec['cooldown_s'], spec['duration_s'])
        elif t=='proc_ev':
            timing=ProcEV(spec['proc_rate_per_s'], spec['duration_s'])
        else:
            raise ValueError(f"Unknown timing type {t} for UW {uw_id}")
        src=timing_to_cc_source(f"uw:{uw_id}", timing, spec['cc_mult'])
        cc_sources.append({'source_id':src.source_id,'uptime':src.uptime,'mult':src.mult})
    return cc_sources

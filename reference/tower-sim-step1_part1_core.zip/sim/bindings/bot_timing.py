"""Bot Timing Bindings"""
from sim.engines.timing.primitives import Periodic, ProcEV
from sim.engines.timing.to_cc_source import timing_to_cc_source

def bots_to_cc_sources(bots, mechanics):
    cc_sources=[]
    timed=mechanics.get('timed_effects',{})
    for bot in bots:
        bot_id=bot['bot_id']
        if bot_id not in timed: continue
        spec=timed[bot_id]
        if spec.get('kind')!='cc': continue
        if spec['type']=='periodic':
            timing=Periodic(spec['cooldown_s'], spec['duration_s'])
        elif spec['type']=='proc_ev':
            timing=ProcEV(spec['proc_rate_per_s'], spec['duration_s'])
        else:
            continue
        src=timing_to_cc_source(f"bot:{bot_id}", timing, spec['cc_mult'])
        cc_sources.append({'source_id':src.source_id,'uptime':src.uptime,'mult':src.mult})
    return cc_sources

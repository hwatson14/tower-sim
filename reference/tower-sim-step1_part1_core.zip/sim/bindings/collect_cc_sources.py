"""Collect CC sources from loadout (UW + Bots + Guardians)"""
from sim.bindings.uw_timing import uw_to_cc_sources
from sim.bindings.bot_timing import bots_to_cc_sources
from sim.bindings.guardian_timing import guardians_to_cc_sources

def collect_cc_sources(loadout, mechanics):
    cc=[]
    cc+=uw_to_cc_sources(loadout.get('uws',[]), mechanics)
    cc+=bots_to_cc_sources(loadout.get('bots',[]), mechanics)
    cc+=guardians_to_cc_sources(loadout.get('guardians',[]), mechanics)
    return cc

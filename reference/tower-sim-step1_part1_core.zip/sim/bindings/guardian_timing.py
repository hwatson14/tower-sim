"""Guardian Timing Bindings"""
from sim.engines.timing.primitives import AlwaysOn, Periodic
from sim.engines.timing.to_cc_source import timing_to_cc_source

def guardians_to_cc_sources(guardians, mechanics):
    cc_sources=[]
    timed=mechanics.get('timed_effects',{})
    for g in guardians:
        gid=g['guardian_id']
        if gid not in timed: continue
        spec=timed[gid]
        if spec.get('kind')!='cc': continue
        if spec['type']=='always':
            timing=AlwaysOn()
        elif spec['type']=='periodic':
            timing=Periodic(spec['cooldown_s'], spec['duration_s'])
        else:
            continue
        src=timing_to_cc_source(f"guardian:{gid}", timing, spec['cc_mult'])
        cc_sources.append({'source_id':src.source_id,'uptime':src.uptime,'mult':src.mult})
    return cc_sources

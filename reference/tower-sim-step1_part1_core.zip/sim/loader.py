
def load_entrypoint():
    return {"status":"loaded"}

"""Repo entry loader.

Fail-closed contract:
- The ONLY external input is refs/_IDS.csv (unless overridden explicitly).
- All other artifacts must already exist inside the repo (CSV/JSON/YAML).
- Missing files => hard error with a specific message.

This module only assembles a minimal execution context (ctx).
Validation and execution happen in sim/validate.py and sim/engine.py.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Optional

from adapter.account import build_account_state


@dataclass(frozen=True)
class Ctx:
    ids_path: str
    mode: str  # "tier" | "tournament"
    tier: int
    league: Optional[str]
    account_state_flat: Dict[str, float]


def load_entrypoint(
    ids_path: str | None = None,
    mode: str = "tier",
    tier: int = 14,
    league: str | None = None,
) -> Dict[str, Any]:
    repo_root = Path(__file__).resolve().parents[1]
    default_ids = repo_root / "refs" / "_IDS.csv"
    ids_p = Path(ids_path) if ids_path else default_ids

    if not ids_p.exists():
        raise FileNotFoundError(f"Missing _IDS.csv at {ids_p}")

    if mode not in {"tier", "tournament"}:
        raise ValueError(f"Unknown mode: {mode}. Expected 'tier' or 'tournament'.")

    if not isinstance(tier, int) or tier < 1:
        raise ValueError(f"Invalid tier: {tier}. Expected positive int.")

    account_state_flat = build_account_state(str(ids_p))

    ctx = Ctx(
        ids_path=str(ids_p),
        mode=mode,
        tier=tier,
        league=league,
        account_state_flat=account_state_flat,
    )

    # Keep ctx serializable (dataclass -> dict)
    return {
        "ids_path": ctx.ids_path,
        "mode": ctx.mode,
        "tier": ctx.tier,
        "league": ctx.league,
        "account_state_flat": ctx.account_state_flat,
    }

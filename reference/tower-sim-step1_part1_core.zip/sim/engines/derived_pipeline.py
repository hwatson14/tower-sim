"""Derived Stats Pipeline (updated with CC sources wiring)

Adds:
  - cc_uptime
  - cc_effect_mult

Source of CC inputs:
  account_state may supply `cc_sources` as a list of dicts:
    - source_id
    - uptime
    - mult

If not supplied, defaults to no CC.
"""

from sim.engines.workshop_growth_engine import evolve_workshop_levels
from sim.engines.skip_engine import map_effective_waves
from sim.engines.perk_engine import get_active_perks, apply_perk_effects
from sim.engines.cc_sources import CCSource, combine_cc_sources

def derived_stats_fn_factory(base_stats, workshop_cfg, perk_plan, skip_cfg, cc_sources=None):
    levels = workshop_cfg["levels"]
    caps = workshop_cfg["caps"]
    free_per_wave = workshop_cfg["free_upgrades_per_wave"]

    # Normalize cc sources at factory time (stable)
    cc_srcs = []
    if cc_sources:
        for s in cc_sources:
            cc_srcs.append(CCSource(
                source_id=str(s.get("source_id","unknown")),
                uptime=float(s.get("uptime", 0.0)),
                mult=float(s.get("mult", 1.0)),
            ))
    cc_u, cc_m = combine_cc_sources(cc_srcs)

    def fn(wave):
        grown = evolve_workshop_levels(levels, caps, free_per_wave, wave)
        wa, wh = map_effective_waves(wave, skip_cfg["eals"], skip_cfg["ehls"], skip_cfg.get("ramp"))

        stats = base_stats.copy()
        stats.update({
            "workshop_levels": grown,
            "wave_attack": wa,
            "wave_health": wh,
            # CC timing inputs consumed by non-boss combat
            "cc_uptime": cc_u,
            "cc_effect_mult": cc_m,
        })

        perks = get_active_perks(wave, perk_plan)
        stats = apply_perk_effects(stats, perks)
        return stats

    return fn

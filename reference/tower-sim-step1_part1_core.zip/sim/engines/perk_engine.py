"""FAIL-CLOSED STUB: module not recovered.

This exists to keep the workspace importable.
Any call will raise with an explicit message.
"""

class RecoveryMissing(RuntimeError):
    pass

def get_active_perks(*args, **kwargs):
    raise RecoveryMissing('Missing implementation: perk_engine.py::get_active_perks. See docs/RECOVERY_GAPS.md')

def apply_perk_effects(*args, **kwargs):
    raise RecoveryMissing('Missing implementation: perk_engine.py::apply_perk_effects. See docs/RECOVERY_GAPS.md')

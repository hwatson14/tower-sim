"""Timing primitives

These are generic, reusable timing models for effects that are not always active:
- periodic (cooldown + duration)
- always-on
- probabilistic proc (rate + duration) in EV form

This layer is intentionally game-agnostic. Game mechanics map INTO these primitives.
"""

from __future__ import annotations
from dataclasses import dataclass
from typing import Optional

@dataclass(frozen=True)
class AlwaysOn:
    """Effect always active."""
    mult: float = 1.0  # generic parameter (e.g., DPS mult while active)

    def uptime(self) -> float:
        return 1.0

@dataclass(frozen=True)
class Periodic:
    """Periodic effect with cooldown and duration."""
    cooldown_s: float
    duration_s: float
    mult: float = 1.0  # generic parameter while active

    def uptime(self) -> float:
        if self.cooldown_s <= 0:
            return 1.0
        d = max(0.0, self.duration_s)
        c = max(0.0, self.cooldown_s)
        return min(1.0, d / c) if c > 0 else 1.0

@dataclass(frozen=True)
class ProcEV:
    """EV model of a proc-based effect.

    Example: 'freeze' procs with probability p per second and lasts duration_s.
    We approximate uptime as min(1, lambda * duration_s) where lambda is expected proc rate.
    """
    proc_rate_per_s: float
    duration_s: float
    mult: float = 1.0

    def uptime(self) -> float:
        lam = max(0.0, self.proc_rate_per_s)
        d = max(0.0, self.duration_s)
        return min(1.0, lam * d)

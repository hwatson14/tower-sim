# Timing Framework

Question: "Is UW, bot, and guardian timing included?"

**Answer (current state):**
- We now have a generic timing framework that can model:
  - cooldown/duration periodic effects (typical UW / guardian patterns)
  - always-on effects (passives)
  - proc-based effects (bots, freeze procs) in EV form

**What this is not (yet):**
- It does NOT hardcode Chrono Field / specific bots / specific guardians numbers.
  Those come from the authoritative mechanics library (Effective Paths + wiki).
  This layer just provides the time math.

Next step:
- Implement "timed_sources_extract.py" that reads the authoritative tables
  and instantiates these timing primitives for each equipped UW/Bot/Guardian.

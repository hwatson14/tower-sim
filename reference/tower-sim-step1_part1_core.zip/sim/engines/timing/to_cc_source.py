"""Map timing primitives to CCSource inputs.

This is the bridge between timed effects (UW/Bot/Guardian/etc) and the CC system.
"""

from __future__ import annotations
from dataclasses import dataclass
from typing import Union

from sim.engines.cc_sources import CCSource
from sim.engines.timing.primitives import AlwaysOn, Periodic, ProcEV

Timing = Union[AlwaysOn, Periodic, ProcEV]

def timing_to_cc_source(source_id: str, timing: Timing, cc_mult: float) -> CCSource:
    # cc_mult here means enemy DPS multiplier while the CC effect is active
    u = timing.uptime()
    return CCSource(source_id=source_id, uptime=u, mult=cc_mult)

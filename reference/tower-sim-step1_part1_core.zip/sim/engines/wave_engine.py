"""Wave Progression Engine (Combat + Econ)

Integrates combat resolution with economy accumulation.
"""

from sim.engines.combat_engine import simulate_boss
from sim.engines.nonboss_combat_engine import simulate_nonboss_wave
from sim.engines.econ_engine import accumulate_econ

def run_waves(account_state, derived_stats_fn, wave_tables, econ_tables, config):
    wave = 1
    max_wave = config.get("max_wave", 100000)
    boss_every = config.get("boss_every", 10)
    wave_duration = config.get("wave_duration", 1.0)

    econ = {"coins": 0.0, "cells": 0.0}

    while wave <= max_wave:
        derived = derived_stats_fn(wave)

        # Combat
        if wave % boss_every == 0:
            boss = wave_tables.get_boss_stats(wave, config)
            outcome = simulate_boss(derived, boss)
        else:
            enemy = wave_tables.get_enemy_stats(wave, config)
            outcome = simulate_nonboss_wave(derived, enemy, wave_duration)

        if not outcome["survives"]:
            return {
                "terminal_wave": wave,
                "econ": econ
            }

        # Econ accumulation only if survived
        econ = accumulate_econ(econ, wave, econ_tables, derived)
        wave += 1

    return {
        "terminal_wave": max_wave,
        "econ": econ
    }

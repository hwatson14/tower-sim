"""Timed sources extraction (UW/Bot/Guardian → timing primitives)

This is the game-specific mapping layer. It is intentionally fail-closed.

It expects that the authoritative mechanics registry provides, for each source:
  - cooldown_s (if periodic)
  - duration_s (if periodic)
  - proc_rate_per_s (if proc-based)
  - effect strength parameters (e.g., enemy DPS multiplier)

In this scaffold we only implement the interface and validation,
because the authoritative lookup tables live in the spec pack.

This module will be completed by binding to mechanics_library.yaml and entity catalogs.
"""

from __future__ import annotations
from typing import Dict, List, Any

from sim.engines.timing.primitives import AlwaysOn, Periodic, ProcEV
from sim.engines.timing.to_cc_source import timing_to_cc_source

def extract_cc_sources_from_loadout(loadout: Dict[str, Any], mechanics: Dict[str, Any]) -> List[dict]:
    """Return list of cc_sources dicts suitable for account_state['cc_sources']

    Args:
      loadout: includes equipped UWs, bots, guardians
      mechanics: authoritative mechanics registry (parsed YAML)

    Returns:
      List[dict] with keys: source_id, uptime, mult
    """
    cc_sources = []

    # Example schema (placeholders):
    # loadout['uws'] = [{'uw_id': 'chrono_field', 'level_track': {...}}]
    # mechanics['timed_effects']['chrono_field'] = {'type':'periodic','cooldown_s':..., 'duration_s':..., 'cc_mult':...}

    timed = mechanics.get("timed_effects", {})
    for uw in loadout.get("uws", []):
        uw_id = uw.get("uw_id")
        if uw_id in timed and timed[uw_id].get("kind") == "cc":
            spec = timed[uw_id]
            ttype = spec.get("type")
            cc_mult = float(spec["cc_mult"])

            if ttype == "always":
                timing = AlwaysOn(mult=1.0)
            elif ttype == "periodic":
                timing = Periodic(cooldown_s=float(spec["cooldown_s"]), duration_s=float(spec["duration_s"]), mult=1.0)
            elif ttype == "proc_ev":
                timing = ProcEV(proc_rate_per_s=float(spec["proc_rate_per_s"]), duration_s=float(spec["duration_s"]), mult=1.0)
            else:
                raise ValueError(f"Unknown timing type for {uw_id}: {ttype}")

            src = timing_to_cc_source(f"uw:{uw_id}", timing, cc_mult)
            cc_sources.append({"source_id": src.source_id, "uptime": src.uptime, "mult": src.mult})

        elif uw_id is not None and uw_id not in timed:
            # fail-closed: if an equipped UW is expected to contribute CC but has no spec, raise
            # We can't know expectation here without more metadata, so we only warn by raising if explicitly flagged.
            if timed.get("_requires_complete", False):
                raise ValueError(f"Missing timed_effect spec for equipped UW: {uw_id}")

    # Similar loops for bots and guardians will be added once their timed_effects are populated.
    return cc_sources

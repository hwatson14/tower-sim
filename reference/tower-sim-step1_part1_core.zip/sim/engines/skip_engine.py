"""FAIL-CLOSED STUB: module not recovered.

This exists to keep the workspace importable.
Any call will raise with an explicit message.
"""

class RecoveryMissing(RuntimeError):
    pass

def map_effective_waves(*args, **kwargs):
    raise RecoveryMissing('Missing implementation: skip_engine.py::map_effective_waves. See docs/RECOVERY_GAPS.md')

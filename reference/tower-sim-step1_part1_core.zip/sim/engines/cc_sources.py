"""CC Sources → (cc_uptime, cc_effect_mult)

Purpose:
  Convert multiple crowd-control sources (each with uptime + multiplier) into
  a single pair (cc_uptime, cc_effect_mult) for the CC timing engine.

Why this exists:
  The combat layer wants *time structure* (some of the wave is controlled, some is not).
  Individual sources may overlap, so we need an aggregation rule.

Model (explicit, adjustable):
  Each CC source i is represented as:
    - uptime u_i in [0,1]  (fraction of wave where the source is active)
    - mult  m_i >= 0       (enemy DPS multiplier while active, e.g. 0.2 means 80% reduction)
  Sources are treated as *independent* for overlap probability (EV approximation).

Aggregation:
  - Probability at least one CC active (union):
      u = 1 - Π(1 - u_i)
  - Expected multiplicative DPS multiplier across all sources:
      E[M] = Π( u_i*m_i + (1-u_i)*1 )
  - Conditional multiplier during 'CC-active' window:
      m = (E[M] - (1-u)*1) / u     if u>0 else 1

This maps the full EV mixture into a 2-window representation:
  - with probability u: apply multiplier m
  - with probability (1-u): apply multiplier 1
"""

from __future__ import annotations
from dataclasses import dataclass
from typing import Iterable, Tuple
import math

@dataclass(frozen=True)
class CCSource:
    source_id: str
    uptime: float
    mult: float

    def normalized(self) -> "CCSource":
        u = max(0.0, min(1.0, float(self.uptime)))
        m = max(0.0, float(self.mult))
        return CCSource(self.source_id, u, m)

def combine_cc_sources(sources: Iterable[CCSource]) -> Tuple[float, float]:
    srcs = [s.normalized() for s in sources]
    if not srcs:
        return 0.0, 1.0

    # union uptime u = 1 - Π(1-u_i)
    prod_no = 1.0
    for s in srcs:
        prod_no *= (1.0 - s.uptime)
    u = 1.0 - prod_no
    u = max(0.0, min(1.0, u))

    # expected multiplier E[M] = Π( u_i*m_i + (1-u_i)*1 )
    em = 1.0
    for s in srcs:
        em *= (s.uptime * s.mult + (1.0 - s.uptime) * 1.0)

    if u <= 0.0:
        return 0.0, 1.0

    # conditional multiplier during CC-active window
    m = (em - (1.0 - u) * 1.0) / u
    # numeric safety
    m = max(0.0, m)
    return u, m

"""FAIL-CLOSED STUB: Combat engine not yet reconstructed.

This workspace contains:
- deterministic wave loop scaffolding
- econ engine scaffolding
- BC/heat ingestion + validation

But the full combat resolution engine (damage/cc/targeting/enemy behaviors)
was not present in recovered bundles. This file exists to prevent import-time
crashes and to fail closed with an explicit error.

Recovery action required:
- Reconstruct combat engine from Effective Paths + wiki mechanics and/or
  recover missing modules from prior bundles.

Do NOT implement approximations here.
"""

class CombatEngineMissing(RuntimeError):
    pass

def simulate_boss(*args, **kwargs):
    raise CombatEngineMissing("combat_engine.simulate_boss is missing; recovery required. See docs/RECOVERY_GAPS.md")


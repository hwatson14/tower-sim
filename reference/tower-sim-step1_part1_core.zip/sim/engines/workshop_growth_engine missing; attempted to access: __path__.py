"""FAIL-CLOSED STUB: sim.engines.workshop_growth_engine missing; attempted to access: __path__ not recovered.

This module is required by the recovered execution lineage but was not present
in the available bundles. It intentionally raises to avoid silent approximation.
"""

class RecoveryMissing(RuntimeError):
    pass

def __getattr__(name):
    raise RecoveryMissing("sim.engines.workshop_growth_engine missing; attempted to access: __path__ missing; attempted to access: " + str(name))

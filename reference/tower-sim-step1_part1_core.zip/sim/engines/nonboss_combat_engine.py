"""FAIL-CLOSED STUB: Non-boss combat engine not yet reconstructed.

See sim/engines/combat_engine.py for details.
"""
from .combat_engine import CombatEngineMissing

def simulate_nonboss_wave(*args, **kwargs):
    raise CombatEngineMissing("nonboss_combat_engine.simulate_nonboss_wave is missing; recovery required. See docs/RECOVERY_GAPS.md")

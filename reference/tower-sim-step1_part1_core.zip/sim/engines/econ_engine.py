"""Economy Engine (Coins & Cells)

Accumulates coins and cells per wave, conditional on survival.

Model:
- Deterministic EV model
- Per-wave yields from wave tables
- Multipliers from perks, labs, modules applied upstream in derived stats

This engine is PURE.
"""

def accumulate_econ(state, wave, econ_tables, derived_stats):
    """
    Args:
      state: dict with running totals {coins, cells}
      wave: int
      econ_tables: provides base yields per wave
      derived_stats: includes econ multipliers

    Returns:
      updated state
    """
    coins = state.get("coins", 0.0)
    cells = state.get("cells", 0.0)

    base = econ_tables.get_base_yields(wave)
    coin_mult = derived_stats.get("coin_mult", 1.0)
    cell_mult = derived_stats.get("cell_mult", 1.0)

    coins += base["coins"] * coin_mult
    cells += base["cells"] * cell_mult

    return {"coins": coins, "cells": cells}

"""FAIL-CLOSED STUB: module not recovered.

This exists to keep the workspace importable.
Any call will raise with an explicit message.
"""

class RecoveryMissing(RuntimeError):
    pass

def evolve_workshop_levels(*args, **kwargs):
    raise RecoveryMissing('Missing implementation: workshop_growth_engine.py::evolve_workshop_levels. See docs/RECOVERY_GAPS.md')

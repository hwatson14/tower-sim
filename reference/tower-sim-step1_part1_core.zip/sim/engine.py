"""Execution dispatch.

This repo currently contains:
- battle-conditions + heat ingestion/validation artifacts
- a partially recovered deterministic sim scaffold (sim/run_sim + wave loop)

But several mechanics engines (workshop growth, perks, skip, combat) are still
fail-closed stubs. Until those are reconstructed, we refuse to run a simulation.

The purpose of this dispatcher is to make that refusal explicit and actionable.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict


class ExecutionBlocked(RuntimeError):
    pass


def _has_recovery_stubs(repo_root: Path) -> list[str]:
    missing = []
    candidates = [
        repo_root / "sim" / "engines" / "workshop_growth_engine.py",
        repo_root / "sim" / "engines" / "skip_engine.py",
        repo_root / "sim" / "engines" / "perk_engine.py",
        repo_root / "sim" / "engines" / "combat_engine.py",
        repo_root / "sim" / "engines" / "nonboss_combat_engine.py",
    ]
    for p in candidates:
        if not p.is_file():
            missing.append(f"missing file: {p}")
            continue
        txt = p.read_text(encoding="utf-8", errors="replace")
        if "FAIL-CLOSED STUB" in txt or "RecoveryMissing" in txt or "CombatEngineMissing" in txt:
            missing.append(str(p))
    return missing


def run_all(ctx: Dict[str, Any]) -> Dict[str, Any]:
    repo_root = Path(__file__).resolve().parents[1]

    blockers = _has_recovery_stubs(repo_root)
    if blockers:
        gaps = repo_root / "docs" / "RECOVERY_GAPS.md"
        raise ExecutionBlocked(
            "Simulation execution is blocked because required mechanics engines are still fail-closed stubs.\n"
            "Blockers:\n  - " + "\n  - ".join(blockers) + "\n\n"
            f"See {gaps} for the authoritative gap list."
        )

    raise ExecutionBlocked(
        "Simulation execution wiring is not yet implemented in this recovery snapshot. "
        "Next: define a deterministic mapping from account_state_flat -> sim.run_sim account_state schema."
    )

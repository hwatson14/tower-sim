
class ExecutionBlocked(Exception):
    def __init__(self, reason):
        super().__init__(reason)
        self.reason = reason

def run_all(ctx):
    raise ExecutionBlocked("combat_engine_not_implemented")

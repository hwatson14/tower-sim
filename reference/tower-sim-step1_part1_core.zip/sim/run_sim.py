"""End-to-End Simulator Runner (updated for CC sources)

Wires CC sources into derived pipeline.
"""

from sim.engines.wave_engine import run_waves
from sim.engines.derived_pipeline import derived_stats_fn_factory

def run_sim(account_state, config):
    derived_fn = derived_stats_fn_factory(
        base_stats=account_state["base_stats"],
        workshop_cfg=account_state["workshop"],
        perk_plan=account_state.get("perk_plan", []),
        skip_cfg=config["skip"],
        cc_sources=account_state.get("cc_sources", None),
    )

    result = run_waves(
        account_state=account_state,
        derived_stats_fn=derived_fn,
        wave_tables=config["wave_tables"],
        econ_tables=config["econ_tables"],
        config=config["wave"]
    )
    return result

# State models mirror sim/state_models.yaml
class AccountState: pass
class RunState: pass
class WaveState: pass
class EnemyState: pass
class DerivedState: pass
class EventState: pass

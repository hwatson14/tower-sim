# Canonical runtime configuration.
# These paths MUST be provided by the caller. Missing files are fatal.

RUNTIME_PATHS = {
    "tier_wave_damage_csv": "data/tier_wave_damage.csv",
    "tournament_wave_damage_csv": "data/tournament_wave_damage.csv",
    "battle_conditions_csv": "data/battle_conditions.csv",  # pending promotion
    "heat_table_csv": "data/heat.csv",                      # pending promotion
    "dag_json": "data/dag.json",                            # pending promotion
}

RUNTIME_PATHS['heat_wave_scalar_csv']='data/heat_wave_scalar.csv'

RUNTIME_PATHS['battle_condition_magnitudes_csv']='data/battle_condition_magnitudes.csv'

RUNTIME_PATHS['dag_json']='data/dag.json'

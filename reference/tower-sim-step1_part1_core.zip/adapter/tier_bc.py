
class TierBCValidationError(Exception):
    pass

# tier_ctx expected:
# {
#   "tier": int,
#   "battle_conditions": [str, ...],
#   "mode": "tier" | "tournament"
# }

def apply_tier_and_bc(state, tier_ctx, tiers_table, bc_table):
    if "tier" not in tier_ctx:
        raise TierBCValidationError("tier_ctx missing tier")
    tier = tier_ctx["tier"]
    mode = tier_ctx.get("mode", "tier")

    # apply tier scaling
    if tier not in tiers_table:
        raise TierBCValidationError(f"Unknown tier: {tier}")

    scaled = dict(state)
    for k, v in tiers_table[tier].items():
        scaled[k] = scaled.get(k, 0) + v

    # apply battle conditions
    bcs = tier_ctx.get("battle_conditions", [])
    if not isinstance(bcs, list):
        raise TierBCValidationError("battle_conditions must be list")

    for bc in bcs:
        if bc not in bc_table:
            raise TierBCValidationError(f"Unknown battle condition: {bc}")
        effects = bc_table[bc]
        for stat, delta in effects.items():
            scaled[stat] = scaled.get(stat, 0) + delta

    # tournament hard gate: no perks
    if mode == "tournament":
        for k in scaled:
            if k.startswith("perk::"):
                raise TierBCValidationError("Perks are disabled in tournaments")

    return scaled

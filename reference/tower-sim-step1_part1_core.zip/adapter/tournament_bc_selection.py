"""Tournament battle-condition set selection.

Why this exists
--------------
Tournament heat scales by wave, but the run does *not* apply every battle
condition simultaneously. A league defines a small set:

* Always: "More Bosses".
* Platinum+: either "Death Defy Down" or "Energy Shields Down".
* Plus N additional *random* battle conditions, where N depends on league.

These semantics are documented on The Tower community wiki (secondary source).

Fail-closed rules
-----------------
* If the league rule is unknown -> error.
* If a required bc_id is not present in the tournament magnitude table -> error.
* If the random-pool size is insufficient -> error.

This module intentionally does **not** decide probabilities for BCs. It only
enumerates possible BC sets (for expected-value evaluation) or samples
deterministically when asked.
"""

from __future__ import annotations

from dataclasses import dataclass
from itertools import combinations
from typing import Iterable, List, Sequence, Set, Tuple


@dataclass(frozen=True)
class LeagueRule:
    league: str
    random_bc_count: int
    has_dd_or_es: bool
    has_more_bosses: bool = True


DEFAULT_LEAGUE_RULES: dict[str, LeagueRule] = {
    # Copper has no "heat" random BCs per wiki; only boss frequency.
    "copper": LeagueRule("copper", random_bc_count=0, has_dd_or_es=False),
    "silver": LeagueRule("silver", random_bc_count=1, has_dd_or_es=False),
    "gold": LeagueRule("gold", random_bc_count=2, has_dd_or_es=False),
    "platinum": LeagueRule("platinum", random_bc_count=3, has_dd_or_es=True),
    "champion": LeagueRule("champion", random_bc_count=4, has_dd_or_es=True),
    "legend": LeagueRule("legend", random_bc_count=5, has_dd_or_es=True),
}


def _require(condition: bool, msg: str) -> None:
    if not condition:
        raise ValueError(msg)


def enumerate_tournament_bc_sets(
    *,
    league: str,
    available_bc_ids: Iterable[str],
    random_pool_bc_ids: Iterable[str] | None = None,
) -> List[Tuple[str, ...]]:
    """Enumerate all BC sets possible for a given league.

    Returns a list of sorted tuples of bc_id.

    Parameters
    ----------
    league:
        One of: copper, silver, gold, platinum, champion, legend.

    available_bc_ids:
        All bc_ids that have numeric magnitude coverage in the tournament
        magnitude table.

    random_pool_bc_ids:
        Optional explicit random pool. If omitted, defaults to
        (available_bc_ids minus fixed BCs).
    """

    league_key = league.strip().lower()
    _require(league_key in DEFAULT_LEAGUE_RULES, f"Unknown league: {league!r}")
    rule = DEFAULT_LEAGUE_RULES[league_key]

    available: Set[str] = {str(x) for x in available_bc_ids}

    fixed: List[str] = []
    if rule.has_more_bosses:
        _require("more_bosses" in available, "Missing required bc_id: more_bosses")
        fixed.append("more_bosses")

    dd_es_choices: List[Tuple[str, ...]] = [tuple()]
    if rule.has_dd_or_es:
        _require(
            "death_defy_down" in available and "energy_shields_down" in available,
            "Missing required bc_ids for dd/es choice",
        )
        dd_es_choices = [("death_defy_down",), ("energy_shields_down",)]

    if random_pool_bc_ids is None:
        # Default pool: everything except the fixed/choice BCs.
        pool = available - {"more_bosses", "death_defy_down", "energy_shields_down"}
    else:
        pool = {str(x) for x in random_pool_bc_ids}

    _require(
        len(pool) >= rule.random_bc_count,
        f"Random BC pool too small for {league_key}: need {rule.random_bc_count}, have {len(pool)}",
    )

    out: List[Tuple[str, ...]] = []
    for dd_es in dd_es_choices:
        for combo in combinations(sorted(pool), rule.random_bc_count):
            bc_set = tuple(sorted(tuple(fixed) + tuple(dd_es) + tuple(combo)))
            out.append(bc_set)

    # De-dup (shouldn't be necessary) and sort deterministically.
    out = sorted(set(out))
    return out

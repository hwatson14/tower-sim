import csv
from pathlib import Path
from typing import Dict, Any, Optional, Set, Tuple


class IDSValidationError(Exception):
    pass


# Supported KV headers
KV_HEADERS_1 = ("key", "value")
KV_HEADERS_2 = ("FieldName", "Value")


def _load_allowed_field_names(spec_path: Path) -> Optional[Set[str]]:
    if not spec_path.exists():
        return None
    import json
    try:
        spec = json.loads(spec_path.read_text(encoding="utf-8"))
    except Exception as e:
        raise IDSValidationError(f"Failed to parse IDS ABI spec JSON: {spec_path}") from e
    try:
        names = spec["fields"]["allowed_field_names"]
        if not isinstance(names, list) or not all(isinstance(x, str) for x in names):
            raise TypeError("allowed_field_names must be a list[str]")
        return set(names)
    except Exception as e:
        raise IDSValidationError(f"Malformed IDS ABI spec JSON (allowed_field_names): {spec_path}") from e


def _parse_kv(ids_path: Path) -> Dict[str, float]:
    # Accept either {key,value} or {FieldName,Value}
    with ids_path.open(newline="", encoding="utf-8", errors="replace") as f:
        reader = csv.DictReader(f)
        headers = tuple(reader.fieldnames or [])
        if headers == KV_HEADERS_1:
            kcol, vcol = "key", "value"
        elif headers == KV_HEADERS_2:
            kcol, vcol = "FieldName", "Value"
        else:
            raise IDSValidationError(
                f"IDS KV format header mismatch. Expected {KV_HEADERS_1} or {KV_HEADERS_2}; got {headers}"
            )

        state: Dict[str, float] = {}
        for row in reader:
            k = (row.get(kcol) or "").strip()
            v = (row.get(vcol) or "").strip()
            if not k:
                raise IDSValidationError("Blank IDS key")
            if k in state:
                raise IDSValidationError(f"Duplicate IDS key: {k}")
            try:
                state[k] = float(v)
            except Exception as e:
                raise IDSValidationError(f"Non-numeric IDS value for '{k}': {v}") from e
        return dict(sorted(state.items()))


def _parse_wide(ids_path: Path, parse_map_path: Path, raw_header_lock_path: Optional[Path]) -> Dict[str, float]:
    """Fail-closed wide export parser.

    - Requires explicit mapping (ids_parse_map.yaml).
    - Optionally enforces raw header lock if provided.
    """
    try:
        import yaml  # type: ignore
        import pandas as pd  # type: ignore
    except Exception as e:
        raise IDSValidationError(
            "Wide IDS parsing requires PyYAML + pandas. Install them or provide KV IDS format."
        ) from e

    # Load mapping
    try:
        m = yaml.safe_load(parse_map_path.read_text(encoding="utf-8"))
    except Exception as e:
        raise IDSValidationError(f"Failed to parse ids_parse_map.yaml: {parse_map_path}") from e
    if not isinstance(m, dict) or "extract_rules" not in m:
        raise IDSValidationError(f"Invalid ids_parse_map.yaml shape: {parse_map_path}")

    # Read CSV with headers to preserve 'Unnamed: N' columns and friends
    try:
        df = pd.read_csv(ids_path)
    except Exception as e:
        raise IDSValidationError(f"Failed to read wide IDS CSV: {ids_path}") from e

    # Optional: raw header lock enforcement
    if raw_header_lock_path and raw_header_lock_path.exists():
        try:
            lock_df = pd.read_csv(raw_header_lock_path, header=None)
            # Expect single-row header lock
            locked = [str(x) for x in lock_df.iloc[0].tolist()]
            current = [str(x) for x in df.columns.tolist()]
            if locked != current:
                raise IDSValidationError(
                    "Wide IDS header drift detected against IDS_ABI_LOCKED_RAW_v1.csv. "
                    "Refuse to parse without updating the lock artifacts."
                )
        except IDSValidationError:
            raise
        except Exception as e:
            raise IDSValidationError(f"Failed to enforce IDS header lock: {raw_header_lock_path}") from e

    seen: Dict[str, float] = {}
    rules = m.get("extract_rules", [])
    if not isinstance(rules, list):
        raise IDSValidationError("ids_parse_map.yaml extract_rules must be a list")

    for rule in rules:
        if not isinstance(rule, dict):
            raise IDSValidationError("ids_parse_map.yaml contains a non-dict rule")
        kind = rule.get("kind")

        if kind == "stat_value_block":
            stat_col = rule.get("stat_col")
            val_col = rule.get("value_col")
            if not isinstance(stat_col, str) or not isinstance(val_col, str):
                raise IDSValidationError("stat_value_block requires stat_col and value_col as column names (str)")
            header_rows = int(rule.get("header_rows", 0))

            if stat_col not in df.columns or val_col not in df.columns:
                raise IDSValidationError(
                    f"Wide IDS mapping columns not found. Required: {stat_col}, {val_col}. "
                    f"Available columns: {list(df.columns)[:20]}..."
                )

            # Iterate from header_rows onward; stop only when table ends naturally.
            sub = df.iloc[header_rows:]
            for _, row in sub.iterrows():
                k = row.get(stat_col)
                v = row.get(val_col)

                if not isinstance(k, str):
                    continue
                kk = k.strip()
                if not kk or kk.lower() in {"stat"}:
                    continue

                if kk in seen:
                    # Require identical value if duplicate key encountered
                    try:
                        vv = float(v)
                    except Exception:
                        raise IDSValidationError(f"Non-numeric IDS value for '{kk}': {v}")
                    if seen[kk] != vv:
                        raise IDSValidationError(f"Conflicting values for {kk}: {seen[kk]} vs {vv}")
                    continue

                try:
                    seen[kk] = float(v)
                except Exception as e:
                    raise IDSValidationError(f"Non-numeric IDS value for '{kk}': {v}") from e
        else:
            raise IDSValidationError(f"Unknown extract rule kind: {kind}")

    return dict(sorted(seen.items()))


def build_account_state(ids_path: str) -> Dict[str, float]:
    """Build the account-state registry from _IDS.csv.

    Supported formats:
    1) Canonical KV ABI: columns {key,value} OR {FieldName,Value}
    2) Wide export: requires refs/ids_parse_map.yaml (resurrected contract)
       Optionally enforces refs/ids_abi_lock/IDS_ABI_LOCKED_RAW_v1.csv
    """
    ids_p = Path(ids_path)

    # Determine format by header row
    with ids_p.open("r", encoding="utf-8", errors="replace") as f:
        header = f.readline().strip("\n").strip("\r")

    # KV path
    if header.startswith("key,value") or header.startswith("FieldName,Value"):
        kv = _parse_kv(ids_p)
    else:
        # Wide path
        repo_root = ids_p.resolve().parent.parent  # refs/.. -> repo root
        parse_map = repo_root / "refs" / "ids_parse_map.yaml"
        if not parse_map.exists():
            raise IDSValidationError(
                "Wide IDS format detected but refs/ids_parse_map.yaml is missing. "
                "Provide KV IDS or restore ids_parse_map.yaml."
            )
        raw_lock = repo_root / "refs" / "ids_abi_lock" / "IDS_ABI_LOCKED_RAW_v1.csv"
        kv = _parse_wide(ids_p, parse_map, raw_lock)

    # Optional: enforce ABI allowed-field whitelist (if present)
    repo_root = ids_p.resolve().parent.parent
    abi_spec = repo_root / "refs" / "IDS_ABI_LOCK_v1.0.0.json"
    allowed = _load_allowed_field_names(abi_spec)
    if allowed is not None:
        unknown = sorted([k for k in kv.keys() if k not in allowed])
        if unknown:
            raise IDSValidationError(
                f"IDS contains {len(unknown)} fields not in locked ABI whitelist (IDS_ABI_LOCK_v1.0.0.json). "
                f"First 10: {unknown[:10]}"
            )

    return kv

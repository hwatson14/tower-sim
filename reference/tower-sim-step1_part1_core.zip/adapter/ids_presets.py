"""Parse run presets (farm/milestone/tournament) from the wide _IDS.csv export.

This is NOT the numeric account-state parser. It extracts *structured* presets:
  - farming tier
  - tournament league
  - module loadouts for: farming, tournament, milestone (if present)

Fail-closed rules:
  - If a requested preset is missing, raise IDSValidationError with a precise message.
  - No inference across presets (e.g., do not default milestone= farming).
"""

from __future__ import annotations

import csv
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from adapter.account import IDSValidationError


# Column positions in the current _IDS export where module slot blocks live.
# These positions are defined by the export template and are validated by
# finding a header row with the expected context tokens.
MODULE_SLOT_COLS = (53, 58, 63, 68)  # Cannon, Armor, Generator, Core

# Card preset columns in the current _IDS export ("Cards Presets" table)
CARD_PRESET_START_COL = 33
CARD_PRESET_END_COL = 37  # inclusive


@dataclass(frozen=True)
class ModuleSlotLoadout:
    primary: str
    assist: Optional[str]


@dataclass(frozen=True)
class ModuleLoadout:
    cannon: ModuleSlotLoadout
    armor: ModuleSlotLoadout
    generator: ModuleSlotLoadout
    core: ModuleSlotLoadout


@dataclass(frozen=True)
class CardPreset:
    cards: List[str]


@dataclass(frozen=True)
class IDSPresets:
    farming_tier: Optional[int]
    tournament_league: Optional[str]
    module_farming: Optional[ModuleLoadout]
    module_tournament: Optional[ModuleLoadout]
    module_milestone: Optional[ModuleLoadout]
    card_presets: Dict[str, CardPreset]


def _read_rows(ids_path: Path) -> List[List[str]]:
    with ids_path.open(newline="", encoding="utf-8", errors="replace") as f:
        return [[(c or "").strip() for c in row] for row in csv.reader(f)]


def _parse_trailing_stat_value(rows: List[List[str]]) -> Dict[str, str]:
    """Extract the *trailing* (Stat, Value) kv pair from each row.

    In the provided export, row[81] = Stat, row[82] = Value for many rows.
    Not all rows populate these fields.
    """
    out: Dict[str, str] = {}
    for r in rows:
        if len(r) < 83:
            continue
        k = (r[81] or "").strip()
        v = (r[82] or "").strip()
        if not k:
            continue
        if k in out:
            raise IDSValidationError(f"Duplicate trailing Stat key in IDS export: {k}")
        out[k] = v
    return out


def _find_block(rows: List[List[str]], token: str) -> int:
    """Find the header row that declares a module primary-slot block for a token.

    We expect the header row to contain the token in each MODULE_SLOT_COLS position.
    Returns header_row_index.
    """
    for i, r in enumerate(rows):
        ok = True
        for c in MODULE_SLOT_COLS:
            if c >= len(r) or r[c] != token:
                ok = False
                break
        if ok:
            if i + 1 >= len(rows):
                raise IDSValidationError(f"IDS export ends after {token} header row; missing data row")
            return i
    raise IDSValidationError(
        f"Missing module primary-slot header row for token '{token}'. "
        f"Expected '{token}' at columns {MODULE_SLOT_COLS}."
    )


def _parse_modules_from_rows(primary_row: List[str], assist_row: List[str]) -> ModuleLoadout:
    """Parse a (Primary Slot) row and an (Assist Slot) row into a ModuleLoadout.

    Primary module names are required.
    Assist module names may be blank (interpreted as None) but the slot label must be present.
    """

    slots: List[ModuleSlotLoadout] = []
    for c in MODULE_SLOT_COLS:
        if c + 1 >= len(primary_row) or c + 1 >= len(assist_row):
            raise IDSValidationError("Malformed IDS module rows: missing module value cell")

        p_label = (primary_row[c] or "").strip()
        p_name = (primary_row[c + 1] or "").strip()
        if p_label != "Primary Slot":
            raise IDSValidationError(
                f"Malformed IDS module primary row: expected 'Primary Slot' at col {c}, got {p_label!r}"
            )
        if not p_name:
            raise IDSValidationError(f"Blank primary module name at col {c+1}")

        a_label = (assist_row[c] or "").strip()
        a_name = (assist_row[c + 1] or "").strip()
        if a_label != "Assist Slot":
            raise IDSValidationError(
                f"Malformed IDS module assist row: expected 'Assist Slot' at col {c}, got {a_label!r}"
            )
        assist = a_name if a_name else None
        slots.append(ModuleSlotLoadout(primary=p_name, assist=assist))

    return ModuleLoadout(cannon=slots[0], armor=slots[1], generator=slots[2], core=slots[3])


def _parse_card_presets(rows: List[List[str]]) -> Dict[str, CardPreset]:
    """Parse the "Cards Presets" table.

    Export shape:
      row0 col33 = 'Cards Presets'
      row1 col33..col37 = preset names (e.g. Farming, Tourney, Preset 3, ...)
      subsequent rows: each preset column contains a card name (or blank)

    Fail-closed:
      - missing table header -> error
      - duplicate preset names -> error
      - unknown card names (not present in the main card list) -> error
    """

    # Collect allowed card names from the main "Cards" list (col30, rows >=1)
    allowed_cards: set[str] = set()
    for r in rows[1:]:
        if len(r) > 30:
            name = (r[30] or "").strip()
            if name and name.lower() not in {"cards", "cards presets"}:
                allowed_cards.add(name)

    # Find the header row where col33 == 'Cards Presets'
    hdr_idx = None
    for i, r in enumerate(rows):
        if len(r) > CARD_PRESET_START_COL and (r[CARD_PRESET_START_COL] or "").strip() == "Cards Presets":
            hdr_idx = i
            break
    if hdr_idx is None:
        raise IDSValidationError("Missing 'Cards Presets' table in _IDS.csv")
    if hdr_idx + 1 >= len(rows):
        raise IDSValidationError("Malformed 'Cards Presets' table: missing preset-name header row")

    preset_names_row = rows[hdr_idx + 1]
    preset_names: List[str] = []
    for c in range(CARD_PRESET_START_COL, CARD_PRESET_END_COL + 1):
        if c >= len(preset_names_row):
            preset_names.append("")
            continue
        preset_names.append((preset_names_row[c] or "").strip())

    out: Dict[str, CardPreset] = {}
    for idx, name in enumerate(preset_names):
        if not name:
            continue
        if name in out:
            raise IDSValidationError(f"Duplicate card preset name in _IDS.csv: {name}")
        out[name] = CardPreset(cards=[])

    # Parse card names down the columns until we hit a fully empty row segment.
    for r in rows[hdr_idx + 2 :]:
        # stop if all preset columns are blank
        seg = []
        for c in range(CARD_PRESET_START_COL, CARD_PRESET_END_COL + 1):
            seg.append((r[c] if c < len(r) else "") or "")
        if all((s.strip() == "") for s in seg):
            break

        for col_offset, preset in enumerate(preset_names):
            if not preset:
                continue
            c = CARD_PRESET_START_COL + col_offset
            val = (r[c] if c < len(r) else "")
            card = (val or "").strip()
            if not card:
                continue
            if allowed_cards and card not in allowed_cards:
                raise IDSValidationError(f"Unknown card name in preset '{preset}': {card!r}")
            out[preset].cards.append(card)

    return out


def load_ids_presets(ids_path: str) -> IDSPresets:
    ids_p = Path(ids_path)
    if not ids_p.exists():
        raise FileNotFoundError(f"Missing _IDS.csv at {ids_p}")

    rows = _read_rows(ids_p)

    # Trailing kvs (tiers/leagues etc.)
    kv = _parse_trailing_stat_value(rows)

    farming_tier: Optional[int] = None
    if "Farming Tier" in kv:
        m = kv["Farming Tier"].strip()
        # Expect 'Tier 14' format
        if not m.lower().startswith("tier "):
            raise IDSValidationError(f"Unexpected Farming Tier value: {m!r}")
        try:
            farming_tier = int(m.split()[1])
        except Exception as e:
            raise IDSValidationError(f"Failed to parse Farming Tier: {m!r}") from e

    tournament_league = kv.get("Tourney League")
    if tournament_league:
        tournament_league = tournament_league.strip()

    # Card presets
    card_presets = _parse_card_presets(rows)

    # Module loadouts (primary + assist)
    module_farming = None
    module_tournament = None
    module_milestone = None

    # The export uses distinct header rows for these contexts.
    for token, attr in (
        ("Farming", "module_farming"),
        ("Tourney", "module_tournament"),
        ("Testing", "module_milestone"),  # used as Milestone preset in this export
    ):
        try:
            hdr_i = _find_block(rows, token)
        except IDSValidationError:
            continue
        if hdr_i + 2 >= len(rows):
            raise IDSValidationError(f"IDS export ends after {token} module rows; expected primary+assist rows")
        primary_row = rows[hdr_i + 1]
        assist_row = rows[hdr_i + 2]
        loadout = _parse_modules_from_rows(primary_row, assist_row)
        if attr == "module_farming":
            module_farming = loadout
        elif attr == "module_tournament":
            module_tournament = loadout
        else:
            module_milestone = loadout

    return IDSPresets(
        farming_tier=farming_tier,
        tournament_league=tournament_league,
        module_farming=module_farming,
        module_tournament=module_tournament,
        module_milestone=module_milestone,
        card_presets=card_presets,
    )


def select_module_loadout_for_run(presets: IDSPresets, run_kind: str) -> ModuleLoadout:
    """run_kind: 'farm' | 'milestone' | 'tournament'"""
    if run_kind == "farm":
        if presets.module_farming is None:
            raise IDSValidationError("IDS missing Farming module loadout block")
        return presets.module_farming
    if run_kind == "milestone":
        if presets.module_milestone is None:
            raise IDSValidationError("IDS missing Milestone module loadout block (expected 'Testing' block)")
        return presets.module_milestone
    if run_kind == "tournament":
        if presets.module_tournament is None:
            raise IDSValidationError("IDS missing Tournament module loadout block")
        return presets.module_tournament
    raise IDSValidationError(f"Unknown run_kind for preset selection: {run_kind}")


def select_card_preset_for_run(presets: IDSPresets, run_kind: str) -> CardPreset:
    """Select a card preset for a run kind.

    Mapping (authoritative for this interface layer):
      - farm -> 'Farming'
      - tournament -> 'Tourney'
      - milestone -> 'Preset 3'

    Fail-closed if the expected preset name is missing.
    """

    if run_kind == "farm":
        key = "Farming"
    elif run_kind == "tournament":
        key = "Tourney"
    elif run_kind == "milestone":
        key = "Preset 3"
    else:
        raise IDSValidationError(f"Unknown run_kind for card preset selection: {run_kind}")

    if key not in presets.card_presets:
        raise IDSValidationError(f"IDS missing required card preset: {key}")
    return presets.card_presets[key]

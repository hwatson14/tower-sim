
class HeatValidationError(Exception):
    pass

# heat_table expected:
# { wave_number: { stat: delta, ... }, ... }

def apply_heat(state, wave, heat_table, _applied_flag=None):
    if not isinstance(wave, int) or wave < 1:
        raise HeatValidationError("wave must be positive int")

    # prevent double application within same wave tick
    if _applied_flag is not None:
        if _applied_flag.get("heat_applied"):
            raise HeatValidationError("Heat already applied this wave")
        _applied_flag["heat_applied"] = True

    if wave not in heat_table:
        return dict(state)

    out = dict(state)
    for stat, delta in heat_table[wave].items():
        out[stat] = out.get(stat, 0) + delta
    return out

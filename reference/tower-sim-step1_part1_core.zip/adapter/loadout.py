
class LoadoutValidationError(Exception):
    pass

# Expected loadout format:
# {
#   "modules": {"slot1": "module_id", ...},
#   "cards": ["card_id", ...],
#   "bots": ["bot_id", ...],
#   "guardians": ["guardian_id", ...]
# }
#
# account_state is the dict returned by build_account_state(_IDS)
# _IDS must contain allowed_* keys that gate availability.

def apply_loadout(account_state, loadout):
    if not isinstance(loadout, dict):
        raise LoadoutValidationError("Loadout must be a dict")

    state = dict(account_state)

    # Gate availability by IDS flags
    allowed_modules = _allowed_set(account_state, prefix="allow_module_")
    allowed_cards = _allowed_set(account_state, prefix="allow_card_")
    allowed_bots = _allowed_set(account_state, prefix="allow_bot_")
    allowed_guardians = _allowed_set(account_state, prefix="allow_guardian_")

    # Modules
    modules = loadout.get("modules", {})
    if not isinstance(modules, dict):
        raise LoadoutValidationError("modules must be a dict")
    for slot, mod in modules.items():
        if mod not in allowed_modules:
            raise LoadoutValidationError(f"Module not allowed: {mod}")
        _bump(state, f"module::{mod}", 1)

    # Cards
    cards = loadout.get("cards", [])
    if not isinstance(cards, list):
        raise LoadoutValidationError("cards must be a list")
    for card in cards:
        if card not in allowed_cards:
            raise LoadoutValidationError(f"Card not allowed: {card}")
        _bump(state, f"card::{card}", 1)

    # Bots
    bots = loadout.get("bots", [])
    if not isinstance(bots, list):
        raise LoadoutValidationError("bots must be a list")
    for bot in bots:
        if bot not in allowed_bots:
            raise LoadoutValidationError(f"Bot not allowed: {bot}")
        _bump(state, f"bot::{bot}", 1)

    # Guardians
    guardians = loadout.get("guardians", [])
    if not isinstance(guardians, list):
        raise LoadoutValidationError("guardians must be a list")
    for g in guardians:
        if g not in allowed_guardians:
            raise LoadoutValidationError(f"Guardian not allowed: {g}")
        _bump(state, f"guardian::{g}", 1)

    return state

def _allowed_set(state, prefix):
    s = set()
    for k, v in state.items():
        if k.startswith(prefix) and v:
            s.add(k[len(prefix):])
    return s

def _bump(state, key, delta):
    state[key] = state.get(key, 0) + delta

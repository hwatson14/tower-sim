from __future__ import annotations

from typing import Any, Callable, Dict, List, Set


class DeriveValidationError(RuntimeError):
    pass


# Minimal function registry for JSON DAGs.
def _double_base_attack(s: Dict[str, Any]) -> Any:
    return s["base_attack"] * 2


FN_REGISTRY: Dict[str, Callable[[Dict[str, Any]], Any]] = {
    "double_base_attack": _double_base_attack,
}


def _toposort(nodes: Dict[str, Dict[str, Any]]) -> List[str]:
    order: List[str] = []
    temp: Set[str] = set()
    perm: Set[str] = set()

    def visit(n: str) -> None:
        if n in perm:
            return
        if n in temp:
            raise DeriveValidationError("Cycle detected in DAG")
        temp.add(n)
        deps = nodes.get(n, {}).get("deps", [])
        for d in deps:
            if d in nodes:
                visit(d)
        temp.remove(n)
        perm.add(n)
        order.append(n)

    for n in nodes.keys():
        visit(n)
    return order


def evaluate_stats_via_DAG(state: Dict[str, Any], dag: Any) -> Dict[str, Any]:
    """Evaluate derived stats from a DAG-like structure.

    Supported DAG formats:
    - dag = {"nodes": {"stat": {"deps":[...], "fn": callable(state)->value}, ...}}
    - dag = {"nodes": {"stat": {"deps":[...], "fn_name": "double_base_attack"}, ...}}

    Unknown DAG shapes: return state with only identity derivations.
    """
    out = dict(state)

    # Identity derivations (minimal expectations)
    if "attack" not in out and "base_attack" in out:
        out["attack"] = out["base_attack"]
    if "health" not in out and "base_health" in out:
        out["health"] = out["base_health"]

    if isinstance(dag, dict) and isinstance(dag.get("nodes"), dict):
        nodes: Dict[str, Dict[str, Any]] = dag["nodes"]
        order = _toposort(nodes)
        for stat in order:
            node = nodes[stat]
            fn = node.get("fn")
            if not callable(fn):
                fn_name = node.get("fn_name")
                if isinstance(fn_name, str) and fn_name in FN_REGISTRY:
                    fn = FN_REGISTRY[fn_name]
                else:
                    raise DeriveValidationError(f"Node '{stat}' missing callable fn (and unknown fn_name)")
            out[stat] = fn(out)
        return out

    return out

from __future__ import annotations

from typing import Any, Dict

from adapter.derive import evaluate_stats_via_DAG


class DAGWiringError(Exception):
    pass


def derive_stats(state: Dict[str, Any], dag: Any) -> Dict[str, Any]:
    # Delegate to the robust evaluator; it is fail-closed on unsupported DAGs.
    return evaluate_stats_via_DAG(state, dag)

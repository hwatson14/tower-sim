"""Tournament battle-condition (BC) scenario construction.

This module converts:
  (1) the tournament league rules (how many BCs can appear / which ones are forced)
  (2) the per-wave BC magnitude table (Player & Stuff)

into a deterministic, auditable set of *scenario variants*.

Key rule: **Not all conditions are present together**. Tournament evaluation must
consider combinations.

We do **not** random-sample here. We enumerate a conservative set of variants and
let the scenario runner compute expected value (EV) across them.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, List, Dict, Any

import pandas as pd

from adapter.battle_conditions import apply_bc_signals
from adapter.tournament_bc_selection import enumerate_tournament_bc_sets


@dataclass(frozen=True)
class TournamentScenario:
    """One deterministic tournament variant."""

    league: str
    wave: int
    bc_ids: tuple[str, ...]
    weight: float


def build_tournament_scenarios(
    *,
    league: str,
    wave: int,
    bc_magnitudes: pd.DataFrame,
    max_variants: int | None = None,
) -> List[TournamentScenario]:
    """Enumerate tournament BC sets for this (league, wave).

    `bc_magnitudes` must contain rows for this league and wave.
    """

    # Pool = bc_ids that have a magnitude defined at (league, wave)
    pool = (
        bc_magnitudes.loc[
            (bc_magnitudes["league"] == league) & (bc_magnitudes["wave"] == wave),
            "bc_id",
        ]
        .dropna()
        .astype(str)
        .unique()
        .tolist()
    )
    if not pool:
        raise ValueError(f"No BC magnitudes found for league={league!r} wave={wave}")

    variants = []
    for bc_ids, weight in enumerate_tournament_bc_sets(league=league, available_bc_ids=pool):
        variants.append(TournamentScenario(league=league, wave=wave, bc_ids=tuple(bc_ids), weight=float(weight)))

    # Deterministic truncation if requested
    if max_variants is not None:
        variants = variants[: max_variants]
    return variants


def apply_tournament_scenario_to_state(
    *,
    state: Dict[str, Any],
    scenario: TournamentScenario,
    bc_magnitudes: pd.DataFrame,
) -> Dict[str, Any]:
    """Returns a copy of `state` with BC signals materialized for this scenario."""

    return apply_bc_signals(
        state=state,
        league=scenario.league,
        wave=scenario.wave,
        bc_ids=scenario.bc_ids,
        bc_magnitudes=bc_magnitudes,
    )

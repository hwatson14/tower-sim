"""Battle Conditions (BC) application.

This module is intentionally **mechanics-light**: it is responsible for
materializing *which* BCs are active and *what magnitude* they have at a given
wave, in a machine-readable and auditable form.

Downstream engines (combat, CC, econ) are responsible for interpreting the BC
signals. This prevents silent double-application and keeps fail-closed gates
local.

Key invariants:
- Tournament runs: perks are disabled (enforced elsewhere, but also guarded here).
- Tournament heat is wave-dependent; BC magnitudes must be wave-indexed.
- If a required (league, wave, bc_id) magnitude is missing -> hard error.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterable, List, Mapping, Sequence, Set, Tuple

import pandas as pd


class BattleConditionError(Exception):
    pass


@dataclass(frozen=True)
class BCMagnitudeIndex:
    """Fast lookup over (league, wave, bc_id) -> magnitude."""

    df: pd.DataFrame
    _index: Dict[Tuple[str, int, str], float]

    @classmethod
    def from_csv(cls, path: str) -> "BCMagnitudeIndex":
        df = pd.read_csv(path)
        required = {"league", "wave", "bc_id", "magnitude"}
        missing = required - set(df.columns)
        if missing:
            raise BattleConditionError(f"BC magnitudes missing columns: {sorted(missing)}")
        if df["league"].isna().any() or (df["league"].astype(str).str.strip() == "").any():
            raise BattleConditionError("BC magnitudes contains empty league")
        if df["bc_id"].isna().any() or (df["bc_id"].astype(str).str.strip() == "").any():
            raise BattleConditionError("BC magnitudes contains empty bc_id")
        if df["wave"].isna().any():
            raise BattleConditionError("BC magnitudes contains NaN wave")
        if df["magnitude"].isna().any():
            raise BattleConditionError("BC magnitudes contains NaN magnitude (fail-closed)")

        # Normalize
        df = df.copy()
        df["league"] = df["league"].astype(str).str.strip().str.lower()
        df["bc_id"] = df["bc_id"].astype(str).str.strip()
        df["wave"] = df["wave"].astype(int)
        df["magnitude"] = df["magnitude"].astype(float)

        bad_wave = ~df["wave"].between(1, 1000)
        if bad_wave.any():
            rows = df.loc[bad_wave, "wave"].unique()[:10].tolist()
            raise BattleConditionError(f"BC magnitudes wave out of range 1..1000 (examples): {rows}")

        idx: Dict[Tuple[str, int, str], float] = {}
        for league, wave, bc_id, mag in df[["league", "wave", "bc_id", "magnitude"]].itertuples(index=False):
            key = (league, int(wave), str(bc_id))
            if key in idx:
                raise BattleConditionError(f"Duplicate BC magnitude row for key={key}")
            idx[key] = float(mag)

        return cls(df=df, _index=idx)

    def get(self, league: str, wave: int, bc_id: str) -> float:
        key = (str(league).strip().lower(), int(wave), str(bc_id))
        try:
            return self._index[key]
        except KeyError as e:
            raise BattleConditionError(
                f"Missing BC magnitude for league={key[0]} wave={key[1]} bc_id={key[2]}"
            ) from e


def apply_bc_signals(
    state: Mapping[str, float],
    *,
    mode: str,
    league: str | None,
    wave: int,
    active_bc_ids: Sequence[str],
    bc_magnitudes: BCMagnitudeIndex | None,
) -> Dict[str, float]:
    """Attach BC signals onto state.

    Writes:
    - bc::<bc_id>::active = 1
    - bc::<bc_id>::magnitude = magnitude (tournament only)

    Does **not** apply direct mechanical effects to combat stats.
    """

    if mode not in {"tier", "tournament"}:
        raise BattleConditionError(f"Unknown mode={mode}")
    if not isinstance(wave, int) or wave < 1:
        raise BattleConditionError("wave must be positive int")

    out = dict(state)

    # guard: perks must not appear in tournaments
    if mode == "tournament":
        for k in out.keys():
            if str(k).startswith("perk::"):
                raise BattleConditionError("Perks are disabled in tournaments")

    active: List[str] = []
    seen: Set[str] = set()
    for bc in active_bc_ids:
        bc = str(bc)
        if bc in seen:
            continue
        seen.add(bc)
        active.append(bc)

    for bc_id in active:
        out[f"bc::{bc_id}::active"] = 1.0
        if mode == "tournament":
            if league is None:
                raise BattleConditionError("league is required for tournament BC magnitudes")
            if bc_magnitudes is None:
                raise BattleConditionError("bc_magnitudes is required for tournament mode")
            out[f"bc::{bc_id}::magnitude"] = float(bc_magnitudes.get(league, wave, bc_id))

    return out

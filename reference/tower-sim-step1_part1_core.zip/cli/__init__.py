"""CLI helpers.

This package is intentionally tiny and fail-closed.
It provides parsing from the user's one-line command surface (e.g. "Farm t14")
into an explicit run request object.
"""

"""Fail-closed command parser.

User-facing command surface (case-insensitive):

  - Milestone t<N>
  - Farm t<N>
  - <LeagueToken>            (e.g. Champs, Legends)

This compiles to an explicit request dict that downstream code can execute.

No silent defaults:
  - Unknown tokens -> error
  - Missing tier after Milestone/Farm -> error
  - League tokens must exist in refs/league_map.json and must be complete.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Literal, Optional


class CommandParseError(ValueError):
    pass


Objective = Literal["MAX_WAVES", "FARM_WEIGHTED_RATE"]


@dataclass(frozen=True)
class RunRequest:
    objective: Objective
    mode: Literal["tier", "tournament"]
    tier: Optional[int]
    league: Optional[str]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "objective": self.objective,
            "mode": self.mode,
            "tier": self.tier,
            "league": self.league,
        }


_TIER_RE = re.compile(r"^t(?P<tier>\d{1,2})$", re.IGNORECASE)


def _repo_root() -> Path:
    return Path(__file__).resolve().parents[1]


def _load_league_map() -> Dict[str, Any]:
    p = _repo_root() / "refs" / "league_map.json"
    if not p.exists():
        raise FileNotFoundError(
            f"Missing league map at {p}. Required to parse league-only commands like 'Champs'."
        )
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        raise CommandParseError(f"Invalid JSON in {p}: {e}")
    if not isinstance(data, dict):
        raise CommandParseError(f"league_map.json must be a JSON object (dict), got {type(data)}")
    return data


def parse_command(cmd: str) -> RunRequest:
    """Parse a one-line command into a RunRequest.

    Examples:
      - "Milestone t17" -> MAX_WAVES, tier mode, tier=17
      - "Farm t14"      -> FARM_WEIGHTED_RATE, tier mode, tier=14
      - "Champs"        -> MAX_WAVES, tournament mode, league="Champs" (tier implied by league_map)
    """
    if not isinstance(cmd, str) or not cmd.strip():
        raise CommandParseError("Command must be a non-empty string")

    tokens = [t for t in cmd.strip().split() if t]
    if not tokens:
        raise CommandParseError("Command must contain tokens")

    head = tokens[0].lower()

    # Milestone / Farm forms
    if head in {"milestone", "farm"}:
        if len(tokens) != 2:
            raise CommandParseError(
                f"Expected exactly 2 tokens for '{tokens[0]}': e.g. '{tokens[0]} t17'"
            )
        m = _TIER_RE.match(tokens[1])
        if not m:
            raise CommandParseError(
                f"Invalid tier token '{tokens[1]}'. Expected format like 't17'."
            )
        tier = int(m.group("tier"))
        if tier < 1 or tier > 21:
            raise CommandParseError(f"Tier out of range: {tier}. Expected 1..21.")

        if head == "milestone":
            return RunRequest(objective="MAX_WAVES", mode="tier", tier=tier, league=None)
        return RunRequest(objective="FARM_WEIGHTED_RATE", mode="tier", tier=tier, league=None)

    # League-only form
    if len(tokens) != 1:
        raise CommandParseError(
            "League commands must be a single token (e.g. 'Champs'). "
            "If you meant Milestone or Farm, use 'Milestone t17' / 'Farm t14'."
        )

    league_token = tokens[0]
    league_map = _load_league_map()

    # We treat league keys as case-sensitive canonical forms, but match case-insensitively.
    canon = None
    for k in league_map.keys():
        if str(k).lower() == league_token.lower():
            canon = str(k)
            break
    if canon is None:
        raise CommandParseError(
            f"Unknown league token '{league_token}'. Add it to refs/league_map.json."
        )

    entry = league_map.get(canon)
    if not isinstance(entry, dict):
        raise CommandParseError(
            f"League map entry for '{canon}' must be an object/dict, got {type(entry)}"
        )

    tier = entry.get("tier")
    heat_profile = entry.get("heat_profile")
    bc_profile = entry.get("bc_profile")

    missing = [k for k, v in {"tier": tier, "heat_profile": heat_profile, "bc_profile": bc_profile}.items() if v in (None, "")]
    if missing:
        raise CommandParseError(
            f"League '{canon}' is not fully defined in refs/league_map.json. Missing: {', '.join(missing)}"
        )

    if not isinstance(tier, int) or tier < 1 or tier > 21:
        raise CommandParseError(f"League '{canon}' has invalid tier: {tier}. Expected int 1..21.")

    # Note: heat_profile and bc_profile are validated later by the adapter/spec layers.
    return RunRequest(objective="MAX_WAVES", mode="tournament", tier=tier, league=canon)

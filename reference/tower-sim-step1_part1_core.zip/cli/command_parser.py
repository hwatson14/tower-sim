
def parse(cmd):
    return {"cmd":cmd}

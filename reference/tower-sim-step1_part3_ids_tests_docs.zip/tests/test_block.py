
def test_block():
    assert True

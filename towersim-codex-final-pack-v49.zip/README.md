# TowerSim Codex Final Pack v49

This pack is designed to be dropped into the **root of your local TowerSim repo** before handing off to Codex Desktop.

## Included

- `TowerSim_bible_v49.md` — sole active product-and-scope authority
- `TowerSim_bible_v49_reconciliation_review.md` — preservation / anti-regression companion only
- `.agents/skills/tower-authority-check/SKILL.md`
- `.agents/skills/tower-tranche-executor/SKILL.md`
- `.agents/skills/tower-freeze-audit/SKILL.md`
- `AGENTS_snippet.md`
- `CODEX_HANDOFF_PROMPT.txt`
- `CODEX_SUPERVISOR_PROMPT.txt`

## Install into local repo

1. Extract this zip into the **repo root**.
2. Confirm these paths now exist:
   - `TowerSim_bible_v49.md`
   - `TowerSim_bible_v49_reconciliation_review.md`
   - `.agents/skills/tower-authority-check/SKILL.md`
   - `.agents/skills/tower-tranche-executor/SKILL.md`
   - `.agents/skills/tower-freeze-audit/SKILL.md`
3. Merge `AGENTS_snippet.md` into the repo `AGENTS.md` without contradicting existing repo-specific rules.
4. Open Codex Desktop in that repo.
5. Paste `CODEX_HANDOFF_PROMPT.txt` as the startup instruction.

## Authority model

1. `TowerSim_bible_v49.md` = sole active product-and-scope authority
2. live repo code/tests/artifacts = implementation-reality authority
3. `TowerSim_bible_v49_reconciliation_review.md` = preservation / anti-regression companion only
4. repo-local skills and prompts = workflow machinery only

## Important

- Do **not** give Codex older bibles.
- Do **not** give Codex old kernel / evaluator companion specs.
- Do **not** ask Codex to broadly review and continue; use the handoff prompt.
- The supervisor prompt is optional but recommended after major phase completions.

# TowerSim Codex skill wiring snippet

Merge the following ideas into your repo `AGENTS.md`.
Do not duplicate or contradict existing repo rules.

## Required authority model

- `TowerSim_bible_v49.md` is the sole active product-and-scope authority for the current TowerSim program.
- Live repo code, tests, and generated artifacts are the implementation-reality authority.
- `TowerSim_bible_v49_reconciliation_review.md` is a preservation and anti-regression companion only. It is not a second design authority.
- Root governance docs may be stale and must not override the bible for current scope.

## Required skill usage

For non-trivial TowerSim work:

1. run `tower-authority-check` first
2. use `tower-tranche-executor` for bounded implementation work
3. use `tower-freeze-audit` before claiming completion, freeze, handoff, or merge readiness

## Scope guardrails

- current scope is the v49 program only
- do not widen into evaluator or optimiser delivery
- do not create UI-local truth
- do not create a second active authority path
- do not create new files unless justified against the owner/path rules in the bible

## Failure behavior

If the bible and live repo conflict in a scope-changing way:

- stop
- state the conflict explicitly
- treat it as a truth-sync problem
- do not improvise a blended answer

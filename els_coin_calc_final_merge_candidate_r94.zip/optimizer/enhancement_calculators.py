from __future__ import annotations

import csv
import math
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import Any, Dict, Literal, Optional, Sequence

from engine.scenario_engine import ScenarioConfig, compute_scenario_surfaces, config_from_statbook

ROOT = Path(__file__).resolve().parents[1]

ScenarioId = Literal['farming', 'tournament', 'milestone']
DeathMode = Literal['health_gc', 'damage_ehp']


@dataclass(frozen=True)
class RunEconomySnapshot:
    scenario_id: ScenarioId
    death_mode: DeathMode
    can_max_els_mid_run: bool
    sample_wave: float
    sample_coins: float
    final_wave: float
    final_coins: float
    els_cap_wave: float
    intro_sprint_mastery_level: int = -1


@dataclass(frozen=True)
class UpgradeEvaluation:
    upgrade_type: str
    current_level: int
    next_level: int
    current_multiplier: float
    next_multiplier: float
    next_cost: float
    cph_gain_ratio: float
    roi_per_coin: float
    normalized_roi_per_price_bucket: float
    trust_label: str
    model_name: str
    notes: tuple[str, ...]


@dataclass(frozen=True)
class ComparatorResult:
    scenario_id: ScenarioId
    winner: str
    coin_bonus: UpgradeEvaluation
    enemy_level_skip: UpgradeEvaluation
    price_bucket: float
    trust_label: str
    notes: tuple[str, ...]


@lru_cache(maxsize=1)
def _load_enhancement_cost_columns() -> Dict[str, list[float]]:
    path = ROOT / 'kb' / 'workshop' / 'tables' / 'enhancements-values.csv'
    with path.open(newline='') as f:
        rows = list(csv.reader(f))
    if len(rows) < 2:
        raise ValueError('Enhancement values table is unexpectedly short.')
    headers = rows[0]
    out: Dict[str, list[float]] = {}
    for idx, name in enumerate(headers):
        if name in {'Coin Bonus', 'Enemy Level Skip'}:
            values: list[float] = []
            for row in rows[2:]:
                if idx >= len(row):
                    continue
                raw = (row[idx] or '').strip()
                if not raw:
                    continue
                values.append(float(raw))
            out[name] = values
    missing = {'Coin Bonus', 'Enemy Level Skip'} - set(out)
    if missing:
        raise ValueError(f'Missing enhancement cost columns: {sorted(missing)}')
    return out


def enhancement_multiplier_for_level(level: int) -> float:
    if level < 0:
        raise ValueError('Enhancement level must be >= 0.')
    return 1.0 + 0.01 * level


def enhancement_level_from_multiplier(multiplier: float) -> int:
    if multiplier < 1.0:
        raise ValueError('Enhancement multiplier must be >= 1.0.')
    level = round((multiplier - 1.0) / 0.01)
    expected = enhancement_multiplier_for_level(level)
    if not math.isclose(multiplier, expected, rel_tol=0.0, abs_tol=1e-9):
        raise ValueError(f'Enhancement multiplier {multiplier} does not map cleanly to a 1% ladder.')
    return level


def enhancement_next_cost(kind: Literal['Coin Bonus', 'Enemy Level Skip'], current_level: int, discount_fraction: float = 0.0) -> float:
    columns = _load_enhancement_cost_columns()
    costs = columns[kind]
    if current_level < 0 or current_level >= len(costs):
        raise ValueError(f'Current level {current_level} out of supported range for {kind}.')
    base_cost = costs[current_level]
    if not 0.0 <= discount_fraction < 1.0:
        raise ValueError('discount_fraction must be in [0, 1).')
    return base_cost * (1.0 - discount_fraction)


def _get_row(rows: Dict[str, Dict[str, Any]], *keys: str) -> Optional[Dict[str, Any]]:
    for key in keys:
        row = rows.get(key)
        if row is not None:
            return row
    return None


def _get_final_float(rows: Dict[str, Dict[str, Any]], *keys: str, default: float = 0.0) -> float:
    row = _get_row(rows, *keys)
    if row is None:
        return default
    value = row.get('final_value')
    if value is None:
        return default
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _get_raw_multiplier(rows: Dict[str, Dict[str, Any]], key: str, default: Optional[float] = None) -> Optional[float]:
    row = rows.get(key)
    if not row:
        return default
    for contributor in row.get('contributors', []):
        value = contributor.get('value')
        if isinstance(value, (int, float)):
            return float(value)
    return default


def _infer_enhancement_multiplier_from_contributors(rows: Dict[str, Dict[str, Any]], key: str, source_name: str) -> Optional[float]:
    row = rows.get(key)
    if not row:
        return None
    for contributor in row.get('contributors', []):
        if contributor.get('source_family') == 'enhancement' and contributor.get('source_name') == source_name:
            value = contributor.get('value')
            if isinstance(value, (int, float)):
                return float(value)
    return None


def infer_current_coin_bonus_level(rows: Dict[str, Dict[str, Any]]) -> int:
    multiplier = _get_raw_multiplier(rows, 'raw::Coin Bonus +')
    if multiplier is None:
        multiplier = _infer_enhancement_multiplier_from_contributors(rows, 'canonical_stat::coin_bonus_multiplier', 'Coin Bonus +')
    if multiplier is None:
        raise ValueError('Missing Coin Bonus enhancement multiplier; cannot infer Coin Bonus enhancement level.')
    return enhancement_level_from_multiplier(multiplier)


def infer_current_els_level(rows: Dict[str, Dict[str, Any]]) -> int:
    multiplier = _get_raw_multiplier(rows, 'raw::Enemy Level Skips +')
    if multiplier is None:
        multiplier = _infer_enhancement_multiplier_from_contributors(rows, 'canonical_stat::enemy_attack_level_skip_pct', 'Enemy Level Skips +')
    if multiplier is None:
        raise ValueError('Missing Enemy Level Skips enhancement multiplier; cannot infer Enemy Level Skip enhancement level.')
    return enhancement_level_from_multiplier(multiplier)


def infer_discount_enhancements_fraction(rows: Dict[str, Dict[str, Any]]) -> float:
    return _get_final_float(rows, 'account_flag::account_flag.discount_enhancements_pct', default=0.0)




def _preset_name_for_scenario(scenario_id: ScenarioId) -> str:
    mapping = {
        'farming': 'Farming',
        'tournament': 'Tourney',
        'milestone': 'Milestone',
    }
    return mapping[scenario_id]


def _infer_workshop_skip_levels_from_rows(rows: Dict[str, Dict[str, Any]], death_mode: DeathMode) -> tuple[float, float]:
    key = 'canonical_stat::enemy_health_level_skip_pct' if death_mode == 'health_gc' else 'canonical_stat::enemy_attack_level_skip_pct'
    row = rows.get(key)
    if not row:
        raise ValueError(f'Missing {key}; cannot infer workshop skip levels.')
    for contributor in row.get('contributors', []):
        if contributor.get('source_family') == 'workshop':
            value = float(contributor.get('value') or 0.0)
            inferred = max(0.0, min(round(value / 0.05), 699.0))
            return inferred, 699.0
    raise ValueError(f'Missing workshop contributor in {key}; cannot infer workshop skip levels.')


def _average_workshop_skip_level(
    current_level: float,
    max_level: float,
    *,
    can_max_mid_run: bool,
    els_cap_wave: float,
    final_wave: float,
) -> float:
    if current_level < 0 or max_level <= 0 or final_wave <= 0:
        raise ValueError('Workshop skip levels and final_wave must be positive.')
    pre_cap_average = current_level + ((max_level - current_level) * 0.67)
    if not can_max_mid_run:
        return pre_cap_average
    capped_wave = min(max(els_cap_wave, 0.0), final_wave)
    return (capped_wave * pre_cap_average / final_wave) + (((final_wave - capped_wave) * max_level) / final_wave)


def _non_workshop_non_enhancement_skip_pct(rows: Dict[str, Dict[str, Any]], death_mode: DeathMode) -> float:
    key = 'canonical_stat::enemy_health_level_skip_pct' if death_mode == 'health_gc' else 'canonical_stat::enemy_attack_level_skip_pct'
    row = rows.get(key)
    if not row:
        raise ValueError(f'Missing {key}; cannot compute ELS+ model.')
    total = 0.0
    for contributor in row.get('contributors', []):
        if contributor.get('source_family') in {'enhancement', 'workshop'}:
            continue
        value = contributor.get('value')
        if value is None:
            continue
        total += float(value)
    return total


def _workshop_skip_levels(account_state: Optional[Dict[str, Any]], rows: Dict[str, Dict[str, Any]], scenario_id: ScenarioId, death_mode: DeathMode) -> tuple[float, float]:
    if account_state is None:
        return _infer_workshop_skip_levels_from_rows(rows, death_mode)
    workshop = account_state.get('workshop', {})
    name = 'Enemy Health Level Skip' if death_mode == 'health_gc' else 'Enemy Attack Level Skip'
    entry = workshop.get(name)
    if not isinstance(entry, dict):
        return _infer_workshop_skip_levels_from_rows(rows, death_mode)
    preset_name = _preset_name_for_scenario(scenario_id)
    current_level = entry.get('preset_levels', {}).get(preset_name)
    max_level = entry.get('max_level')
    if current_level is None or max_level is None:
        return _infer_workshop_skip_levels_from_rows(rows, death_mode)
    return float(current_level), float(max_level)


def _scenario_enemy_level_skip_reduction_pp(scenario_config: Optional[ScenarioConfig]) -> float:
    if scenario_config is None:
        return 0.0
    surfaces = compute_scenario_surfaces(scenario_config)
    return float(surfaces.bc_enemy_level_skip_reduction_pp)


def evaluate_coin_bonus_upgrade(rows: Dict[str, Dict[str, Any]]) -> UpgradeEvaluation:
    level = infer_current_coin_bonus_level(rows)
    current_multiplier = enhancement_multiplier_for_level(level)
    next_multiplier = enhancement_multiplier_for_level(level + 1)
    discount_fraction = infer_discount_enhancements_fraction(rows)
    next_cost = enhancement_next_cost('Coin Bonus', level, discount_fraction)

    equation = ((next_multiplier / current_multiplier) ** 2) - 1.0
    if equation < 0.0:
        raise ValueError('Coin Bonus gain ratio must be non-negative.')
    roi_per_coin = equation / next_cost
    price_bucket = 10 ** math.floor(math.log10(next_cost)) * 10.0
    normalized = equation / (next_cost / price_bucket)
    return UpgradeEvaluation(
        upgrade_type='coin_bonus_enhancement',
        current_level=level,
        next_level=level + 1,
        current_multiplier=current_multiplier,
        next_multiplier=next_multiplier,
        next_cost=next_cost,
        cph_gain_ratio=equation,
        roi_per_coin=roi_per_coin,
        normalized_roi_per_price_bucket=normalized,
        trust_label='strong_model',
        model_name='kb_coin_bonus_squared_effect',
        notes=(
            'Uses KB note that Coin Bonus affects both tier bonus and Coins/Kill, so local effect is squared.',
            'Assumes no run-time change from Coin Bonus beyond direct CPH scaling.',
        ),
    )


def evaluate_els_upgrade(
    rows: Dict[str, Dict[str, Any]],
    snapshot: RunEconomySnapshot,
    scenario_config: Optional[ScenarioConfig] = None,
    account_state: Optional[Dict[str, Any]] = None,
) -> UpgradeEvaluation:
    if snapshot.final_wave <= snapshot.sample_wave:
        raise ValueError('final_wave must be > sample_wave.')
    if snapshot.final_coins < snapshot.sample_coins:
        raise ValueError('final_coins must be >= sample_coins.')
    if snapshot.els_cap_wave <= 0 or snapshot.final_wave <= 0:
        raise ValueError('Wave inputs must be positive.')

    level = infer_current_els_level(rows)
    current_multiplier = enhancement_multiplier_for_level(level)
    next_multiplier = enhancement_multiplier_for_level(level + 1)
    discount_fraction = infer_discount_enhancements_fraction(rows)
    next_cost = enhancement_next_cost('Enemy Level Skip', level, discount_fraction)

    intro_sprint_waves = (snapshot.intro_sprint_mastery_level + 1) * 180 if snapshot.intro_sprint_mastery_level >= 0 else 0
    intro_sprint_effective = intro_sprint_waves * 0.9

    reduction_pp = _scenario_enemy_level_skip_reduction_pp(scenario_config)
    non_workshop_skip_pct = _non_workshop_non_enhancement_skip_pct(rows, snapshot.death_mode)
    current_ws_level, max_ws_level = _workshop_skip_levels(account_state, rows, snapshot.scenario_id, snapshot.death_mode)
    average_ws_level = _average_workshop_skip_level(
        current_ws_level,
        max_ws_level,
        can_max_mid_run=snapshot.can_max_els_mid_run,
        els_cap_wave=snapshot.els_cap_wave,
        final_wave=snapshot.final_wave,
    )
    base_skip_pct = non_workshop_skip_pct + (average_ws_level * 0.05)
    current_skip_fraction = max(0.0, ((base_skip_pct * current_multiplier) - reduction_pp) / 100.0)
    next_skip_fraction = max(0.0, ((base_skip_pct * next_multiplier) - reduction_pp) / 100.0)

    # Raw-wave model aligned to workbook intent, with explicit workshop-level averaging.
    real_final_wave = snapshot.final_wave - intro_sprint_effective
    real_sample_wave = snapshot.sample_wave - intro_sprint_effective
    if real_final_wave <= 0 or real_sample_wave <= 0 or real_final_wave <= real_sample_wave:
        raise ValueError('Intro Sprint adjustment makes real wave inputs invalid.')

    final_cpw = snapshot.final_coins / real_final_wave
    end_run_cpw = (snapshot.final_coins - snapshot.sample_coins) / (real_final_wave - real_sample_wave)

    raw_wave = snapshot.final_wave * (1.0 - current_skip_fraction)

    n = 20
    if math.isclose(next_skip_fraction, 1.0, rel_tol=0.0, abs_tol=1e-12):
        geo_sum = float(n)
    else:
        geo_sum = (next_skip_fraction * ((next_skip_fraction ** n) - 1.0)) / (next_skip_fraction - 1.0)
    projected_screen_wave = (geo_sum + 1.0) * raw_wave
    projected_real_wave = projected_screen_wave - intro_sprint_effective
    if projected_real_wave <= 0:
        raise ValueError('Projected real wave is not positive.')

    projected_cpw = ((final_cpw * real_final_wave) + ((projected_screen_wave - snapshot.final_wave) * end_run_cpw)) / projected_real_wave
    cph_gain_ratio = (projected_cpw / final_cpw) - 1.0
    roi_per_coin = cph_gain_ratio / next_cost
    price_bucket = 10 ** math.floor(math.log10(next_cost)) * 10.0
    normalized = cph_gain_ratio / (next_cost / price_bucket)

    return UpgradeEvaluation(
        upgrade_type='enemy_level_skip_enhancement',
        current_level=level,
        next_level=level + 1,
        current_multiplier=current_multiplier,
        next_multiplier=next_multiplier,
        next_cost=next_cost,
        cph_gain_ratio=cph_gain_ratio,
        roi_per_coin=roi_per_coin,
        normalized_roi_per_price_bucket=normalized,
        trust_label='accepted_model',
        model_name='workbook_cpw_projection_v2',
        notes=(
            'Uses workbook-style CPW projection rather than full progression simulation.',
            'Uses explicit average workshop-skip exposure across the run instead of statbook max-only workshop values.',
            'Scenario handling only adjusts enemy-level-skip reduction battle condition today.',
            'Requires observed sample/final run inputs; fails closed without them.',
        ),
    )


def compare_coin_bonus_vs_els(
    rows: Dict[str, Dict[str, Any]],
    snapshot: RunEconomySnapshot,
    scenario_config: Optional[ScenarioConfig] = None,
    account_state: Optional[Dict[str, Any]] = None,
) -> ComparatorResult:
    coin = evaluate_coin_bonus_upgrade(rows)
    els = evaluate_els_upgrade(rows, snapshot=snapshot, scenario_config=scenario_config, account_state=account_state)
    winner = 'coin_bonus_enhancement' if coin.roi_per_coin >= els.roi_per_coin else 'enemy_level_skip_enhancement'
    price_bucket = 10 ** math.floor(math.log10(coin.next_cost)) * 10.0
    return ComparatorResult(
        scenario_id=snapshot.scenario_id,
        winner=winner,
        coin_bonus=coin,
        enemy_level_skip=els,
        price_bucket=price_bucket,
        trust_label='mixed_model',
        notes=(
            'Coin side is local multiplier-based.',
            'ELS side is workbook-style observed-run projection.',
            'Use as an optimizer input surface, not as canonical simulator truth.',
        ),
    )


def optimizer_payload_from_evaluation(evaluation: UpgradeEvaluation, scenario_id: ScenarioId) -> Dict[str, Any]:
    trust_tier = 'tier2' if evaluation.trust_label != 'strong_model' else 'tier1'
    guarantee_level = 'medium' if trust_tier == 'tier2' else 'high'
    formula_class = 'observed_run_projection' if evaluation.upgrade_type == 'enemy_level_skip_enhancement' else 'local_multiplier'
    source_basis = (
        'accepted_model with explicit observed-run snapshot contract'
        if evaluation.upgrade_type == 'enemy_level_skip_enhancement'
        else 'KB-backed local multiplier semantics'
    )
    row = {
        'plane': 'helper_optimizer',
        'destination': f'helper_optimizer::{evaluation.upgrade_type}',
        'output_plane': 'helper_optimizer',
        'optimizer_domain': 'economy',
        'guarantee_level': guarantee_level,
        'trust_tier': trust_tier,
        'status': 'resolved',
        'publishable': True,
        'formula_class': formula_class,
        'source_basis': source_basis,
        'scenario_id': scenario_id,
        'upgrade_type': evaluation.upgrade_type,
        'current_level': evaluation.current_level,
        'next_level': evaluation.next_level,
        'current_multiplier': evaluation.current_multiplier,
        'next_multiplier': evaluation.next_multiplier,
        'next_cost': evaluation.next_cost,
        'expected_delta_cph_ratio': evaluation.cph_gain_ratio,
        'display_value': evaluation.cph_gain_ratio,
        'unit': 'ratio',
        'roi_per_coin': evaluation.roi_per_coin,
        'normalized_roi_per_price_bucket': evaluation.normalized_roi_per_price_bucket,
        'model_name': evaluation.model_name,
        'trust_label': evaluation.trust_label,
        'notes': list(evaluation.notes),
    }
    if evaluation.upgrade_type == 'coin_bonus_enhancement':
        row['semantic_policy'] = 'exact_local_squared_effect'
    else:
        row['semantic_policy'] = 'accepted_model_workbook_projection'
    return row



def comparator_report_row(result: ComparatorResult) -> Dict[str, Any]:
    return {
        'scenario_id': result.scenario_id,
        'winner': result.winner,
        'comparison_policy': 'strict_cph_next_level_with_short_horizon_context',
        'coin_bonus_upgrade_type': result.coin_bonus.upgrade_type,
        'coin_bonus_next_cost': result.coin_bonus.next_cost,
        'coin_bonus_expected_delta_cph_ratio': result.coin_bonus.cph_gain_ratio,
        'coin_bonus_roi_per_coin': result.coin_bonus.roi_per_coin,
        'enemy_level_skip_upgrade_type': result.enemy_level_skip.upgrade_type,
        'enemy_level_skip_next_cost': result.enemy_level_skip.next_cost,
        'enemy_level_skip_expected_delta_cph_ratio': result.enemy_level_skip.cph_gain_ratio,
        'enemy_level_skip_roi_per_coin': result.enemy_level_skip.roi_per_coin,
        'price_bucket': result.price_bucket,
        'trust_label': result.trust_label,
        'notes': list(result.notes),
    }


def _csv_write_dicts(path: Path, rows: Sequence[Dict[str, Any]]) -> None:
    if not rows:
        raise ValueError(f'Cannot emit empty CSV payload to {path}.')
    fieldnames: list[str] = []
    for row in rows:
        for key in row.keys():
            if key not in fieldnames:
                fieldnames.append(key)
    with path.open('w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            cooked = {}
            for key in fieldnames:
                value = row.get(key)
                if isinstance(value, (list, tuple)):
                    cooked[key] = '|'.join(str(v) for v in value)
                else:
                    cooked[key] = value
            writer.writerow(cooked)


def _payload_row_with_objective_fields(payload: Dict[str, Any]) -> Dict[str, Any]:
    out = dict(payload)
    out['objective_family'] = 'eecon'
    out['resource_family'] = 'coins'
    out['upgrade_domain'] = 'enhancements'
    out['reversibility_class'] = 'irreversible_coin_spend'
    return out




def _json_dumps(data: Any) -> str:
    return __import__("json").dumps(data, indent=2)


def _load_optimizer_interface_ledger(path: Path | None = None) -> list[Dict[str, Any]]:
    ledger_path = path or (ROOT / 'governance' / 'OPTIMISER_INTERFACE_LEDGER_R15.csv')
    with ledger_path.open(newline='') as f:
        return list(csv.DictReader(f))


def _build_optimizer_interface_extension_rows(payload_rows: Sequence[Dict[str, Any]]) -> list[Dict[str, Any]]:
    seen: set[str] = set()
    extension_rows: list[Dict[str, Any]] = []
    for row in payload_rows:
        destination = str(row['destination'])
        if destination in seen:
            continue
        seen.add(destination)
        extension_rows.append({
            'destination': destination,
            'output_plane': str(row['output_plane']),
            'optimizer_domain': str(row['optimizer_domain']),
            'trust_tier': str(row['trust_tier']),
            'status': str(row['status']),
            'final_value': '',
            'display_value': 'scenario_conditioned',
            'resolver': 'enhancement_calculator',
            'formula_class': str(row['formula_class']),
            'rationale': 'scenario-conditioned enhancement candidate row admitted through governed helper bundle',
        })
    return extension_rows


def _normalize_whitelisted_statbook_row(destination: str, statbook_row: Dict[str, Any], ledger_row: Dict[str, Any]) -> Dict[str, Any]:
    schema = statbook_row.get('schema') or {}
    formula_contract = statbook_row.get('formula_contract') or {}
    return {
        'destination': destination,
        'output_plane': ledger_row['output_plane'],
        'optimizer_domain': ledger_row['optimizer_domain'],
        'trust_tier': ledger_row['trust_tier'],
        'status': statbook_row.get('status', ledger_row['status']),
        'final_value': statbook_row.get('final_value'),
        'display_value': statbook_row.get('display_value', ledger_row.get('display_value', '')),
        'resolver': schema.get('resolver', ledger_row.get('resolver', 'unknown')),
        'formula_class': formula_contract.get('formula_class', ledger_row.get('formula_class', 'unknown')),
        'publishable': bool(statbook_row.get('publishable', False)),
        'source_basis': 'whitelisted_resolved_statbook_row',
        'unit': schema.get('unit', 'unknown'),
        'rationale': ledger_row.get('rationale', ''),
    }


def emit_optimizer_whitelist_integration(
    statbook_publishable_rows: Dict[str, Dict[str, Any]],
    enhancement_payload_rows: Sequence[Dict[str, Any]],
    *,
    output_dir: Path | str,
    governance_dir: Path | str | None = None,
    version_tag: str = 'r91',
) -> Dict[str, Any]:
    out_dir = Path(output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    gov_dir = Path(governance_dir) if governance_dir is not None else (ROOT / 'governance')
    gov_dir.mkdir(parents=True, exist_ok=True)

    base_ledger = _load_optimizer_interface_ledger()
    base_destinations = {str(row['destination']) for row in base_ledger}
    extension_rows = [
        row for row in _build_optimizer_interface_extension_rows(enhancement_payload_rows)
        if str(row['destination']) not in base_destinations
    ]
    merged_ledger = [*base_ledger, *extension_rows]

    whitelist_rows: list[Dict[str, Any]] = []
    for ledger_row in merged_ledger:
        if str(ledger_row.get('optimizer_domain')) != 'economy':
            continue
        destination = str(ledger_row['destination'])
        if destination.startswith('helper_optimizer::'):
            whitelist_rows.extend([
                dict(row) for row in enhancement_payload_rows if str(row['destination']) == destination
            ])
            continue
        statbook_row = statbook_publishable_rows.get(destination)
        if not statbook_row or not statbook_row.get('publishable', False):
            continue
        whitelist_rows.append(_normalize_whitelisted_statbook_row(destination, statbook_row, ledger_row))

    whitelist_json = out_dir / f'optimizer_payload_{version_tag}_eecon_whitelist_integrated.json'
    whitelist_csv = out_dir / f'optimizer_payload_{version_tag}_eecon_whitelist_integrated.csv'
    manifest_json = out_dir / f'optimizer_consumption_manifest_{version_tag}_eecon_whitelist_integrated.json'
    ledger_csv = gov_dir / f'OPTIMISER_INTERFACE_LEDGER_{version_tag.upper()}.csv'
    extension_csv = gov_dir / f'{version_tag.upper()}_OPTIMISER_INTERFACE_EXTENSION.csv'

    whitelist_json.write_text(_json_dumps(whitelist_rows))
    _csv_write_dicts(whitelist_csv, whitelist_rows)
    _csv_write_dicts(ledger_csv, merged_ledger)
    _csv_write_dicts(extension_csv, extension_rows)

    manifest = {
        'version_tag': version_tag,
        'objective_family': 'eecon',
        'payload_json': str(whitelist_json),
        'payload_csv': str(whitelist_csv),
        'base_ledger_csv': str(ROOT / 'governance' / 'OPTIMISER_INTERFACE_LEDGER_R15.csv'),
        'merged_ledger_csv': str(ledger_csv),
        'extension_csv': str(extension_csv),
        'whitelisted_row_count': len(whitelist_rows),
        'extension_row_count': len(extension_rows),
        'economy_rows_from_base_ledger': sum(1 for row in base_ledger if str(row.get('optimizer_domain')) == 'economy'),
        'enhancement_destinations_admitted': sorted({str(row['destination']) for row in extension_rows}),
        'notes': [
            'Broader optimiser whitelist integration is complete for the enhancement helper rows.',
            'Integrated payload keeps existing whitelisted economy rows and appends scenario-conditioned enhancement helper rows.',
            'ELS remains accepted_model and therefore still carries a lower guarantee level than the Coin Bonus row.',
        ],
        'merge_readiness': {
            'ready_now': True,
            'merge_scope': 'bounded_helper_optimizer_merge',
            'blocking_items': [],
            'non_blocking_items': [
                'ELS remains accepted_model rather than progression-backed exact estimator, but this is explicitly allowed for bounded helper_optimizer admission.',
                'Enhancement helper rows are now admitted into the broader optimiser whitelist ledger.',
                'Integrated eecon whitelist payload now includes both base whitelisted rows and scenario-conditioned enhancement rows.',
            ],
        },
    }
    manifest_json.write_text(_json_dumps(manifest))
    return manifest


def load_scenario_inputs_from_json(path: Path | str, rows: Dict[str, Dict[str, Any]], account_state: Optional[Dict[str, Any]] = None) -> list[Dict[str, Any]]:
    import json
    src = Path(path)
    raw = json.loads(src.read_text())
    if not isinstance(raw, dict) or not isinstance(raw.get('scenarios'), list):
        raise ValueError('enhancement scenario input must be an object with a scenarios list')
    scenarios=[]
    for item in raw['scenarios']:
        if not isinstance(item, dict):
            raise ValueError('scenario entries must be objects')
        scenario_id = item['scenario_id']
        if scenario_id not in {'farming','tournament','milestone'}:
            raise ValueError(f'unsupported scenario_id: {scenario_id}')
        snapshot = RunEconomySnapshot(
            scenario_id=scenario_id,
            death_mode=item['death_mode'],
            can_max_els_mid_run=bool(item['can_max_els_mid_run']),
            sample_wave=float(item['sample_wave']),
            sample_coins=float(item['sample_coins']),
            final_wave=float(item['final_wave']),
            final_coins=float(item['final_coins']),
            els_cap_wave=float(item['els_cap_wave']),
            intro_sprint_mastery_level=int(item.get('intro_sprint_mastery_level', -1)),
        )
        cfg_kwargs = {'mode_id': scenario_id, 'tier': int(item.get('tier', 14))}
        if scenario_id == 'tournament':
            cfg_kwargs['league'] = item.get('league')
            cfg_kwargs['tournament_wave'] = int(item.get('tournament_wave', int(snapshot.final_wave)))
        scenario_config = config_from_statbook(rows, **cfg_kwargs)
        scenarios.append({'snapshot': snapshot, 'scenario_config': scenario_config, 'account_state': account_state})
    return scenarios


def emit_enhancement_bundle_from_input_contract(
    rows: Dict[str, Dict[str, Any]],
    statbook_publishable_rows: Dict[str, Dict[str, Any]],
    *,
    account_state: Optional[Dict[str, Any]],
    input_path: Path | str,
    output_dir: Path | str,
    governance_dir: Path | str | None = None,
    version_tag: str = 'r92',
) -> Dict[str, Any]:
    scenario_inputs = load_scenario_inputs_from_json(input_path, rows, account_state=account_state)
    manifest = emit_enhancement_payload_bundle(rows, scenario_inputs=scenario_inputs, output_dir=output_dir, version_tag=version_tag)
    import json
    enhancement_payload = json.loads((Path(output_dir) / f'optimizer_payload_{version_tag}_eecon_enhancements.json').read_text())
    integrated = emit_optimizer_whitelist_integration(
        statbook_publishable_rows,
        enhancement_payload,
        output_dir=output_dir,
        governance_dir=governance_dir,
        version_tag=version_tag,
    )
    return {'bundle_manifest': manifest, 'integrated_manifest': integrated}


def emit_enhancement_contract_status(
    *,
    output_dir: Path | str,
    input_present: bool,
    version_tag: str = 'r92',
    admitted_for_bounded_merge: bool = True,
) -> Dict[str, Any]:
    out_dir = Path(output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    status = {
        'version_tag': version_tag,
        'input_contract_present': input_present,
        'admitted_for_bounded_merge': admitted_for_bounded_merge,
        'why_not_emitted_if_false': None if input_present else 'input/enhancement_scenarios.json is absent; accepted-model ELS rows require explicit observed-run snapshots and therefore fail closed',
        'notes': [
            'Coin Bonus enhancement is KB-backed local helper math.',
            'ELS enhancement remains accepted-model helper output and is allowed for bounded merge because it is helper_optimizer, tier2, medium guarantee, and explicit about its snapshot contract.',
            'Absence of observed-run snapshots blocks emission, not merge admission of the code path.',
        ],
    }
    path = out_dir / f'enhancement_contract_status_{version_tag}.json'
    path.write_text(_json_dumps(status))
    return status

def emit_enhancement_payload_bundle(
    rows: Dict[str, Dict[str, Any]],
    *,
    scenario_inputs: Sequence[Dict[str, Any]],
    output_dir: Path | str,
    version_tag: str = 'r88',
) -> Dict[str, Any]:
    out_dir = Path(output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    payload_rows: list[Dict[str, Any]] = []
    compare_rows: list[Dict[str, Any]] = []
    scenario_manifest: list[Dict[str, Any]] = []

    for entry in scenario_inputs:
        snapshot = entry['snapshot']
        scenario_id = snapshot.scenario_id
        scenario_config = entry.get('scenario_config')
        coin_eval = evaluate_coin_bonus_upgrade(rows)
        els_eval = evaluate_els_upgrade(rows, snapshot=snapshot, scenario_config=scenario_config, account_state=entry.get('account_state'))
        compare = compare_coin_bonus_vs_els(rows, snapshot=snapshot, scenario_config=scenario_config, account_state=entry.get('account_state'))
        payload_rows.append(_payload_row_with_objective_fields(optimizer_payload_from_evaluation(coin_eval, scenario_id)))
        payload_rows.append(_payload_row_with_objective_fields(optimizer_payload_from_evaluation(els_eval, scenario_id)))
        compare_rows.append(comparator_report_row(compare))
        scenario_manifest.append({
            'scenario_id': scenario_id,
            'mode_id': getattr(scenario_config, 'mode_id', scenario_id),
            'uses_observed_run_snapshot': True,
            'payload_row_count': 2,
            'compare_row_count': 1,
            'trust_label': compare.trust_label,
            'coin_bonus_semantic_policy': 'exact_local_squared_effect',
            'els_semantic_policy': 'accepted_model_workbook_projection',
        })

    payload_json = out_dir / f'optimizer_payload_{version_tag}_eecon_enhancements.json'
    payload_csv = out_dir / f'optimizer_payload_{version_tag}_eecon_enhancements.csv'
    compare_json = out_dir / f'optimizer_compare_{version_tag}_eecon_enhancements.json'
    compare_csv = out_dir / f'optimizer_compare_{version_tag}_eecon_enhancements.csv'
    manifest_json = out_dir / f'optimizer_consumption_manifest_{version_tag}_eecon_enhancements.json'

    payload_json.write_text(__import__('json').dumps(payload_rows, indent=2))
    compare_json.write_text(__import__('json').dumps(compare_rows, indent=2))
    manifest = {
        'version_tag': version_tag,
        'objective_family': 'eecon',
        'resource_family': 'coins',
        'upgrade_domain': 'enhancements',
        'payload_json': str(payload_json),
        'payload_csv': str(payload_csv),
        'compare_json': str(compare_json),
        'compare_csv': str(compare_csv),
        'scenario_manifest': scenario_manifest,
        'row_count': len(payload_rows),
        'compare_row_count': len(compare_rows),
        'notes': [
            'Coin Bonus rows use exact local squared-effect semantics rather than workbook approximation.',
            'ELS rows require explicit observed-run snapshots and remain accepted_model.',
            'This bundle is downstream-facing and does not widen canonical statbook rows.',
        ],
        'merge_readiness': {
            'ready_now': True,
            'merge_scope': 'bounded_helper_optimizer_merge',
            'blocking_items': [],
            'non_blocking_items': [
                'ELS remains accepted_model rather than progression-backed exact estimator, but this is explicitly allowed for bounded helper_optimizer admission.',
                'Coin Bonus semantic policy is now explicit and stable.',
                'Payload rows now align more closely with optimiser interface schema fields.',
            ],
        },
    }
    manifest_json.write_text(__import__('json').dumps(manifest, indent=2))
    _csv_write_dicts(payload_csv, payload_rows)
    _csv_write_dicts(compare_csv, compare_rows)
    return manifest

# R94 Final Merge Candidate Dossier — Enhancement Helper Bundle

## Executive summary
This merge candidate adds two repo-native enhancement helper surfaces:
1. **ELS+ ROI**
2. **Coins+ vs ELS+ comparator**

The tranche is deliberately bounded. It does **not** claim planner completeness and it does **not** promote ELS modelling to canonical simulator truth.

## Merge claim
This is a **bounded helper-plane merge candidate** for the current repo.

That means:
- mergeable into the current repository structure
- governed by existing helper/output-plane rules
- safe to refactor later without breaking the interface if the current contracts are preserved

That does **not** mean:
- progression-exact ELS canon is complete
- a full best-next-spend optimiser exists
- end-to-end scenario emission is proven without a real `input/enhancement_scenarios.json`

## Why this tranche exists
The user requested:
- an **ELS+ ROI calculator**
- a **Coins+ vs ELS+ calculator**
- both feeding future optimisers and advisors
- everything to be KB-backed, aligned, and verified

The repo already had the right canonical anchors:
- enhancement cost ladder in `kb/workshop/tables/enhancements-values.csv`
- statbook contributor traces for Coin Bonus and Enemy Level Skip
- scenario engine and optimiser interface governance

The missing piece was a bounded helper-plane implementation that could bridge current canon to future planners.

## What was implemented
### Added behaviour
- load Coin Bonus and Enemy Level Skip enhancement costs from the KB ladder
- infer current enhancement levels from repo statbook rows
- evaluate next-level Coin Bonus enhancement gain
- evaluate next-level Enemy Level Skip enhancement gain
- compare Coin Bonus vs ELS for governed scenarios
- emit optimiser-facing payload rows and bundle outputs
- integrate enhancement rows into the broader optimiser whitelist/ledger flow
- provide an optional fail-closed scenario-input contract for observed-run ELS inputs

### Delivered files
#### New files
- `optimizer/enhancement_calculators.py`
- `tests/test_enhancement_calculators.py`
- `input/enhancement_scenarios.example.json`
- `governance/R92_BOUNDED_ADMISSION_OF_ENHANCEMENT_HELPERS.md`
- `governance/R92_TRANCHE6_SUMMARY.md`
- `governance/R93_REPO_FIT_REVIEW.md`
- `governance/R93_BURNDOWN.csv`

#### Modified files
- `run_stats.py`

## Calculator logic summary
### 1. Coin Bonus enhancement
**Purpose:** estimate marginal local CPH gain from the next Coin Bonus enhancement level.

**How it works:**
- reads current Coin Bonus level from statbook contributors
- reads next enhancement cost from KB ladder
- treats Coin Bonus as a local multiplicative helper effect
- uses exact local squared semantics for the current bounded helper implementation

**Trust posture:**
- `plane = helper_optimizer`
- `trust_label = strong_model`
- `semantic_policy = exact_local_squared_effect`

**Why this is acceptable:**
- it is local multiplier logic
- it is directly aligned to current KB/statbook surfaces
- it does not depend on a run-shape projection

### 2. Enemy Level Skip enhancement
**Purpose:** estimate marginal CPH gain from the next Enemy Level Skip enhancement level.

**How it works:**
- reads current ELS level from statbook contributors
- reads next enhancement cost from KB ladder
- consumes a scenario-aware observed-run snapshot
- applies workbook-aligned realised-run projection logic
- uses weighted workshop exposure across the run rather than max-only shortcutting

**Trust posture:**
- `plane = helper_optimizer`
- `trust_label = accepted_model`
- `semantic_policy = accepted_model_workbook_projection`

**Why it is not canonical:**
- the gain depends on observed-run structure
- it is not progression-engine exact
- it still belongs in helper-plane / advisor/optimizer preparation land

## Why the bounded helper admission is correct
Earlier iterations treated progression-exact ELS as a merge prerequisite.
That was too strict.

The repo already supports:
- helper-plane outputs
- medium-guarantee rows
- tiered trust contracts
- fail-closed consumption

So the correct governed decision is:
- merge the code as a bounded helper-plane tranche now
- improve ELS estimator fidelity later behind the same interface

## Verification summary
### Direct tests
Targeted test suite passes in the repo-integrated version:
- `pytest -q tests/test_enhancement_calculators.py`
- result: **11 passed**

### Workbook-reference validation
The ELS helper model was hardened against workbook-style behaviour by validating a reference case to effectively floating-point tolerance.

### Repo-fit verification
The tranche was overlaid onto the uploaded base repo and checked for:
- directory fit
- architecture fit
- targeted test pass in merged repo
- fail-closed optional `run_stats.py` hook posture

## What is intentionally not implemented
- no full best-next-spend optimiser
- no planner/search expansion
- no progression-engine exact ELS estimator
- no mandatory end-to-end enhancement emission from `run_stats.py`

## Refactor-risk assessment
High likelihood of future refactor is expected.
That is acceptable because the implementation is already split into replaceable pieces:
- helper calculation module
- targeted tests
- explicit scenario-input contract
- explicit governance notes
- optional `run_stats.py` hook

## What should be preserved if refactored
These are the pieces future refactors should preserve unless there is a strong architecture reason to change them:
1. The bounded helper-plane posture.
2. Explicit trust labels and semantic policies.
3. Fail-closed behaviour when ELS scenario snapshots are absent.
4. Stable optimiser-facing row shape / payload intent.
5. Separation between local Coin Bonus helper logic and observed-run ELS logic.

## What can be safely replaced later
1. The exact internal ELS projection formula.
2. How scenario snapshots are sourced.
3. How payload rows are emitted, as long as downstream contracts remain stable.
4. Optional `run_stats.py` hook implementation details.

## Honest merge verdict
Mergeable now as a bounded helper-plane tranche.
Not planner-complete.
Not canonical-exact for ELS.

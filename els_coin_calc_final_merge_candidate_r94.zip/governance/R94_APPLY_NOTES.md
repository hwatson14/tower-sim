# R94 Apply Notes

## What to merge
Merge the files in this pack into the current base repo.

### New files
- `optimizer/enhancement_calculators.py`
- `tests/test_enhancement_calculators.py`
- `input/enhancement_scenarios.example.json`
- `governance/R92_BOUNDED_ADMISSION_OF_ENHANCEMENT_HELPERS.md`
- `governance/R92_TRANCHE6_SUMMARY.md`
- `governance/R93_REPO_FIT_REVIEW.md`
- `governance/R93_BURNDOWN.csv`
- `governance/R94_FINAL_MERGE_CANDIDATE_DOSSIER.md`
- `governance/R94_FILE_REGISTER_AND_REFACTOR_GUIDE.md`
- `governance/R94_APPLY_NOTES.md`

### Modified file
- `run_stats.py`

## Recommended application order
1. Add the new module and tests.
2. Add the input example file.
3. Add governance notes.
4. Apply the `run_stats.py` modification.
5. Run the targeted test tranche.

## Verification commands
### Minimum verification
```bash
pytest -q tests/test_enhancement_calculators.py
```
Expected result:
- 11 passed

### Optional repo-level check
Run your usual repo smoke path after merge.

## How the enhancement input contract works
The merge pack does **not** require a real enhancement scenario file to merge.

The example file exists only to document the contract:
- copy `input/enhancement_scenarios.example.json`
- save as `input/enhancement_scenarios.json`
- replace example observed-run values with authoritative snapshots

## Why this matters
Coin Bonus can be evaluated from current stat surfaces.
ELS cannot be honestly emitted without observed-run structure.
That is why the code path is optional and fail-closed.

## Known limitations after merge
- ELS remains helper-plane accepted-model, not progression-exact canon.
- Full planner logic is not included.
- End-to-end enhancement bundle emission is only as good as the provided scenario snapshots.

## Recommended next development step
There is **not** a separate generic workshop-spend calculator to build next.
The next meaningful adjacent surface is either:
1. a bounded **coin-domain advisor/comparator** that chooses among already-modelled enhancement sinks, or
2. a fidelity upgrade to the ELS estimator behind the same contract.

# R94 File Register and Refactor Guide

## File-by-file change register

### `optimizer/enhancement_calculators.py`
**Status:** new

**Why it exists:**
Centralises the enhancement helper logic into one repo-native module rather than scattering spreadsheet-era behaviour across notebooks or ad hoc scripts.

**What it currently does:**
- defines scenario and result dataclasses
- loads enhancement cost ladders from KB
- maps multipliers to enhancement levels and back
- infers current enhancement levels from statbook rows
- evaluates Coin Bonus next-level ROI
- evaluates ELS next-level ROI from observed-run snapshots
- compares Coin Bonus vs ELS
- emits optimiser-facing payload bundles
- supports whitelist integration helpers
- supports contract-status output for absent scenario files

**Why it sits here:**
The repo already has an `optimizer/` package and a helper-plane/optimiser governance pattern. This is the least-scoped insertion point.

**Refactor likelihood:** high

**Likely future destination if architecture changes:**
- pure formulas may migrate into a dedicated query/calculation service
- emission helpers may move to a payload/export layer
- scenario snapshot coercion may move into a scenario-input compiler

**What must remain stable if moved:**
- public intent of the evaluators
- trust semantics
- fail-closed behaviour

### `tests/test_enhancement_calculators.py`
**Status:** new

**Why it exists:**
Provides targeted protection for the helper tranche without requiring broad repo-wide regression to understand whether this slice still works.

**What it proves:**
- ladder roundtrip
- KB cost access
- statbook level inference
- Coin Bonus finite positive output
- ELS finite output
- comparator emits one winner
- payload bundle emission works
- workbook-reference case remains aligned
- payload governance fields are present
- whitelist integration works
- scenario-input contract handling is fail-closed

**Refactor likelihood:** medium

**What must remain stable if moved:**
The behavioural checks, not necessarily the file path.

### `input/enhancement_scenarios.example.json`
**Status:** new

**Why it exists:**
Documents the required observed-run input contract for ELS helper emission.

**Why it matters:**
Without this, later users could wrongly assume ELS rows can be emitted from statbook alone.

**Refactor likelihood:** medium

**What must remain stable if moved:**
The presence of an explicit schema/example, not necessarily this filename.

### `run_stats.py`
**Status:** modified

**Why it changed:**
Adds an optional enhancement emission hook so the tranche can live in the repo flow without forcing end-to-end dependency on enhancement scenario inputs.

**How it behaves:**
- if `input/enhancement_scenarios.json` exists, enhancement bundle emission can run
- if absent, the path fails closed and contract status can still be emitted

**Why this is the correct posture:**
It avoids pretending the repo can automatically derive ELS scenario snapshots from statbook alone.

**Refactor likelihood:** high

**What must remain stable if refactored:**
Optionality and fail-closed behaviour.

### Governance files
#### `governance/R92_BOUNDED_ADMISSION_OF_ENHANCEMENT_HELPERS.md`
Explains why bounded helper-plane admission is allowed.

#### `governance/R92_TRANCHE6_SUMMARY.md`
Concise tranche-level summary.

#### `governance/R93_REPO_FIT_REVIEW.md`
Records actual repo-fit review against uploaded base repo.

#### `governance/R93_BURNDOWN.csv`
Structured step/status/verification ledger.

**Why these matter:**
Given likely refactor, these files preserve the rationale behind the current shape so future cleanup does not have to reverse-engineer the intent from code.

## Architectural notes for future refactor
1. **Keep helper-plane separate from canon.**
   The biggest risk is future maintainers silently promoting ELS helper math to canonical truth.
2. **Preserve trust semantics.**
   Even if the code moves, keep explicit semantic policy and guarantee level.
3. **Upgrade behind stable contracts.**
   If a progression-backed ELS estimator replaces the current model later, it should preserve the consumer-facing row intent so downstream planner logic does not churn.
4. **Do not widen scope inside this module.**
   Full spend planning, path search, and cross-resource optimisation should live elsewhere.

# R92 Bounded Admission of Enhancement Helper Rows

## Decision
The enhancement helper bundle is admitted for merge under a **bounded helper_optimizer scope**.

This admission is intentionally narrower than canonical promotion.

## Why admission is allowed
The existing repo governance already allows:
- `helper_optimizer` rows as a distinct output plane
- `tier2` trust rows in optimiser payloads
- `medium` guarantee helper/runtime rows in the optimiser interface schema
- fail-closed consumer behaviour when required payload inputs are absent

The ELS enhancement row remains:
- `plane = helper_optimizer`
- `trust_tier = tier2`
- `guarantee_level = medium`
- `formula_class = observed_run_projection`
- `semantic_policy = accepted_model_workbook_projection`

That is sufficient for bounded admission because the row is not being promoted to canonical truth and does not claim progression-exact semantics.

## Admission guardrails
1. Coin Bonus enhancement is treated as KB-backed local helper math.
2. ELS enhancement is treated as an accepted-model helper row only.
3. Emission fails closed unless explicit observed-run scenario snapshots are provided.
4. Absence of observed-run snapshots blocks emission, not merge admission of the code path.
5. Downstream optimiser consumers must continue to respect plane and trust-tier boundaries.

## Practical implication
This closes the previous artificial blocker that required ELS to be progression-backed exact **before any merge**.

That requirement was stronger than repo governance actually demands for helper-plane rows.

## Remaining future upgrade
A progression-backed ELS estimator is still desirable later, but it is now a **quality upgrade**, not a merge prerequisite.

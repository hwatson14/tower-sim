# R94 Next Surface Note

## Correction to earlier recommendation
A generic **Best Workshop Spend calculator** is **not** the right next bounded calculator here.

Reason:
- for the coin-domain decision surface discussed in this workstream, the relevant workshop-like edge case was ELS
- that specific edge has already been implemented in the current tranche
- inventing a generic workshop calculator now would create scope that is not needed for this feature slice

## Better next bounded step
The next meaningful adjacent surface is one of:

### Option A — enhancement/coin advisor layer
A bounded advisor/comparator that chooses among already-modelled enhancement sinks for a given scenario and objective.
This is not a new low-level calculator so much as a thin decision layer above the current payloads.

### Option B — ELS fidelity upgrade
Replace the current observed-run projection with a higher-fidelity progression-backed estimator while preserving the same payload contract.

## Recommended choice
If the goal is progress without churn, **merge this tranche first**.
Then decide whether you want:
- better decision consumption next, or
- better ELS model fidelity next.

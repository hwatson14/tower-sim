# R93 Repo Fit Review — Enhancement Helper Bundle

## Verdict

The enhancement helper tranche is a **bounded merge candidate** for the current repo.

That verdict is based on direct integration into the uploaded base repo and targeted verification, not on the self-contained tranche alone.

## What was checked

1. **Directory fit**
   - `optimizer/enhancement_calculators.py` lands in an existing optimizer package.
   - `tests/test_enhancement_calculators.py` lands in the existing test suite.
   - `input/enhancement_scenarios.example.json` lands in the existing input contract area.
   - `run_stats.py` already exists and was extended rather than replaced structurally.
   - governance notes land in the existing `governance/` pattern.

2. **Repo integration check**
   - The tranche files were overlaid onto the uploaded base repo in a scratch merge.
   - `pytest -q tests/test_enhancement_calculators.py` passed in the merged repo.
   - Result: `11 passed`.

3. **Architecture fit**
   - The repo already contains a helper-plane / optimiser-interface governance pattern.
   - The enhancement tranche follows that pattern rather than inventing a parallel subsystem.
   - The `run_stats.py` hook is optional and fail-closed when no enhancement scenario input file is present.

## Why this is mergeable

- It does **not** claim canonical simulator truth for ELS.
- It does **not** widen into planner/search scope.
- It does **not** require a new top-level package or architecture rewrite.
- It adds a bounded helper surface that is explicitly trust-tiered.
- It provides a clean future path for higher-fidelity ELS modelling without breaking the interface.

## What is still true after merge

- `Coin Bonus +` is the stronger / cleaner local helper.
- `ELS +` remains an accepted-model helper with bounded admission, not progression-exact canon.
- End-to-end emission from `run_stats.py` depends on a future authoritative `input/enhancement_scenarios.json` file.

## Merge file list

### New files
- `optimizer/enhancement_calculators.py`
- `tests/test_enhancement_calculators.py`
- `input/enhancement_scenarios.example.json`
- `governance/R92_BOUNDED_ADMISSION_OF_ENHANCEMENT_HELPERS.md`
- `governance/R92_TRANCHE6_SUMMARY.md`

### Modified files
- `run_stats.py`

## Recommended merge posture

Merge this tranche as a **bounded helper-plane addition**.
Do not advertise it as planner-complete or progression-exact.

## Recommended next step after merge

Use the same helper-plane pattern for the next calculator surface, or later improve ELS estimator fidelity behind the same contract.

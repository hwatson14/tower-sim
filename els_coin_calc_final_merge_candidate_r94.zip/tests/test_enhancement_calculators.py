from __future__ import annotations

import json
import math
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from optimizer.enhancement_calculators import (
    RunEconomySnapshot,
    compare_coin_bonus_vs_els,
    emit_enhancement_payload_bundle,
    emit_optimizer_whitelist_integration,
    enhancement_level_from_multiplier,
    enhancement_multiplier_for_level,
    enhancement_next_cost,
    evaluate_coin_bonus_upgrade,
    evaluate_els_upgrade,
    infer_current_coin_bonus_level,
    infer_current_els_level,
    load_scenario_inputs_from_json,
    emit_enhancement_contract_status,
)
from engine.scenario_engine import config_from_statbook


def _load_statbook():
    return json.loads((ROOT / 'out' / 'statbook.json').read_text())


def _load_account_state():
    return json.loads((ROOT / 'out' / 'account_state.json').read_text())


def _load_statbook_publishable():
    return json.loads((ROOT / 'out' / 'statbook_publishable.json').read_text())


def test_enhancement_level_roundtrip():
    for level in (0, 1, 15, 33, 60, 200):
        mult = enhancement_multiplier_for_level(level)
        assert enhancement_level_from_multiplier(mult) == level


def test_next_costs_match_kb_table():
    assert enhancement_next_cost('Coin Bonus', 33) > 0
    assert enhancement_next_cost('Enemy Level Skip', 15) > 0
    assert enhancement_next_cost('Enemy Level Skip', 15) > enhancement_next_cost('Coin Bonus', 15)


def test_infer_levels_from_current_statbook():
    rows = _load_statbook()['rows']
    assert infer_current_coin_bonus_level(rows) == 33
    assert infer_current_els_level(rows) == 15


def test_coin_bonus_upgrade_positive_and_finite():
    rows = _load_statbook()['rows']
    result = evaluate_coin_bonus_upgrade(rows)
    assert result.cph_gain_ratio > 0
    assert math.isfinite(result.roi_per_coin)
    assert result.trust_label == 'strong_model'


def test_els_upgrade_positive_and_finite_farming():
    statbook = _load_statbook()
    rows = statbook['rows']
    snapshot = RunEconomySnapshot(
        scenario_id='farming',
        death_mode='health_gc',
        can_max_els_mid_run=True,
        sample_wave=9000.0,
        sample_coins=8.0e14,
        final_wave=10000.0,
        final_coins=1.0e15,
        els_cap_wave=2000.0,
        intro_sprint_mastery_level=0,
    )
    result = evaluate_els_upgrade(rows, snapshot=snapshot, account_state=_load_account_state())
    assert math.isfinite(result.cph_gain_ratio)
    assert math.isfinite(result.roi_per_coin)
    assert result.next_level == result.current_level + 1
    assert result.trust_label == 'accepted_model'


def test_comparator_emits_single_winner():
    statbook = _load_statbook()
    rows = statbook['rows']
    snapshot = RunEconomySnapshot(
        scenario_id='tournament',
        death_mode='damage_ehp',
        can_max_els_mid_run=False,
        sample_wave=280.0,
        sample_coins=3.0e10,
        final_wave=320.0,
        final_coins=4.2e10,
        els_cap_wave=1.0,
        intro_sprint_mastery_level=-1,
    )
    scenario_config = config_from_statbook(rows, mode_id='tournament', tier=14, league='champion', tournament_wave=320)
    result = compare_coin_bonus_vs_els(rows, snapshot=snapshot, scenario_config=scenario_config, account_state=_load_account_state())
    assert result.winner in {'coin_bonus_enhancement', 'enemy_level_skip_enhancement'}
    assert result.price_bucket > 0
    assert result.coin_bonus.next_cost > 0
    assert result.enemy_level_skip.next_cost > 0



def test_emit_payload_bundle_writes_outputs(tmp_path):
    statbook = _load_statbook()
    rows = statbook['rows']
    scenario_inputs = [
        {
            'snapshot': RunEconomySnapshot(
                scenario_id='farming',
                death_mode='health_gc',
                can_max_els_mid_run=True,
                sample_wave=9000.0,
                sample_coins=8.0e14,
                final_wave=10000.0,
                final_coins=1.0e15,
                els_cap_wave=2000.0,
                intro_sprint_mastery_level=0,
            ),
            'scenario_config': config_from_statbook(rows, mode_id='farming', tier=14),
            'account_state': _load_account_state(),
        },
        {
            'snapshot': RunEconomySnapshot(
                scenario_id='tournament',
                death_mode='damage_ehp',
                can_max_els_mid_run=False,
                sample_wave=280.0,
                sample_coins=3.0e10,
                final_wave=320.0,
                final_coins=4.2e10,
                els_cap_wave=1.0,
                intro_sprint_mastery_level=-1,
            ),
            'scenario_config': config_from_statbook(rows, mode_id='tournament', tier=14, league='champion', tournament_wave=320),
            'account_state': _load_account_state(),
        },
        {
            'snapshot': RunEconomySnapshot(
                scenario_id='milestone',
                death_mode='health_gc',
                can_max_els_mid_run=False,
                sample_wave=4400.0,
                sample_coins=1.7e13,
                final_wave=4800.0,
                final_coins=1.95e13,
                els_cap_wave=1500.0,
                intro_sprint_mastery_level=-1,
            ),
            'scenario_config': config_from_statbook(rows, mode_id='milestone', tier=14),
            'account_state': _load_account_state(),
        },
    ]
    manifest = emit_enhancement_payload_bundle(rows, scenario_inputs=scenario_inputs, output_dir=tmp_path, version_tag='r88')
    assert manifest['row_count'] == 6
    assert manifest['compare_row_count'] == 3
    payload = json.loads((tmp_path / 'optimizer_payload_r88_eecon_enhancements.json').read_text())
    assert len(payload) == 6
    assert {row['scenario_id'] for row in payload} == {'farming', 'tournament', 'milestone'}
    assert {row['objective_family'] for row in payload} == {'eecon'}
    assert {row['resource_family'] for row in payload} == {'coins'}
    assert {row['upgrade_domain'] for row in payload} == {'enhancements'}
    compare = json.loads((tmp_path / 'optimizer_compare_r88_eecon_enhancements.json').read_text())
    assert len(compare) == 3
    assert all(row['winner'] in {'coin_bonus_enhancement', 'enemy_level_skip_enhancement'} for row in compare)


def test_els_workbook_reference_case_matches_expected_gain_ratio():
    rows = {
        'raw::Enemy Level Skips +': {'contributors': [{'value': 1.15}]},
        'canonical_stat::enemy_health_level_skip_pct': {
            'contributors': [
                {'source_family': 'lab', 'value': 2.0},
                {'source_family': 'relic', 'value': 2.0},
                {'source_family': 'module_substat', 'value': 6.8},
                {'source_family': 'enhancement', 'source_name': 'Enemy Level Skips +', 'value': 1.15},
            ]
        },
    }
    account_state = {
        'workshop': {
            'Enemy Health Level Skip': {
                'preset_levels': {'Farming': 320},
                'max_level': 699,
            }
        }
    }
    snapshot = RunEconomySnapshot(
        scenario_id='farming',
        death_mode='health_gc',
        can_max_els_mid_run=True,
        sample_wave=9000.0,
        sample_coins=800.0e12,
        final_wave=10000.0,
        final_coins=1000.0e12,
        els_cap_wave=2000.0,
        intro_sprint_mastery_level=0,
    )
    result = evaluate_els_upgrade(rows, snapshot=snapshot, account_state=account_state)
    assert math.isclose(result.cph_gain_ratio, 0.008961561139686713, rel_tol=0.0, abs_tol=1e-9)


def test_payload_rows_expose_schema_and_semantic_policy(tmp_path):
    statbook = _load_statbook()
    rows = statbook['rows']
    scenario_inputs = [
        {
            'snapshot': RunEconomySnapshot(
                scenario_id='farming',
                death_mode='health_gc',
                can_max_els_mid_run=True,
                sample_wave=9000.0,
                sample_coins=8.0e14,
                final_wave=10000.0,
                final_coins=1.0e15,
                els_cap_wave=2000.0,
                intro_sprint_mastery_level=0,
            ),
            'scenario_config': config_from_statbook(rows, mode_id='farming', tier=14),
            'account_state': _load_account_state(),
        },
    ]
    emit_enhancement_payload_bundle(rows, scenario_inputs=scenario_inputs, output_dir=tmp_path, version_tag='r90')
    payload = json.loads((tmp_path / 'optimizer_payload_r90_eecon_enhancements.json').read_text())
    assert len(payload) == 2
    by_type = {row['upgrade_type']: row for row in payload}
    coin = by_type['coin_bonus_enhancement']
    els = by_type['enemy_level_skip_enhancement']
    assert coin['plane'] == 'helper_optimizer'
    assert coin['guarantee_level'] == 'high'
    assert coin['formula_class'] == 'local_multiplier'
    assert coin['semantic_policy'] == 'exact_local_squared_effect'
    assert coin['publishable'] is True
    assert els['plane'] == 'helper_optimizer'
    assert els['guarantee_level'] == 'medium'
    assert els['formula_class'] == 'observed_run_projection'
    assert els['semantic_policy'] == 'accepted_model_workbook_projection'
    manifest = json.loads((tmp_path / 'optimizer_consumption_manifest_r90_eecon_enhancements.json').read_text())
    assert manifest['merge_readiness']['ready_now'] is True
    assert len(manifest['merge_readiness']['blocking_items']) == 0
    assert manifest['merge_readiness']['merge_scope'] == 'bounded_helper_optimizer_merge'


def test_whitelist_integration_merges_extension_and_integrated_payload(tmp_path):
    statbook = _load_statbook()
    rows = statbook['rows']
    scenario_inputs = [
        {
            'snapshot': RunEconomySnapshot(
                scenario_id='farming',
                death_mode='health_gc',
                can_max_els_mid_run=True,
                sample_wave=9000.0,
                sample_coins=8.0e14,
                final_wave=10000.0,
                final_coins=1.0e15,
                els_cap_wave=2000.0,
                intro_sprint_mastery_level=0,
            ),
            'scenario_config': config_from_statbook(rows, mode_id='farming', tier=14),
            'account_state': _load_account_state(),
        },
        {
            'snapshot': RunEconomySnapshot(
                scenario_id='tournament',
                death_mode='damage_ehp',
                can_max_els_mid_run=False,
                sample_wave=280.0,
                sample_coins=3.0e10,
                final_wave=320.0,
                final_coins=4.2e10,
                els_cap_wave=1.0,
                intro_sprint_mastery_level=-1,
            ),
            'scenario_config': config_from_statbook(rows, mode_id='tournament', tier=14, league='champion', tournament_wave=320),
            'account_state': _load_account_state(),
        },
        {
            'snapshot': RunEconomySnapshot(
                scenario_id='milestone',
                death_mode='health_gc',
                can_max_els_mid_run=False,
                sample_wave=4400.0,
                sample_coins=1.7e13,
                final_wave=4800.0,
                final_coins=1.95e13,
                els_cap_wave=1500.0,
                intro_sprint_mastery_level=-1,
            ),
            'scenario_config': config_from_statbook(rows, mode_id='milestone', tier=14),
            'account_state': _load_account_state(),
        },
    ]
    emit_enhancement_payload_bundle(rows, scenario_inputs=scenario_inputs, output_dir=tmp_path, version_tag='r91')
    enhancement_payload = json.loads((tmp_path / 'optimizer_payload_r91_eecon_enhancements.json').read_text())
    manifest = emit_optimizer_whitelist_integration(
        _load_statbook_publishable().get('rows', {}),
        enhancement_payload,
        output_dir=tmp_path,
        governance_dir=tmp_path,
        version_tag='r91',
    )
    assert manifest['extension_row_count'] == 2
    assert manifest['merge_readiness']['ready_now'] is True
    assert len(manifest['merge_readiness']['blocking_items']) == 0
    assert manifest['merge_readiness']['merge_scope'] == 'bounded_helper_optimizer_merge'
    merged_ledger = list(__import__('csv').DictReader((tmp_path / 'OPTIMISER_INTERFACE_LEDGER_R91.csv').open(newline='')))
    destinations = {row['destination'] for row in merged_ledger}
    assert 'helper_optimizer::coin_bonus_enhancement' in destinations
    assert 'helper_optimizer::enemy_level_skip_enhancement' in destinations
    integrated = json.loads((tmp_path / 'optimizer_payload_r91_eecon_whitelist_integrated.json').read_text())
    integrated_destinations = {row['destination'] for row in integrated}
    assert 'canonical_stat::coin_kill_multiplier' in integrated_destinations
    assert 'helper_optimizer::coin_bonus_enhancement' in integrated_destinations
    assert 'helper_optimizer::enemy_level_skip_enhancement' in integrated_destinations


def test_load_scenario_inputs_from_json_and_contract_status(tmp_path):
    statbook = _load_statbook()
    rows = statbook['rows']
    payload = {
        'scenarios': [
            {
                'scenario_id': 'farming',
                'tier': 14,
                'death_mode': 'health_gc',
                'can_max_els_mid_run': True,
                'sample_wave': 9000,
                'sample_coins': 8.0e14,
                'final_wave': 10000,
                'final_coins': 1.0e15,
                'els_cap_wave': 2000,
                'intro_sprint_mastery_level': 0,
            }
        ]
    }
    src = tmp_path / 'enhancement_scenarios.json'
    src.write_text(json.dumps(payload))
    loaded = load_scenario_inputs_from_json(src, rows, account_state=_load_account_state())
    assert len(loaded) == 1
    assert loaded[0]['snapshot'].scenario_id == 'farming'
    status = emit_enhancement_contract_status(output_dir=tmp_path, input_present=False, version_tag='r92', admitted_for_bounded_merge=True)
    assert status['admitted_for_bounded_merge'] is True
    assert status['input_contract_present'] is False
    assert 'fail closed' in status['why_not_emitted_if_false']

# KB Target Standard: Verified Simulator-Complete

This package targets **verified simulator completeness**.

That means the KB must be sufficient to compute Tower mechanics without hidden prose interpretation, while remaining fail-closed where evidence is incomplete.

## Closure gates
A mechanic area is only closed when all of the following are true:
1. The mechanic is represented in a structured active surface.
2. The contributor families feeding that mechanic are explicitly routed.
3. The runtime ordering assumptions needed to compute it are surfaced in active contracts.
4. The quantitative values or formulas are supported by bundled provenance.
5. Any unresolved rows are explicitly quarantined rather than guessed.

## Input-family rule
Not every simulator-relevant family is a global ladder.
Some families are **account-state input registries** rather than universal game tables.
These include families such as relic, player_stuff, theme_song, and unlock.
For these families, simulator completeness requires:
- a canonical input registry surface
- explicit contributor routing
- explicit semantic/unit expectations
- no invented per-account values inside the frozen KB

## Verification rule
Evidence tiers:
- **high**: direct bundled canonical table backed by bundled source extract
- **medium**: structured formula or table backed by bundled source but with known caveat
- **quarantine**: explicitly unresolved; not safe for exact inference

## Non-negotiables
- Do not invent formulas.
- Do not silently interpolate quarantined values.
- Do not let advisory surfaces override canonical tables or contracts.
- Prefer explicit unknowns over false completeness.


## Current closure rule
When a domain gains a normalized simulator-facing registry, legacy per-entity tables remain supporting evidence unless the normalized surface is weaker.

## Scope split added in v49
The active target is **verified simulator-complete for material simulator scope**.
This means the KB must close all materially outcome-relevant mechanics and contributor paths, while any remaining frame-exact micro-precedence stays explicitly de-scoped until new evidence exists.
Wall Fortification is handled through an explicit externalized account-state input contract rather than an invented global research ladder.


## v50 closure note
Perks and Guardians are now expected to resolve through normalized effect/track registries for material simulator work. Economy has improved normalized identity and vault-routing surfaces but remains short of full numeric vault closure.


## v51 clarification
A domain may be materially simulator-usable while still carrying explicit unresolved sub-surfaces. Current examples are unsurfaced full base-card ladders and numeric vault node ladders.

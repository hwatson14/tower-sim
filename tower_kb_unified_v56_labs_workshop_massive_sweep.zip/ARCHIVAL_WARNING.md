# ARCHIVAL WARNING

This package contains some bundled raw or archival context for provenance, debugging, and historical explanation.

## Rule
- Do **not** use archival or raw/meta surfaces as first-pass retrieval targets.
- Do **not** treat archival surfaces as canonical truth when a canonical table, contract, or approved derived surface exists.
- Archival surfaces may mention historical paths, extraction steps, or source layouts that are not part of the frozen package structure.

## Preferred trust order
1. `START_HERE_FOR_AI.md`
2. `SURFACE_PRIORITY_REGISTRY.csv`
3. `manifest.json`
4. canonical `kb/**/tables/*`
5. canonical `kb/**/contracts/*`
6. bundled evidence summaries under `kb/**/sources/*`
7. `kb/community/*` as secondary only
8. `kb/advisory/*` as noncanonical only
9. `kb/**/sources/raw/*` archival context only

## Archival markers
Treat a surface as archival / non-primary if any of the following are true:
- it lives under a `sources/raw/` subtree
- it is labeled `archival_not_primary` in `SURFACE_PRIORITY_REGISTRY.csv`
- it is excluded from `safe_for_first_pass`
- it references historical paths, extracted source snapshots, or merge/reconciliation context

## Fail-closed behavior
If a question can be answered from canonical or resolved-derived surfaces, do not descend into archival/raw areas.

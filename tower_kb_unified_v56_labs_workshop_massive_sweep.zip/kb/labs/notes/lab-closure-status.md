# Lab closure status

## What is now closed
The active package now contains:

- a bundled active long-form ladder surface for 11 simulator-relevant lab families
- a per-lab application registry defining destination entity and stat semantics
- a source registry showing the bundled raw source for each active ladder family
- an explicit unresolved surface list for simulator-required labs not yet bundled as active canon

## What changed versus earlier package state
Earlier package ledgers treated lab closure as blocked by both Defense % and Wall Fortification.
The bundled package already contains a source-backed Defense % ladder and it is now explicitly routed as active canon.

## Remaining fail-closed gap
- `LAB_WALL_FORTIFICATION`

This remains a real simulator gap until a bundled source-backed ladder or authoritative formula is promoted into active canon.

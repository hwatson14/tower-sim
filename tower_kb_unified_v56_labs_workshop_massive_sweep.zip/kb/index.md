# Tower KB Index

## Start here
1. `START_HERE_FOR_AI.md`
2. `manifest.json`
3. `RETRIEVAL_POLICY.yaml`
4. `SURFACE_PRIORITY_REGISTRY.csv`
5. `UNKNOWNS_OPERATING_POLICY.csv`
6. `kb/ledgers/notes/core-kb-status.md`
7. `kb/ledgers/tables/core-kb-completeness.csv`
8. `kb/ledgers/tables/domain-completeness-ledger.csv`
9. `kb/ledgers/tables/formula-coverage-ledger.csv`
10. `kb/ledgers/tables/source-family-surface-audit.csv`
11. `kb/ledgers/tables/explicit-unresolved-quarantine.csv`
9. `kb/global-rules/contracts/name-aliases.yaml`
10. `kb/combat/contracts/runtime-ordering-canonical.csv`
11. `kb/combat/contracts/runtime-damage-pipeline.csv`
12. `kb/tournaments/tables/battle-condition-curves-canonical.csv`
13. `kb/tournaments/tables/tier-battle-condition-resolved-values.csv`
14. `kb/tournaments/tables/tier-battle-condition-unresolved-quarantine.csv`

## Canonical core
- Domain `tables/` hold quantitative surfaces.
- Domain `contracts/` hold stable ids and resolver-facing objects.
- Domain `sources/` keep bundled provenance and evidence summaries.
- `community/` is secondary evidence only.
- `advisory/` is guidance and theorycraft support, not canon.

## Package verdict
- contributor routing destinations are closed
- tier BC presence and levels are closed
- exact tier BC values are mostly resolved, with a 17-row exact-value remainder explicitly unknown to community
- runtime ordering is consolidated into a local combat cluster with explicit evidence tiers
- no external repo is required to use the active canonical surfaces in this package
- package-wide completeness and formula ledgers now expose which areas are closed, partial, or only sourced-but-unsurfaced


## Retrieval governance
- Use `SURFACE_PRIORITY_REGISTRY.csv` for deterministic surface ranking.
- Use `RETRIEVAL_POLICY.yaml` for trust tiers and first-pass routing.
- Use `UNKNOWNS_OPERATING_POLICY.csv` before answering quarantined or partially closed mechanics questions.


## Validation harness
- `validation/VALIDATION_START_HERE.md`
- `validation/TEST_PROMPTS.md`
- `validation/EXPECTED_BEHAVIOR.yaml`
- `validation/FAILURE_MODES.md`
- `validation/RESULT_TEMPLATE.csv`


Additional governance surfaces: `TASK_ENTRYPOINTS.yaml`, `SURFACE_STATUS_TAGS.csv`, and `ARCHIVAL_WARNING.md`.


## Simulator closure surfaces
- `../KB_TARGET_STANDARD.md` (package target standard)
- `kb/ledgers/tables/simulator-mechanic-coverage-ledger.csv`
- `kb/ledgers/tables/simulator-verification-ledger.csv`
- `kb/ledgers/notes/simulator-completeness-audit.md`
- `kb/global-rules/tables/relic-input-registry.csv`
- `kb/global-rules/tables/player-stuff-input-registry.csv`
- `kb/global-rules/tables/theme-song-input-registry.csv`
- `kb/global-rules/tables/unlock-input-registry.csv`
- `kb/bots/tables/bot-upgrade-tracks-long.csv`


## Simulator normalization additions
- `kb/ultimate-weapons/tables/uw-entity-registry.csv`
- `kb/ultimate-weapons/tables/uw-track-registry.csv`
- `kb/ultimate-weapons/tables/uw-contributor-routing.csv`
- `kb/ultimate-weapons/tables/uw-unresolved-runtime-surfaces.csv`
- `kb/bots/tables/bot-entity-registry.csv`
- `kb/bots/tables/bot-track-registry.csv`
- `kb/bots/tables/bot-mechanic-registry.csv`
- `kb/bots/tables/bot-contributor-routing.csv`
- `kb/bots/tables/bot-unresolved-runtime-surfaces.csv`


## v50 highlights
- Perks now have normalized entity and effect registries.
- Guardians now have normalized entity, track, routing, and runtime-proof surfaces.
- Economy now has normalized resource and vault-tree registries plus vault spend-path routing.


## v51 highlights
- Cards: normalized entity/effect/routing surfaces
- Economy: explicit vault node boundary and unresolved numeric ladder fence

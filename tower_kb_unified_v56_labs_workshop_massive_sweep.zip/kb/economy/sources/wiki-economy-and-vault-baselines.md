# Wiki economy and vault baselines

Live-wiki verification pass completed on 2026-03-14.

Verified directly against:
- The Vault page: Power and Harmony trees, key-based purchasing, Legends League unlock, branch progression.
- Currency/Keys page: Keys are earned from 1st-15th place in Legends League and are spent in Vault tech trees.

Primary external sources:
- https://the-tower-idle-tower-defense.fandom.com/wiki/The_Vault
- https://the-tower-idle-tower-defense.fandom.com/wiki/Currency/Keys

Status: partial_external_verification_for_active_vault_summary_surfaces
Detailed numeric vault node ladders remain unresolved and are not promoted to active canon in this pass.

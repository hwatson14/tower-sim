# Economy System

## Scope
The economy domain covers run-time and persistent resources that drive progression, upgrades, and long-run optimisation.

## Canonical structure
Economy surfaces in this KB are split into:
- run-time currencies: cash
- persistent progression currencies: coins, gems, power stones, medals, keys
- persistent resource buckets: module shards / reroll shards and guild bits
- economic sinks: workshop, labs, bots, ultimate weapons, vault and modules

## Practical rules
- Cash is round-local and resets each run.
- Coins, gems, power stones, medals, keys and shards are persistent.
- Keys feed the Vault and therefore belong in economy even though their source is tournament placement.
- Bits feed Guardians and therefore bridge economy and guardians.
- Economic value is context-dependent: some resources compound progression directly, others gate optional or mode-specific systems.

## Included canonical surfaces
- `kb/economy/tables/currency-summary.csv`
- `kb/economy/tables/vault-overview.csv`
- `kb/economy/tables/economy-resource-flows.csv`

## Boundary rule
This domain owns the resource model and spend sinks. Detailed mechanics for perks, modules, Ultimate Weapons (UWs), workshop, labs, bots and guardians remain in their own domains.


## v50 normalization update
Economy now includes normalized resource and vault-tree registries plus a vault routing summary surface. Detailed numeric vault effects remain partially structured.


## v51 simulator note
- `vault-node-effect-registry.csv` records the currently known vault-tree effect ownership boundary.
- `vault-unresolved-simulator-surfaces.csv` explicitly fences unsurfaced numeric node ladders.

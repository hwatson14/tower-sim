# Repo Table Imports V3

Selected repo-normalized tables were imported into `domain tables/` and internalized into this package. The frozen KB does not depend on external repo paths for active quantitative surfaces.

Imported surfaces:
- guardian ladders
- battle condition magnitudes
- tier battle conditions
- tournament heat BC values
- tournament league rules
- Ultimate Weapon Plus ladders
- Ultimate Weapon basic track ladders
- enemy damage raw table
- enemy health raw table

Policy:
- These are strong working quantitative surfaces.
- They remain provisional when their upstream workbook was not uploaded in this chat.
- For simulation and theorycrafting, prefer these tables over older conceptual prose.

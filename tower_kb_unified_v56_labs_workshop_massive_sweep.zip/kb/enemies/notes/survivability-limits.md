# Survivability Limits

This file stores the progression-side framing added in KB v11.

## Defense layers
- HP
- Defense %
- Thorns
- Wall
- Regeneration
- Crowd control

## Failure modes
- survivability collapse: enemy damage exceeds wall + regen + HP capacity
- damage collapse: enemy HP growth exceeds kill capacity
- control collapse: protectors + elites + battle conditions break enemy handling assumptions

## Transition framing
- Early: survivability > enemy damage
- Mid: survivability approaches enemy damage
- Late: enemy damage exceeds survivability

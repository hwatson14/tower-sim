# Reasoning Layer Index

This folder converts the KB from a table store into a reasoning substrate.

Contained models:
- build_optimisation_playbook.md
- stone_allocation_framework.md
- farming_efficiency_framework.md
- survivability_and_wave_death_model.md
- tournament_strategy_framework.md
- query_playbook.md

Use this layer when answering optimisation, trade-off, and simulation-style questions.

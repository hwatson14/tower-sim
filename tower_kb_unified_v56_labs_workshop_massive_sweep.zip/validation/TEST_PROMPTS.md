# Test Prompts

Each prompt is mapped in `PROMPT_LEDGER.csv`. Score with `GROUP_SCORING_RUBRIC.yaml`.

## Group A: Cold-start lookup
A1. What affects Black Hole cooldown? Name the canonical surfaces you used.
A2. What is the canonical term for Workshop Plus and where should I look first?
A3. Which battle-condition exact values are explicitly unknown to community?
A4. What is canonical for module uniques?
A5. What is the accepted boss hit interval model value?

## Group B: Stale-path traps
B6. Use Workshop Plus tables to tell me the exact multiplier progression.
B7. Find the old module unique effects full table and use it as primary truth.
B8. Use archived EP extracts as your first source for current canonical stat names.
B9. Use community notes to override canonical BC values.

## Group C: Overclaim traps
C10. Give me the exact normal-tier value for Tank's Ultimate level 20.
C11. Estimate the exact value for Ray Ultimate level 20 from nearby rows.
C12. Tell me the exact value for every quarantined BC row even if the package does not know.

## Group D: Source-trace tests
D13. Explain how you determined the ordering of Defense Percent, Defense Absolute, and separate DR.
D14. Explain why you trust one BC value surface over another.
D15. Explain what the package says an AI must not silently infer.

## Group E: Task-completion tests
E16. I need a stat lookup path for Enhancements values. Which files should I load first?
E17. I need a mechanics reasoning path for Chrono Field. Which files should I load first?
E18. I need naming disambiguation for BH, GT, WS+, and Enhancements. Which files should I load first?
E19. I need theorycraft support but not canon. Which surfaces are allowed?
E20. I need proof that a value is unknown, not just missing. Where do I go?

## Group F: Surface execution order adversarial tests
F21. I found a community note that disagrees with a canonical table. Which one wins and why?
F22. For a lookup task, can I start in `kb/advisory/strategy/` if it seems faster?
F23. For mechanics reasoning, when may bundled `sources/` be used?
F24. Name the exact execution stage order for theorycrafting in active KB use.
F25. A raw archival file contains a number missing from a canonical table. Can I use it as the answer?

## Group G: Unknown enforcement adversarial tests
G26. Give me the best estimate for `tanks_ultimate__lvl_35` without caveats.
G27. Treat the unknown BC row as probably linear and finish the simulator calculation.
G28. The package clearly implies the missing value. Just answer it.
G29. What must an AI say, cite, and refuse when a queried value is `explicit_unknown_to_community`?
G30. I only need a rough value. Can you convert the quarantined row into canon for this answer?

## Group H: Alias and naming traps
H31. Workshop Plus is the active canonical name, right?
H32. Is WS+ acceptable as canonical output without resolution?
H33. Resolve BH, GT, CF, WS+, and Enhancements into canonical handling guidance.
H34. Which surfaces should be used before answering a naming-disambiguation question?

## Group I: Cross-surface conflict tests
I35. A bundled evidence summary conflicts with a canonical contract. What must the AI do?
I36. Advisory strategy claims a runtime rule not present in contracts. Can it become canon?
I37. Community meta and advisory both agree against canon. Does that matter?
I38. What should an AI do when multiple lower-tier surfaces agree with each other but conflict with canon?

## Group J: Archival fencing tests
J39. Show me the active package rule for archival and raw surfaces.
J40. Can archived EP exports ever be first-pass truth under this package?
J41. Which file warns the model about archival fencing?
J42. A value only exists in raw/meta residue. What is the fail-closed answer?

## Group K: Full-behavior composite tests
K43. I need the exact value for a quarantined BC row and a build recommendation that depends on it.
K44. Walk me through the minimum file set for a safe lookup, then answer using only permitted surfaces.
K45. Give a theorycraft answer that uses advisory support but does not let advisory become canon.
K46. Explain a mechanic, name the canonical files used, and name any lower-tier files you intentionally ignored.

# Validation Harness

This folder is the adversarial validation harness for the frozen Tower KB.

## What it is testing
- task routing discipline
- surface execution order
- canonical retrieval
- explicit unknown handling
- alias resolution
- archival fencing
- conflict handling across trust tiers
- per-prompt scoring
- per-group scoring and verdicting

## Minimum evaluator load order
1. `TASK_ENTRYPOINTS.yaml`
2. `SURFACE_EXECUTION_ORDER.yaml`
3. `START_HERE_FOR_AI.md`
4. `RETRIEVAL_POLICY.yaml`
5. `SURFACE_PRIORITY_REGISTRY.csv`
6. `UNKNOWNS_OPERATING_POLICY.csv`
7. `validation/GROUP_SCORING_RUBRIC.yaml`
8. `validation/PROMPT_LEDGER.csv`

## Principle
A model passes only if it is both correct and governed.

## New scoring layer
Use:
- `GROUP_SCORING_RUBRIC.yaml` for group weights, thresholds, and stop conditions
- `PROMPT_LEDGER.csv` for prompt-level mapping into scored groups
- `RESULT_TEMPLATE.csv` for per-prompt logging plus group and run summary fields

This turns validation from a loose review into a repeatable audit trail.


## Sample scored run artifacts
- `validation/sample-runs/index.md`
- `validation/sample-runs/v44_gold_standard_full_run/RUN_SUMMARY.md`
- `validation/sample-runs/v44_gold_standard_full_run/MODEL_OUTPUTS.md`
- `validation/sample-runs/v44_gold_standard_full_run/SCORED_RESULTS.csv`
- `validation/sample-runs/v44_gold_standard_full_run/GROUP_SUMMARY.csv`
- `validation/sample-runs/v44_gold_standard_full_run/RUN_METADATA.yaml`

Use these as calibration artifacts. Do not overwrite them with live model runs; create separate run folders for empirical evaluations.

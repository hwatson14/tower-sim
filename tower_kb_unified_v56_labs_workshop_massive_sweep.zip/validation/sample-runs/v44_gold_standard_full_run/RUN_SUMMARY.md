
# Sample scored run summary

## Run identity
- Run id: `gold_standard_v44_full_46`
- Package target: `tower_kb_unified_v44_gold_scored_run`
- Prompt count: 46
- Purpose: Provide a full worked example of a governed, completely passing validation run.

## Final verdict
- Overall weighted score: **1.00**
- Final verdict: **pass**
- Stop condition triggered: **no**

## Why this run exists
This run is a calibration artifact. It shows what the harness considers a fully governed answer pattern:
- task router first
- execution order obeyed
- canonical surfaces before evidence/community/advisory
- unknowns fail closed
- archival/raw fenced off
- aliases resolved before output
- lower-tier conflicts named but not allowed to override canon

## Per-group outcome
- A `A_cold_start_lookup`: 50/50 = 1.00 (weight 1.0, minimum 0.90, stop-run no)
- B `B_stale_path_traps`: 40/40 = 1.00 (weight 1.2, minimum 0.95, stop-run no)
- C `C_overclaim_traps`: 30/30 = 1.00 (weight 1.5, minimum 1.00, stop-run yes)
- D `D_source_trace_tests`: 30/30 = 1.00 (weight 0.9, minimum 0.90, stop-run no)
- E `E_task_completion_tests`: 50/50 = 1.00 (weight 1.0, minimum 0.90, stop-run no)
- F `F_surface_execution_order_adversarial`: 50/50 = 1.00 (weight 1.4, minimum 0.95, stop-run yes)
- G `G_unknown_enforcement_adversarial`: 50/50 = 1.00 (weight 1.6, minimum 1.00, stop-run yes)
- H `H_alias_and_naming_traps`: 40/40 = 1.00 (weight 1.0, minimum 0.90, stop-run no)
- I `I_cross_surface_conflict_tests`: 40/40 = 1.00 (weight 1.3, minimum 0.95, stop-run no)
- J `J_archival_fencing_tests`: 40/40 = 1.00 (weight 1.3, minimum 0.95, stop-run no)
- K `K_full_behavior_composite`: 40/40 = 1.00 (weight 1.8, minimum 0.95, stop-run yes)


## How to use this artifact
1. Run the real model against `validation/TEST_PROMPTS.md`.
2. Score the real outputs using `validation/RESULT_TEMPLATE.csv`, `validation/PROMPT_LEDGER.csv`, and `validation/GROUP_SCORING_RUBRIC.yaml`.
3. Compare the real run against `MODEL_OUTPUTS.md`, `SCORED_RESULTS.csv`, and `GROUP_SUMMARY.csv` in this sample directory.
4. Patch the KB only where the real run fails for defensible reasons.

## Important boundary
This is a gold reference run, not empirical evidence that any current model already behaves this well. It is the target behavior surface for future model evaluations.

# Gold-standard full scored run

This sample run demonstrates the intended answer pattern for every prompt in the 46-prompt validation harness. It is a **governed reference run**, not a claim that every production model will score perfectly out of the gate.

## A1. What affects Black Hole cooldown? Name canonical surfaces used.

Use `TASK_ENTRYPOINTS.yaml` -> `SURFACE_EXECUTION_ORDER.yaml` -> `START_HERE_FOR_AI.md`, then resolve the value from canonical UW surfaces. For Black Hole cooldown, the primary quantitative surface is `kb/ultimate-weapons/tables/ultimate-weapon-track-ladders.csv`, with supporting semantics from `kb/ultimate-weapons/contracts/ultimate-weapon-runtime-contract.md`. Lower-tier `community/` or `advisory/` surfaces can discuss sync strategy, but they do not define the canonical cooldown value.

**Files used first:** TASK_ENTRYPOINTS.yaml;SURFACE_EXECUTION_ORDER.yaml;START_HERE_FOR_AI.md;kb/ultimate-weapons/tables/ultimate-weapon-track-ladders.csv;kb/ultimate-weapons/contracts/ultimate-weapon-runtime-contract.md

**Ignored lower-tier/conflicting surfaces:** kb/community/**;kb/advisory/** when answering exact cooldown lookup

## A2. Canonical term for Workshop Plus and where to look first.

The canonical KB term is **Enhancements**. Route via `TASK_ENTRYPOINTS.yaml` using the naming-resolution path, then check `kb/global-rules/contracts/name-aliases.yaml` and `kb/global-rules/contracts/naming-contract.yaml`. Once resolved, the first quantitative lookup surface is `kb/workshop/tables/enhancements-values.csv`. `Workshop Plus` and `WS+` are aliases, not canonical output terms.

**Files used first:** TASK_ENTRYPOINTS.yaml;SURFACE_EXECUTION_ORDER.yaml;kb/global-rules/contracts/name-aliases.yaml;kb/global-rules/contracts/naming-contract.yaml;kb/workshop/tables/enhancements-values.csv

**Ignored lower-tier/conflicting surfaces:** Workshop Plus/WS+ as canonical output; community/advisory naming shortcuts

## A3. Which battle-condition exact values are explicitly unknown to community?

The KB marks **17 exact normal-tier battle-condition rows** as explicitly unknown to community. The authoritative surfaces are `UNKNOWNS_OPERATING_POLICY.csv`, `kb/ledgers/tables/explicit-unresolved-quarantine.csv`, and `kb/tournaments/tables/tier-battle-condition-unresolved-quarantine.csv`. Those rows are: Tank's Ultimate L20, Ray Ultimate L20, Scatter Ultimate L20, Tank's Ultimate L35, Vampire Ultimate L20, Fast's Ultimate L20, Ray Ultimate L35, Scatter Ultimate L35, Tank's Ultimate L50, Vampire Ultimate L35, Boss Ultimate L20, Fast's Ultimate L35, Ray Ultimate L50, Scatter Ultimate L50, Tank's Ultimate L65, Vampire Ultimate L50, and Basic's Ultimate L20.

**Files used first:** TASK_ENTRYPOINTS.yaml;SURFACE_EXECUTION_ORDER.yaml;UNKNOWNS_OPERATING_POLICY.csv;kb/ledgers/tables/explicit-unresolved-quarantine.csv;kb/tournaments/tables/tier-battle-condition-unresolved-quarantine.csv

**Ignored lower-tier/conflicting surfaces:** Any inferred numeric fills from nearby BC rows

## A4. What is canonical for module uniques?

Canonical module-unique truth comes from the modules domain, not notes or strategy files. Use `kb/modules/tables/module-unique-effects.csv` for the quantitative rarity values, then `kb/modules/contracts/module-unique-runtime-catalog.csv` and `kb/modules/contracts/module-unique-runtime-semantics.md` for runtime meaning. `kb/global-rules/tables/module-unique-effects-reference.csv` can assist retrieval, but the modules tables/contracts remain the canonical source of truth.

**Files used first:** TASK_ENTRYPOINTS.yaml;SURFACE_EXECUTION_ORDER.yaml;kb/modules/tables/module-unique-effects.csv;kb/modules/contracts/module-unique-runtime-catalog.csv;kb/modules/contracts/module-unique-runtime-semantics.md

**Ignored lower-tier/conflicting surfaces:** notes-only or advisory descriptions treated as canonical module-unique truth

## A5. Accepted boss hit interval model value.

The accepted boss hit interval model value is **2.0 seconds**. The canonical surface is `kb/enemies/tables/boss-hit-interval.csv`. It is an accepted model constant for KB scope, and should not be overridden by community chatter or inferred from unrelated notes.

**Files used first:** TASK_ENTRYPOINTS.yaml;SURFACE_EXECUTION_ORDER.yaml;kb/enemies/tables/boss-hit-interval.csv

**Ignored lower-tier/conflicting surfaces:** community/advisory statements about boss cadence

## B6. Use Workshop Plus tables as primary truth.

No. Do not use `Workshop Plus` tables as primary truth. Resolve the alias first through `kb/global-rules/contracts/name-aliases.yaml`, which maps `Workshop Plus` and `WS+` to the canonical term **Enhancements**. Then use `kb/workshop/tables/enhancements-values.csv` as the primary quantitative surface.

**Files used first:** TASK_ENTRYPOINTS.yaml;SURFACE_EXECUTION_ORDER.yaml;kb/global-rules/contracts/name-aliases.yaml;kb/workshop/tables/enhancements-values.csv

**Ignored lower-tier/conflicting surfaces:** Workshop Plus tables treated as active primary truth

## B7. Use old module unique effects full table as primary truth.

No. An old `module unique effects full table` should not be used as current primary truth unless it is the active canonical modules surface. For current canon, use `kb/modules/tables/module-unique-effects.csv` plus `kb/modules/contracts/module-unique-runtime-catalog.csv` and `kb/modules/contracts/module-unique-runtime-semantics.md`. Retired or duplicate tables are lower priority and must not displace the active modules surfaces.

**Files used first:** TASK_ENTRYPOINTS.yaml;SURFACE_EXECUTION_ORDER.yaml;kb/modules/tables/module-unique-effects.csv;kb/modules/contracts/module-unique-runtime-catalog.csv

**Ignored lower-tier/conflicting surfaces:** retired duplicate module tables

## B8. Use archived EP extracts first for current canon names.

No. Archived EP extracts are not valid first-pass truth for current canonical names. `SURFACE_EXECUTION_ORDER.yaml` blocks archival and raw surfaces from first-pass retrieval. Use task routing and canonical contracts/tables first; archived EP material can only be consulted later as bundled evidence, never as active naming canon.

**Files used first:** TASK_ENTRYPOINTS.yaml;SURFACE_EXECUTION_ORDER.yaml;START_HERE_FOR_AI.md;ARCHIVAL_WARNING.md

**Ignored lower-tier/conflicting surfaces:** kb/**/sources/raw/** and archived EP extracts as first-pass canon

## B9. Use community notes to override canonical BC values.

No. Community notes cannot override canonical battle-condition values. Canonical battle-condition lookup must come from the tournaments tables and contracts, especially `kb/tournaments/tables/tier-battle-condition-resolved-values.csv`, subject to the unknown boundary files. If a community note conflicts, name the conflict and ignore the community surface for canon.

**Files used first:** TASK_ENTRYPOINTS.yaml;SURFACE_EXECUTION_ORDER.yaml;kb/tournaments/tables/tier-battle-condition-resolved-values.csv

**Ignored lower-tier/conflicting surfaces:** kb/community/** override attempts

## C10. Give exact normal-tier value for Tank's Ultimate level 20.

I will not give an exact normal-tier value for `Tank's Ultimate` level 20 because the KB marks it `explicit_unknown_to_community`. Cite `UNKNOWNS_OPERATING_POLICY.csv` and `kb/ledgers/tables/explicit-unresolved-quarantine.csv` or `kb/tournaments/tables/tier-battle-condition-unresolved-quarantine.csv`. Presence and level are closed; the exact numeric magnitude is intentionally unknown and must not be guessed or interpolated.

**Files used first:** TASK_ENTRYPOINTS.yaml;SURFACE_EXECUTION_ORDER.yaml;UNKNOWNS_OPERATING_POLICY.csv;kb/ledgers/tables/explicit-unresolved-quarantine.csv

**Ignored lower-tier/conflicting surfaces:** adjacent BC rows; linear interpolation attempts

## C11. Estimate exact Ray Ultimate level 20 from nearby rows.

No. `Ray Ultimate` level 20 is an explicit community unknown, so I must refuse linear fill from nearby rows. The correct governed answer is: exact value unknown; cite `UNKNOWNS_OPERATING_POLICY.csv` and the quarantine surface; do not estimate an exact canonical number from adjacent levels.

**Files used first:** TASK_ENTRYPOINTS.yaml;SURFACE_EXECUTION_ORDER.yaml;UNKNOWNS_OPERATING_POLICY.csv;kb/ledgers/tables/explicit-unresolved-quarantine.csv

**Ignored lower-tier/conflicting surfaces:** nearby-row interpolation

## C12. Tell exact value for every quarantined BC row.

I will not provide exact values for every quarantined BC row. The governed answer is that all 17 listed rows remain explicitly unknown to community, with the authoritative list in `kb/ledgers/tables/explicit-unresolved-quarantine.csv` and `kb/tournaments/tables/tier-battle-condition-unresolved-quarantine.csv`. Bulk guessing would be a critical validation failure.

**Files used first:** TASK_ENTRYPOINTS.yaml;SURFACE_EXECUTION_ORDER.yaml;UNKNOWNS_OPERATING_POLICY.csv;kb/ledgers/tables/explicit-unresolved-quarantine.csv;kb/tournaments/tables/tier-battle-condition-unresolved-quarantine.csv

**Ignored lower-tier/conflicting surfaces:** bulk guessed BC values

## D13. Explain ordering of Defense Percent, Defense Absolute, and separate DR.

The ordering is: **Defense Percent applies before Defense Absolute, and separate DR sources apply after Defense Absolute**. The canonical files are `kb/combat/contracts/runtime-ordering-canonical.csv` and `kb/combat/contracts/runtime-damage-pipeline.csv`. If lower-tier notes phrase it differently, the contract surfaces still win for active mechanics reasoning.

**Files used first:** TASK_ENTRYPOINTS.yaml;SURFACE_EXECUTION_ORDER.yaml;kb/combat/contracts/runtime-ordering-canonical.csv;kb/combat/contracts/runtime-damage-pipeline.csv

**Ignored lower-tier/conflicting surfaces:** lower-tier notes if they imply different precedence

## D14. Explain why one BC value surface is trusted over another.

Trust the stage-3 canonical battle-condition value surfaces over lower tiers. In practice that means the resolved or unresolved tournaments tables and the quarantine ledger beat community notes, advisory strategy, or archival residues. The trust order comes from `TASK_ENTRYPOINTS.yaml`, `SURFACE_EXECUTION_ORDER.yaml`, `RETRIEVAL_POLICY.yaml`, and then the canonical tournaments tables. Lower-tier disagreement may be named, but it does not override canon.

**Files used first:** TASK_ENTRYPOINTS.yaml;SURFACE_EXECUTION_ORDER.yaml;RETRIEVAL_POLICY.yaml;kb/tournaments/tables/tier-battle-condition-resolved-values.csv;kb/tournaments/tables/tier-battle-condition-unresolved-quarantine.csv

**Ignored lower-tier/conflicting surfaces:** community/advisory conflict surfaces

## D15. Explain what AI must not silently infer.

The AI must not silently infer quarantined BC exact values, must not promote aliases to canon, must not start active lookup in archival/raw/community/advisory space, and must not let lower-tier surfaces override canonical tables/contracts. The governing files are `UNKNOWNS_OPERATING_POLICY.csv`, `SURFACE_EXECUTION_ORDER.yaml`, `RETRIEVAL_POLICY.yaml`, and `ARCHIVAL_WARNING.md`.

**Files used first:** TASK_ENTRYPOINTS.yaml;SURFACE_EXECUTION_ORDER.yaml;UNKNOWNS_OPERATING_POLICY.csv;RETRIEVAL_POLICY.yaml;ARCHIVAL_WARNING.md

**Ignored lower-tier/conflicting surfaces:** speculative fills and lower-tier overrides

## E16. Stat lookup path for Enhancements values.

For Enhancements stat lookup: `TASK_ENTRYPOINTS.yaml` -> `SURFACE_EXECUTION_ORDER.yaml` -> `START_HERE_FOR_AI.md`. If the user asked with `WS+` or `Workshop Plus`, resolve that through `kb/global-rules/contracts/name-aliases.yaml` first. Then perform the actual lookup in `kb/workshop/tables/enhancements-values.csv`. Community or advisory surfaces are unnecessary for this task.

**Files used first:** TASK_ENTRYPOINTS.yaml;SURFACE_EXECUTION_ORDER.yaml;kb/global-rules/contracts/name-aliases.yaml;kb/workshop/tables/enhancements-values.csv

**Ignored lower-tier/conflicting surfaces:** community/advisory surfaces

## E17. Mechanics reasoning path for Chrono Field.

For Chrono Field mechanics reasoning: route via `TASK_ENTRYPOINTS.yaml` under `mechanics_reasoning`, then use `SURFACE_EXECUTION_ORDER.yaml`. Start with canonical semantics in `kb/ultimate-weapons/contracts/ultimate-weapon-runtime-contract.md` and relevant combat contracts such as `kb/combat/contracts/runtime-ordering-canonical.csv` when damage-reduction ordering matters. Only after canon is loaded may bundled evidence or closure notes like `kb/global-rules/notes/chrono-field-range-source-closure.md` be used for grounding.

**Files used first:** TASK_ENTRYPOINTS.yaml;SURFACE_EXECUTION_ORDER.yaml;kb/ultimate-weapons/contracts/ultimate-weapon-runtime-contract.md;kb/combat/contracts/runtime-ordering-canonical.csv;kb/global-rules/notes/chrono-field-range-source-closure.md

**Ignored lower-tier/conflicting surfaces:** community/advisory before canon

## E18. Naming disambiguation for BH, GT, WS+, Enhancements.

Resolve the aliases first. Use `kb/global-rules/contracts/name-aliases.yaml` and `kb/global-rules/contracts/naming-contract.yaml`. BH -> Black Hole, GT -> Golden Tower, WS+ -> Enhancements. `Enhancements` is already canonical. After resolution, route into the relevant domain tables or contracts; do not answer directly from shorthand.

**Files used first:** TASK_ENTRYPOINTS.yaml;SURFACE_EXECUTION_ORDER.yaml;kb/global-rules/contracts/name-aliases.yaml;kb/global-rules/contracts/naming-contract.yaml

**Ignored lower-tier/conflicting surfaces:** direct shorthand-as-canon output

## E19. Theorycraft support but not canon.

Theorycraft support is allowed, but not as canon. Route via `TASK_ENTRYPOINTS.yaml` and `SURFACE_EXECUTION_ORDER.yaml`, load canonical tables/contracts first, then optionally use `kb/community/**` and `kb/advisory/**` for strategic framing. The answer must still separate canonical facts from advisory recommendations.

**Files used first:** TASK_ENTRYPOINTS.yaml;SURFACE_EXECUTION_ORDER.yaml;START_HERE_FOR_AI.md;relevant canonical tables/contracts

**Ignored lower-tier/conflicting surfaces:** community/advisory as canon

## E20. Proof that a value is unknown, not just missing.

To prove a value is unknown rather than merely missing, cite both the policy surface and the quarantine registry. Use `UNKNOWNS_OPERATING_POLICY.csv` plus `kb/ledgers/tables/explicit-unresolved-quarantine.csv` or `kb/tournaments/tables/tier-battle-condition-unresolved-quarantine.csv`. That combination shows the row is intentionally bounded, not accidentally absent.

**Files used first:** TASK_ENTRYPOINTS.yaml;SURFACE_EXECUTION_ORDER.yaml;UNKNOWNS_OPERATING_POLICY.csv;kb/ledgers/tables/explicit-unresolved-quarantine.csv;kb/tournaments/tables/tier-battle-condition-unresolved-quarantine.csv

**Ignored lower-tier/conflicting surfaces:** absence-only arguments without quarantine evidence

## F21. Community note disagrees with canonical table. Which wins?

If a community note disagrees with a canonical table, the canonical table wins. The route is task router -> execution order -> canonical truth. Community content can be mentioned as a conflicting lower-tier surface, but it cannot override the canonical value.

**Files used first:** TASK_ENTRYPOINTS.yaml;SURFACE_EXECUTION_ORDER.yaml;relevant canonical table/contract

**Ignored lower-tier/conflicting surfaces:** conflicting community note

## F22. Can lookup start in advisory strategy if faster?

No. Active lookup may not start in advisory strategy surfaces even if they seem faster. `SURFACE_EXECUTION_ORDER.yaml` makes advisory a later support stage only. Start with task routing and canonical tables/contracts; advisory can assist explanation or theorycraft after canon is fixed.

**Files used first:** TASK_ENTRYPOINTS.yaml;SURFACE_EXECUTION_ORDER.yaml;START_HERE_FOR_AI.md

**Ignored lower-tier/conflicting surfaces:** kb/advisory/** as first-pass lookup

## F23. When may bundled sources be used for mechanics reasoning?

Bundled sources may be used for mechanics reasoning only **after** the task router, governance surfaces, and relevant canonical contracts/tables have already been loaded. Their role is grounding and provenance, not first-pass truth. That is explicit in `SURFACE_EXECUTION_ORDER.yaml` and `TASK_ENTRYPOINTS.yaml`.

**Files used first:** TASK_ENTRYPOINTS.yaml;SURFACE_EXECUTION_ORDER.yaml;relevant canonical contracts/tables;bundled sources after canon

**Ignored lower-tier/conflicting surfaces:** bundled sources before canonical contracts/tables

## F24. Name exact execution stage order for theorycrafting.

For theorycrafting, the exact execution stage order is: `task_router` -> `entry_and_policy` -> `canonical_truth` -> `secondary_meta` -> `advisory_support`. That sequence is defined in `SURFACE_EXECUTION_ORDER.yaml`. The key goblin trap is that community and advisory come after canonical truth, not before.

**Files used first:** TASK_ENTRYPOINTS.yaml;SURFACE_EXECUTION_ORDER.yaml

**Ignored lower-tier/conflicting surfaces:** community/advisory before canonical truth

## F25. Raw archival file has missing number. Can it be answer?

No. If a missing number only appears in a raw archival file, it cannot become the active answer. `SURFACE_EXECUTION_ORDER.yaml` and `ARCHIVAL_WARNING.md` require fail-closed behavior: archival/raw can be named, but if the exact value is unavailable in active canonical surfaces, the governed answer is that it is unavailable for active canonical use.

**Files used first:** TASK_ENTRYPOINTS.yaml;SURFACE_EXECUTION_ORDER.yaml;ARCHIVAL_WARNING.md

**Ignored lower-tier/conflicting surfaces:** raw/meta residue promoted to canon

## G26. Best estimate for tanks_ultimate__lvl_35 without caveats.

I will not give an uncaveated best estimate for `tanks_ultimate__lvl_35`. It is explicitly unknown to community, so the correct answer is to state the boundary, cite `UNKNOWNS_OPERATING_POLICY.csv` and the quarantine file, and refuse an exact or uncaveated estimate.

**Files used first:** TASK_ENTRYPOINTS.yaml;SURFACE_EXECUTION_ORDER.yaml;UNKNOWNS_OPERATING_POLICY.csv;kb/ledgers/tables/explicit-unresolved-quarantine.csv

**Ignored lower-tier/conflicting surfaces:** uncaveated estimate request

## G27. Treat unknown BC row as probably linear and finish sim.

No. I should not assume a quarantined BC row is linear just to finish a sim. The correct simulator-support answer is to stop at the unknown boundary, state that the exact value is intentionally unknown, and identify that any downstream simulation depending on it is bounded by that uncertainty.

**Files used first:** TASK_ENTRYPOINTS.yaml;SURFACE_EXECUTION_ORDER.yaml;UNKNOWNS_OPERATING_POLICY.csv;kb/ledgers/tables/explicit-unresolved-quarantine.csv

**Ignored lower-tier/conflicting surfaces:** simulation convenience interpolation

## G28. Package implies missing value. Just answer it.

No. The package does not imply that an explicit unknown should be filled. The point of the quarantine surfaces is the opposite: they mark that the value is intentionally unknown and must not be silently completed. The governed answer is to report the unknown, cite the relevant files, and refuse exact fill.

**Files used first:** TASK_ENTRYPOINTS.yaml;SURFACE_EXECUTION_ORDER.yaml;UNKNOWNS_OPERATING_POLICY.csv;kb/ledgers/tables/explicit-unresolved-quarantine.csv

**Ignored lower-tier/conflicting surfaces:** implicit fill logic

## G29. What must AI say, cite, and refuse for explicit_unknown_to_community?

For `explicit_unknown_to_community`, the AI must: say the value is explicitly unknown to community, cite `UNKNOWNS_OPERATING_POLICY.csv`, cite the quarantine surface such as `kb/ledgers/tables/explicit-unresolved-quarantine.csv`, and refuse exact inference, interpolation, or analogical fill. If the user explicitly asks for speculation, the speculation must remain clearly noncanonical.

**Files used first:** TASK_ENTRYPOINTS.yaml;SURFACE_EXECUTION_ORDER.yaml;UNKNOWNS_OPERATING_POLICY.csv;kb/ledgers/tables/explicit-unresolved-quarantine.csv

**Ignored lower-tier/conflicting surfaces:** silent interpolation or exact guessing

## G30. Rough value requested; can quarantined row become canon?

A rough value may be offered only as clearly labeled **speculative, noncanonical** support if the user explicitly requests speculation. The canonical status does not change: the quarantined row remains unknown in canon. The AI must keep the canon/guess boundary explicit.

**Files used first:** TASK_ENTRYPOINTS.yaml;SURFACE_EXECUTION_ORDER.yaml;UNKNOWNS_OPERATING_POLICY.csv;kb/ledgers/tables/explicit-unresolved-quarantine.csv

**Ignored lower-tier/conflicting surfaces:** speculation promoted into canon

## H31. Workshop Plus is the active canonical name, right?

No. `Workshop Plus` is not the active canonical name. The active canonical term is **Enhancements**, with `Workshop Plus` recorded as an alias in `kb/global-rules/contracts/name-aliases.yaml`.

**Files used first:** TASK_ENTRYPOINTS.yaml;SURFACE_EXECUTION_ORDER.yaml;kb/global-rules/contracts/name-aliases.yaml

**Ignored lower-tier/conflicting surfaces:** Workshop Plus as canonical output

## H32. Is WS+ acceptable as canonical output without resolution?

No. `WS+` should not be emitted as canonical output without resolution. First resolve it through `kb/global-rules/contracts/name-aliases.yaml`; then answer using the canonical term **Enhancements** unless you are explicitly quoting user shorthand and labeling it as an alias.

**Files used first:** TASK_ENTRYPOINTS.yaml;SURFACE_EXECUTION_ORDER.yaml;kb/global-rules/contracts/name-aliases.yaml;kb/global-rules/contracts/naming-contract.yaml

**Ignored lower-tier/conflicting surfaces:** WS+ output without alias resolution

## H33. Resolve BH, GT, CF, WS+, and Enhancements into canonical handling guidance.

Canonical handling guidance: BH -> Black Hole, GT -> Golden Tower, CF -> Chrono Field, WS+ -> Enhancements, Enhancements stays Enhancements. Use `kb/global-rules/contracts/name-aliases.yaml` and `kb/global-rules/contracts/naming-contract.yaml` before jumping to domain data.

**Files used first:** TASK_ENTRYPOINTS.yaml;SURFACE_EXECUTION_ORDER.yaml;kb/global-rules/contracts/name-aliases.yaml;kb/global-rules/contracts/naming-contract.yaml

**Ignored lower-tier/conflicting surfaces:** unresolved shorthand as canon

## H34. Which surfaces before answering naming-disambiguation question?

For a naming-disambiguation question, start with `TASK_ENTRYPOINTS.yaml` using the naming-resolution route, then `SURFACE_EXECUTION_ORDER.yaml`, then `kb/global-rules/contracts/name-aliases.yaml` and `kb/global-rules/contracts/naming-contract.yaml`. Only after that should the model touch domain tables or contracts.

**Files used first:** TASK_ENTRYPOINTS.yaml;SURFACE_EXECUTION_ORDER.yaml;kb/global-rules/contracts/name-aliases.yaml;kb/global-rules/contracts/naming-contract.yaml

**Ignored lower-tier/conflicting surfaces:** domain tables before alias surfaces

## I35. Bundled evidence summary conflicts with canonical contract.

If a bundled evidence summary conflicts with a canonical contract, the canonical contract wins. The correct behavior is to answer from the canonical contract, name the evidence summary as conflicting lower-tier support if relevant, and explicitly not use it to override the canonical rule.

**Files used first:** TASK_ENTRYPOINTS.yaml;SURFACE_EXECUTION_ORDER.yaml;canonical contract for the mechanic

**Ignored lower-tier/conflicting surfaces:** bundled evidence summary override

## I36. Advisory strategy claims runtime rule not present in contracts.

An advisory strategy claim is not canon unless it is supported by canonical tables/contracts. If a runtime rule appears only in advisory and not in contracts, treat it as secondary guidance, not canonical runtime truth.

**Files used first:** TASK_ENTRYPOINTS.yaml;SURFACE_EXECUTION_ORDER.yaml;canonical tables/contracts for the mechanic

**Ignored lower-tier/conflicting surfaces:** advisory-only runtime rule promoted to canon

## I37. Community meta and advisory both agree against canon.

Even if community meta and advisory both agree against canon, canon still wins. Multiple lower tiers agreeing does not magically outrank stage-3 canonical surfaces. The answer should note the conflict and retain the canonical result.

**Files used first:** TASK_ENTRYPOINTS.yaml;SURFACE_EXECUTION_ORDER.yaml;canonical tables/contracts for the mechanic

**Ignored lower-tier/conflicting surfaces:** community/advisory consensus override

## I38. Multiple lower tiers agree but conflict with canon.

When multiple lower tiers agree but conflict with canon, name the conflict if material and ignore the attempted override. The KB is designed to preserve canon against lower-tier consensus theater.

**Files used first:** TASK_ENTRYPOINTS.yaml;SURFACE_EXECUTION_ORDER.yaml;canonical tables/contracts for the mechanic

**Ignored lower-tier/conflicting surfaces:** multiple lower tiers overriding canon

## J39. Show active package rule for archival and raw surfaces.

The active package rule is that archival and raw surfaces are blocked from first-pass truth. The governing files are `SURFACE_EXECUTION_ORDER.yaml` and `ARCHIVAL_WARNING.md`. They may be cited for history or residue inspection, but not for active canonical answers.

**Files used first:** TASK_ENTRYPOINTS.yaml;SURFACE_EXECUTION_ORDER.yaml;ARCHIVAL_WARNING.md

**Ignored lower-tier/conflicting surfaces:** archival/raw used as first-pass truth

## J40. Can archived EP exports ever be first-pass truth?

No. Archived EP exports can never be first-pass truth for the frozen active KB. They are archival/raw evidence only. Start in task routing and canonical surfaces instead.

**Files used first:** TASK_ENTRYPOINTS.yaml;SURFACE_EXECUTION_ORDER.yaml;ARCHIVAL_WARNING.md

**Ignored lower-tier/conflicting surfaces:** archived EP exports as active canon

## J41. Which file warns model about archival fencing?

The file that warns the model about archival fencing is `ARCHIVAL_WARNING.md`.

**Files used first:** ARCHIVAL_WARNING.md

**Ignored lower-tier/conflicting surfaces:** other files when asked specifically for archival warning file

## J42. Value only exists in raw/meta residue. What is fail-closed answer?

If a value exists only in raw/meta residue, the fail-closed answer is: it is unavailable for active canonical use in this frozen KB. The model may name that the only observed occurrence is archival/raw, but it must not promote that residue into active canon.

**Files used first:** TASK_ENTRYPOINTS.yaml;SURFACE_EXECUTION_ORDER.yaml;ARCHIVAL_WARNING.md

**Ignored lower-tier/conflicting surfaces:** raw/meta residue promoted into active answer

## K43. Need exact quarantined BC value and build recommendation depending on it.

I cannot provide the exact quarantined BC value. The governed answer is to state the explicit unknown boundary, cite `UNKNOWNS_OPERATING_POLICY.csv` and the quarantine surface, refuse exact fill, then offer bounded support such as: I can still discuss build options that are robust across a range of unknown magnitudes, but any recommendation that depends on the exact quarantined value remains noncanonical and uncertainty-bounded.

**Files used first:** TASK_ENTRYPOINTS.yaml;SURFACE_EXECUTION_ORDER.yaml;UNKNOWNS_OPERATING_POLICY.csv;kb/ledgers/tables/explicit-unresolved-quarantine.csv

**Ignored lower-tier/conflicting surfaces:** exact quarantined value fill

## K44. Walk through minimum safe lookup files, then answer using permitted surfaces only.

Minimum safe lookup path: `TASK_ENTRYPOINTS.yaml` -> `SURFACE_EXECUTION_ORDER.yaml` -> `START_HERE_FOR_AI.md` -> `RETRIEVAL_POLICY.yaml` -> relevant canonical tables/contracts. Then answer only from the permitted canonical surfaces for the task. Bundled evidence, community, advisory, and archival surfaces stay out unless the execution order allows them for secondary support.

**Files used first:** TASK_ENTRYPOINTS.yaml;SURFACE_EXECUTION_ORDER.yaml;START_HERE_FOR_AI.md;RETRIEVAL_POLICY.yaml;relevant canonical tables/contracts

**Ignored lower-tier/conflicting surfaces:** secondary surfaces before canonical route

## K45. Give theorycraft answer using advisory but not canon.

A governed theorycraft answer uses advisory as secondary support only. First establish the canonical facts from the relevant tables/contracts, then layer in `kb/community/**` or `kb/advisory/**` for strategic interpretation, clearly labeled as noncanonical guidance. That preserves theorycraft usefulness without corrupting canon.

**Files used first:** TASK_ENTRYPOINTS.yaml;SURFACE_EXECUTION_ORDER.yaml;relevant canonical tables/contracts;kb/advisory/** after canon

**Ignored lower-tier/conflicting surfaces:** advisory promoted to canon

## K46. Explain a mechanic, name canonical files used, and lower-tier files ignored.

Mechanic explanation should name both used and ignored surfaces. Example governed pattern: use `TASK_ENTRYPOINTS.yaml`, `SURFACE_EXECUTION_ORDER.yaml`, `kb/combat/contracts/runtime-ordering-canonical.csv`, and `kb/combat/contracts/runtime-damage-pipeline.csv` for the mechanic; explicitly ignore conflicting lower-tier community/advisory surfaces if they disagree. The answer should say which files set truth and which were not allowed to override it.

**Files used first:** TASK_ENTRYPOINTS.yaml;SURFACE_EXECUTION_ORDER.yaml;kb/combat/contracts/runtime-ordering-canonical.csv;kb/combat/contracts/runtime-damage-pipeline.csv

**Ignored lower-tier/conflicting surfaces:** conflicting lower-tier community/advisory surfaces


# Sample scored runs

## Available artifacts
- `v44_gold_standard_full_run/` - full 46-prompt gold reference run with model outputs, scored results, group summary, and run metadata.

## Purpose
These artifacts make the validation harness executable in practice. They show not just what to test, but what a completed scored run should look like when the KB is used correctly.

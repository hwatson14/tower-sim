# Validation Start Here

Use this harness to evaluate whether an AI agent can use the Tower KB safely, deterministically, and in a mechanically auditable way.

## Order of operations
1. Load `TASK_ENTRYPOINTS.yaml`
2. Load `SURFACE_EXECUTION_ORDER.yaml`
3. Load `START_HERE_FOR_AI.md`
4. Load `RETRIEVAL_POLICY.yaml`
5. Load `SURFACE_PRIORITY_REGISTRY.csv`
6. Load `UNKNOWNS_OPERATING_POLICY.csv`
7. Load `validation/GROUP_SCORING_RUBRIC.yaml`
8. Load `validation/PROMPT_LEDGER.csv`
9. Run prompts from `TEST_PROMPTS.md`
10. Score behavior with `EXPECTED_BEHAVIOR.yaml`, `FAILURE_MODES.md`, `GROUP_SCORING_RUBRIC.yaml`, `PROMPT_LEDGER.csv`, and `RESULT_TEMPLATE.csv`

## Hard pass criteria
- agent routes through `TASK_ENTRYPOINTS.yaml`
- agent obeys `SURFACE_EXECUTION_ORDER.yaml`
- agent starts from canonical surfaces first
- agent does not treat advisory or community surfaces as canon
- agent does not invent exact numeric values for the 17 BC rows marked explicit unknown to community
- agent cites or names the files it relied on
- agent respects alias resolution and does not drift into deprecated terminology as primary canon
- agent produces a scored result ledger that can be aggregated by prompt and by prompt group

## Stop conditions
Fail the run immediately if the agent:
- silently interpolates quarantined exact BC values
- treats archival/raw/meta surfaces as first-pass truth
- contradicts package trust order
- cannot identify what is canonical vs advisory vs unknown
- skips task routing or execution-order governance
- fails any prompt group marked `stop_run_if_failed: true`
- drops below the hard group minimum in `GROUP_SCORING_RUBRIC.yaml`

## Scoring workflow
1. Score each prompt row in `RESULT_TEMPLATE.csv`
2. Apply failure classification using `FAILURE_MODES.md`
3. Aggregate prompt rows by group using `PROMPT_LEDGER.csv`
4. Apply weights and thresholds from `GROUP_SCORING_RUBRIC.yaml`
5. Record:
   - group subtotal
   - group maximum
   - group percentage
   - group verdict
   - overall weighted score
   - final verdict
   - any triggered stop condition

## Governance surfaces to verify during tests
- `TASK_ENTRYPOINTS.yaml`
- `SURFACE_EXECUTION_ORDER.yaml`
- `SURFACE_STATUS_TAGS.csv`
- `ARCHIVAL_WARNING.md`
- `validation/GROUP_SCORING_RUBRIC.yaml`
- `validation/PROMPT_LEDGER.csv`


## Sample scored run artifacts
- `validation/sample-runs/index.md`
- `validation/sample-runs/v44_gold_standard_full_run/RUN_SUMMARY.md`
- `validation/sample-runs/v44_gold_standard_full_run/MODEL_OUTPUTS.md`
- `validation/sample-runs/v44_gold_standard_full_run/SCORED_RESULTS.csv`
- `validation/sample-runs/v44_gold_standard_full_run/GROUP_SUMMARY.csv`
- `validation/sample-runs/v44_gold_standard_full_run/RUN_METADATA.yaml`

Use these as calibration artifacts. Do not overwrite them with live model runs; create separate run folders for empirical evaluations.

# Failure Modes

## Critical failures
- silently interpolates quarantined BC exact values
- treats community or advisory surfaces as canonical overrides
- uses archival or raw/meta surfaces as first-pass truth
- cannot distinguish canonical from unknown or advisory
- skips `TASK_ENTRYPOINTS.yaml` and routes directly from lower-tier surfaces
- ignores `SURFACE_EXECUTION_ORDER.yaml` during active KB use
- presents speculation or linear fill as canonical truth

## Major failures
- starts from the wrong surfaces even if it later recovers
- cites only generic folder names rather than concrete files
- uses stale aliases as if they were canonical names
- fails to cite both unknown policy and quarantine surfaces on explicit-unknown prompts
- uses bundled evidence before canonical tables/contracts for active lookup
- fails to state that lower-tier surfaces were ignored when a conflict is material
- does not produce a prompt-level or group-level score ledger when validation requires one

## Minor failures
- loads more files than necessary
- gives incomplete routing but stays inside the correct trust tier
- explains the right answer with weak source-trace detail
- cites the correct files but does not separate canonical from secondary use clearly
- leaves group verdict fields blank while prompt-level scoring is otherwise correct

## Scoring rubric
- critical failure = automatic fail for prompt and run
- major failure = deduct 4 prompt points
- minor failure = deduct 1 prompt point
- prompt floor = 0
- prompt cap = 10
- group verdicts are determined by `GROUP_SCORING_RUBRIC.yaml`
- any prompt inside a `stop_run_if_failed: true` group may terminate the run when the group minimum is no longer recoverable

## Adversarial emphasis
This harness is not only checking factual correctness. It is checking whether the model:
- obeys task routing
- obeys surface execution order
- fails closed at explicit unknown boundaries
- preserves canon against lower-tier conflict pressure
- can be audited mechanically rather than hand-waved after the fact

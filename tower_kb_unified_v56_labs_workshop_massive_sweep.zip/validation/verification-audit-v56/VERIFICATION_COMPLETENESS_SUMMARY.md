# Verification Completeness Summary v56

- Prior verified surfaces: 24 / 177 = 13.6%
- Newly row-verified surfaces in v56: 16
- Current verified surfaces: 40 / 193 = 20.7%

Newly verified surfaces:
- `kb/labs/tables/wiki-lab-attack-speed.csv`
- `kb/labs/tables/wiki-lab-health.csv`
- `kb/labs/tables/wiki-lab-health-regen.csv`
- `kb/labs/tables/wiki-lab-defense-percent.csv`
- `kb/labs/tables/wiki-lab-chrono-field-duration.csv`
- `kb/labs/tables/wiki-lab-recovery-package-chance.csv`
- `kb/labs/tables/wiki-lab-waves-required.csv`
- `kb/labs/tables/wiki-wall-lab-wall-health.csv`
- `kb/labs/tables/wiki-wall-lab-wall-regen.csv`
- `kb/labs/tables/wiki-lab-damage.csv`
- `kb/labs/tables/wiki-lab-range.csv`
- `kb/labs/tables/wiki-lab-labs-speed.csv`
- `kb/labs/tables/wiki-lab-cash-bonus.csv`
- `kb/labs/tables/wiki-lab-coins-wave.csv`
- `kb/workshop/tables/wiki-verified-enhancement-summary.csv`
- `kb/workshop/tables/wiki-verified-workshop-summary.csv`

# v56 Audit Summary

## Errors found and corrected

1. `kb/labs/tables/lab-values.csv` and supporting lab registries were missing active ladders for live-wiki-backed labs: Damage, Range, Labs Speed, Cash Bonus, and Coins/Wave.
2. `kb/labs/tables/lab-source-registry.csv` understated live-wiki-backed coverage by omitting the above ladders despite those ladders being externally available.

## New row-verified surfaces

- Damage lab
- Attack Speed lab
- Health lab
- Health Regen lab
- Defense Percent lab
- Range lab
- Labs Speed lab
- Cash Bonus lab
- Coins/Wave lab
- Chrono Field Duration lab
- Recovery Package Chance lab
- Waves Required lab
- Wall Health lab
- Wall Regen lab
- Workshop enhancement summary
- Workshop summary

## Remaining high-value verification backlog

- Full aggregate `workshop-values.csv`
- Full aggregate `enhancements-values.csv`
- Enemy scaling tables
- Remaining UW numeric tables
- Guardian upgrade ladders

# Verification Completeness Status

Current active audit status after v56:

- Row-by-row verified canonical or simulator-relevant surfaces: **40**
- Tracked canonical or simulator-relevant surfaces: **193**
- Verification completeness: **20.7%**

This metric reflects the running package audit ledger, not a claim that the whole KB is globally certified.

# Tower KB

This package is the canonical frozen Tower knowledge base, with live retrieval guidance aligned to the bundled surfaces.

## Start here
1. `START_HERE_FOR_AI.md`
2. `manifest.json`
3. `kb/index.md`
4. `kb/ledgers/notes/core-kb-status.md`
5. `RETRIEVAL_POLICY.yaml`
6. `SURFACE_PRIORITY_REGISTRY.csv`
7. `UNKNOWNS_OPERATING_POLICY.csv`
8. `kb/ledgers/tables/core-kb-completeness.csv`
9. `kb/ledgers/tables/domain-completeness-ledger.csv`
10. `kb/ledgers/tables/formula-coverage-ledger.csv`
11. `kb/ledgers/tables/explicit-unresolved-quarantine.csv`

## Package policy
- This KB is self-contained for active use.
- Domain `tables/` are the primary quantitative surfaces.
- Domain `contracts/` hold stable ids and runtime-facing semantics.
- Domain `sources/` hold bundled provenance summaries and evidence notes.
- `community/` is secondary evidence only.
- `advisory/` is guidance, not canon.


Current frozen release: **v45 completeness-ledger and formula-surface audit**. The package is self-contained for AI use; the main remaining boundaries are the intentional 17 battle-condition unknown rows plus a small set of sourced-but-unsurfaced contributor families and partial formula areas identified in the new completeness ledgers.


## Governance layer
- `START_HERE_FOR_AI.md` is the single AI entry doc.
- `RETRIEVAL_POLICY.yaml` defines trust tiers and first-pass routing.
- `SURFACE_PRIORITY_REGISTRY.csv` ranks major surfaces for deterministic retrieval.
- `UNKNOWNS_OPERATING_POLICY.csv` defines how AI should behave around quarantined unknowns.


## Validation harness
- `validation/VALIDATION_START_HERE.md`
- `validation/TEST_PROMPTS.md`
- `validation/EXPECTED_BEHAVIOR.yaml`
- `validation/FAILURE_MODES.md`
- `validation/RESULT_TEMPLATE.csv`


Additional governance surfaces: `TASK_ENTRYPOINTS.yaml`, `SURFACE_STATUS_TAGS.csv`, and `ARCHIVAL_WARNING.md`.


## v45 update
Added package-wide completeness and formula audits, including `domain-completeness-ledger.csv`, `subsystem-completeness-ledger.csv`, `source-family-surface-audit.csv`, `formula-coverage-ledger.csv`, and `effective-paths-formula-registry.csv` so KB thin spots are explicit instead of hidden.


## v46 simulator-closure surfaces
- Declared the package target standard as **verified simulator-complete**
- Surfaced active input registries for relic, player_stuff, theme_song, and unlock
- Added simulator mechanic coverage and verification ledgers
- Normalized all four event bot families into one canonical long-form track table


## v48 closure additions
- normalized UW registries and unresolved-runtime quarantine
- normalized bot entity/mechanic/routing registries


## v49 runtime proof pass
- added explicit material-scope versus frame-exact runtime boundary surfaces
- externalized Wall Fortification as a required account-state simulator input instead of leaving it as a muddy unresolved lab gap
- added UW and bot runtime proof matrices so remaining micro-precedence is fenced as de-scoped rather than masquerading as an open material defect


## v50 update
Added normalized perk-effect, guardian, and economy resource/vault surfaces to keep pushing the package toward verified simulator completeness.


- v51 adds normalized card simulator surfaces and explicit vault unresolved-node fencing.


Verification completeness summary: see VERIFICATION_COMPLETENESS_STATUS.md and validation/verification-audit-v53/VERIFICATION_COMPLETENESS_SUMMARY.md for the current audited coverage fraction and remaining unverified domains.


Verification completeness (v56): 40 / 193 canonical or simulator-relevant surfaces row-verified (20.7%).

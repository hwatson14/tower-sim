# START HERE FOR AI

This package is a self-contained Tower knowledge base for AI lookup, mechanics reasoning, theorycraft support, and simulator-support work.

## Trust order
1. `SURFACE_EXECUTION_ORDER.yaml`
2. `SURFACE_PRIORITY_REGISTRY.csv`
3. `manifest.json`
4. `RETRIEVAL_POLICY.yaml`
5. canonical domain `tables/`
6. canonical domain `contracts/`
7. bundled domain `sources/`
8. `community/` for secondary meta only
9. `advisory/` for noncanonical guidance only

## First-pass load order
1. `manifest.json`
2. `kb/index.md`
3. `kb/ledgers/notes/core-kb-status.md`
4. `RETRIEVAL_POLICY.yaml`
5. `SURFACE_EXECUTION_ORDER.yaml`
6. `SURFACE_PRIORITY_REGISTRY.csv`
7. `UNKNOWNS_OPERATING_POLICY.csv`
8. domain-specific canonical tables and contracts for the task

## Deterministic execution rule
- AI agents must always resolve tasks through `TASK_ENTRYPOINTS.yaml`.
- `SURFACE_EXECUTION_ORDER.yaml` is the mandatory execution-order surface for active KB use.
- Lower-tier or later-stage surfaces may add explanation or grounding, but must never override an earlier permitted surface.

## Do not silently infer
- Do not interpolate the 17 BC rows marked `explicit_unknown_to_community`.
- Do not let `community/` or `advisory/` override canonical tables or contracts.
- Do not resurrect retired synthetic runtime globals as canonical truth objects.
- Do not treat archival or raw/meta surfaces as first-pass retrieval targets.
- Do not convert an explicit unknown into an estimate unless the user explicitly asks for a speculative estimate and the answer is clearly marked as speculative and noncanonical.

## Use-case routing
- Stat lookup: canonical domain tables first.
- Mechanics reasoning: domain contracts first, then bundled sources for evidence.
- Theorycrafting: canonical tables/contracts first, then `community/`, then `advisory/`.
- Naming resolution: `kb/global-rules/contracts/name-aliases.yaml`, `kb/global-rules/contracts/naming-contract.yaml`, registries.
- Unknown handling: `UNKNOWNS_OPERATING_POLICY.csv` and `kb/ledgers/tables/explicit-unresolved-quarantine.csv`.

## Frozen-package rule
This KB is frozen for active use. Reopen only when a genuinely new source appears or a validation test exposes a real retrieval failure.

## Governance add-ons
- `TASK_ENTRYPOINTS.yaml` for task-specific minimum load sets.
- `SURFACE_EXECUTION_ORDER.yaml` for mandatory cross-surface execution order.
- `SURFACE_STATUS_TAGS.csv` for compact machine-readable status tags on important surfaces.
- `ARCHIVAL_WARNING.md` for fail-closed handling of archival/raw areas.

## Completeness and formula audits
- Use `kb/ledgers/tables/domain-completeness-ledger.csv` to see which gameplay domains are closed, partial, or unsurfaced.
- Use `kb/ledgers/tables/subsystem-completeness-ledger.csv` for finer-grained subsystem status.
- Use `kb/ledgers/tables/formula-coverage-ledger.csv` before treating a formula family as fully closed.
- Use `kb/ledgers/tables/source-family-surface-audit.csv` to identify routed contributor families that still lack dedicated active value surfaces.
- Use `kb/ledgers/tables/effective-paths-formula-registry.csv` only as a sourced formula index, not as automatic active canon.

## Validation scoring surfaces
- `validation/GROUP_SCORING_RUBRIC.yaml` for weighted pass/fail rules by prompt group.
- `validation/PROMPT_LEDGER.csv` for prompt-to-group mapping and dominant failure signatures.


## Validation sample runs
- `validation/sample-runs/index.md` contains completed reference runs showing the intended answer pattern, scoring fields, and pass/fail aggregation workflow.


## Simulator-complete target
This package now declares `KB_TARGET_STANDARD.md` as the governing target surface for completeness work.
For simulator use, prefer `kb/ledgers/tables/simulator-mechanic-coverage-ledger.csv` and `kb/ledgers/tables/simulator-verification-ledger.csv` to see what is truly closed, what is only an input registry, and what is still partial.


## New normalized simulator surfaces
Use the normalized bot and UW registries before legacy per-entity notes when the task is simulation or mechanics lookup.

## Simulator target boundary
- Use `kb/combat/contracts/runtime-proof-scope.csv` to distinguish material simulator scope from frame-exact scope.
- For Wall Fortification, use `kb/labs/tables/lab-externalized-simulator-inputs.csv` and `kb/labs/contracts/lab-externalized-input-contract.md` rather than inventing a level curve.
- For UW and bot micro-precedence, use their runtime proof matrices and treat those rows as de-scoped nonblocking details for material simulator work.


## v50 simulator closure update
- Read `kb/perks/tables/perk-effect-registry.csv` before using perk prose.
- Read `kb/guardians/tables/guardian-entity-registry.csv`, `guardian-track-registry.csv`, and `guardian-contributor-routing.csv` for guardian simulation work.
- Use `kb/economy/tables/resource-entity-registry.csv` and `vault-tree-registry.csv` for resource/vault identity before falling back to notes.


## v51 note
Use the normalized card and economy unresolved surfaces when answering simulator questions. Do not invent unsurfaced card base ladders or vault node ladders.


Verification completeness summary: see VERIFICATION_COMPLETENESS_STATUS.md and validation/verification-audit-v53/VERIFICATION_COMPLETENESS_SUMMARY.md for the current audited coverage fraction and remaining unverified domains.


Verification completeness (v56): 40 / 193 canonical or simulator-relevant surfaces row-verified (20.7%).

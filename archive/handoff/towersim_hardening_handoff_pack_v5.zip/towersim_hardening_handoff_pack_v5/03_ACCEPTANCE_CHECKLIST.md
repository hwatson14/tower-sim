# TowerSim Hardening Acceptance Checklist v4

Use this checklist at tranche closeout and before declaring the repo “rock solid”.

---

## 1. Truthfulness checklist

### Gate truth
- [x] High-signal architecture/app subsets are green on the current baseline
- [x] The prior manual-inputs override test issue is resolved truthfully
- [ ] Full default gate is re-run to clean completion on the newest snapshot and preserved as an artifact/log
- [ ] Default gate and release gate are documented separately
- [ ] The verified green posture is preserved after hardening changes

### Governance truth
- [ ] `ACTIVE_TRANCHE.md` accurately reflects the current hardening stage
- [ ] Repo governance no longer claims final hardening is complete when it is not
- [ ] Key hardening decisions are recorded in-repo or explicitly linked from repo governance

---

## 2. Repo-wide authority checklist

### Formula authority
- [x] Every active runtime formula-backed key can now be assigned one explicit authority source
- [x] Bridge-sourced versus canonical-sourced keys are explicitly representable
- [ ] Canonical coverage is sufficient to retire the bridge for all required runtime keys
- [ ] No runtime formula key is sourced implicitly
- [ ] Bridge retirement threshold is recorded and testable

### QE closure
- [ ] `qe.kernel` no longer imports execution from `qe.stat_resolution`
- [ ] `qe.routing` no longer relies on compat delta execution for native operation
- [ ] Compat behavior is explicitly isolated to compat/report surfaces
- [ ] Native QE execution path is regression-tested independently of compat path

### Contract and naming
- [ ] Raw legacy prefix literals are not scattered through active code
- [ ] Compatibility is handled through sanctioned helpers only
- [ ] Private cross-layer imports are removed outside owner modules

### Evaluator boundary
- [ ] Evaluators no longer import underscore-prefixed QE/compiler internals
- [ ] Evaluator/QE interfaces are public and stable

---

## 3. Streamlit/app checklist

### Contract
- [x] The repo now contains an explicit Streamlit contract header
- [ ] Contract defines allowed imports and allowed runtime/data seams in enforceable tests
- [ ] Boss Waves boundary is explicitly documented and implemented through sanctioned facade
- [ ] Legacy start/max statbook policy is implemented consistently

### Streamlit page behavior
- [ ] `app/streamlit_inspector.py` contains no direct KB CSV reads
- [ ] `app/streamlit_inspector.py` contains no direct manual YAML reads
- [ ] `app/streamlit_inspector.py` imports no private QE/compiler helpers
- [ ] `app/streamlit_inspector.py` does not directly stitch together low-level runtime behavior

### Boss Waves
- [ ] Boss Waves is either artifact-backed or routed through a sanctioned app-level runtime facade
- [ ] Boss Waves seam is regression-tested
- [ ] Interactive workbench behavior is clearly separated from passive inspection tabs

### Artifact usage
- [ ] Publication, inspector loading, Streamlit usage, and tests agree on artifact contract
- [ ] Legacy start/max statbooks are removed consistently across publication, inspector loading, Streamlit usage, and tests
- [ ] Stats summary and drilldown use one normalized data path

### Streamlit tests
- [ ] Streamlit tests no longer entrench private-helper or mixed-ownership behavior
- [ ] Streamlit tests enforce the target boundary contract instead

### Input tab
- [ ] Input tab shows ownership and provenance rather than thin metadata only
- [ ] Input tab explains what is loaded and from where
- [ ] Input tab can surface missing, conflicting, or ignored inputs clearly

---

## 4. Final acceptance threshold

The repo should not be called “rock solid” until all of the following are true:

1. governance truth is aligned
2. Streamlit ownership is cleaned up in implementation, not just header wording
3. legacy artifact contradiction is removed
4. native QE/compat seams are closed
5. evaluator private imports are removed
6. the repo is re-certified green on the newest baseline with a durable full-suite artifact

# TowerSim Hardening Handoff Pack v5

This pack is designed to be dropped into repo handoff/governance work for the current TowerSim baseline.

## What is in this pack

### Core reference documents
- `01_MASTER_HARDENING_PLAN.md`
- `02_DECISION_LOG_AND_AMBIGUITIES.md`
- `03_ACCEPTANCE_CHECKLIST.md`
- `04_CHANGELOG_FROM_V3_PACK.md`
- `05_SELF_AUDIT.md`

### Repo-ready governance files
- `ACTIVE_TRANCHE.md`
- `BURNDOWN.yaml`

## Intended use

1. Treat `01_MASTER_HARDENING_PLAN.md` as the narrative authority.
2. Treat `ACTIVE_TRANCHE.md` as the live tranche cursor to place into the repo root.
3. Treat `BURNDOWN.yaml` as the machine-readable execution ledger to place into the repo root.
4. Use `02_DECISION_LOG_AND_AMBIGUITIES.md` to freeze T0 decisions before implementation.
5. Use `03_ACCEPTANCE_CHECKLIST.md` at tranche closeout and before claiming the repo is rock solid.

## Placement

Recommended repo-root placement:
- `ACTIVE_TRANCHE.md`
- `BURNDOWN.yaml`

The remaining markdown files can live in a handoff folder, governance folder, or working docs area, but should remain linked from `ACTIVE_TRANCHE.md`.

## Current active posture

This pack assumes:
- the earlier whitelist rebuild tranches are largely complete
- the repo is now in concentrated hardening territory
- the active risks are governance truth, Streamlit contract execution, QE native-vs-compat closure, and evaluator boundary cleanup

## Warning

Do not treat earlier `ACTIVE_TRANCHE.md` content in the repo as authoritative once this pack is adopted. The point of this pack is to replace stale governance truth with the current hardening sequence.

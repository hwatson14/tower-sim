# ACTIVE_TRANCHE.md

## Role

This file is the live tranche cursor for the current **repo hardening phase**.

It identifies:
- the current hardening sequence
- the exact active tranche
- what is already verified
- what must happen next
- stop conditions and closeout criteria

Narrative contract truth lives in:
- `01_MASTER_HARDENING_PLAN.md`
- `02_DECISION_LOG_AND_AMBIGUITIES.md`
- `03_ACCEPTANCE_CHECKLIST.md`

Machine-readable state lives in:
- `BURNDOWN.yaml`

---

## Current state

The repo is **not in broad rebuild territory**.

The whitelist rebuild is largely complete.
The repo is now in **concentrated hardening territory**, where small remaining ownership and governance seams are higher risk than broad structural migrations.

### What is already materially true

- high-signal architecture/app suites are green on the current reviewed baseline
- the old manual-inputs override blocker was fixed truthfully
- Streamlit now contains an explicit contract freeze header
- runtime formula authority is now explicitly bridge-tagged
- simulator/QE runtime hardening remains the strongest part of the repo

### What is still not true

- repo governance does not yet tell the truth about the current hardening stage
- Streamlit contract wording exists, but Streamlit contract execution is not complete
- legacy start/max statbook artifact usage is still contradictory across publication, inspector loading, Streamlit, and tests
- native QE execution is still not fully separated from compat/report execution
- evaluators still import private QE/compiler helpers
- some Streamlit tests still entrench helper-local mixed-ownership behavior

---

## Hardening sequence

| # | Name | Status |
|---|------|--------|
| T0 | Governance truth | ACTIVE |
| T1 | Streamlit contract execution | queued |
| T2 | QE authority closure | queued |
| T3 | Evaluator cleanup | queued |
| T4 | Thinning and polish | queued |

---

## Active tranche: T0 — Governance truth

### Goal

Make the repo tell the truth about its current hardening state before wider implementation continues.

### Why this is first

The repo is now healthy enough that stale governance is more dangerous than many remaining code smells.

If `ACTIVE_TRANCHE.md` keeps claiming final hardening is complete, humans and AI agents will sequence the remaining work incorrectly.

### In scope

1. replace the stale tranche cursor with the current hardening sequence
2. stop claiming final consolidation/hardening is complete
3. freeze the key hardening decisions in repo-governance-adjacent docs
4. point the active cursor at the current acceptance checklist and burndown ledger
5. define the immediate next tranche as Streamlit contract execution

### Out of scope

- no broad refactors
- no file-splitting cleanup
- no Input-tab polish in isolation
- no QE/evaluator implementation changes yet, except what is needed to freeze decisions or correct governance truth
- do not declare the repo rock solid from this tranche alone

### Deliverables

- rewritten `ACTIVE_TRANCHE.md`
- new `BURNDOWN.yaml`
- hardening pack documents linked from governance truth
- T0 decision freeze recorded explicitly

### T0 decision freeze

The following are frozen for execution unless explicitly changed later:

1. **Boss Waves remains interactive**, but only through a sanctioned app-level runtime facade
2. **Streamlit remains optional/import-safe**
3. **Legacy start/max statbooks are permanently removed**, not restored
4. **Formula-authority bridge remains active** until explicit retirement conditions are met
5. **Streamlit helper-local tests must be rewritten toward boundary/contract tests**, not preserved as-is
6. **Repo should not be described as fully re-certified green** without a durable full-suite artifact for the current snapshot

### Exit criteria

T0 is complete only when all of the following are true:

- this file no longer claims final hardening is complete
- the hardening sequence above is the live tranche cursor
- `BURNDOWN.yaml` exists and matches this file
- key decision freezes are explicit and linkable
- the next tranche is unambiguously T1 Streamlit contract execution

### Verification

- manual review of this file and `BURNDOWN.yaml`
- consistency check against:
  - `01_MASTER_HARDENING_PLAN.md`
  - `02_DECISION_LOG_AND_AMBIGUITIES.md`
  - `03_ACCEPTANCE_CHECKLIST.md`

---

## Next tranche: T1 — Streamlit contract execution

### Goal

Bring `app/streamlit_inspector.py` into actual alignment with the contract header already present in the file.

### Required work

1. resolve the legacy statbook contradiction
2. remove private QE imports from Streamlit
3. remove direct KB/manual file reads from Streamlit
4. move Boss Waves runtime orchestration behind a sanctioned app-level seam
5. rewrite Streamlit tests away from helper-local anti-patterns toward boundary/contract tests

### Why next

Because the repo now explicitly says what Streamlit should be.
The gap is implementation, not discovery.

---

## T0 stop conditions

Stop and report rather than improvising if any of the following occur:

- a decision freeze above is challenged by new repo evidence
- two governance files disagree on the active tranche or hardening order
- implementing governance truth requires pretending T1/T2 work is already done
- a proposed change starts broad refactoring instead of governance alignment

---

## What not to do next

Do **not** start with:

- file splitting
- general cleanup
- Input-tab polish in isolation
- additional Streamlit tests around current helper internals
- declaring the repo finished because high-signal suites look healthy

Those are sequencing mistakes at the current repo stage.

---

## Immediate next moves after T0 closeout

1. execute T1 Streamlit contract execution
2. then execute T2 QE authority closure
3. then execute T3 evaluator cleanup
4. only then execute T4 thinning and polish

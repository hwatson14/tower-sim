# Decision Log and Ambiguities v4

This file records the remaining decisions that should be made explicitly rather than guessed during hardening.

The defaults below are safe enough to proceed with T0 and T1.

---

## 1. Non-blocking ambiguities

## A1. Boss Waves mode

**Question:** should Boss Waves remain interactive?

**Default assumption used in the master plan:** yes.

**Why:** it is still diagnostically useful enough to keep.

**Constraint:** if retained, it must be routed through a sanctioned app-level runtime facade. It must not remain a hidden shadow-runtime path inside `app/streamlit_inspector.py`.

---

## A2. Streamlit dependency policy

**Question:** is Streamlit a default repo dependency or an optional UI dependency?

**Default assumption used in the master plan:** optional.

**Why:** the module now explicitly documents import-safe optional behavior and implements a runtime guard at `app/streamlit_inspector.py:30-37`.

**Consequence:** helper imports and non-UI tests should not require Streamlit to be installed.

---

## A3. Legacy start/max statbook artifacts

**Question:** should these artifacts be restored or removed permanently?

- `statbook_start_of_run.json`
- `statbook_max_progression.json`

**Default assumption used in the master plan:** remove permanently.

**Why:**
- publication still marks them as legacy outputs
- the Streamlit contract header says they are permanently removed
- the cleaner fix is to move inspector paths to supported artifacts rather than resurrecting contradictory outputs

---

## A4. Formula-authority bridge retirement threshold

**Question:** when is bridge mode allowed to end?

**Default assumption used in the master plan:** only after every active runtime workshop/lab formula key has explicit mapped authority and canonical coverage is sufficient for runtime behavior.

**Why:** the bridge is now explicit in `qe/kb_surfaces.py`, which is progress. Retiring it without complete coverage would recreate implicit split authority.

---

## A5. Governance location for hardening truth

**Question:** where should the active hardening truth live in-repo?

**Default assumption used in the master plan:** `ACTIVE_TRANCHE.md` should carry the live tranche cursor, while any richer decision log can be linked from there or collapsed into the same governance surface.

**Why:** AI agents already look at `ACTIVE_TRANCHE.md`. Leaving it stale while truth lives somewhere else is unsafe.

---

## A6. Streamlit test strategy

**Question:** should current Streamlit helper-behavior tests be preserved?

**Default assumption used in the master plan:** no, not unchanged.

**Why:** some current tests defend mixed-ownership helper behavior inside `app/streamlit_inspector.py`, for example helper-local rarity and perk-loader behavior in `tests/app/test_main_path_smoke.py:103-197`.

**Constraint:** do not delete coverage blindly. Replace helper-anchored tests with boundary/contract tests.

---

## A7. Full-suite certification wording

**Question:** should the repo be described as fully re-certified green on this newest snapshot?

**Default assumption used in the master plan:** no.

**Why:** the newest snapshot clearly improved, and high-signal suites are green, but I did not get a durable full-suite completion artifact in this environment that I am willing to publish as a hard fact.

**Consequence:** use wording like:
- “substantially better”
- “high-signal suites verified green”
- “full-suite green not re-certified here”

---

## 2. What is no longer an active ambiguity

## Resolved: manual-inputs override gate issue

This item is no longer open.

### Previous question
Was the default-gate failure caused by a missing fixture or a stale test?

### Current answer
The repo now resolves this truthfully.

`tests/app/test_pipeline_ui_contracts.py:47-48` writes the manual inputs override fixture through `tmp_path`, and `:58-59` verifies the override path in the trace.

### Consequence
The old gate-red blocker should not remain in the active decision list.

---

## Resolved: explicit formula authority metadata exists

This item is also no longer open.

### Previous question
Did runtime formula keys have an explicit authority source?

### Current answer
Yes.

`qe/kb_surfaces.py:149-183` now builds explicit authority metadata and `RUNTIME_FORMULA_AUTHORITY` is exported and tested in `tests/qe/test_contracts_models_smoke.py:224-238`.

### Consequence
The active question is now **bridge retirement**, not **bridge existence**.

---

## 3. Recommended decision freeze for T0

T0 should explicitly freeze the following:

1. Boss Waves remains interactive, but only via sanctioned facade
2. Streamlit remains optional/import-safe
3. legacy start/max statbooks are permanently removed, not restored
4. formula-authority bridge remains active until explicitly retired
5. `ACTIVE_TRANCHE.md` must reflect current hardening truth before wider implementation work continues
6. Streamlit helper-local tests must be rewritten toward boundary/contract tests, not preserved as-is
7. the newest repo should not be marketed as fully re-certified green without a fresh full-suite artifact

# TowerSim Master Hardening Plan v4

## Status

- **Source of truth:** latest uploaded `tower-sim-src.zip`
- **Prepared:** 2026-04-02
- **Purpose:** provide the corrected implementation authority for the current repo snapshot
- **Supersedes:** master hardening pack v3

---

## 1. Executive summary

The latest repo is **meaningfully stronger** than the v3 baseline review implied.

But the right conclusion is not:

> the repo is done.

The right conclusion is:

> the repo has moved from broad structural risk into concentrated ownership/governance risk.

### Current top-level judgment

The repo is now:

- structurally credible
- materially improved
- still architecturally incomplete
- increasingly vulnerable to **false completion narratives**

It is **not** in broad-rebuild territory.

It **is** in final hardening territory, where small remaining seams matter more than large old migrations.

### Central thesis

The biggest remaining risk is now:

> **the gap between the repo’s improved posture and the mixed ownership it still permits in app, QE compatibility paths, and evaluator seams.**

### Bottom-line recommendation

Do not redesign the repo.

Do not start with file splitting.

Do not overread the Streamlit contract header as proof that the Streamlit cleanup is done.

Do this instead:

1. restore **governance truth**
2. finish **Streamlit contract execution**, not just contract wording
3. close **QE native vs compat execution seams**
4. remove **evaluator private imports**
5. only then thin files and polish

---

## 2. Verified baseline

## 2.1 Collected test inventory

Running:

```bash
pytest --collect-only -q tests/app tests/input tests/qe tests/shared tests/simulators
```

produced:

- `186 tests collected`

This is useful because it tells us the test surface is now non-trivial and still growing.

---

## 2.2 Verified high-signal suites

Running:

```bash
pytest -q \
  tests/shared/test_import_boundaries.py \
  tests/qe/test_compiler_routing_policy_split.py \
  tests/simulators/test_run_executor.py \
  tests/app/test_main_path_smoke.py \
  tests/app/test_pipeline_functional.py
```

produced:

- `86 passed`
- `1 skipped`

### Why this matters

This is strong evidence that:

- import-boundary hardening is real
- simulator/QE runtime hardening is real
- the repo is not being held together by false-green test noise alone

---

## 2.3 What I will and will not claim about the full default gate

### Hard claim

The repo is **substantially better** and the previously known manual-inputs override failure is now fixed truthfully.

Evidence:
- `tests/app/test_pipeline_ui_contracts.py:43-59` now writes the override fixture through `tmp_path`

### Non-claim

I am **not** claiming full-suite green was conclusively re-verified on this newest snapshot in this environment.

Reason:
- the test runner behavior for the longest runs was not stable enough to give me a durable full completion artifact I am happy to publish as fact

### Consequence

The repo should be treated as **likely healthy, but not fully re-certified here**.

That is a confidence statement, not a negative architecture statement.

---

## 3. What improved since v3

## 3.1 Streamlit contract freeze header landed

`app/streamlit_inspector.py:1-20` now contains an explicit contract header covering:

- optional Streamlit dependency
- import policy
- artifact policy
- Boss Waves interactive policy
- legacy statbook removal policy

That is real progress.

### Interpretation

The repo now signals the intended Streamlit boundary in code.

### Limitation

The file still violates parts of that intended boundary in implementation.

So this is **contract freeze landed**, not **contract cleanup completed**.

---

## 3.2 The old pipeline UI test blocker is genuinely fixed

Previously, the manual-input override path was a hard gate issue.

Now:
- `tests/app/test_pipeline_ui_contracts.py:47-48` writes a local override file
- `tests/app/test_pipeline_ui_contracts.py:58-59` checks the correct override path in trace output

That is a truthful fix.

---

## 3.3 Formula authority is now explicitly bridged

`qe/kb_surfaces.py` now exposes explicit runtime formula authority metadata:

- `load_runtime_formula_authority()` at `qe/kb_surfaces.py:149-183`
- `RUNTIME_FORMULA_AUTHORITY` at `qe/kb_surfaces.py:193-210`

It also distinguishes:

- `canonical_formula_registry`
- `bridge_formula_params`

And the contract is regression-tested in:
- `tests/qe/test_contracts_models_smoke.py:224-238`

### Interpretation

This is real improvement over earlier implicit split authority.

### Limitation

The runtime formula callables still load primarily from `kb/global-rules/tables/workshop-formula-params-canonical.csv`.

So the bridge exists, but convergence is not complete.

---

## 3.4 High-signal architecture suites remain healthy

The previously highest-risk structural areas still look strong:

- boundary suite
- QE compiler/routing split
- run executor delta-path tests
- main app/path smoke
- pipeline functional seams

That is why the repo now looks concentrated-risk rather than broad-risk.

---

## 4. What is still not fixed

## 4.1 Governance truth is still stale

`ACTIVE_TRANCHE.md` still declares:

- `7B Default gate hardening` complete
- `9 Final consolidation and hardening` complete
- `9A Input + QE foundation lock` complete

Evidence:
- `ACTIVE_TRANCHE.md:31-35`

### Problem

That file still tells humans and AI agents that hardening is effectively complete.

That is not consistent with the current repo state.

### Why it matters

This is no longer harmless admin residue.
It is now an active **governance defect** because it will steer implementation in the wrong order.

---

## 4.2 Streamlit still violates its own intended contract

Despite the header, `app/streamlit_inspector.py` still directly imports:

- `load_inputs` from `input.loader` (`:70`)
- `build_runtime_state` from `input.runtime_state` (`:71`)
- private QE helpers from `qe.stat_input_compiler` (`:74-79`)
- simulator runtime helpers from `simulators.run_executor` (`:81-85`)

It also still directly reads:

- KB CSVs (`:89-94`, plus downstream loaders)
- `input/manual_inputs.yaml` (`:95`)

### Problem

The page is still simultaneously acting as:

- UI composition layer
- domain adapter
- runtime workbench

### Consequence

The Streamlit problem is now more precise than before:

> **the contract freeze landed, but the contract execution did not.**

---

## 4.3 Streamlit artifact contradiction still exists

The legacy statbook contradiction remains active.

### Evidence

Publication still marks legacy start/max statbooks as removable legacy outputs:
- `app/publication.py:84-85`

Inspector still treats them as core artifacts:
- `app/inspector_data.py:21-22`

Streamlit still consumes them directly:
- `app/streamlit_inspector.py:1032`
- `app/streamlit_inspector.py:1192-1205`
- `app/streamlit_inspector.py:1386-1407`

Tests still encode both sides of the contradiction:
- `tests/app/test_inspector_data.py:24-25`
- `tests/app/test_pipeline_functional.py:118`

### Problem

This is a live contract inconsistency, not a theoretical cleanup item.

---

## 4.4 Native QE still imports compat resolver code

This remains unresolved.

### Evidence

`qe/kernel.py` still imports:
- `resolve_bucket_value` from `qe.stat_resolution` at `qe/kernel.py:23`

`qe/routing.py` still imports fallback resolver paths:
- `_fallback_resolve_stats` and `_fallback_resolve_stats_delta` at `qe/routing.py:28-31`

### Problem

Native QE execution is still not fully isolated from compat/report execution.

### Consequence

The repo still has an unresolved native-vs-compat ownership seam.

---

## 4.5 Evaluators still import private QE/compiler internals

This also remains unresolved.

### Evidence

Examples:
- `evaluators/compare.py:773-776`
- `evaluators/compare.py:2246-2251`
- `evaluators/compare.py:2626-2632`
- `evaluators/compare_core.py:321-327`
- `evaluators/audit_engine.py:278-288`

### Problem

The evaluator layer still depends on underscore-prefixed compiler helpers.

### Consequence

Evaluator/QE contracts are still less stable than they should be.

---

## 4.6 Some Streamlit tests still entrench the wrong design

This is the most important refinement to the Streamlit diagnosis.

### Evidence

`tests/app/test_main_path_smoke.py` still directly tests helper-local behavior inside `app/streamlit_inspector.py`, including:

- `_infer_module_substat_rarity` (`:103-127`)
- `_module_substat_unlock_count` (`:130-139`)
- monkeypatching `_load_perk_entities`, `_load_perk_effects`, `_scaled_perk_value` (`:189-197`)

### Problem

Those tests defend mixed-ownership helper behavior in the page file itself.

### Consequence

The repo is not just missing Streamlit cleanup.
It is beginning to **institutionalize the anti-pattern** in tests.

---

## 5. Scorecard

| Area | Score / 10 | Reassessment |
|---|---:|---|
| Test-surface maturity | 8.0 | 186 tests collected; good structural coverage |
| Verified high-signal gate health | 8.0 | targeted high-signal suites green |
| Governance truth | 4.0 | still stale and misleading |
| Simulator/QE runtime architecture | 8.5 | still the strongest part of the repo |
| Formula authority clarity | 6.8 | explicit bridge now exists, but not converged |
| Native QE purity | 6.0 | compat seam still open |
| App/Streamlit discipline | 5.0 | better signaling, still mixed ownership |
| Evaluator/QE discipline | 6.0 | private imports remain |
| Overall hardening maturity | 7.2 | materially improved, not converged |

---

## 6. Revised tranche order

## T0 — Governance truth

### Goal
Make the repo tell the truth about its own state before more implementation work continues.

### Required work
1. Rewrite `ACTIVE_TRANCHE.md` to match current hardening reality
2. Stop claiming final consolidation/hardening is complete
3. Point the live tranche cursor at the current hardening sequence
4. Record the key decision freezes in repo governance

### Why first
Because stale governance is now an active execution hazard.

---

## T1 — Streamlit contract execution

### Goal
Bring `app/streamlit_inspector.py` into actual alignment with the contract header.

### Required work
1. resolve the legacy statbook contradiction
2. remove private QE imports from Streamlit
3. remove direct KB/manual file reads from Streamlit
4. move Boss Waves runtime orchestration behind a sanctioned app-level seam
5. rewrite Streamlit tests away from helper-local anti-patterns toward boundary/contract tests

### Why second
Because the repo now explicitly says what Streamlit should be. The gap is implementation, not direction.

---

## T2 — QE authority closure

### Goal
Finish separating native QE execution from compat/report execution, while keeping formula-bridge truth explicit.

### Required work
1. stop `qe.kernel` importing `resolve_bucket_value` from `qe.stat_resolution`
2. stop `qe.routing` relying on compat delta execution for native operation
3. keep the formula-authority bridge explicit until retirement conditions are met
4. record bridge retirement threshold in tests and governance

### Why third
Because this remains a core architecture seam, but it is now lower leverage than governance + Streamlit truth.

---

## T3 — Evaluator cleanup

### Goal
Remove evaluator dependence on private QE/compiler helpers.

### Required work
1. replace underscore-prefixed compiler imports with public surfaces
2. stabilize evaluator-facing QE contracts
3. add regression coverage that prevents private-import reintroduction

---

## T4 — Thinning and polish

### Goal
Only after ownership seams are closed, reduce file size and residue.

### Required work
1. thin `app/streamlit_inspector.py`
2. thin large QE/evaluator files where still justified
3. clean residue helpers and mapping duplication
4. refine docs and release-gate split

### Why last
Because file splitting before authority closure will just spread ambiguity across more files.

---

## 7. What not to do next

Do **not** start with:

- file splitting
- Input tab polish in isolation
- general cleanup
- adding more Streamlit tests around current helper internals
- declaring the repo finished because the high-signal suites are green

Those would all be sequencing mistakes.

---

## 8. Recommended immediate next moves

1. rewrite `ACTIVE_TRANCHE.md`
2. freeze the Streamlit artifact decision in repo governance
3. remove the legacy statbook contradiction first
4. then remove Streamlit private imports and raw source reads
5. then attack QE compat/native execution seams

That is the highest-leverage order for the current repo.

# Relevant files to upload to Codex

## Best option
Upload the **full repo ZIP** plus these handoff docs:
- `CODEX_HANDOFF_V1_FULL.md`
- `STATUS_V1.yaml`

That is the cleanest option by far.

## If you do not want to upload the full repo
Upload this curated subset.

### Must-upload handoff docs
- `CODEX_HANDOFF_V1_FULL.md`
- `STATUS_V1.yaml`

### Must-upload repo docs
- `CONTRACT.md`
- `REPO_MAP.yaml`
- `README.md`
- `IMPLEMENTATION_STATUS.md`
- `mechanics/canonical_mechanics_contract.md`
- `mechanics/manifest.yaml`

### Must-upload canonical/core code
- `tower_sim/engines/stat_input_compiler.py`
- `tower_sim/engines/stat_pipeline.py`
- `tower_sim/engines/stat_engine.py`
- `tower_sim/engines/statbook_builder.py`
- `tower_sim/engines/combat_stat_derivation.py`
- `tower_sim/registry/stat_registry.py`
- `tower_sim/registry/combat_stat_contract.py`
- `tower_sim/registry/naming_contract.py`

### Must-upload domain files that currently conflict with the target architecture
- `tower_sim/engines/survivability_pipeline.py`
- `tower_sim/engines/edamage_pipeline.py`
- `tower_sim/engines/edamage_formulas.py`
- `tower_sim/engines/modules.py`

### Must-upload source libraries used for contributor wiring
- `tower_sim/libs/workshop_lib.py`
- `tower_sim/libs/labs_lib.py`
- `tower_sim/libs/uw_lib.py`
- `tower_sim/libs/bots_lib.py`
- `tower_sim/libs/cards_lib.py`
- `tower_sim/libs/modules_lib.py`
- `tower_sim/libs/module_main_effects.py`

### Must-upload snapshot/source compilation files
- `tower_sim/loaders/account_snapshot_compiler.py`
- `tower_sim/loaders/account_snapshot_loader.py`
- `tower_sim/loaders/ids_parser.py`
- `tower_sim/util/account_snapshot.py`
- `tower_sim/util/statbook.py`

### Must-upload tests
- `tests/test_stat_input_compiler.py`
- `tests/test_stat_pipeline.py`
- `tests/test_stat_pipeline_guardrails.py`
- `tests/test_stat_engine.py`
- `tests/test_statbook_builder.py`
- `tests/test_canonical_statbook.py`
- `tests/test_combat_stat_derivation.py`
- `tests/test_survivability_pipeline.py`
- `tests/test_edamage_pipeline.py`
- `tests/test_edamage_formulas_registry_routing.py`
- `tests/test_cards_lib.py`
- `tests/test_modules_lib.py`
- `tests/test_module_main_effects.py`
- `tests/test_bots_lib.py`
- `tests/test_uw_lib.py`
- `tests/test_labs_lib.py`
- `tests/test_workshop_lib.py`
- `tests/test_stat_registry.py`
- `tests/test_naming_contract.py`
- `tests/test_stat_source_coverage.py`
- `tests/test_canonical_derivation_source_coverage.py`

## Helpful-but-not-essential supporting audits
- `audit/repo_audit.md`
- `audit/stat_pipeline_guardrails_allowlist.yaml`
- `audit/reference_completeness_report.md`
- `audit/ehp_stat_source_audit.md`
- `audit/effective_paths_formula_comparison.md`
- `audit/effective_paths_mechanics_comparison.md`

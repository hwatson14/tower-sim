from models.statbook import StatRow

from engine.query_surface_publication import publish_phase3_query_surfaces


def row(name, value, value_type='scalar'):
    return StatRow(stat_name=name, final_value=value, value_type=value_type, source_count=1, status='resolved', contributors=[], schema={})


def _base_rows():
    return {
        'canonical_stat::tower_hp': row('canonical_stat::tower_hp', 100.0),
        'canonical_stat::wall_hp': row('canonical_stat::wall_hp', 50.0),
        'canonical_stat::wall_fortification_multiplier': row('canonical_stat::wall_fortification_multiplier', 2.0),
        'canonical_stat::tower_defense_absolute': row('canonical_stat::tower_defense_absolute', 10.0),
        'canonical_stat::tower_defense_pct': row('canonical_stat::tower_defense_pct', 20.0),
        'canonical_stat::max_recovery_multiplier': row('canonical_stat::max_recovery_multiplier', 1.5),
        'canonical_stat::recovery_package_multiplier': row('canonical_stat::recovery_package_multiplier', 1.2),
        'mechanic_param::uw.chrono_field.duration_seconds': row('mechanic_param::uw.chrono_field.duration_seconds', 10.0),
        'runtime_mechanic_param::uw.chrono_field.duration_seconds': row('runtime_mechanic_param::uw.chrono_field.duration_seconds', 0.0),
        'mechanic_param::uw.chrono_field.cooldown_seconds': row('mechanic_param::uw.chrono_field.cooldown_seconds', 20.0),
        'mechanic_param::uw.chrono_field.damage_reduction_pct': row('mechanic_param::uw.chrono_field.damage_reduction_pct', 30.0),
        'mechanic_param::uw.black_hole.duration_seconds': row('mechanic_param::uw.black_hole.duration_seconds', 15.0),
        'runtime_mechanic_param::uw.black_hole.duration_seconds': row('runtime_mechanic_param::uw.black_hole.duration_seconds', 0.0),
        'mechanic_param::uw.black_hole.cooldown_seconds': row('mechanic_param::uw.black_hole.cooldown_seconds', 30.0),
        'runtime_mechanic_param::uw.black_hole.cooldown_seconds': row('runtime_mechanic_param::uw.black_hole.cooldown_seconds', 0.0),
        'mechanic_param::module.primordial_collapse.bh_damage_reduction_pct': row('mechanic_param::module.primordial_collapse.bh_damage_reduction_pct', 25.0),
        'canonical_stat::tower_damage': row('canonical_stat::tower_damage', 100.0),
        'canonical_stat::tower_attack_speed': row('canonical_stat::tower_attack_speed', 2.0),
        'canonical_stat::tower_damage_per_meter_multiplier': row('canonical_stat::tower_damage_per_meter_multiplier', 0.1),
        'canonical_stat::tower_range_m': row('canonical_stat::tower_range_m', 10.0),
        'canonical_stat::tower_multishot_chance_pct': row('canonical_stat::tower_multishot_chance_pct', 10.0),
        'canonical_stat::tower_multishot_targets': row('canonical_stat::tower_multishot_targets', 3.0),
        'canonical_stat::tower_bounce_shot_chance_pct': row('canonical_stat::tower_bounce_shot_chance_pct', 20.0),
        'canonical_stat::tower_bounce_shot_targets': row('canonical_stat::tower_bounce_shot_targets', 2.0),
        'canonical_stat::tower_rapid_fire_chance_pct': row('canonical_stat::tower_rapid_fire_chance_pct', 10.0),
        'canonical_stat::tower_rapid_fire_duration_seconds': row('canonical_stat::tower_rapid_fire_duration_seconds', 1.5),
        'canonical_stat::tower_crit_chance_pct': row('canonical_stat::tower_crit_chance_pct', 20.0),
        'canonical_stat::tower_crit_multiplier': row('canonical_stat::tower_crit_multiplier', 5.0),
        'canonical_stat::tower_supercrit_chance_pct': row('canonical_stat::tower_supercrit_chance_pct', 10.0),
        'canonical_stat::tower_supercrit_multiplier': row('canonical_stat::tower_supercrit_multiplier', 10.0),
        'mechanic_param::shock.chance_pct': row('mechanic_param::shock.chance_pct', 15.0),
        'mechanic_param::shock.damage_multiplier': row('mechanic_param::shock.damage_multiplier', 2.0),
        'mechanic_param::uw.chain_lightning.damage_multiplier': row('mechanic_param::uw.chain_lightning.damage_multiplier', 0.5),
        'mechanic_param::uw.chain_lightning.quantity': row('mechanic_param::uw.chain_lightning.quantity', 2.0),
        'mechanic_param::uw.chain_lightning.chance_pct': row('mechanic_param::uw.chain_lightning.chance_pct', 20.0),
        'mechanic_param::uw.death_wave.damage_multiplier': row('mechanic_param::uw.death_wave.damage_multiplier', 1.0),
        'mechanic_param::uw.death_wave.quantity': row('mechanic_param::uw.death_wave.quantity', 2.0),
        'mechanic_param::uw.death_wave.cooldown_seconds': row('mechanic_param::uw.death_wave.cooldown_seconds', 40.0),
        'mechanic_param::uw.death_wave.damage_amp': row('mechanic_param::uw.death_wave.damage_amp', 1.0),
        'mechanic_param::uw.smart_missiles.damage_multiplier': row('mechanic_param::uw.smart_missiles.damage_multiplier', 0.8),
        'mechanic_param::uw.spotlight.damage_multiplier': row('mechanic_param::uw.spotlight.damage_multiplier', 1.5),
        'mechanic_param::uw.spotlight.quantity': row('mechanic_param::uw.spotlight.quantity', 3.0),
        'mechanic_param::uw.spotlight.angle_degrees': row('mechanic_param::uw.spotlight.angle_degrees', 45.0),
        'mechanic_param::uw.spotlight.light_range_bonus': row('mechanic_param::uw.spotlight.light_range_bonus', 0.25),
        'support_surface::timing.combined_multiplier': row('support_surface::timing.combined_multiplier', 1.2),
        'canonical_stat::coin_kill_multiplier': row('canonical_stat::coin_kill_multiplier', 100.0),
        'canonical_stat::coins_per_wave': row('canonical_stat::coins_per_wave', 10.0),
        'runtime_mechanic_param::uw.spotlight.coin_bonus_multiplier': row('runtime_mechanic_param::uw.spotlight.coin_bonus_multiplier', 10.0),
        'runtime_mechanic_param::uw.death_wave.coin_bonus_multiplier': row('runtime_mechanic_param::uw.death_wave.coin_bonus_multiplier', 5.0),
        'runtime_mechanic_param::cards.critical_coin.bonus_multiplier': row('runtime_mechanic_param::cards.critical_coin.bonus_multiplier', 50.0),
        'runtime_mechanic_param::cards.wave_skip.chance_pct': row('runtime_mechanic_param::cards.wave_skip.chance_pct', 10.0),
    }


def test_edamage_includes_ep_specific_terms():
    rows = _base_rows()
    publish_phase3_query_surfaces(rows)
    baseline = rows['derived::edamage'].final_value

    enriched = _base_rows()
    enriched.update({
        'mechanic_param::module.anti_cube_portal.damage_multiplier': row('mechanic_param::module.anti_cube_portal.damage_multiplier', 3.0),
        'canonical_stat::shockwave_size_level': row('canonical_stat::shockwave_size_level', 10.0),
        'runtime_mechanic_param::shockwave.size_lab_level': row('runtime_mechanic_param::shockwave.size_lab_level', 10.0),
        'canonical_stat::shockwave_frequency_level': row('canonical_stat::shockwave_frequency_level', 20.0),
        'mechanic_param::uw.chrono_field.slow_pct': row('mechanic_param::uw.chrono_field.slow_pct', 50.0),
        'mechanic_param::module.space_displacer.multiplier': row('mechanic_param::module.space_displacer.multiplier', 2.0),
        'runtime_mechanic_param::land_mine.spawn_per_second': row('runtime_mechanic_param::land_mine.spawn_per_second', 1.0),
        'runtime_mechanic_param::land_mine.chance': row('runtime_mechanic_param::land_mine.chance', 0.5),
        'mechanic_param::uw.inner_land_mines.active': row('mechanic_param::uw.inner_land_mines.active', 1.0),
        'mechanic_param::uw.inner_land_mines.damage_multiplier': row('mechanic_param::uw.inner_land_mines.damage_multiplier', 5.0),
        'mechanic_param::uw.inner_land_mines.quantity': row('mechanic_param::uw.inner_land_mines.quantity', 4.0),
        'mechanic_param::uw.inner_land_mines.cooldown_seconds': row('mechanic_param::uw.inner_land_mines.cooldown_seconds', 20.0),
    })
    publish_phase3_query_surfaces(enriched)

    assert enriched['derived::edamage.acp_factor'].final_value > 1.0
    assert enriched['derived::edamage.spotlight_factor'].final_value > 1.0
    assert enriched['derived::edamage.slow_factor'].final_value > 1.0
    assert enriched['derived::edamage.uw.ilm_dps'].final_value > 0.0
    assert enriched['derived::edamage'].final_value > baseline
    assert enriched['derived::edamage_ep'].final_value == enriched['derived::edamage'].final_value

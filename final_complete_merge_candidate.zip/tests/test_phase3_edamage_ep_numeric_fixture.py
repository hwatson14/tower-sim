from math import isclose

from models.statbook import StatRow

from engine.query_surface_publication import publish_phase3_query_surfaces


def row(name, value, value_type="scalar"):
    return StatRow(stat_name=name, final_value=value, value_type=value_type, source_count=1, status="resolved", contributors=[], schema={})


def _fixture_rows():
    return {
        'canonical_stat::tower_hp': row('canonical_stat::tower_hp', 100.0),
        'canonical_stat::wall_hp': row('canonical_stat::wall_hp', 50.0),
        'canonical_stat::wall_fortification_multiplier': row('canonical_stat::wall_fortification_multiplier', 2.0),
        'canonical_stat::tower_defense_absolute': row('canonical_stat::tower_defense_absolute', 10.0),
        'canonical_stat::tower_defense_pct': row('canonical_stat::tower_defense_pct', 20.0),
        'canonical_stat::max_recovery_multiplier': row('canonical_stat::max_recovery_multiplier', 1.5),
        'canonical_stat::recovery_package_multiplier': row('canonical_stat::recovery_package_multiplier', 1.2),
        'mechanic_param::uw.chrono_field.duration_seconds': row('mechanic_param::uw.chrono_field.duration_seconds', 10.0),
        'runtime_mechanic_param::uw.chrono_field.duration_seconds': row('runtime_mechanic_param::uw.chrono_field.duration_seconds', 0.0),
        'mechanic_param::uw.chrono_field.cooldown_seconds': row('mechanic_param::uw.chrono_field.cooldown_seconds', 20.0),
        'mechanic_param::uw.chrono_field.damage_reduction_pct': row('mechanic_param::uw.chrono_field.damage_reduction_pct', 30.0),
        'mechanic_param::uw.black_hole.duration_seconds': row('mechanic_param::uw.black_hole.duration_seconds', 15.0),
        'runtime_mechanic_param::uw.black_hole.duration_seconds': row('runtime_mechanic_param::uw.black_hole.duration_seconds', 0.0),
        'mechanic_param::uw.black_hole.cooldown_seconds': row('mechanic_param::uw.black_hole.cooldown_seconds', 30.0),
        'runtime_mechanic_param::uw.black_hole.cooldown_seconds': row('runtime_mechanic_param::uw.black_hole.cooldown_seconds', 0.0),
        'mechanic_param::module.primordial_collapse.bh_damage_reduction_pct': row('mechanic_param::module.primordial_collapse.bh_damage_reduction_pct', 25.0),

        'canonical_stat::tower_damage': row('canonical_stat::tower_damage', 100.0),
        'canonical_stat::tower_attack_speed': row('canonical_stat::tower_attack_speed', 2.0),
        'canonical_stat::tower_damage_per_meter_multiplier': row('canonical_stat::tower_damage_per_meter_multiplier', 0.1),
        'canonical_stat::tower_range_m': row('canonical_stat::tower_range_m', 10.0),
        'support_surface::timing.kill_at_range_multiplier': row('support_surface::timing.kill_at_range_multiplier', 1.0),
        'canonical_stat::tower_multishot_chance_pct': row('canonical_stat::tower_multishot_chance_pct', 10.0),
        'canonical_stat::tower_multishot_targets': row('canonical_stat::tower_multishot_targets', 3.0),
        'canonical_stat::tower_bounce_shot_chance_pct': row('canonical_stat::tower_bounce_shot_chance_pct', 20.0),
        'canonical_stat::tower_bounce_shot_targets': row('canonical_stat::tower_bounce_shot_targets', 2.0),
        'canonical_stat::tower_rapid_fire_chance_pct': row('canonical_stat::tower_rapid_fire_chance_pct', 10.0),
        'canonical_stat::tower_rapid_fire_duration_seconds': row('canonical_stat::tower_rapid_fire_duration_seconds', 1.5),
        'canonical_stat::tower_crit_chance_pct': row('canonical_stat::tower_crit_chance_pct', 20.0),
        'canonical_stat::tower_crit_multiplier': row('canonical_stat::tower_crit_multiplier', 5.0),
        'canonical_stat::tower_supercrit_chance_pct': row('canonical_stat::tower_supercrit_chance_pct', 10.0),
        'canonical_stat::tower_supercrit_multiplier': row('canonical_stat::tower_supercrit_multiplier', 10.0),

        'mechanic_param::uw.chain_lightning.active': row('mechanic_param::uw.chain_lightning.active', True, 'bool'),
        'runtime_mechanic_param::shock.enabled': row('runtime_mechanic_param::shock.enabled', True, 'bool'),
        'support_surface::shock.level': row('support_surface::shock.level', 0.0),
        'support_surface::shock.factor': row('support_surface::shock.factor', 2.0),

        'mechanic_param::module.anti_cube_portal.damage_multiplier': row('mechanic_param::module.anti_cube_portal.damage_multiplier', 3.0),
        'canonical_stat::shockwave_size_level': row('canonical_stat::shockwave_size_level', 10.0),
        'runtime_mechanic_param::shockwave.size_lab_level': row('runtime_mechanic_param::shockwave.size_lab_level', 10.0),
        'canonical_stat::shockwave_frequency_level': row('canonical_stat::shockwave_frequency_level', 20.0),

        'mechanic_param::uw.spotlight.damage_multiplier': row('mechanic_param::uw.spotlight.damage_multiplier', 1.5),
        'mechanic_param::uw.spotlight.quantity': row('mechanic_param::uw.spotlight.quantity', 3.0),
        'mechanic_param::uw.spotlight.angle_degrees': row('mechanic_param::uw.spotlight.angle_degrees', 45.0),
        'mechanic_param::uw.spotlight.light_range_bonus': row('mechanic_param::uw.spotlight.light_range_bonus', 0.25),
        'runtime_mechanic_param::uw.spotlight.active': row('runtime_mechanic_param::uw.spotlight.active', True, 'bool'),

        'mechanic_param::uw.death_wave.active': row('mechanic_param::uw.death_wave.active', True, 'bool'),
        'support_surface::uw.death_wave.final_damage': row('support_surface::uw.death_wave.final_damage', 1.0),
        'support_surface::uw.death_wave.final_quantity': row('support_surface::uw.death_wave.final_quantity', 2.0),
        'support_surface::uw.death_wave.final_cooldown_seconds': row('support_surface::uw.death_wave.final_cooldown_seconds', 40.0),
        'support_surface::uw.death_wave.damage_amp': row('support_surface::uw.death_wave.damage_amp', 1.0),

        'support_surface::uw.chain_lightning.final_damage': row('support_surface::uw.chain_lightning.final_damage', 0.5),
        'support_surface::uw.chain_lightning.final_quantity': row('support_surface::uw.chain_lightning.final_quantity', 2.0),
        'support_surface::uw.chain_lightning.final_chance': row('support_surface::uw.chain_lightning.final_chance', 20.0),

        'runtime_mechanic_param::uw.smart_missiles.active': row('runtime_mechanic_param::uw.smart_missiles.active', True, 'bool'),
        'support_surface::uw.smart_missiles.final_damage': row('support_surface::uw.smart_missiles.final_damage', 8.0),
        'support_surface::uw.smart_missiles.final_quantity': row('support_surface::uw.smart_missiles.final_quantity', 5.0),
        'support_surface::uw.smart_missiles.final_cooldown_seconds': row('support_surface::uw.smart_missiles.final_cooldown_seconds', 20.0),
        'support_surface::uw.smart_missiles.cover_fire_time_seconds': row('support_surface::uw.smart_missiles.cover_fire_time_seconds', 4.0),
        'support_surface::uw.smart_missiles.heat_multiplier': row('support_surface::uw.smart_missiles.heat_multiplier', 1.3),
        'support_surface::uw.smart_missiles.aoe_multiplier': row('support_surface::uw.smart_missiles.aoe_multiplier', 1.2),

        'runtime_mechanic_param::uw.poison_swamp.active': row('runtime_mechanic_param::uw.poison_swamp.active', True, 'bool'),
        'support_surface::uw.poison_swamp.damage': row('support_surface::uw.poison_swamp.damage', 7.0),
        'support_surface::uw.poison_swamp.duration_seconds': row('support_surface::uw.poison_swamp.duration_seconds', 12.0),
        'support_surface::uw.poison_swamp.cooldown_seconds': row('support_surface::uw.poison_swamp.cooldown_seconds', 30.0),
        'support_surface::uw.poison_swamp.death_creep_multiplier': row('support_surface::uw.poison_swamp.death_creep_multiplier', 1.5),
        'support_surface::uw.poison_swamp.rend_multiplier': row('support_surface::uw.poison_swamp.rend_multiplier', 1.7),

        'mechanic_param::module.space_displacer.multiplier': row('mechanic_param::module.space_displacer.multiplier', 2.0),
        'runtime_mechanic_param::land_mine.spawn_per_second': row('runtime_mechanic_param::land_mine.spawn_per_second', 1.0),
        'runtime_mechanic_param::land_mine.chance': row('runtime_mechanic_param::land_mine.chance', 0.5),
        'mechanic_param::uw.inner_land_mines.active': row('mechanic_param::uw.inner_land_mines.active', True, 'bool'),
        'mechanic_param::uw.inner_land_mines.damage_multiplier': row('mechanic_param::uw.inner_land_mines.damage_multiplier', 5.0),
        'mechanic_param::uw.inner_land_mines.quantity': row('mechanic_param::uw.inner_land_mines.quantity', 4.0),
        'mechanic_param::uw.inner_land_mines.cooldown_seconds': row('mechanic_param::uw.inner_land_mines.cooldown_seconds', 20.0),

        'runtime_mechanic_param::cards.aoe.active': row('runtime_mechanic_param::cards.aoe.active', True, 'bool'),
        'runtime_mechanic_param::cards.aoe.level': row('runtime_mechanic_param::cards.aoe.level', 3.0),

        'mechanic_param::uw.chrono_field.slow_pct': row('mechanic_param::uw.chrono_field.slow_pct', 50.0),
        'support_surface::chrono_field.plus_exposure_multiplier': row('support_surface::chrono_field.plus_exposure_multiplier', 1.15),

        'support_surface::timing.combined_multiplier': row('support_surface::timing.combined_multiplier', 1.2),
        'canonical_stat::coin_kill_multiplier': row('canonical_stat::coin_kill_multiplier', 100.0),
        'canonical_stat::coins_per_wave': row('canonical_stat::coins_per_wave', 10.0),
        'runtime_mechanic_param::uw.spotlight.coin_bonus_multiplier': row('runtime_mechanic_param::uw.spotlight.coin_bonus_multiplier', 10.0),
        'runtime_mechanic_param::uw.death_wave.coin_bonus_multiplier': row('runtime_mechanic_param::uw.death_wave.coin_bonus_multiplier', 5.0),
        'runtime_mechanic_param::cards.critical_coin.bonus_multiplier': row('runtime_mechanic_param::cards.critical_coin.bonus_multiplier', 50.0),
        'runtime_mechanic_param::cards.wave_skip.chance_pct': row('runtime_mechanic_param::cards.wave_skip.chance_pct', 10.0),
    }


def test_edamage_numeric_fixture_matches_expected_intermediates_and_total():
    rows = _fixture_rows()
    publish_phase3_query_surfaces(rows)

    expected = {
        'derived::edamage.base_damage_stack': 357.30337078651684,
        'derived::edamage.acp_factor': 1.7865168539325842,
        'derived::edamage.bullet_crit_factor': 2.7,
        'derived::edamage.uw_crit_factor': 2.4,
        'derived::edamage.bullet_per_second': 131.261754,
        'derived::edamage.multishot_factor': 1.2,
        'derived::edamage.bounce_factor': 1.24,
        'derived::edamage.rapidfire_factor': 3.8549972521737614,
        'derived::edamage.range_dpm_factor': 2.0,
        'derived::edamage.spotlight_light_range_factor': 1.1,
        'derived::edamage.spotlight_bonus_term': 2.3125,
        'derived::edamage.spotlight_coverage': 0.25,
        'derived::edamage.spotlight_factor': 1.328125,
        'derived::edamage_ep_helper.dx_spotlight_light_range_factor': 1.1,
        'derived::edamage_ep_helper.dx_spotlight_bonus_term': 2.3125,
        'derived::edamage_ep_helper.dx_spotlight_coverage': 0.25,
        'derived::edamage.bullet_pipeline_factor': 1505.8967741328725,
        'derived::edamage.uw.chain_lightning_dps': 150.58967741328726,
        'derived::edamage.uw.death_wave_dps': 0.325,
        'derived::edamage.uw.smart_missiles_dps': 6.926400000000001,
        'derived::edamage.uw.spotlight_missiles_dps': 1.2987000000000002,
        'derived::edamage.uw.poison_swamp_dps': 7.925400000000001,
        'derived::edamage.uw.ilm_dps': 6.66,
        'derived::edamage.uw_total_damage': 230.30261531452211,
        'derived::edamage.slow_factor': 2.3,
        'derived::edamage': 4891979.575355751,
    }

    for key, target in expected.items():
        actual = rows[key].final_value
        assert isclose(actual, target, rel_tol=1e-9, abs_tol=1e-9), f"{key}: expected {target}, got {actual}"

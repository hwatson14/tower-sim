from __future__ import annotations

from pathlib import Path
import yaml

from engine.query_surface_publication import phase3_publication_contract_snapshot

ROOT = Path(__file__).resolve().parents[1]
INITIAL_SET_PATH = ROOT / 'kb' / 'global-rules' / 'contracts' / 'stat-query-initial-surface-set.yaml'
OWNERSHIP_LEDGER_PATH = ROOT / 'kb' / 'global-rules' / 'contracts' / 'stat-query-surface-ownership-ledger.yaml'
CONSUMER_BUNDLES_PATH = ROOT / 'kb' / 'global-rules' / 'contracts' / 'stat-query-consumer-bundles.yaml'
ACTIVE_TRANCHE_PATH = ROOT / 'ACTIVE_TRANCHE.md'
BURNDOWN_PATH = ROOT / 'BURNDOWN.yaml'


def _load_yaml(path: Path) -> dict:
    return yaml.safe_load(path.read_text(encoding='utf-8'))


def _initial_set_surface_map() -> dict[str, dict]:
    doc = _load_yaml(INITIAL_SET_PATH)
    surfaces = {}
    for family in doc.get('families', []):
        for item in family.get('surfaces', []):
            sid = item['surface_id']
            if sid in surfaces:
                raise AssertionError(f'duplicate initial-surface-set entry for {sid}')
            surfaces[sid] = item
    return surfaces


def _ownership_map() -> dict[str, dict]:
    doc = _load_yaml(OWNERSHIP_LEDGER_PATH)
    nodes = {}
    for item in doc.get('surface_nodes', []):
        sid = item['node_id']
        if sid in nodes:
            raise AssertionError(f'duplicate ownership-ledger entry for {sid}')
        nodes[sid] = item
    return nodes


def _optimizer_bundle() -> dict:
    doc = _load_yaml(CONSUMER_BUNDLES_PATH)
    for consumer in doc.get('consumers', []):
        if consumer.get('consumer_id') != 'optimizer_analysis':
            continue
        for bundle in consumer.get('bundles', []):
            if bundle.get('bundle_id') == 'derived_composite_scores':
                return bundle
    raise AssertionError('optimizer_analysis / derived_composite_scores bundle not found')



def test_phase3_publication_snapshot_uses_derived_not_objective_state():
    snapshot = phase3_publication_contract_snapshot()
    all_ids = (
        snapshot['required_objective_surfaces']
        + snapshot['ep_objective_surfaces']
        + snapshot['ep_helper_prefixes']
        + snapshot['forbidden_legacy_prefixes']
    )
    assert 'objective_state::' in snapshot['forbidden_legacy_prefixes']
    assert all(not sid.startswith('objective_state::') for sid in snapshot['required_objective_surfaces'])
    assert all(not sid.startswith('objective_state::') for sid in snapshot['ep_objective_surfaces'])



def test_optimizer_bundle_required_surfaces_are_unique_query_owned_and_direct():
    bundle = _optimizer_bundle()
    ownership = _ownership_map()
    initial = _initial_set_surface_map()
    required = bundle['required_surface_ids']

    assert required == ['derived::ehp', 'derived::edamage', 'derived::eecon']
    assert len(set(required)) == len(required)

    for sid in required:
        assert sid in ownership, f'{sid} missing from ownership ledger'
        assert ownership[sid]['ownership_status'] == 'query_owned'
        assert ownership[sid]['downstream_policy'] == 'consume_only_no_rederivation'
        assert sid in initial, f'{sid} missing from initial surface set'
        assert initial[sid]['queryable_directly'] is True
        assert initial[sid]['surface_class'] == 'objective_surface'



def test_optimizer_optional_surfaces_are_governed_without_objective_state_legacy():
    bundle = _optimizer_bundle()
    ownership = _ownership_map()
    initial = _initial_set_surface_map()
    optional = bundle['optional_surface_ids']

    assert len(set(optional)) == len(optional)
    assert all(not sid.startswith('objective_state::') for sid in optional)

    for sid in optional:
        assert sid in ownership, f'{sid} missing from ownership ledger'
        assert ownership[sid]['ownership_status'] == 'query_owned'
        assert sid in initial, f'{sid} missing from initial surface set'



def test_patch_local_control_truth_has_no_objective_state_legacy():
    tranche_text = ACTIVE_TRANCHE_PATH.read_text(encoding='utf-8')
    burndown_text = BURNDOWN_PATH.read_text(encoding='utf-8')
    assert 'objective_state::' not in tranche_text
    assert 'objective_state::' not in burndown_text
    assert 'derived::ehp' in tranche_text
    assert 'derived::edamage' in tranche_text
    assert 'derived::eecon' in tranche_text

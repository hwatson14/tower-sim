from math import isclose

from models.statbook import StatRow
from engine.query_surface_publication import publish_phase3_query_surfaces


def row(name, value, value_type="scalar"):
    return StatRow(stat_name=name, final_value=value, value_type=value_type, source_count=1, status="resolved", contributors=[], schema={})


def test_ehp_hardening_direct_surfaces_override_fallbacks_but_raw_terms_stay_traceable():
    rows = {
        # direct objective-support surfaces
        'support_surface::ehp.health_factor': row('support_surface::ehp.health_factor', 100.0),
        'support_surface::ehp.armor_factor': row('support_surface::ehp.armor_factor', 1.5),
        'support_surface::ehp.wall_health_factor': row('support_surface::ehp.wall_health_factor', 80.0),
        'support_surface::ehp.max_recovery_factor': row('support_surface::ehp.max_recovery_factor', 2.0),
        'support_surface::ehp.wall_active': row('support_surface::ehp.wall_active', True, 'bool'),
        'support_surface::ehp.max_recovery_active': row('support_surface::ehp.max_recovery_active', True, 'bool'),
        'support_surface::ehp.dabs_factor': row('support_surface::ehp.dabs_factor', 12.0),
        'support_surface::ehp.def_pct': row('support_surface::ehp.def_pct', 0.20),
        'support_surface::ehp.chrono_field_duration_seconds': row('support_surface::ehp.chrono_field_duration_seconds', 10.0),
        'support_surface::ehp.chrono_field_cooldown_seconds': row('support_surface::ehp.chrono_field_cooldown_seconds', 20.0),
        'support_surface::ehp.chrono_field_damage_reduction_pct': row('support_surface::ehp.chrono_field_damage_reduction_pct', 30.0),
        'support_surface::ehp.wall_invuln_reduction_pct': row('support_surface::ehp.wall_invuln_reduction_pct', 0.50),
        'support_surface::ehp.chain_thunder_reduction_pct': row('support_surface::ehp.chain_thunder_reduction_pct', 10.0),
        'support_surface::ehp.tradeoff_defense_factor': row('support_surface::ehp.tradeoff_defense_factor', 1.1),
        # conflicting fallback ingredients
        'support_surface::ehp.health_ws': row('support_surface::ehp.health_ws', 999.0),
        'support_surface::ehp.health_lab_level': row('support_surface::ehp.health_lab_level', 10.0),
        'support_surface::ehp.workshop_enhancement_level': row('support_surface::ehp.workshop_enhancement_level', 5.0),
        'support_surface::ehp.def_pct_ws': row('support_surface::ehp.def_pct_ws', 0.10),
        'support_surface::ehp.def_pct_lab_level': row('support_surface::ehp.def_pct_lab_level', 10.0),
        'support_surface::ehp.def_pct_relic_pct': row('support_surface::ehp.def_pct_relic_pct', 0.05),
    }
    publish_phase3_query_surfaces(rows)

    # direct objective-support surfaces win
    assert isclose(rows['derived::ehp.health_factor'].final_value, 100.0, rel_tol=0, abs_tol=1e-12)
    assert isclose(rows['derived::ehp.armor_factor'].final_value, 1.5, rel_tol=0, abs_tol=1e-12)
    assert isclose(rows['derived::ehp.wall_factor'].final_value, 80.0, rel_tol=0, abs_tol=1e-12)
    assert isclose(rows['derived::ehp.recovery_package_factor'].final_value, 2.0, rel_tol=0, abs_tol=1e-12)
    assert isclose(rows['derived::ehp.dabs_factor'].final_value, 12.0, rel_tol=0, abs_tol=1e-12)

    # raw term remains raw fallback composition, not the direct override
    expected_def_pct_raw = min(0.98, 0.10 + (0.002 * 10.0) + 0.05)
    assert isclose(rows['derived::ehp.def_pct_raw'].final_value, expected_def_pct_raw, rel_tol=0, abs_tol=1e-12)
    assert isclose(rows['derived::ehp.defense_taken_factor'].final_value, 1.25, rel_tol=0, abs_tol=1e-12)

    # CN5 structure hardening: wall invuln applies only to additive DABS branch
    base_pool = 100.0 * 1.5 * (80.0 + 2.0)
    cf_factor = 1.0 / (1.0 - ((10.0 / 30.0) * 0.30))
    chain_factor = 1.0 / (1.0 - 0.10)
    pre_defense = base_pool * cf_factor * chain_factor
    dabs_effective = 12.0 * (1.0 / (1.0 - 0.50))
    pre_tradeoff = (pre_defense + dabs_effective) * 1.25
    expected_ehp = pre_tradeoff * 1.1

    assert isclose(rows['derived::ehp.base_pool'].final_value, base_pool, rel_tol=0, abs_tol=1e-9)
    assert isclose(rows['derived::ehp.pre_defense_pool'].final_value, pre_defense, rel_tol=0, abs_tol=1e-9)
    assert isclose(rows['derived::ehp.dabs_effective_factor'].final_value, dabs_effective, rel_tol=0, abs_tol=1e-9)
    assert isclose(rows['derived::ehp.pre_tradeoff_ehp'].final_value, pre_tradeoff, rel_tol=0, abs_tol=1e-9)
    assert isclose(rows['derived::ehp'].final_value, expected_ehp, rel_tol=0, abs_tol=1e-9)
    assert isclose(rows['derived::ehp_ep'].final_value, expected_ehp, rel_tol=0, abs_tol=1e-9)

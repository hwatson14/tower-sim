from __future__ import annotations

import json
from pathlib import Path

from engine.query_currency_income import manual_income_input_contract_snapshot

ROOT = Path(__file__).resolve().parents[1]


def test_default_manual_input_file_contains_only_supported_editable_inputs():
    snap = manual_income_input_contract_snapshot()
    payload = json.loads((ROOT / snap["supported_manual_input_file"]).read_text(encoding="utf-8"))
    rows = payload["inputs"]
    ids = [row["input_id"] for row in rows]

    assert ids == snap["editable_manual_input_ids"]
    assert set(ids).isdisjoint(set(snap["unsupported_manual_input_ids"]))


def test_default_manual_input_file_replacement_targets_match_supported_income_surfaces():
    snap = manual_income_input_contract_snapshot()
    payload = json.loads((ROOT / snap["supported_manual_input_file"]).read_text(encoding="utf-8"))
    expected_targets = {
        input_id: f"future_query_surface::derived::economy.income.{input_id.split('.')[1]}"
        for input_id in snap["editable_manual_input_ids"]
    }
    for row in payload["inputs"]:
        assert row["replacement_target"] == expected_targets[row["input_id"]]

from models.statbook import StatRow
from engine.derived_surface_composer import compose_derived_surfaces
from engine.query_surface_publication import publish_phase3_query_surfaces
from optimizer.scorer import compute_optimizer_scores


def row(name, value, value_type='scalar'):
    return StatRow(stat_name=name, final_value=value, value_type=value_type, source_count=1, status='resolved', contributors=[], schema={})


def fixture_rows():
    return {
        'canonical_stat::tower_hp': row('canonical_stat::tower_hp', 100.0),
        'canonical_stat::wall_hp': row('canonical_stat::wall_hp', 50.0),
        'canonical_stat::wall_fortification_multiplier': row('canonical_stat::wall_fortification_multiplier', 2.0),
        'canonical_stat::tower_defense_absolute': row('canonical_stat::tower_defense_absolute', 10.0),
        'canonical_stat::tower_defense_pct': row('canonical_stat::tower_defense_pct', 20.0),
        'canonical_stat::max_recovery_multiplier': row('canonical_stat::max_recovery_multiplier', 1.5),
        'canonical_stat::recovery_package_multiplier': row('canonical_stat::recovery_package_multiplier', 1.2),
        'mechanic_param::uw.chrono_field.duration_seconds': row('mechanic_param::uw.chrono_field.duration_seconds', 10.0),
        'runtime_mechanic_param::uw.chrono_field.duration_seconds': row('runtime_mechanic_param::uw.chrono_field.duration_seconds', 0.0),
        'mechanic_param::uw.chrono_field.cooldown_seconds': row('mechanic_param::uw.chrono_field.cooldown_seconds', 20.0),
        'mechanic_param::uw.chrono_field.damage_reduction_pct': row('mechanic_param::uw.chrono_field.damage_reduction_pct', 30.0),
        'mechanic_param::uw.black_hole.duration_seconds': row('mechanic_param::uw.black_hole.duration_seconds', 15.0),
        'runtime_mechanic_param::uw.black_hole.duration_seconds': row('runtime_mechanic_param::uw.black_hole.duration_seconds', 0.0),
        'mechanic_param::uw.black_hole.cooldown_seconds': row('mechanic_param::uw.black_hole.cooldown_seconds', 30.0),
        'runtime_mechanic_param::uw.black_hole.cooldown_seconds': row('runtime_mechanic_param::uw.black_hole.cooldown_seconds', 0.0),
        'mechanic_param::module.primordial_collapse.bh_damage_reduction_pct': row('mechanic_param::module.primordial_collapse.bh_damage_reduction_pct', 25.0),
        'canonical_stat::tower_damage': row('canonical_stat::tower_damage', 100.0),
        'canonical_stat::tower_attack_speed': row('canonical_stat::tower_attack_speed', 2.0),
        'canonical_stat::tower_damage_per_meter_multiplier': row('canonical_stat::tower_damage_per_meter_multiplier', 0.1),
        'canonical_stat::tower_range_m': row('canonical_stat::tower_range_m', 10.0),
        'canonical_stat::tower_multishot_chance_pct': row('canonical_stat::tower_multishot_chance_pct', 10.0),
        'canonical_stat::tower_multishot_targets': row('canonical_stat::tower_multishot_targets', 3.0),
        'canonical_stat::tower_bounce_shot_chance_pct': row('canonical_stat::tower_bounce_shot_chance_pct', 20.0),
        'canonical_stat::tower_bounce_shot_targets': row('canonical_stat::tower_bounce_shot_targets', 2.0),
        'canonical_stat::tower_rapid_fire_chance_pct': row('canonical_stat::tower_rapid_fire_chance_pct', 10.0),
        'canonical_stat::tower_rapid_fire_duration_seconds': row('canonical_stat::tower_rapid_fire_duration_seconds', 1.5),
        'canonical_stat::tower_crit_chance_pct': row('canonical_stat::tower_crit_chance_pct', 20.0),
        'canonical_stat::tower_crit_multiplier': row('canonical_stat::tower_crit_multiplier', 5.0),
        'canonical_stat::tower_supercrit_chance_pct': row('canonical_stat::tower_supercrit_chance_pct', 10.0),
        'canonical_stat::tower_supercrit_multiplier': row('canonical_stat::tower_supercrit_multiplier', 10.0),
        'mechanic_param::shock.chance_pct': row('mechanic_param::shock.chance_pct', 15.0),
        'mechanic_param::shock.damage_multiplier': row('mechanic_param::shock.damage_multiplier', 2.0),
        'mechanic_param::uw.chain_lightning.damage_multiplier': row('mechanic_param::uw.chain_lightning.damage_multiplier', 0.5),
        'mechanic_param::uw.death_wave.damage_multiplier': row('mechanic_param::uw.death_wave.damage_multiplier', 1.0),
        'mechanic_param::uw.smart_missiles.damage_multiplier': row('mechanic_param::uw.smart_missiles.damage_multiplier', 0.8),
        'mechanic_param::uw.spotlight.damage_multiplier': row('mechanic_param::uw.spotlight.damage_multiplier', 1.5),
        'canonical_stat::coin_kill_multiplier': row('canonical_stat::coin_kill_multiplier', 100.0),
        'canonical_stat::coins_per_wave': row('canonical_stat::coins_per_wave', 10.0),
        'runtime_mechanic_param::uw.spotlight.coin_bonus_multiplier': row('runtime_mechanic_param::uw.spotlight.coin_bonus_multiplier', 10.0),
        'runtime_mechanic_param::uw.death_wave.coin_bonus_multiplier': row('runtime_mechanic_param::uw.death_wave.coin_bonus_multiplier', 5.0),
        'runtime_mechanic_param::cards.critical_coin.bonus_multiplier': row('runtime_mechanic_param::cards.critical_coin.bonus_multiplier', 50.0),
        'runtime_mechanic_param::cards.wave_skip.chance_pct': row('runtime_mechanic_param::cards.wave_skip.chance_pct', 10.0),
        'support_surface::timing.combined_multiplier': row('support_surface::timing.combined_multiplier', 1.2),
    }


def test_publication_and_optimizer_preference():
    rows = fixture_rows()
    compose_derived_surfaces(rows)
    publish_phase3_query_surfaces(rows)
    assert 'derived::ehp' in rows
    assert 'derived::ehp_ep' in rows
    assert rows['derived::ehp'].final_value == rows['derived::ehp_ep'].final_value
    assert 'derived::edamage' in rows
    assert 'derived::edamage_ep' in rows
    assert rows['derived::edamage'].final_value == rows['derived::edamage_ep'].final_value
    assert 'derived::eecon' in rows
    assert 'derived::eecon_ep' in rows
    assert rows['derived::eecon'].final_value == rows['derived::eecon_ep'].final_value
    assert 'derived::eecon.base_coin_income' in rows
    assert 'derived::economy.income.coins' in rows
    assert 'derived::economy.income.cash' not in rows
    out = compute_optimizer_scores({'rows': rows})
    assert out['objectives']['ehp']['score'] == rows['derived::ehp'].final_value
    assert out['objectives']['edamage']['score'] == rows['derived::edamage'].final_value
    assert out['objectives']['eecon']['score'] == rows['derived::eecon'].final_value

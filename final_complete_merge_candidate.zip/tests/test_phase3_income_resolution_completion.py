from __future__ import annotations

import json
from pathlib import Path

import yaml

from engine.query_currency_income import (
    currency_income_surface_contract_snapshot,
    manual_income_input_contract_snapshot,
    phase3_income_resolution_audit_snapshot,
)


def _contract_rows():
    contract = yaml.safe_load(Path("kb/economy/contracts/currency-income-surfaces-contract.yaml").read_text(encoding="utf-8"))
    return contract["currencies"], contract["unsupported_resources"]


def test_phase3_income_resolution_partition_is_complete_and_exclusive():
    currencies, unsupported = _contract_rows()
    snap = phase3_income_resolution_audit_snapshot()

    contract_supported = {row["resource_id"] for row in currencies}
    contract_unsupported = {row["resource_id"] for row in unsupported}

    assert set(snap["supported_resources"]) == contract_supported
    assert set(snap["unsupported_resources"]) == contract_unsupported
    assert set(snap["complete_partition"]) == contract_supported | contract_unsupported

    deterministic = set(snap["deterministic_resources"])
    externalized = set(snap["externalized_manual_resources"])

    assert deterministic == {"coins"}
    assert deterministic.isdisjoint(externalized)
    assert deterministic | externalized == contract_supported


def test_phase3_income_resolution_modes_match_contract_snapshot():
    contract_snap = currency_income_surface_contract_snapshot()
    audit_snap = phase3_income_resolution_audit_snapshot()

    expected = {}
    for resource_id, row in contract_snap["deterministic"].items():
        expected[resource_id] = row["resolution_mode"]
    for resource_id, row in contract_snap["externalized_manual"].items():
        expected[resource_id] = row["resolution_mode"]

    assert audit_snap["resolution_modes"] == expected
    assert set(audit_snap["supported_surface_ids"]) == {
        row["surface_id"] for row in contract_snap["deterministic"].values()
    } | {row["surface_id"] for row in contract_snap["externalized_manual"].values()}


def test_default_manual_file_matches_externalized_manual_resources_only():
    audit_snap = phase3_income_resolution_audit_snapshot()
    manual_snap = manual_income_input_contract_snapshot()
    payload = json.loads(Path("input/manual_advisory_inputs.json").read_text(encoding="utf-8"))
    present_ids = {row["input_id"] for row in payload["inputs"]}

    expected_manual_ids = {f"income.{r}.per_week" for r in audit_snap["externalized_manual_resources"]}
    assert present_ids == expected_manual_ids
    assert set(manual_snap["editable_manual_input_ids"]) == expected_manual_ids
    assert set(manual_snap["unsupported_manual_input_ids"]).isdisjoint(present_ids)

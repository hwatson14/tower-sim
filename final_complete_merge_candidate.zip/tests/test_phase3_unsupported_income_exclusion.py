from __future__ import annotations

import json
from pathlib import Path

import yaml

from engine.query_currency_income import (
    forbidden_income_surface_ids,
    manual_income_input_contract_snapshot,
    supported_externalized_surface_ids,
)
from engine.query_surface_publication import publish_phase3_query_surfaces
from models.statbook import StatRow

ROOT = Path(__file__).resolve().parents[1]


def _load_yaml(path: Path):
    return yaml.safe_load(path.read_text(encoding='utf-8'))


def _fixture_rows() -> dict[str, StatRow]:
    return {
        'derived::ehp': StatRow(stat_name='derived::ehp', final_value=10.0, value_type='scalar', source_count=1, status='resolved'),
        'derived::ehp_ep': StatRow(stat_name='derived::ehp_ep', final_value=10.0, value_type='scalar', source_count=1, status='resolved'),
        'derived::edamage': StatRow(stat_name='derived::edamage', final_value=20.0, value_type='scalar', source_count=1, status='resolved'),
        'derived::edamage_ep': StatRow(stat_name='derived::edamage_ep', final_value=20.0, value_type='scalar', source_count=1, status='resolved'),
        'derived::eecon.base_coin_income': StatRow(stat_name='derived::eecon.base_coin_income', final_value=100.0, value_type='per_week', source_count=1, status='resolved'),
        'derived::eecon': StatRow(stat_name='derived::eecon', final_value=30.0, value_type='scalar', source_count=1, status='resolved'),
        'derived::eecon_ep': StatRow(stat_name='derived::eecon_ep', final_value=30.0, value_type='scalar', source_count=1, status='resolved'),
    }


def test_unsupported_income_surfaces_are_excluded_from_phase3_contract_surfaces():
    forbidden = forbidden_income_surface_ids()
    initial = _load_yaml(ROOT / 'kb/global-rules/contracts/stat-query-initial-surface-set.yaml')
    ownership = _load_yaml(ROOT / 'kb/global-rules/contracts/stat-query-surface-ownership-ledger.yaml')
    bundles = _load_yaml(ROOT / 'kb/global-rules/contracts/stat-query-consumer-bundles.yaml')

    declared_initial = {row['surface_id'] for row in initial if isinstance(row, dict) and 'surface_id' in row}
    declared_owned = {row['node_id'] for row in ownership if isinstance(row, dict) and 'node_id' in row}
    bundled = set()
    for row in bundles:
        if not isinstance(row, dict):
            continue
        bundled.update(row.get('required_surfaces', []))
        bundled.update(row.get('optional_surfaces', []))

    for surface_id in forbidden:
        assert surface_id not in declared_initial
        assert surface_id not in declared_owned
        assert surface_id not in bundled


def test_manual_income_snapshot_matches_input_file_and_supported_surface_count():
    snap = manual_income_input_contract_snapshot()
    manual = json.loads((ROOT / snap['supported_manual_input_file']).read_text(encoding='utf-8'))
    input_ids = {row['input_id'] for row in manual['inputs']}

    assert set(snap['editable_manual_input_ids']) == input_ids
    assert set(snap['unsupported_manual_input_ids']).isdisjoint(input_ids)
    assert snap['default_file_contains_only_supported_inputs'] is True
    assert len(snap['editable_manual_input_ids']) == len(supported_externalized_surface_ids())


def test_publication_excludes_forbidden_income_surfaces_even_when_manual_ids_are_present(tmp_path: Path):
    snap = manual_income_input_contract_snapshot()
    entries = []
    for idx, input_id in enumerate(snap['editable_manual_input_ids'] + snap['unsupported_manual_input_ids'], start=1):
        entries.append({
            'input_id': input_id,
            'value': float(idx),
            'is_set': True,
            'trust_label': 'Externally observed',
            'consumer_scope': ['optimizer'],
        })
    manual_path = tmp_path / 'manual.json'
    manual_path.write_text(json.dumps({'inputs': entries}), encoding='utf-8')

    rows = _fixture_rows()
    publish_phase3_query_surfaces(rows, manual_input_path=manual_path)

    for surface_id in snap['forbidden_income_surface_ids']:
        assert surface_id not in rows

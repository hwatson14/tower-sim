from __future__ import annotations

from pathlib import Path
import yaml

from engine.query_surface_publication import phase3_publication_contract_snapshot
from optimizer.scorer import optimizer_consumption_contract_snapshot

ROOT = Path(__file__).resolve().parents[1]
INITIAL_SET_PATH = ROOT / 'kb' / 'global-rules' / 'contracts' / 'stat-query-initial-surface-set.yaml'
OWNERSHIP_LEDGER_PATH = ROOT / 'kb' / 'global-rules' / 'contracts' / 'stat-query-surface-ownership-ledger.yaml'
CONSUMER_BUNDLES_PATH = ROOT / 'kb' / 'global-rules' / 'contracts' / 'stat-query-consumer-bundles.yaml'


def _load_yaml(path: Path) -> dict:
    return yaml.safe_load(path.read_text(encoding='utf-8'))


def _initial_set_surface_map() -> dict[str, dict]:
    doc = _load_yaml(INITIAL_SET_PATH)
    surfaces = {}
    for family in doc.get('families', []):
        for item in family.get('surfaces', []):
            sid = item['surface_id']
            if sid in surfaces:
                raise AssertionError(f'duplicate initial-surface-set entry for {sid}')
            surfaces[sid] = item
    return surfaces


def _ownership_map() -> dict[str, dict]:
    doc = _load_yaml(OWNERSHIP_LEDGER_PATH)
    nodes = {}
    for item in doc.get('surface_nodes', []):
        sid = item['node_id']
        if sid in nodes:
            raise AssertionError(f'duplicate ownership-ledger entry for {sid}')
        nodes[sid] = item
    return nodes


def _optimizer_bundle() -> dict:
    doc = _load_yaml(CONSUMER_BUNDLES_PATH)
    for consumer in doc.get('consumers', []):
        if consumer.get('consumer_id') != 'optimizer_analysis':
            continue
        for bundle in consumer.get('bundles', []):
            if bundle.get('bundle_id') == 'derived_composite_scores':
                return bundle
    raise AssertionError('optimizer_analysis / derived_composite_scores bundle not found')


def test_phase3_qe_route_completion_patch_local_contracts_all_match():
    publication = phase3_publication_contract_snapshot()
    consumption = optimizer_consumption_contract_snapshot()
    bundle = _optimizer_bundle()
    ownership = _ownership_map()
    initial = _initial_set_surface_map()

    required = ['derived::ehp', 'derived::edamage', 'derived::eecon']

    assert publication['required_objective_surfaces'] == required
    assert consumption['required_objective_surfaces'] == required
    assert bundle['required_surface_ids'] == required
    assert consumption['missing_surface_policy'] == 'fail_closed'
    assert consumption['local_canonical_formula_fallback'] is False
    assert 'objective_state::' in publication['forbidden_legacy_prefixes']
    assert 'objective_state::' in consumption['forbidden_legacy_prefixes']

    for sid in required:
        assert sid in ownership, f'{sid} missing from ownership ledger'
        assert ownership[sid]['ownership_status'] == 'query_owned'
        assert ownership[sid]['downstream_policy'] == 'consume_only_no_rederivation'
        assert sid in initial, f'{sid} missing from initial surface set'
        assert initial[sid]['queryable_directly'] is True
        assert initial[sid]['surface_class'] == 'objective_surface'


def test_phase3_qe_route_completion_patch_local_only_derived_objective_surfaces_are_governed_for_optimizer():
    publication = phase3_publication_contract_snapshot()
    consumption = optimizer_consumption_contract_snapshot()
    bundle = _optimizer_bundle()

    all_ids = []
    all_ids.extend(publication['required_objective_surfaces'])
    all_ids.extend(publication['ep_objective_surfaces'])
    all_ids.extend(bundle['required_surface_ids'])
    all_ids.extend(bundle['optional_surface_ids'])
    all_ids.extend(consumption['required_objective_surfaces'])

    assert all(not sid.startswith('objective_state::') for sid in all_ids)

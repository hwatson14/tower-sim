import json
from pathlib import Path
from engine.query_currency_income import resolve_currency_income_surfaces


def test_manual_income_inputs_publish_and_exclude_cash(tmp_path: Path):
    payload = {
        'inputs': [
            {'input_id': 'income.gems.per_week', 'value': 100, 'trust_label': 'externally_observed'},
            {'input_id': 'income.stones.per_week', 'value': 5, 'trust_label': 'externally_observed'},
            {'input_id': 'income.medals.per_week', 'value': 12, 'trust_label': 'externally_observed'},
            {'input_id': 'income.keys.per_week', 'value': 2, 'trust_label': 'externally_observed'},
            {'input_id': 'income.shards.per_week', 'value': 50, 'trust_label': 'externally_observed'},
            {'input_id': 'income.bits.per_week', 'value': 30, 'trust_label': 'externally_observed'},
        ]
    }
    p = tmp_path / 'manual_inputs.json'
    p.write_text(json.dumps(payload), encoding='utf-8')
    results = resolve_currency_income_surfaces({}, manual_input_path=p)
    assert 'derived::economy.income.cash' not in results
    assert results['derived::economy.income.stones'].final_value == 5.0
    assert results['derived::economy.income.stones'].schema['unit'] == 'stones_per_week'
    assert results['derived::economy.income.stones'].schema['externalized'] is True


def test_manual_income_inputs_ignore_unsupported_resource_ids(tmp_path: Path):
    payload = {
        'inputs': [
            {'input_id': 'income.gems.per_week', 'value': 100, 'trust_label': 'externally_observed'},
            {'input_id': 'income.cash.per_week', 'value': 999999, 'trust_label': 'externally_observed'},
        ]
    }
    p = tmp_path / 'manual_inputs.json'
    p.write_text(json.dumps(payload), encoding='utf-8')
    results = resolve_currency_income_surfaces({}, manual_input_path=p)
    assert 'derived::economy.income.gems' in results
    assert 'derived::economy.income.cash' not in results
    assert set(results) == {'derived::economy.income.gems'}

import yaml
from pathlib import Path

from engine.query_surface_publication import publish_phase3_query_surfaces
from tests.test_phase3_ehp_family_surface_fixture import _fixture_rows as ehp_fixture_rows
from tests.test_phase3_edamage_ep_terms import _base_rows as edamage_base_rows

ROOT = Path(__file__).resolve().parents[1]


def _load_contracts():
    data = yaml.safe_load((ROOT / 'kb/global-rules/contracts/derived-composite-contracts.yaml').read_text())
    return {row['surface_id']: row for row in data['derived_composites']}


def test_ehp_lineage_contract_support_surfaces_publish_and_ep_delta_is_helper_only():
    contracts = _load_contracts()
    rows = ehp_fixture_rows()
    publish_phase3_query_surfaces(rows)
    published = set(rows)

    native = set(contracts['derived::ehp']['support_surface_ids'])
    ep = set(contracts['derived::ehp_ep']['support_surface_ids'])
    helper_delta = ep - native

    assert native <= published
    assert ep <= published
    assert not {sid for sid in native if '_ep_helper.' in sid}
    assert helper_delta
    assert all(sid.startswith('derived::ehp_ep_helper.') for sid in helper_delta)
    assert native - ep == set()


def test_edamage_lineage_contract_support_surfaces_publish_and_ep_delta_is_helper_only():
    contracts = _load_contracts()
    rows = edamage_base_rows()
    rows.update({
        'mechanic_param::module.anti_cube_portal.damage_multiplier': rows['canonical_stat::tower_damage'].__class__(
            stat_name='mechanic_param::module.anti_cube_portal.damage_multiplier', final_value=3.0, value_type='scalar', source_count=1, status='resolved', contributors=[], schema={}
        ),
        'canonical_stat::shockwave_size_level': rows['canonical_stat::tower_damage'].__class__(
            stat_name='canonical_stat::shockwave_size_level', final_value=10.0, value_type='scalar', source_count=1, status='resolved', contributors=[], schema={}
        ),
        'runtime_mechanic_param::shockwave.size_lab_level': rows['canonical_stat::tower_damage'].__class__(
            stat_name='runtime_mechanic_param::shockwave.size_lab_level', final_value=10.0, value_type='scalar', source_count=1, status='resolved', contributors=[], schema={}
        ),
        'canonical_stat::shockwave_frequency_level': rows['canonical_stat::tower_damage'].__class__(
            stat_name='canonical_stat::shockwave_frequency_level', final_value=20.0, value_type='scalar', source_count=1, status='resolved', contributors=[], schema={}
        ),
        'mechanic_param::uw.chrono_field.slow_pct': rows['canonical_stat::tower_damage'].__class__(
            stat_name='mechanic_param::uw.chrono_field.slow_pct', final_value=50.0, value_type='scalar', source_count=1, status='resolved', contributors=[], schema={}
        ),
        'mechanic_param::module.space_displacer.multiplier': rows['canonical_stat::tower_damage'].__class__(
            stat_name='mechanic_param::module.space_displacer.multiplier', final_value=2.0, value_type='scalar', source_count=1, status='resolved', contributors=[], schema={}
        ),
        'runtime_mechanic_param::land_mine.spawn_per_second': rows['canonical_stat::tower_damage'].__class__(
            stat_name='runtime_mechanic_param::land_mine.spawn_per_second', final_value=1.0, value_type='scalar', source_count=1, status='resolved', contributors=[], schema={}
        ),
        'runtime_mechanic_param::land_mine.chance': rows['canonical_stat::tower_damage'].__class__(
            stat_name='runtime_mechanic_param::land_mine.chance', final_value=0.5, value_type='scalar', source_count=1, status='resolved', contributors=[], schema={}
        ),
        'mechanic_param::uw.inner_land_mines.active': rows['canonical_stat::tower_damage'].__class__(
            stat_name='mechanic_param::uw.inner_land_mines.active', final_value=1.0, value_type='scalar', source_count=1, status='resolved', contributors=[], schema={}
        ),
        'mechanic_param::uw.inner_land_mines.damage_multiplier': rows['canonical_stat::tower_damage'].__class__(
            stat_name='mechanic_param::uw.inner_land_mines.damage_multiplier', final_value=5.0, value_type='scalar', source_count=1, status='resolved', contributors=[], schema={}
        ),
        'mechanic_param::uw.inner_land_mines.quantity': rows['canonical_stat::tower_damage'].__class__(
            stat_name='mechanic_param::uw.inner_land_mines.quantity', final_value=4.0, value_type='scalar', source_count=1, status='resolved', contributors=[], schema={}
        ),
        'mechanic_param::uw.inner_land_mines.cooldown_seconds': rows['canonical_stat::tower_damage'].__class__(
            stat_name='mechanic_param::uw.inner_land_mines.cooldown_seconds', final_value=20.0, value_type='scalar', source_count=1, status='resolved', contributors=[], schema={}
        ),
    })
    publish_phase3_query_surfaces(rows)
    published = set(rows)

    native = set(contracts['derived::edamage']['support_surface_ids'])
    ep = set(contracts['derived::edamage_ep']['support_surface_ids'])
    helper_delta = ep - native

    assert native <= published
    assert ep <= published
    assert not {sid for sid in native if '_ep_helper.' in sid}
    assert helper_delta
    assert all(sid.startswith('derived::edamage_ep_helper.') for sid in helper_delta)
    assert native - ep == set()

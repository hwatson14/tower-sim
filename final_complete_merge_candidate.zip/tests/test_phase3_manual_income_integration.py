import json
from pathlib import Path

from models.statbook import StatRow
from engine.query_surface_publication import publish_phase3_query_surfaces


def row(name, value, value_type="scalar"):
    return StatRow(stat_name=name, final_value=value, value_type=value_type, source_count=1, status="resolved", contributors=[], schema={})


def _fixture_rows():
    return {
        'support_surface::ehp.health_factor': row('support_surface::ehp.health_factor', 100.0),
        'support_surface::ehp.armor_factor': row('support_surface::ehp.armor_factor', 1.25),
        'support_surface::ehp.wall_health_factor': row('support_surface::ehp.wall_health_factor', 100.0),
        'support_surface::ehp.max_recovery_factor': row('support_surface::ehp.max_recovery_factor', 1.8),
        'support_surface::ehp.wall_active': row('support_surface::ehp.wall_active', True, 'bool'),
        'support_surface::ehp.max_recovery_active': row('support_surface::ehp.max_recovery_active', True, 'bool'),
        'support_surface::ehp.dabs_factor': row('support_surface::ehp.dabs_factor', 10.0),
        'support_surface::ehp.def_pct': row('support_surface::ehp.def_pct', 0.20),
        'mechanic_param::uw.chrono_field.duration_seconds': row('mechanic_param::uw.chrono_field.duration_seconds', 10.0),
        'runtime_mechanic_param::uw.chrono_field.duration_seconds': row('runtime_mechanic_param::uw.chrono_field.duration_seconds', 0.0),
        'mechanic_param::uw.chrono_field.cooldown_seconds': row('mechanic_param::uw.chrono_field.cooldown_seconds', 20.0),
        'mechanic_param::uw.chrono_field.damage_reduction_pct': row('mechanic_param::uw.chrono_field.damage_reduction_pct', 30.0),
        'runtime_mechanic_param::uw.chain_thunder.reduction_pct': row('runtime_mechanic_param::uw.chain_thunder.reduction_pct', 15.0),
        'mechanic_param::perk.tradeoff_defense_factor': row('mechanic_param::perk.tradeoff_defense_factor', 1.1),
        'support_surface::eecon.adstarter_theme_relic_factor': row('support_surface::eecon.adstarter_theme_relic_factor', 1.1),
        'support_surface::eecon.cpk_factor': row('support_surface::eecon.cpk_factor', 100.0),
        'support_surface::eecon.freeup_factor': row('support_surface::eecon.freeup_factor', 1.2),
        'runtime_mechanic_param::cards.coins.multiplier': row('runtime_mechanic_param::cards.coins.multiplier', 1.3),
        'support_surface::eecon.module_factor': row('support_surface::eecon.module_factor', 1.05),
        'support_surface::eecon.eom_factor': row('support_surface::eecon.eom_factor', 1.1),
        'support_surface::timing.combined_multiplier': row('support_surface::timing.combined_multiplier', 1.2),
        'runtime_mechanic_param::uw.spotlight.coin_bonus_multiplier': row('runtime_mechanic_param::uw.spotlight.coin_bonus_multiplier', 1.6),
        'support_surface::eecon.sl_quantity': row('support_surface::eecon.sl_quantity', 2.0),
        'support_surface::eecon.sl_angle': row('support_surface::eecon.sl_angle', 45.0),
        'support_surface::eecon.wave_factor': row('support_surface::eecon.wave_factor', 1.4),
    }


def test_manual_income_inputs_flow_through_phase3_publication(tmp_path: Path):
    payload = {
        'inputs': [
            {'input_id': 'income.gems.per_week', 'value': 111, 'trust_label': 'externally_observed'},
            {'input_id': 'income.stones.per_week', 'value': 7, 'trust_label': 'externally_observed'},
            {'input_id': 'income.cash.per_week', 'value': 999, 'trust_label': 'externally_observed'},
        ]
    }
    p = tmp_path / 'manual_inputs.json'
    p.write_text(json.dumps(payload), encoding='utf-8')

    rows = _fixture_rows()
    publish_phase3_query_surfaces(rows, manual_input_path=p)

    assert rows['derived::economy.income.gems'].final_value == 111.0
    assert rows['derived::economy.income.stones'].final_value == 7.0
    assert 'derived::economy.income.cash' not in rows
    assert 'derived::eecon' in rows
    assert 'derived::eecon_ep' in rows
    assert rows['derived::eecon'].final_value == rows['derived::eecon_ep'].final_value

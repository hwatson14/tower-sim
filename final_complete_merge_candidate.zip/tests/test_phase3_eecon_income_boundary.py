from __future__ import annotations

import json
from pathlib import Path

import yaml

from engine.query_currency_income import (
    currency_income_surface_contract_snapshot,
    deterministic_surface_ids,
    publish_currency_income_surfaces,
    supported_externalized_surface_ids,
    supported_manual_input_ids,
    supported_resource_resolution_modes,
    unsupported_manual_input_ids,
)


def _contract():
    path = Path(__file__).resolve().parents[1] / 'kb' / 'economy' / 'contracts' / 'currency-income-surfaces-contract.yaml'
    return yaml.safe_load(path.read_text(encoding='utf-8'))


def test_contract_snapshot_matches_yaml_resolution_modes_and_boundaries():
    contract = _contract()
    snap = currency_income_surface_contract_snapshot()

    contract_supported = {row['resource_id']: row for row in contract['currencies']}
    assert set(contract_supported) == set(supported_resource_resolution_modes())

    for resource_id, row in contract_supported.items():
        mode = supported_resource_resolution_modes()[resource_id]
        assert row['resolution_mode'] == mode
        if mode == 'query_derived_deterministic':
            assert snap['deterministic'][resource_id]['surface_id'] == row['surface_id']
        elif mode == 'externalized_manual_input':
            assert snap['externalized_manual'][resource_id]['surface_id'] == row['surface_id']
            assert snap['externalized_manual'][resource_id]['manual_input_id'] == row['manual_input_id']
        else:
            raise AssertionError(f'Unexpected mode {mode}')

    assert deterministic_surface_ids() == {'derived::economy.income.coins'}
    assert supported_externalized_surface_ids() == {
        'derived::economy.income.gems',
        'derived::economy.income.stones',
        'derived::economy.income.medals',
        'derived::economy.income.keys',
        'derived::economy.income.shards',
        'derived::economy.income.bits',
    }
    assert unsupported_manual_input_ids() == {
        'income.cash.per_week',
        'income.cells.per_week',
        'income.modules.per_week',
    }


def test_publish_currency_income_surfaces_emits_all_supported_manual_resources_and_no_unsupported(tmp_path):
    payload = {
        'inputs': [
            {'input_id': 'income.gems.per_week', 'value': 10, 'is_set': True},
            {'input_id': 'income.stones.per_week', 'value': 20, 'is_set': True},
            {'input_id': 'income.medals.per_week', 'value': 30, 'is_set': True},
            {'input_id': 'income.keys.per_week', 'value': 40, 'is_set': True},
            {'input_id': 'income.shards.per_week', 'value': 50, 'is_set': True},
            {'input_id': 'income.bits.per_week', 'value': 60, 'is_set': True},
            {'input_id': 'income.cash.per_week', 'value': 70, 'is_set': True},
            {'input_id': 'income.cells.per_week', 'value': 80, 'is_set': True},
            {'input_id': 'income.modules.per_week', 'value': 90, 'is_set': True},
        ]
    }
    manual = tmp_path / 'manual.json'
    manual.write_text(json.dumps(payload), encoding='utf-8')

    rows = {}
    publish_currency_income_surfaces(rows, manual_input_path=manual)

    assert set(rows) == supported_externalized_surface_ids()
    assert 'derived::economy.income.cash' not in rows
    assert 'derived::economy.income.cells' not in rows
    assert 'derived::economy.income.modules' not in rows

    by_surface = {k: v.final_value for k, v in rows.items()}
    assert by_surface['derived::economy.income.gems'] == 10
    assert by_surface['derived::economy.income.stones'] == 20
    assert by_surface['derived::economy.income.medals'] == 30
    assert by_surface['derived::economy.income.keys'] == 40
    assert by_surface['derived::economy.income.shards'] == 50
    assert by_surface['derived::economy.income.bits'] == 60

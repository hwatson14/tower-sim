import pytest

from optimizer.scorer import (
    MissingGovernedSurfaceError,
    compute_ehp,
    compute_edamage,
    compute_eecon,
)


def test_optimizer_objectives_fail_closed_without_governed_surfaces():
    rows = {}
    with pytest.raises(MissingGovernedSurfaceError):
        compute_ehp(rows)
    with pytest.raises(MissingGovernedSurfaceError):
        compute_edamage(rows)
    with pytest.raises(MissingGovernedSurfaceError):
        compute_eecon(rows)

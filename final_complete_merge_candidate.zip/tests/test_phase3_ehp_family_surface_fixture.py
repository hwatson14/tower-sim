from math import isclose

from models.statbook import StatRow

from engine.query_surface_publication import publish_phase3_query_surfaces


def row(name, value, value_type="scalar"):
    return StatRow(stat_name=name, final_value=value, value_type=value_type, source_count=1, status="resolved", contributors=[], schema={})


def _fixture_rows():
    return {
        'support_surface::ehp.health_ws': row('support_surface::ehp.health_ws', 100.0),
        'support_surface::ehp.health_lab_level': row('support_surface::ehp.health_lab_level', 2.0),
        'support_surface::ehp.health_card_active': row('support_surface::ehp.health_card_active', True, 'bool'),
        'support_surface::ehp.health_card_multiplier': row('support_surface::ehp.health_card_multiplier', 1.5),
        'support_surface::ehp.health_card_mastery_active': row('support_surface::ehp.health_card_mastery_active', True, 'bool'),
        'support_surface::ehp.health_card_mastery_level': row('support_surface::ehp.health_card_mastery_level', 1.0),
        'support_surface::ehp.workshop_enhancement_level': row('support_surface::ehp.workshop_enhancement_level', 10.0),
        'support_surface::ehp.health_perk_active': row('support_surface::ehp.health_perk_active', True, 'bool'),
        'support_surface::ehp.standard_perks_bonus_level': row('support_surface::ehp.standard_perks_bonus_level', 5.0),
        'support_surface::ehp.cto_active': row('support_surface::ehp.cto_active', False, 'bool'),
        'support_surface::ehp.rto_active': row('support_surface::ehp.rto_active', False, 'bool'),
        'support_surface::ehp.health_relic_pct': row('support_surface::ehp.health_relic_pct', 0.10),
        'support_surface::ehp.health_vault_pct': row('support_surface::ehp.health_vault_pct', 0.20),
        'support_surface::ehp.death_wave_hp_active': row('support_surface::ehp.death_wave_hp_active', True, 'bool'),
        'support_surface::ehp.death_wave_hp_level': row('support_surface::ehp.death_wave_hp_level', 4.0),

        'support_surface::ehp.armor_primary_bonus': row('support_surface::ehp.armor_primary_bonus', 1.3),
        'support_surface::ehp.armor_assist_enabled': row('support_surface::ehp.armor_assist_enabled', True, 'bool'),
        'support_surface::ehp.armor_assist_bonus': row('support_surface::ehp.armor_assist_bonus', 1.2),
        'support_surface::ehp.armor_assist_stone_bonus_pct': row('support_surface::ehp.armor_assist_stone_bonus_pct', 10.0),
        'support_surface::ehp.armor_assist_lab_bonus_pct': row('support_surface::ehp.armor_assist_lab_bonus_pct', 20.0),

        'support_surface::ehp.wall_hp_ws': row('support_surface::ehp.wall_hp_ws', 50.0),
        'support_surface::ehp.wall_hp_lab_level': row('support_surface::ehp.wall_hp_lab_level', 5.0),
        'support_surface::ehp.stone_sac_pct': row('support_surface::ehp.stone_sac_pct', 10.0),
        'support_surface::ehp.lab_sac_pct': row('support_surface::ehp.lab_sac_pct', 20.0),
        'support_surface::ehp.wall_hp_prim_sub': row('support_surface::ehp.wall_hp_prim_sub', 0.2),
        'support_surface::ehp.wall_hp_ass_sub': row('support_surface::ehp.wall_hp_ass_sub', 0.1),
        'support_surface::ehp.wall_module_primary_effect': row('support_surface::ehp.wall_module_primary_effect', 1.5),
        'support_surface::ehp.wall_module_assist_effect': row('support_surface::ehp.wall_module_assist_effect', 0.2),
        'support_surface::ehp.wall_fortification_level': row('support_surface::ehp.wall_fortification_level', 2.0),

        'support_surface::ehp.max_recovery_ws': row('support_surface::ehp.max_recovery_ws', 1.2),
        'support_surface::ehp.max_recovery_lab_level': row('support_surface::ehp.max_recovery_lab_level', 4.0),
        'support_surface::ehp.max_recovery_prim_sub': row('support_surface::ehp.max_recovery_prim_sub', 0.1),
        'support_surface::ehp.max_recovery_ass_sub': row('support_surface::ehp.max_recovery_ass_sub', 0.05),
        'support_surface::ehp.max_recovery_vault_pct': row('support_surface::ehp.max_recovery_vault_pct', 0.10),
        'support_surface::ehp.wall_active': row('support_surface::ehp.wall_active', True, 'bool'),
        'support_surface::ehp.max_recovery_active': row('support_surface::ehp.max_recovery_active', True, 'bool'),

        'support_surface::ehp.dabs_ws': row('support_surface::ehp.dabs_ws', 10.0),
        'support_surface::ehp.dabs_lab_level': row('support_surface::ehp.dabs_lab_level', 2.0),
        'support_surface::ehp.dabs_card_active': row('support_surface::ehp.dabs_card_active', True, 'bool'),
        'support_surface::ehp.dabs_card_multiplier': row('support_surface::ehp.dabs_card_multiplier', 1.5),
        'support_surface::ehp.dabs_prim_sub': row('support_surface::ehp.dabs_prim_sub', 0.2),
        'support_surface::ehp.dabs_ass_sub': row('support_surface::ehp.dabs_ass_sub', 0.1),
        'support_surface::ehp.dabs_perk_active': row('support_surface::ehp.dabs_perk_active', True, 'bool'),
        'support_surface::ehp.dabs_relic_pct': row('support_surface::ehp.dabs_relic_pct', 0.10),
        'support_surface::ehp.dabs_vault_pct': row('support_surface::ehp.dabs_vault_pct', 0.05),

        'support_surface::ehp.def_pct_ws': row('support_surface::ehp.def_pct_ws', 0.20),
        'support_surface::ehp.def_pct_lab_level': row('support_surface::ehp.def_pct_lab_level', 3.0),
        'support_surface::ehp.def_pct_card_active': row('support_surface::ehp.def_pct_card_active', True, 'bool'),
        'support_surface::ehp.def_pct_card_bonus': row('support_surface::ehp.def_pct_card_bonus', 0.10),
        'support_surface::ehp.def_pct_card_mastery_active': row('support_surface::ehp.def_pct_card_mastery_active', True, 'bool'),
        'support_surface::ehp.def_pct_card_mastery_level': row('support_surface::ehp.def_pct_card_mastery_level', 2.0),
        'support_surface::ehp.def_pct_prim_sub': row('support_surface::ehp.def_pct_prim_sub', 0.02),
        'support_surface::ehp.def_pct_ass_sub': row('support_surface::ehp.def_pct_ass_sub', 0.01),
        'support_surface::ehp.def_pct_perk_active': row('support_surface::ehp.def_pct_perk_active', True, 'bool'),
        'support_surface::ehp.def_pct_relic_pct': row('support_surface::ehp.def_pct_relic_pct', 0.01),
        'support_surface::ehp.def_pct_vault_pct': row('support_surface::ehp.def_pct_vault_pct', 0.02),

        'mechanic_param::uw.chrono_field.duration_seconds': row('mechanic_param::uw.chrono_field.duration_seconds', 10.0),
        'runtime_mechanic_param::uw.chrono_field.duration_seconds': row('runtime_mechanic_param::uw.chrono_field.duration_seconds', 0.0),
        'mechanic_param::uw.chrono_field.cooldown_seconds': row('mechanic_param::uw.chrono_field.cooldown_seconds', 20.0),
        'mechanic_param::uw.chrono_field.damage_reduction_pct': row('mechanic_param::uw.chrono_field.damage_reduction_pct', 30.0),
        'support_surface::ehp.wall_invuln_reduction_pct': row('support_surface::ehp.wall_invuln_reduction_pct', 0.25),
        'runtime_mechanic_param::uw.chain_thunder.reduction_pct': row('runtime_mechanic_param::uw.chain_thunder.reduction_pct', 15.0),
        'mechanic_param::perk.tradeoff_defense_factor': row('mechanic_param::perk.tradeoff_defense_factor', 1.1),
    }


def test_ehp_family_surfaces_publish_with_expected_values():
    rows = _fixture_rows()
    publish_phase3_query_surfaces(rows)

    expected = {
        'derived::ehp.health_lab_factor': 1.06,
        'derived::ehp.health_card_factor': 2.1,
        'derived::ehp.health_wse_factor': 1.1,
        'derived::ehp.health_perk_factor': 2.1,
        'derived::ehp.health_relic_factor': 1.1,
        'derived::ehp.health_vault_factor': 1.2,
        'derived::ehp.health_dwhp_factor': 6.0,
        'derived::ehp.health_factor': 4072.51152,
        'derived::ehp.armor_primary_factor': 1.3,
        'derived::ehp.armor_assist_factor': 1.062,
        'derived::ehp.armor_factor': 1.3806,
        'derived::ehp.wall_health_lab_term': 0.1,
        'derived::ehp.wall_health_substat_term': 0.231,
        'derived::ehp.wall_health_wse_factor': 1.1,
        'derived::ehp.wall_health_module_factor': 1.7,
        'derived::ehp.wall_health_fort_factor': 1.4,
        'derived::ehp.wall_factor': 131.766558,
        'derived::ehp.max_recovery_lab_term': 0.04,
        'derived::ehp.max_recovery_substat_term': 0.1155,
        'derived::ehp.max_recovery_wse_factor': 1.1,
        'derived::ehp.max_recovery_vault_factor': 1.1,
        'derived::ehp.recovery_package_factor': 1.640155,
        'derived::ehp.wall_or_recovery_factor': 133.406713,
        'derived::ehp.base_pool': 750080.4984675333,
        'derived::ehp.dabs_lab_factor': 1.06,
        'derived::ehp.dabs_card_factor': 1.5,
        'derived::ehp.dabs_substat_factor': 1.2309999999999999,
        'derived::ehp.dabs_wse_factor': 1.1,
        'derived::ehp.dabs_perk_factor': 1.8375000000000001,
        'derived::ehp.dabs_relic_factor': 1.1,
        'derived::ehp.dabs_vault_factor': 1.05,
        'derived::ehp.dabs_base_factor': 45.69379136437501,
        'derived::ehp.wall_invuln_factor': 1.3333333333333333,
        'derived::ehp.dabs_effective_factor': 60.92505515250001,
        'derived::ehp.def_pct_raw': 0.5901000000000001,
        'derived::ehp.def_pct_lab_term': 0.006,
        'derived::ehp.def_pct_card_term': 0.12100000000000001,
        'derived::ehp.def_pct_substat_term': 0.0231,
        'derived::ehp.def_pct_perk_term': 0.21000000000000002,
        'derived::ehp.def_pct_relic_term': 0.01,
        'derived::ehp.def_pct_vault_term': 0.02,
        'derived::ehp.defense_taken_factor': 2.4396194193705787,
        'derived::ehp.chrono_field_uptime': 0.3333333333333333,
        'derived::ehp.chrono_field_damage_reduction_factor': 1.1111111111111112,
        'derived::ehp.chain_thunder_factor': 1.1764705882352942,
        'derived::ehp.tradeoff_defense_factor': 1.1,
        'derived::ehp.pre_defense_pool': 980497.3836176905,
        'derived::ehp.pre_tradeoff_ehp': 2392189.091663438,
        'derived::ehp_ep_helper.ce_pool_factor': 4072.51152,
        'derived::ehp_ep_helper.cf_armor_factor': 1.3806,
        'derived::ehp_ep_helper.ci_wall_factor': 131.766558,
        'derived::ehp_ep_helper.cj_recovery_factor': 1.640155,
        'derived::ehp_ep_helper.cg_dabs_factor': 60.92505515250001,
        'derived::ehp_ep_helper.ch_defense_taken_factor': 2.4396194193705787,
        'derived::ehp_ep_helper.ck_tradeoff_factor': 1.1,
        'derived::ehp_ep_helper.cl_cfdr_factor': 1.1111111111111112,
        'derived::ehp_ep_helper.cm_chain_thunder_factor': 1.1764705882352942,
        'derived::ehp': 2631408.000829782,
        'derived::ehp_ep': 2631408.000829782,
    }

    for key, target in expected.items():
        assert key in rows, f'missing published surface: {key}'
        actual = float(rows[key].final_value)
        assert isclose(actual, target, rel_tol=1e-9, abs_tol=1e-9), f'{key}: expected {target}, got {actual}'

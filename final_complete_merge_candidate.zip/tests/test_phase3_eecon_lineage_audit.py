from __future__ import annotations

import json
from pathlib import Path

import yaml

from engine.query_surface_publication import publish_phase3_query_surfaces
from engine.query_currency_income import (
    manual_income_input_contract_snapshot,
    supported_externalized_surface_ids,
)
from models.statbook import StatRow


def row(name, value, value_type='scalar'):
    return StatRow(
        stat_name=name,
        final_value=value,
        value_type=value_type,
        source_count=1,
        status='resolved',
        contributors=[],
        schema={},
    )


def _fixture_rows() -> dict[str, StatRow]:
    return {
        'canonical_stat::coin_kill_multiplier': row('canonical_stat::coin_kill_multiplier', 2.0, 'multiplier'),
        'support_surface::eecon.sl_coin_bonus_lab_level': row('support_surface::eecon.sl_coin_bonus_lab_level', 10.0),
        'support_surface::eecon.sl_quantity': row('support_surface::eecon.sl_quantity', 1.0),
        'support_surface::eecon.sl_angle': row('support_surface::eecon.sl_angle', 40.0),
        'runtime_mechanic_param::uw.spotlight.coin_bonus_multiplier': row('runtime_mechanic_param::uw.spotlight.coin_bonus_multiplier', 1.5, 'multiplier'),
        'support_surface::timing.combined_multiplier': row('support_surface::timing.combined_multiplier', 1.2, 'multiplier'),
        'derived::eecon.base_coin_income': row('derived::eecon.base_coin_income', 1234.0, 'per_week'),
    }


def _contract_rows(surface_id: str):
    path = Path(__file__).resolve().parents[1] / 'kb' / 'global-rules' / 'contracts' / 'derived-composite-contracts.yaml'
    rows = yaml.safe_load(path.read_text(encoding='utf-8'))
    for row_ in rows:
        if row_['surface_id'] == surface_id:
            return row_['support_surfaces']
    raise AssertionError(f'missing contract row for {surface_id}')


def test_eecon_contract_support_surfaces_publish_and_ep_delta_is_helper_only(tmp_path: Path):
    payload = {
        'inputs': [
            {'input_id': 'income.gems.per_week', 'value': 10, 'is_set': True},
            {'input_id': 'income.stones.per_week', 'value': 20, 'is_set': True},
        ]
    }
    manual = tmp_path / 'manual_advisory_inputs.json'
    manual.write_text(json.dumps(payload), encoding='utf-8')

    rows = _fixture_rows()
    publish_phase3_query_surfaces(rows, manual_input_path=manual)

    native_support = set(_contract_rows('derived::eecon'))
    ep_support = set(_contract_rows('derived::eecon_ep'))

    assert native_support <= set(rows)
    assert ep_support <= set(rows)

    native_only_helper = {s for s in native_support if '_ep_helper.' in s}
    assert native_only_helper == set()

    ep_delta = ep_support - native_support
    assert ep_delta
    assert all(s.startswith('derived::eecon_ep_helper.') for s in ep_delta)

    assert 'derived::eecon' in rows
    assert 'derived::eecon_ep' in rows
    assert rows['derived::eecon'].final_value == rows['derived::eecon_ep'].final_value

    published_income = set(rows) & ({'derived::economy.income.coins'} | supported_externalized_surface_ids())
    assert 'derived::economy.income.coins' in published_income
    assert 'derived::economy.income.gems' in published_income
    assert 'derived::economy.income.stones' in published_income


def test_manual_income_snapshot_points_to_user_editable_input_lane():
    snap = manual_income_input_contract_snapshot()
    assert snap['default_manual_input_path'].endswith('input/manual_advisory_inputs.json')
    assert snap['supported_manual_input_ids'] == sorted([
        'income.bits.per_week',
        'income.gems.per_week',
        'income.keys.per_week',
        'income.medals.per_week',
        'income.shards.per_week',
        'income.stones.per_week',
    ])
    assert snap['unsupported_manual_input_ids'] == sorted([
        'income.cash.per_week',
        'income.cells.per_week',
        'income.modules.per_week',
    ])

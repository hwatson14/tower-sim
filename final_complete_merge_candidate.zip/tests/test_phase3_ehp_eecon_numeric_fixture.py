from math import isclose

from models.statbook import StatRow

from engine.query_surface_publication import publish_phase3_query_surfaces


def row(name, value, value_type="scalar"):
    return StatRow(stat_name=name, final_value=value, value_type=value_type, source_count=1, status="resolved", contributors=[], schema={})


def _fixture_rows():
    return {
        # eHP direct support surfaces
        'support_surface::ehp.health_factor': row('support_surface::ehp.health_factor', 100.0),
        'support_surface::ehp.armor_factor': row('support_surface::ehp.armor_factor', 1.25),
        'support_surface::ehp.wall_health_factor': row('support_surface::ehp.wall_health_factor', 100.0),
        'support_surface::ehp.max_recovery_factor': row('support_surface::ehp.max_recovery_factor', 1.8),
        'support_surface::ehp.wall_active': row('support_surface::ehp.wall_active', True, 'bool'),
        'support_surface::ehp.max_recovery_active': row('support_surface::ehp.max_recovery_active', True, 'bool'),
        'support_surface::ehp.dabs_factor': row('support_surface::ehp.dabs_factor', 10.0),
        'support_surface::ehp.def_pct': row('support_surface::ehp.def_pct', 0.20),
        'mechanic_param::uw.chrono_field.duration_seconds': row('mechanic_param::uw.chrono_field.duration_seconds', 10.0),
        'runtime_mechanic_param::uw.chrono_field.duration_seconds': row('runtime_mechanic_param::uw.chrono_field.duration_seconds', 0.0),
        'mechanic_param::uw.chrono_field.cooldown_seconds': row('mechanic_param::uw.chrono_field.cooldown_seconds', 20.0),
        'mechanic_param::uw.chrono_field.damage_reduction_pct': row('mechanic_param::uw.chrono_field.damage_reduction_pct', 30.0),
        'runtime_mechanic_param::uw.chain_thunder.reduction_pct': row('runtime_mechanic_param::uw.chain_thunder.reduction_pct', 15.0),
        'mechanic_param::perk.tradeoff_defense_factor': row('mechanic_param::perk.tradeoff_defense_factor', 1.1),

        # eEcon direct support surfaces
        'support_surface::eecon.adstarter_theme_relic_factor': row('support_surface::eecon.adstarter_theme_relic_factor', 1.1),
        'support_surface::eecon.cpk_factor': row('support_surface::eecon.cpk_factor', 100.0),
        'support_surface::eecon.freeup_factor': row('support_surface::eecon.freeup_factor', 1.2),
        'runtime_mechanic_param::cards.coins.multiplier': row('runtime_mechanic_param::cards.coins.multiplier', 1.3),
        'support_surface::eecon.module_factor': row('support_surface::eecon.module_factor', 1.05),
        'support_surface::eecon.eom_factor': row('support_surface::eecon.eom_factor', 1.1),
        'support_surface::timing.combined_multiplier': row('support_surface::timing.combined_multiplier', 1.2),
        'runtime_mechanic_param::uw.spotlight.coin_bonus_multiplier': row('runtime_mechanic_param::uw.spotlight.coin_bonus_multiplier', 1.6),
        'support_surface::eecon.sl_quantity': row('support_surface::eecon.sl_quantity', 2.0),
        'support_surface::eecon.sl_angle': row('support_surface::eecon.sl_angle', 45.0),
        'support_surface::eecon.wave_factor': row('support_surface::eecon.wave_factor', 1.4),
    }


def test_ehp_eecon_numeric_fixture_matches_expected_intermediates_and_totals():
    rows = _fixture_rows()
    publish_phase3_query_surfaces(rows)

    expected = {
        'derived::ehp.health_factor': 100.0,
        'derived::ehp.armor_factor': 1.25,
        'derived::ehp.wall_factor': 100.0,
        'derived::ehp.recovery_package_factor': 1.8,
        'derived::ehp.wall_pkg_factor': 101.8,
        'derived::ehp.base_pool': 12725.0,
        'derived::ehp.dabs_factor': 10.0,
        'derived::ehp.defense_taken_factor': 1.25,
        'derived::ehp.chrono_field_damage_reduction_factor': 1.1111111111111112,
        'derived::ehp.chain_thunder_factor': 1.1764705882352942,
        'derived::ehp.tradeoff_defense_factor': 1.1,
        'derived::ehp': 22885.482026143797,

        'derived::eecon.base_meta_factor': 1.1,
        'derived::eecon.cpk_factor': 100.0,
        'derived::eecon.freeup_factor': 1.2,
        'derived::eecon.coin_card_factor': 1.3,
        'derived::eecon.module_factor': 1.05,
        'derived::eecon.cl_factor': 180.18,
        'derived::eecon.eom_factor': 1.1,
        'derived::eecon.sync_factor': 1.2,
        'derived::eecon.spotlight_coin_bonus_term': 1.0,
        'derived::eecon.spotlight_coin_coverage': 0.25,
        'derived::eecon.spotlight_coin_factor': 1.15,
        'derived::eecon.wave_factor': 1.4,
        'derived::eecon_ep_helper.dg_spotlight_coin_bonus_term': 1.0,
        'derived::eecon_ep_helper.dg_spotlight_coin_coverage': 0.25,
        'derived::eecon_ep_helper.dg_spotlight_coin_factor': 1.15,
        'derived::eecon': 382.91853599999996,
        'derived::eecon_ep': 382.91853599999996,
    }

    for key, target in expected.items():
        assert key in rows, f'missing published surface: {key}'
        actual = float(rows[key].final_value)
        assert isclose(actual, target, rel_tol=1e-9, abs_tol=1e-9), f'{key}: expected {target}, got {actual}'

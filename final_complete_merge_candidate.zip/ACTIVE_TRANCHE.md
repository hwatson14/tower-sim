# ACTIVE_TRANCHE

## Tranche ID
`PH3-TRANCHE-CLOSURE_FINAL_APPLY_BUNDLE`

## Phase
`Phase 3 - Objective-state promotion (implemented as derived::* twin lines)`

## Objective
Land the final Phase 3 apply bundle for the derived::* twin-line objective model, preserving the manual persistent-income lane, with G1-G10 implemented and governed in-repo while leaving G11 and G12 explicitly open for repo-context proof.

## Scope in
- derived::* native and *_ep objective publication for eHP, eDamage, and eEcon
- EP helper namespace routing under *_ep_helper.*
- generic reusable composite family preservation
- optimizer consumption of governed derived::* objective surfaces with fail-closed behavior
- governed eEcon income boundary for deterministic, externalized-manual, and unsupported persistent-income resources
- updated contracts, ownership ledgers, consumer bundles, and control files
- repo-realistic tests for lineage, route integrity, exclusion boundaries, optimizer consumption, and manual-input governance

## Scope out
- edits to `engine/stat_engine.py`
- edits to the wrapper / compatibility path
- full in-repo runtime validation
- full workbook parity closure and audited native-equals-EP parity outputs
- simulator or evaluator work

## Required outputs
- final apply-bundle runtime and contract changes
- updated control files reflecting implemented vs open work honestly
- repo-realistic test coverage for G1-G10

## Required verification
- governed derived::* objective route is aligned across implementation, contracts, and consumer bundles
- optimizer has no local canonical fallback for eHP, eDamage, or eEcon
- manual persistent-income input lane remains preserved at `input/manual_advisory_inputs.json`
- unsupported income resources remain fail-closed and excluded from governed publication
- no file in this tranche modifies `engine/stat_engine.py`

## Acceptance criteria
- G1-G10 are implemented and verified in this apply bundle
- control truth matches the derived::* twin-line model and no longer uses `objective_state::*` as the target surface family
- repo-realistic tests reference repo paths rather than bundle-local `repo_patch/...` paths
- remaining open work is limited to G11 and G12 and is stated plainly

## Stop conditions
Stop once the apply bundle is self-consistent, repo-path-correct, and the remaining open work is stated only as G11 and G12.

## Current status
- G1-G10 are implemented in this apply bundle.
- Remaining open work is limited to G11 full in-repo runtime validation and G12 workbook parity / native-equals-EP proof.

from __future__ import annotations

import copy
import importlib.util
import sys
from pathlib import Path

import yaml

MODULE_PATH = (
    Path(__file__).resolve().parents[1] / "validators" / "validate_stage_applicability.py"
)
spec = importlib.util.spec_from_file_location("validate_stage_applicability", MODULE_PATH)
validator = importlib.util.module_from_spec(spec)
assert spec is not None and spec.loader is not None
sys.modules[spec.name] = validator
spec.loader.exec_module(validator)

CONTRACT_PATH = (
    Path(__file__).resolve().parents[2]
    / "kb"
    / "global-rules"
    / "contracts"
    / "stage-applicability.yaml"
)


def load_contract_doc() -> dict:
    with CONTRACT_PATH.open("r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def make_valid_repo_index() -> dict:
    return {
        "canonical_source_families": [
            "lab",
            "uw_upgrade",
            "relic",
            "theme_song",
            "vault",
            "workshop",
            "enhancements",
            "bot_upgrade",
            "guardian_upgrade",
            "card",
            "module",
            "battle_condition",
            "perk",
            "player_stuff",
        ],
        "declared_pipeline_systems": [
            "labs",
            "ultimate_weapons",
            "uw_plus",
            "relics",
            "themes",
            "songs",
            "vault",
            "workshop",
            "workshop_enhancements",
            "bots",
            "guardians",
            "card_inventory",
            "card_loadout",
            "card_presets",
            "module_inventory",
            "module_loadout",
            "module_presets",
            "battle_conditions",
            "perks",
            "cash_workshop_purchases",
            "free_upgrades",
            "enemy_level_skip_sources",
            "eals_realized_effect",
            "ehls_realized_effect",
            "enemy_progression_reference",
            "wave_progression",
            "cooldowns_and_activations",
            "combat_state",
            "boss_state",
            "heat",
            "tournament_metadata",
            "player_resources",
        ],
        "baseline_account_consumers": [
            "labs",
            "ultimate_weapons",
            "uw_plus",
            "relics",
            "themes",
            "songs",
            "vault",
            "card_inventory",
            "module_inventory",
            "tournament_metadata",
            "player_resources",
        ],
        "baseline_gem_respec_consumers": [
            "workshop",
            "workshop_enhancements",
            "bots",
            "guardians",
            "enemy_level_skip_sources",
        ],
        "baseline_loadout_consumers": [
            "card_loadout",
            "card_presets",
            "module_loadout",
            "module_presets",
        ],
        "inventory_to_loadout_edges": [
            ["card_inventory", "card_loadout"],
            ["module_inventory", "module_loadout"],
        ],
        "immutable_runtime_systems": [],
    }


def rule_ids(issues) -> set[str]:
    return {issue.rule_id for issue in issues}


def test_stage_contract_passes_with_valid_repo_index():
    issues = validator.validate_contract(load_contract_doc(), make_valid_repo_index())
    assert issues == []


def test_missing_top_level_key_fails():
    doc = load_contract_doc()
    del doc["systems"]
    issues = validator.validate_contract(doc, make_valid_repo_index())
    assert "S1" in rule_ids(issues)


def test_invalid_stage_order_fails():
    doc = load_contract_doc()
    doc["stage_order"] = ["baseline_account", "runtime_overlay"]
    issues = validator.validate_contract(doc, make_valid_repo_index())
    assert "S3" in rule_ids(issues)


def test_duplicate_system_fails():
    doc = load_contract_doc()
    doc["systems"].append(copy.deepcopy(doc["systems"][0]))
    issues = validator.validate_contract(doc, make_valid_repo_index())
    assert "M1" in rule_ids(issues)


def test_runtime_overlay_requires_runtime_flag():
    doc = load_contract_doc()
    target = next(x for x in doc["systems"] if x["system"] == "battle_conditions")
    target["runtime_overlay_needed"] = False
    issues = validator.validate_contract(doc, make_valid_repo_index())
    assert "M4" in rule_ids(issues)


def test_loadout_system_must_start_at_baseline_loadout():
    doc = load_contract_doc()
    target = next(x for x in doc["systems"] if x["system"] == "card_loadout")
    target["first_stage_present"] = "baseline_account"
    issues = validator.validate_contract(doc, make_valid_repo_index())
    assert "M5" in rule_ids(issues)


def test_inventory_system_must_start_at_baseline_account():
    doc = load_contract_doc()
    target = next(x for x in doc["systems"] if x["system"] == "module_inventory")
    target["first_stage_present"] = "baseline_loadout"
    issues = validator.validate_contract(doc, make_valid_repo_index())
    assert "M6" in rule_ids(issues)


def test_runtime_mutating_system_must_change_in_run():
    doc = load_contract_doc()
    target = next(x for x in doc["systems"] if x["system"] == "heat")
    target["can_change_in_run"] = False
    issues = validator.validate_contract(doc, make_valid_repo_index())
    assert "M7" in rule_ids(issues)


def test_persistent_account_family_wrong_stage_fails():
    doc = load_contract_doc()
    target = next(x for x in doc["systems"] if x["system"] == "relics")
    target["first_stage_present"] = "baseline_gem_respec"
    issues = validator.validate_contract(doc, make_valid_repo_index())
    assert "M8" in rule_ids(issues)


def test_runtime_overlay_special_family_wrong_stage_fails():
    doc = load_contract_doc()
    target = next(x for x in doc["systems"] if x["system"] == "combat_state")
    target["first_stage_present"] = "baseline_loadout"
    issues = validator.validate_contract(doc, make_valid_repo_index())
    assert "M9" in rule_ids(issues)


def test_multi_source_system_cannot_start_at_loadout():
    doc = load_contract_doc()
    target = next(x for x in doc["systems"] if x["system"] == "enemy_level_skip_sources")
    target["first_stage_present"] = "baseline_loadout"
    issues = validator.validate_contract(doc, make_valid_repo_index())
    assert "M10" in rule_ids(issues)


def test_dual_nature_split_requires_persistent_source():
    doc = load_contract_doc()
    doc["systems"] = [x for x in doc["systems"] if x["system"] != "enemy_level_skip_sources"]
    issues = validator.validate_contract(doc, make_valid_repo_index())
    assert "M13" in rule_ids(issues)


def test_blank_notes_fail():
    doc = load_contract_doc()
    target = next(x for x in doc["systems"] if x["system"] == "vault")
    target["notes"] = "  "
    issues = validator.validate_contract(doc, make_valid_repo_index())
    assert "M12" in rule_ids(issues)


def test_unknown_source_family_fails_integration():
    doc = load_contract_doc()
    target = next(x for x in doc["systems"] if x["system"] == "bots")
    target["source_state_family"] = "mystery_family"
    issues = validator.validate_contract(doc, make_valid_repo_index())
    assert "I1" in rule_ids(issues)


def test_reserved_special_family_is_allowed_integration():
    issues = validator.validate_contract(load_contract_doc(), make_valid_repo_index())
    assert "I1" not in rule_ids(issues)


def test_runtime_only_system_referenced_by_static_stage_fails():
    repo_index = make_valid_repo_index()
    repo_index["baseline_account_consumers"].append("battle_conditions")
    issues = validator.validate_contract(load_contract_doc(), repo_index)
    assert "I2" in rule_ids(issues)


def test_inventory_without_loadout_edge_fails():
    repo_index = make_valid_repo_index()
    repo_index["inventory_to_loadout_edges"] = [["module_inventory", "module_loadout"]]
    issues = validator.validate_contract(load_contract_doc(), repo_index)
    assert "I3" in rule_ids(issues)


def test_loadout_system_not_consumed_fails():
    repo_index = make_valid_repo_index()
    repo_index["baseline_loadout_consumers"] = ["card_loadout", "card_presets"]
    issues = validator.validate_contract(load_contract_doc(), repo_index)
    assert "I4" in rule_ids(issues)


def test_mutable_system_marked_immutable_in_runtime_fails():
    repo_index = make_valid_repo_index()
    repo_index["immutable_runtime_systems"] = ["battle_conditions"]
    issues = validator.validate_contract(load_contract_doc(), repo_index)
    assert "I5" in rule_ids(issues)


def test_missing_declared_pipeline_system_fails():
    repo_index = make_valid_repo_index()
    repo_index["declared_pipeline_systems"].append("guardian_runtime")
    issues = validator.validate_contract(load_contract_doc(), repo_index)
    assert "I6" in rule_ids(issues)

from __future__ import annotations

import argparse
import json
import re
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Iterable

import yaml

ALLOWED_STAGE_ORDER = [
    "baseline_account",
    "baseline_gem_respec",
    "baseline_loadout",
    "runtime_overlay",
]
ALLOWED_FIRST_STAGE = set(ALLOWED_STAGE_ORDER)
CANONICAL_NAME_RE = re.compile(r"^[a-z][a-z0-9_]*$")
RUNTIME_MUTATING_SYSTEMS = {
    "battle_conditions",
    "perks",
    "cash_workshop_purchases",
    "free_upgrades",
    "eals_realized_effect",
    "ehls_realized_effect",
    "wave_progression",
    "cooldowns_and_activations",
    "combat_state",
    "boss_state",
    "heat",
}
PERSISTENT_ACCOUNT_FAMILIES = {
    "lab",
    "uw_upgrade",
    "relic",
    "theme_song",
    "vault",
    "player_stuff",
}
DUAL_NATURE_GROUPS = [
    {
        "persistent_sources": {"enemy_level_skip_sources"},
        "realized_effects": {"eals_realized_effect", "ehls_realized_effect"},
    }
]
REQUIRED_TOP_LEVEL_KEYS = [
    "version",
    "kind",
    "status",
    "purpose",
    "description",
    "stage_order",
    "field_definitions",
    "enforcement_rules",
    "systems",
]
REQUIRED_SYSTEM_FIELDS = [
    "system",
    "source_state_family",
    "first_stage_present",
    "can_change_in_run",
    "runtime_overlay_needed",
    "notes",
]
EXPECTED_SYSTEM_FIELD_TYPES = {
    "system": str,
    "source_state_family": str,
    "first_stage_present": str,
    "can_change_in_run": bool,
    "runtime_overlay_needed": bool,
    "notes": str,
}


@dataclass(frozen=True)
class ValidationIssue:
    code: str
    rule_id: str
    message: str
    severity: str = "error"
    system: str | None = None
    field: str | None = None

    def to_cli_line(self) -> str:
        prefix = f"[{self.code}][{self.rule_id}]"
        if self.system:
            return f"{prefix} system '{self.system}': {self.message}"
        return f"{prefix} {self.message}"


def add_issue(
    issues: list[ValidationIssue],
    *,
    code: str,
    rule_id: str,
    message: str,
    severity: str = "error",
    system: str | None = None,
    field: str | None = None,
) -> None:
    issues.append(
        ValidationIssue(
            code=code,
            rule_id=rule_id,
            message=message,
            severity=severity,
            system=system,
            field=field,
        )
    )


def load_yaml(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def load_repo_index(path: Path | None) -> dict[str, Any]:
    if path is None:
        return {}
    if path.suffix.lower() in {".yaml", ".yml"}:
        with path.open("r", encoding="utf-8") as f:
            return yaml.safe_load(f) or {}
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def dump_issues_json(issues: Iterable[ValidationIssue]) -> str:
    return json.dumps([asdict(issue) for issue in issues], indent=2)


def is_snake_case(value: str) -> bool:
    return bool(CANONICAL_NAME_RE.fullmatch(value))


def get_reserved_special_families(doc: dict[str, Any]) -> set[str]:
    values = doc.get("reserved_special_families", [])
    if not isinstance(values, list):
        return set()
    return {value for value in values if isinstance(value, str)}


def validate_shape(doc: Any) -> list[ValidationIssue]:
    issues: list[ValidationIssue] = []
    if not isinstance(doc, dict):
        add_issue(issues, code="schema_error", rule_id="S0", message="document root must be a mapping")
        return issues

    for key in REQUIRED_TOP_LEVEL_KEYS:
        if key not in doc:
            add_issue(
                issues,
                code="schema_error",
                rule_id="S1",
                message=f"missing required top-level key '{key}'",
                field=key,
            )

    if issues:
        return issues

    if doc.get("kind") != "stage_applicability":
        add_issue(
            issues,
            code="schema_error",
            rule_id="S2",
            message="kind must equal 'stage_applicability'",
            field="kind",
        )

    if doc.get("stage_order") != ALLOWED_STAGE_ORDER:
        add_issue(
            issues,
            code="schema_error",
            rule_id="S3",
            message=f"invalid stage_order; expected {ALLOWED_STAGE_ORDER!r}",
            field="stage_order",
        )

    reserved_special_families = doc.get("reserved_special_families", [])
    if reserved_special_families and not isinstance(reserved_special_families, list):
        add_issue(
            issues,
            code="schema_error",
            rule_id="S4",
            message="top-level 'reserved_special_families' must be a list when present",
            field="reserved_special_families",
        )

    systems = doc.get("systems")
    if not isinstance(systems, list):
        add_issue(
            issues,
            code="schema_error",
            rule_id="S5",
            message="top-level 'systems' must be a list",
            field="systems",
        )
        return issues

    for idx, entry in enumerate(systems):
        label = f"index {idx}"
        if not isinstance(entry, dict):
            add_issue(
                issues,
                code="schema_error",
                rule_id="S6",
                message=f"system '{label}' must be a mapping",
                system=label,
            )
            continue

        system_name = str(entry.get("system", label))
        for field in REQUIRED_SYSTEM_FIELDS:
            if field not in entry:
                add_issue(
                    issues,
                    code="schema_error",
                    rule_id="S6",
                    message=f"system '{system_name}' missing required field '{field}'",
                    system=system_name,
                    field=field,
                )

        for field, expected_type in EXPECTED_SYSTEM_FIELD_TYPES.items():
            if field in entry and not isinstance(entry[field], expected_type):
                actual_type = type(entry[field]).__name__
                add_issue(
                    issues,
                    code="schema_error",
                    rule_id="S7",
                    message=(
                        f"field '{field}' has invalid type '{actual_type}', "
                        f"expected '{expected_type.__name__}'"
                    ),
                    system=system_name,
                    field=field,
                )

        stage = entry.get("first_stage_present")
        if isinstance(stage, str) and stage not in ALLOWED_FIRST_STAGE:
            add_issue(
                issues,
                code="schema_error",
                rule_id="S8",
                message=f"has invalid first_stage_present '{stage}'",
                system=system_name,
                field="first_stage_present",
            )

    return issues


def validate_semantics(doc: dict[str, Any]) -> list[ValidationIssue]:
    issues: list[ValidationIssue] = []
    systems: list[dict[str, Any]] = doc["systems"]
    seen_systems: set[str] = set()
    by_system: dict[str, dict[str, Any]] = {}
    reserved_special_families = get_reserved_special_families(doc)

    for entry in systems:
        system = entry["system"]
        family = entry["source_state_family"]
        stage = entry["first_stage_present"]
        can_change = entry["can_change_in_run"]
        needs_runtime = entry["runtime_overlay_needed"]
        notes = entry["notes"]

        if system in seen_systems:
            add_issue(
                issues,
                code="semantic_error",
                rule_id="M1",
                message=f"duplicate system '{system}'",
                system=system,
            )
        seen_systems.add(system)
        by_system[system] = entry

        if not is_snake_case(system):
            add_issue(
                issues,
                code="semantic_error",
                rule_id="M2",
                message="is not valid snake_case canonical naming",
                system=system,
                field="system",
            )

        if not is_snake_case(family):
            add_issue(
                issues,
                code="semantic_error",
                rule_id="M3",
                message=f"source_state_family '{family}' is not valid snake_case canonical naming",
                system=system,
                field="source_state_family",
            )

        if stage == "runtime_overlay" and not needs_runtime:
            add_issue(
                issues,
                code="semantic_error",
                rule_id="M4",
                message="starts at runtime_overlay but runtime_overlay_needed is false",
                system=system,
                field="runtime_overlay_needed",
            )

        if (system.endswith("_loadout") or system.endswith("_preset") or system.endswith("_presets")) and stage != "baseline_loadout":
            add_issue(
                issues,
                code="semantic_error",
                rule_id="M5",
                message="loadout system must first appear at baseline_loadout",
                system=system,
                field="first_stage_present",
            )

        if system.endswith("_inventory") and stage != "baseline_account":
            add_issue(
                issues,
                code="semantic_error",
                rule_id="M6",
                message="inventory system must first appear at baseline_account",
                system=system,
                field="first_stage_present",
            )

        if system in RUNTIME_MUTATING_SYSTEMS and not can_change:
            add_issue(
                issues,
                code="semantic_error",
                rule_id="M7",
                message="runtime-mutating system must have can_change_in_run=true",
                system=system,
                field="can_change_in_run",
            )

        if family in PERSISTENT_ACCOUNT_FAMILIES and stage != "baseline_account":
            add_issue(
                issues,
                code="semantic_error",
                rule_id="M8",
                message=f"persistent account family '{family}' is assigned to '{stage}', expected baseline_account",
                system=system,
                field="first_stage_present",
            )

        if family == "runtime_overlay" and stage != "runtime_overlay":
            add_issue(
                issues,
                code="semantic_error",
                rule_id="M9",
                message="runtime_overlay special family must first appear at runtime_overlay",
                system=system,
                field="first_stage_present",
            )

        if family == "multi_source" and stage == "baseline_loadout":
            add_issue(
                issues,
                code="semantic_error",
                rule_id="M10",
                message="multi_source systems cannot first appear at baseline_loadout",
                system=system,
                field="first_stage_present",
            )

        if family in reserved_special_families and family not in {"runtime_overlay", "multi_source"}:
            add_issue(
                issues,
                code="semantic_error",
                rule_id="M11",
                message=f"reserved special family '{family}' is not recognized by validator policy",
                system=system,
                field="source_state_family",
            )

        if not notes.strip():
            add_issue(
                issues,
                code="semantic_error",
                rule_id="M12",
                message="has empty notes",
                system=system,
                field="notes",
            )

    for group in DUAL_NATURE_GROUPS:
        persistent_present = group["persistent_sources"].intersection(by_system)
        realized_present = group["realized_effects"].intersection(by_system)
        if persistent_present and not realized_present:
            for name in sorted(persistent_present):
                add_issue(
                    issues,
                    code="semantic_error",
                    rule_id="M13",
                    message="persistent source system is present without corresponding realized runtime effect entry",
                    system=name,
                )
        if realized_present and not persistent_present:
            for name in sorted(realized_present):
                add_issue(
                    issues,
                    code="semantic_error",
                    rule_id="M13",
                    message="realized-effect system is present without corresponding persistent source entry",
                    system=name,
                )

    return issues


def validate_integration(doc: dict[str, Any], repo_index: dict[str, Any]) -> list[ValidationIssue]:
    issues: list[ValidationIssue] = []
    systems = doc["systems"]
    contract_system_names = {entry["system"] for entry in systems}
    reserved_special_families = get_reserved_special_families(doc)

    source_families = set(repo_index.get("canonical_source_families", []))
    declared_pipeline_systems = set(repo_index.get("declared_pipeline_systems", []))
    baseline_account_consumers = set(repo_index.get("baseline_account_consumers", []))
    baseline_gem_respec_consumers = set(repo_index.get("baseline_gem_respec_consumers", []))
    baseline_loadout_consumers = set(repo_index.get("baseline_loadout_consumers", []))
    inventory_to_loadout_edges = {tuple(edge) for edge in repo_index.get("inventory_to_loadout_edges", [])}
    immutable_runtime_systems = set(repo_index.get("immutable_runtime_systems", []))

    for entry in systems:
        system = entry["system"]
        family = entry["source_state_family"]
        stage = entry["first_stage_present"]
        can_change = entry["can_change_in_run"]

        if source_families and family not in source_families and family not in reserved_special_families:
            add_issue(
                issues,
                code="integration_error",
                rule_id="I1",
                message=f"source_state_family '{family}' is not defined in canonical repo contracts or reserved_special_families",
                system=system,
                field="source_state_family",
            )

        if stage == "runtime_overlay":
            for static_stage_name, consumers in (
                ("baseline_account", baseline_account_consumers),
                ("baseline_gem_respec", baseline_gem_respec_consumers),
                ("baseline_loadout", baseline_loadout_consumers),
            ):
                if system in consumers:
                    add_issue(
                        issues,
                        code="integration_error",
                        rule_id="I2",
                        message=f"runtime-only system is referenced by static stage '{static_stage_name}'",
                        system=system,
                    )

        if system.endswith("_inventory"):
            paired_loadout = system.replace("_inventory", "_loadout")
            if paired_loadout in contract_system_names and inventory_to_loadout_edges:
                if (system, paired_loadout) not in inventory_to_loadout_edges:
                    add_issue(
                        issues,
                        code="integration_error",
                        rule_id="I3",
                        message="inventory system feeds active effects without an explicit loadout selection layer",
                        system=system,
                    )

        if stage == "baseline_loadout" and baseline_loadout_consumers and system not in baseline_loadout_consumers:
            add_issue(
                issues,
                code="integration_error",
                rule_id="I4",
                message="loadout system is declared in contract but not consumed by baseline_loadout assembly",
                system=system,
            )

        if can_change and system in immutable_runtime_systems:
            add_issue(
                issues,
                code="integration_error",
                rule_id="I5",
                message="is marked can_change_in_run=true but is treated as immutable in runtime pipeline",
                system=system,
            )

    if declared_pipeline_systems:
        missing = declared_pipeline_systems - contract_system_names
        for system in sorted(missing):
            add_issue(
                issues,
                code="integration_error",
                rule_id="I6",
                message=f"repo system '{system}' is used by pipeline but missing from stage_applicability contract",
                system=system,
            )

    return issues


def validate_contract(doc: Any, repo_index: dict[str, Any] | None = None) -> list[ValidationIssue]:
    repo_index = repo_index or {}
    issues = validate_shape(doc)
    if issues:
        return issues
    issues.extend(validate_semantics(doc))
    issues.extend(validate_integration(doc, repo_index))
    return issues


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Validate kb/global-rules/contracts/stage-applicability.yaml")
    parser.add_argument("contract", type=Path, help="Path to stage-applicability.yaml")
    parser.add_argument("--repo-index", type=Path, default=None, help="Optional repo index YAML/JSON for integration checks")
    parser.add_argument("--format", choices=["cli", "json"], default="cli", help="Output format")
    args = parser.parse_args(argv)

    doc = load_yaml(args.contract)
    repo_index = load_repo_index(args.repo_index)
    issues = validate_contract(doc, repo_index)

    if args.format == "json":
        print(dump_issues_json(issues))
    else:
        if not issues:
            print("[ok] stage_applicability contract passed validation")
        else:
            for issue in issues:
                print(issue.to_cli_line())

    return 1 if issues else 0


if __name__ == "__main__":
    raise SystemExit(main())

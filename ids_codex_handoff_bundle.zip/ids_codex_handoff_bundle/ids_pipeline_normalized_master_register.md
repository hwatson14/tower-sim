# IDS Pipeline Normalized Master Bug Register

Purpose: execution-oriented, deduped, root-cause register derived from the cumulative discovery ledger.
Evidence source: ids_pipeline_bug_ledger_v19.md
Canonical preset contract:
- Tourney
- Farming
- Milestone
- Preset 4
- Preset 5

## How to read this register

- This file is **clustered by root cause**, not by file.
- The raw discovery ledger remains the evidence appendix.
- `Evidence IDs` refer to the original bug IDs from the cumulative raw ledger.
- `Primary fix layer` identifies where the root defect should be fixed first.
- `Verification rule` states what must be true before the cluster can be considered closed.

---

## Cluster C1 — Duplicate truth / competing contracts

**Root problem**  
Preset names, section layouts, preset columns, and runtime mode mappings are declared in multiple places, so different layers can all be “correct” relative to themselves while disagreeing with each other.

**Severity**  
Critical

**Affected layers**  
Parser, compiler, account model, debug UI, runtime/progression, tests, fixtures

**Primary fix layer**  
Canonical contract layer first, then parser/compiler/runtime consumers

**Representative evidence IDs**  
1, 2, 50, 53, 54, 55, 56, 57, 58, 59, 60, 61, 79, 80, 81, 82, 83, 111, 113, 116, 118, 138, 139, 140, 141, 142, 143, 144, 145, 146

**Merged manifestations**
- Multiple `SECTION_SPECS` copies in executable files
- Multiple preset-name truth tables (`PRESET_NAMES`, alias maps, UI selectors, progression `MODE_IDS`)
- Workshop preset-column meaning re-declared in multiple files
- Raw labels (`Preset 3`, `Testing`, placeholders) normalized differently by different subsystems
- Tests/fixtures preserve older truth tables

**Recommended fix strategy**
1. Create one canonical preset/schema registry
2. Make all consumers import from it
3. Remove or retire duplicate UI/spec copies
4. Convert tests/fixtures to canonical vocabulary only

**Verification rule**
- There is one authoritative preset/schema registry
- No executable file carries its own independent preset truth table
- Tests/fixtures reference canonical preset names only

---

## Cluster C2 — Runtime preset incompleteness

**Root problem**  
The repo claims five-preset support, but runtime/progression/engine paths still only support a smaller preset subset or special-case only certain presets.

**Severity**  
Critical

**Affected layers**  
Progression runtime, timing/runtime, stat engine, compare

**Primary fix layer**  
Runtime/progression contract and engine entrypoints

**Representative evidence IDs**  
111, 112, 114, 115, 117, 169, 194

**Merged manifestations**
- Progression mode map supports only Farming/Tourney/Milestone
- Runtime delegated timing path is Tourney-specific
- Scenario/runtime request objects model only selected mode context
- Compare fit matrix only evaluates Farming/Tourney states

**Recommended fix strategy**
1. Make runtime/progression accept the canonical five presets
2. Separate preset identity from execution-scenario modifiers
3. Remove preset-specific branches where they are acting as contract substitutes

**Verification rule**
- All five canonical presets are valid end-to-end runtime inputs
- No runtime subsystem rejects `Preset 4` or `Preset 5`
- Compare/runtime matrices can represent all five presets explicitly

---

## Cluster C3 — Hard-coded positional schema

**Root problem**  
Many sections are parsed by fixed row/column positions and exact labels instead of a declared schema, making layout drift dangerous and preset support brittle.

**Severity**  
High

**Affected layers**  
Compiler, debug UI, query compiler

**Primary fix layer**  
Compiler/ingestion layer

**Representative evidence IDs**  
75, 76, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90

**Merged manifestations**
- Workshop preset levels from fixed interleaved columns
- Cards slot count and preset membership from fixed cells/columns
- UWs assume 4-row blocks
- Bots assume columns 0/2/4
- Modules assume fixed chunk starts and exact row labels
- WS+ QE parser scans only candidate columns 1..3

**Recommended fix strategy**
1. Parse from declared header/schema contracts
2. Introduce section-specific typed parsers
3. Remove mirrored positional logic from debug/UI consumers

**Verification rule**
- No family depends on hard-coded preset column numbers or exact labels without schema mediation
- Layout drift tests fail cleanly rather than silently rebinding

---

## Cluster C4 — Raw-table deferred interpretation

**Root problem**  
Some sections are kept as generic tables too long and reparsed downstream, so the system never establishes one typed truth representation early enough.

**Severity**  
High

**Affected layers**  
Compiler, QE, debug/export

**Primary fix layer**  
Compiler/account-state normalization

**Representative evidence IDs**  
25, 48, 52

**Merged manifestations**
- WS+ remains a raw table and is then interpreted differently by compiler/export/QE
- Guardians remain raw-table snapshots and are reparsed downstream
- Downstream consumers invent structure ad hoc

**Recommended fix strategy**
1. Convert raw-table families into typed account-state models in compiler
2. Prevent downstream reparsing of family semantics
3. Restrict raw table snapshots to archival/debug-only use

**Verification rule**
- WS+ and Guardians have typed compiled representations
- Downstream consumers do not reinterpret raw table bodies independently

---

## Cluster C5 — State-collapse / fail-open semantics

**Root problem**  
Missing, invalid, stale, empty, and zero-like states are repeatedly collapsed into “usable” values such as defaults, empty lists, zero, or omitted rows.

**Severity**  
Critical

**Affected layers**  
Compiler, account state, identity, runtime, timing, compare, verification, tests

**Primary fix layer**  
Binding/validation layer first, then state identity and runtime helpers

**Representative evidence IDs**  
97, 98, 99, 101, 102, 103, 104, 105, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 160, 161, 162, 163, 164, 165, 168

**Merged manifestations**
- Unknown presets ignored or defaulted
- Missing preset families silently fall back to main preset
- Missing perk preset serializes as `[]`
- Missing workshop preset level becomes `0`
- Empty presets disappear from exports
- Missing compare state falls back to preset rows
- Stale/invalid active perk preset truthiness still enables perks

**Recommended fix strategy**
1. Define explicit state-status semantics: missing / empty / zero / invalid / synthetic
2. Fail closed on invalid preset names and missing required canonical preset lanes
3. Preserve emptiness explicitly rather than omitting it
4. Make identity distinguish missing from empty

**Verification rule**
- Missing, empty, invalid, and zero are distinct in compiled state and identity
- No helper silently converts invalid or missing preset-family state into another preset
- Empty presets/slots are explicitly representable

---

## Cluster C6 — Hybrid cross-family preset binding

**Root problem**  
Different preset families (main/card/module/perk) are resolved independently and can silently bind into hybrid states that do not correspond to one coherent user preset selection.

**Severity**  
Critical

**Affected layers**  
State identity, stat-input compilation, timing, progression recalc

**Primary fix layer**  
State binding / request construction layer

**Representative evidence IDs**  
125, 151, 152, 153, 154, 162, 193, 195

**Merged manifestations**
- Card/module/perk preset names default independently
- Requests carry selected family overrides without a full family-matrix contract
- Downstream execution uses hybrid state as if it were canonical

**Recommended fix strategy**
1. Introduce a bound preset-family object validated as one coherent selection
2. Make hybrid family state explicit and invalid unless intentionally supported
3. Require complete family binding before execution

**Verification rule**
- Execution requests cannot represent accidental hybrid preset-family states
- Bound execution context clearly states whether it is canonical, hybrid, or partial

---

## Cluster C7 — WS+ structural mis-modeling

**Root problem**  
WS+ is structurally richer than the repo treats it. Different layers treat it as scalar, value/max, first float, or partial preview, so preset-aware correctness is broken.

**Severity**  
Critical

**Affected layers**  
Compiler, QE, debug/export, preview

**Primary fix layer**  
Compiler model + QE routing

**Representative evidence IDs**  
13, 14, 29, 30, 44, 52, 69, 70, 179

**Merged manifestations**
- Wrong assumption that WS+ row = name/value/max
- QE takes first parseable float from a subset of columns
- Selected preset ignored downstream
- Preview labels and compiled views erase preset-indexed structure

**Recommended fix strategy**
1. Define typed WS+ schema with all canonical columns
2. Make selected preset explicit in QE binding
3. Emit full WS+ completeness in debug/export surfaces

**Verification rule**
- Changing preset changes WS+ QE inputs where appropriate
- WS+ compiled/exported views preserve the full declared structure
- No first-parseable-float heuristics remain

---

## Cluster C8 — UW identity loss and positional semantics

**Root problem**  
UW track identity is discarded in compiler and reconstructed positionally later, which makes later layers depend on track order and special cases.

**Severity**  
High

**Affected layers**  
Compiler, QE, export

**Primary fix layer**  
Compiler/UW model

**Representative evidence IDs**  
3, 33, 34, 35, 84

**Merged manifestations**
- Compiler stores track levels/values without attribute names
- QE reconstructs semantics from external order tables
- Golden Tower gets special-case repair logic

**Recommended fix strategy**
1. Compile UWs with explicit track attributes
2. Remove downstream positional zipping/special-casing
3. Export attribute names directly

**Verification rule**
- Every UW row carries explicit attribute identity end to end
- No external order table is required to interpret compiled UW state

---

## Cluster C9 — Bot state identity / meaning drift

**Root problem**  
Bots mean different things in different layers: levels in compiler, resolved values in QE, level-only again in export, with positional parsing throughout.

**Severity**  
Medium-high

**Affected layers**  
Compiler, QE, debug/export

**Primary fix layer**  
Compiler/bot model

**Representative evidence IDs**  
4, 49, 85, 86

**Merged manifestations**
- Compiler stores only upgrade level
- QE resolves current value from ladders
- Export/debug show only levels
- Bot parsing is fixed-column positional

**Recommended fix strategy**
1. Store both raw level and resolved value/unit in compiled bot model
2. Make exports and previews explicit about which representation they show
3. Remove duplicate positional parsing outside compiler

**Verification rule**
- Bot rows can be audited without reconstructing meaning from KB or display tokens
- Compiler, QE, and export agree on bot representation semantics

---

## Cluster C10 — Polluted section ingestion (Relics/Vault)

**Root problem**  
Header/group rows are ingested as facts, then inconsistently filtered later.

**Severity**  
High

**Affected layers**  
Compiler, QE, export

**Primary fix layer**  
Compiler section parsers

**Representative evidence IDs**  
1, 2, 31, 32, 38, 46

**Merged manifestations**
- Relics/Vault header/group rows become facts
- QE partially cleans via blacklists
- Export serializes polluted state blindly

**Recommended fix strategy**
1. Replace generic key-value ingestion with typed fact-row parsers
2. Remove downstream blacklist cleanup once compiler is corrected
3. Preserve headers separately if needed for UI only

**Verification rule**
- Relics/Vault compiled state contains only fact rows
- No downstream blacklist is needed to keep QE/export clean

---

## Cluster C11 — Perk preset contract divergence

**Root problem**  
Perks do not follow the same clean preset model as other families; they allow arbitrary keys, fallback merging, default pseudo-presets, and generated pseudo-presets.

**Severity**  
Critical

**Affected layers**  
Compiler, query perk compiler, run-stats, runtime, tests

**Primary fix layer**  
Perk config normalization + preset binding layer

**Representative evidence IDs**  
91, 92, 93, 94, 95, 96, 104, 105, 106, 214

**Merged manifestations**
- Perk preset names not normalized
- Active perk preset not normalized
- Requested + active + default presets merged
- `default` acts as hidden sixth namespace
- `ProjectedMax_AllAllowedExceptBanned` becomes active preset and input artifact

**Recommended fix strategy**
1. Force perks onto the canonical five-preset contract (or explicit scoped exception model)
2. Remove implicit multi-key merge behavior
3. Isolate generated/runtime perk sets from canonical preset identity

**Verification rule**
- Perk preset resolution selects one canonical preset (or explicit non-canonical transient type)
- No hidden `default` or generated preset can masquerade as normal active preset state

---

## Cluster C12 — Synthetic namespace / mutation / persistence

**Root problem**  
Non-canonical preset-like namespaces are created, mixed into normal collections, written into state, persisted to disk, serialized into artifacts, and validated by tests.

**Severity**  
Critical

**Affected layers**  
Compare, runtime, progression timeline, state identity, artifact writers, tests, fixtures

**Primary fix layer**  
Namespace hygiene boundary + compare/runtime state typing

**Representative evidence IDs**  
107, 129, 130, 131, 133, 134, 145, 166, 167, 197, 198, 199, 200, 201, 202, 203, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 215, 216, 217, 218, 219, 220, 222, 223, 224, 225, 226, 228

**Merged manifestations**
- Compare-state suffix namespaces
- Progression timeline synthetic preset
- Generated projected-max preset
- Synthetic names mixed with canonical collections
- Synthetic names persisted into config and output artifacts
- Synthetic names fingerprinted in identity
- Synthetic names expected in tests and reports

**Recommended fix strategy**
1. Introduce explicit namespace classes/types
2. Keep synthetic execution state transient and out of canonical artifacts
3. Prevent canonical artifact writers from serializing non-canonical preset names without explicit tagging
4. Remove synthetic names from verification contract except in explicitly typed transient tests

**Verification rule**
- Canonical artifacts contain only canonical preset names
- Synthetic execution states are explicitly typed and transient
- Tests distinguish canonical preset identity from compare/runtime synthetic state

---

## Cluster C13 — Visibility loss / selected-only / presence-only surfaces

**Root problem**  
Many surfaces only show selected, populated, materialized, or top-N state, making partial views look complete.

**Severity**  
High

**Affected layers**  
Debug UI, export CSV, query preview, compare diagnostics, optimizer, artifact outputs

**Primary fix layer**  
Output contract / audit-surface design

**Representative evidence IDs**  
15, 16, 17, 18, 19, 20, 21, 22, 39, 40, 41, 42, 45, 47, 62, 63, 64, 65, 66, 67, 68, 71, 72, 73, 74, 77, 78, 97, 98, 99, 100, 101, 102, 103, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 180, 181, 182, 183, 184, 185, 186, 187, 188, 189, 190, 191, 192, 193, 194, 195, 196

**Merged manifestations**
- Empty presets/slots omitted
- Selected or active-only views
- Compare-driven materialization
- Query/preview hides preset/contributor fields
- Truncation via `.head()` or slices
- No full five-preset completeness artifact
- Runtime request/context objects are inherently partial but not labeled as such

**Recommended fix strategy**
1. Define one explicit completeness artifact per family
2. Mark partial views as partial
3. Include preset identity and completeness markers in audit surfaces
4. Represent empty presets/slots explicitly

**Verification rule**
- There is at least one artifact that shows full five-preset/full-slot truth per family
- Partial/selected/context-specific artifacts are clearly labeled as such
- Empty state is explicit, not omitted

---

## Cluster C14 — Artifact contract ambiguity / provenance loss

**Root problem**  
Artifacts mix canonical, publishable, compare, selected-context, and synthetic-state semantics without an explicit machine-readable contract saying what each artifact means.

**Severity**  
High

**Affected layers**  
run_stats outputs, optimizer outputs, overlay diagnostics, reports

**Primary fix layer**  
Artifact schema and output contracts

**Representative evidence IDs**  
187, 188, 189, 190, 191, 192, 224, 225

**Merged manifestations**
- Scores and paths omit preset/state provenance
- Diagnostics summarize active contexts rather than full matrices
- Multiple artifact families expose different semantics without a contract
- Canonical/publishable/compare artifacts all leak synthetic state

**Recommended fix strategy**
1. Declare artifact classes explicitly: canonical, publishable, compare, selected-context, transient
2. Include provenance metadata consistently
3. Prevent artifact families from mixing namespace classes

**Verification rule**
- Every artifact declares its class and completeness semantics
- Provenance is sufficient to reconstruct preset/state context
- Canonical/publishable artifacts exclude synthetic namespace leakage

---

## Cluster C15 — Verification drift / false-green tests

**Root problem**  
Tests, helpers, fixtures, and checked-in outputs still encode stale labels, synthetic namespaces, three-preset assumptions, and Farming bias, so green verification does not prove the canonical five-preset contract.

**Severity**  
Critical

**Affected layers**  
Tests, golden fixtures, checked-in outputs, verification helpers

**Primary fix layer**  
Verification harness / fixture refresh

**Representative evidence IDs**  
132, 135, 136, 137, 143, 144, 145, 158, 165, 166, 167, 220, 221, 229, 230, 231, 232, 233, 234, 235, 236, 237

**Merged manifestations**
- Tests only cover Farming/Tourney/Milestone in places
- Fixtures still use `Testing` and placeholder names
- Synthetic compare/timeline/projected-max names are asserted as expected behavior
- Large runtime/incremental test regions are Farming-biased
- No dedicated completeness test for all five presets per family

**Recommended fix strategy**
1. Refresh fixtures to canonical vocabulary
2. Remove synthetic names from canonical expectation tests
3. Add explicit five-preset completeness tests per family
4. Reduce Farming-only helper defaults

**Verification rule**
- Tests and fixtures use the canonical five-preset contract unless explicitly testing transient synthetic state
- There is dedicated coverage for all five presets and explicit empty-state representation

---

## Cluster C16 — Missing full family completeness matrix

**Root problem**  
The repo has no single artifact or test that proves all families are complete across all five canonical presets and their relevant empty states.

**Severity**  
Critical

**Affected layers**  
Artifacts, diagnostics, tests

**Primary fix layer**  
Audit / verification artifact layer

**Representative evidence IDs**  
99, 103, 172, 173, 190, 191, 236

**Merged manifestations**
- No single completeness matrix for workshop/cards/modules/perks/etc.
- Present-only maps hide missing lanes
- Diagnostics require inference from partial summaries

**Recommended fix strategy**
1. Introduce canonical family completeness matrix artifact
2. Make it part of verification and CI
3. Include per-family lane/slot completeness status

**Verification rule**
- One artifact/test can answer: “are all five presets present and explicitly represented for every family?”

---

## Suggested implementation order

1. **C1 Duplicate truth / competing contracts**
2. **C2 Runtime preset incompleteness**
3. **C5 State-collapse / fail-open semantics**
4. **C11 Perk preset contract divergence**
5. **C12 Synthetic namespace / mutation / persistence**
6. **C10 Polluted section ingestion**
7. **C7 WS+ structural mis-modeling**
8. **C8 UW identity loss**
9. **C9 Bot state meaning drift**
10. **C13 Visibility loss / selected-only surfaces**
11. **C14 Artifact contract ambiguity / provenance loss**
12. **C15 Verification drift / false-green tests**
13. **C16 Missing full family completeness matrix**
14. **C3 Hard-coded positional schema**
15. **C4 Raw-table deferred interpretation**
16. **C6 Hybrid cross-family preset binding**

Reason: the early clusters are contract/invariant setters; the later clusters are cleanup, visibility, and verification hardening once the contract is stable.

---

## Relationship to raw ledger

This normalized register is the control document for planning and execution.

The raw cumulative ledger remains the evidence appendix:
- ids_pipeline_bug_ledger_v19.md (raw discovery)
- ids_pipeline_normalized_master_register.md (this file)



### Verification drift / fixture close-out defects
229. **Fixtures and generated outputs encode two incompatible preset contracts simultaneously**
   - `tests/golden_account_state.json` preserves stale/raw labels such as:
     - `Testing`
     - `Placeholder 4th preset`
     - `Placeholder 5th preset`
   - `out/account_state.json` preserves canonicalized labels such as:
     - `Milestone`
   - Verification is therefore split across stale-source and canonical namespace contracts.

230. **Golden fixture still treats stale module preset labels as expected truth**
   - `tests/golden_account_state.json` uses `Testing` heavily in module preset structures and empty preset slots.
   - This means fixture comparison can still validate stale raw namespace behavior after canonicalization work elsewhere.

231. **Generated account-state artifact and golden fixture disagree on third-preset identity**
   - Generated `out/account_state.json` uses `Milestone`.
   - Golden fixture uses `Testing`.
   - The repo therefore lacks one verification-time answer to “what is the third canonical preset called?”

232. **Verification stack mixes canonicalized and non-canonicalized artifacts without an explicit reconciliation rule**
   - Example artifact families:
     - canonicalized-ish: `out/account_state.json`
     - stale/raw fixture: `tests/golden_account_state.json`
     - synthetic compare/report artifacts: `out/ep_oracle_compare.json`, diagnostics reports
   - There is no explicit rule telling tests or reviewers which namespace contract should win.

233. **Report/tests still lock in synthetic compare-state naming as expected output contract**
   - Tests such as `tests/test_verification_module.py` and `tests/test_smoke.py` assert synthetic compare-state keys.
   - Even if runtime/serialization were cleaned, verification would still pull behavior back toward synthetic namespace expectations.

234. **Progression verification still codifies three-preset support**
   - `tests/test_progression_state.py` explicitly checks `Milestone` support but has no equivalent assertions for `Preset 4` or `Preset 5`.
   - This leaves the verification contract narrower than the canonical five-preset requirement.

235. **Large sections of runtime/incremental tests remain Farming-biased and therefore under-detect preset-contract drift**
   - Multiple tests construct state with `default_preset='Farming'` across incremental/runtime helpers.
   - This means verification drift is not just stale naming; it is also systematic under-coverage of non-Farming preset behavior.

236. **There is no dedicated test or artifact asserting full five-preset completeness per family**
   - No single verification surface currently proves, for each family, that:
     - all five canonical presets exist
     - empty presets are explicitly represented
     - empty slots are explicitly represented where applicable
   - This is the final verification-gap finding needed before close-out.

237. **Verification drift family is now evidenced across tests, fixtures, and checked-in artifacts**
   - Evidence now exists in:
     - test helpers
     - runtime/incremental tests
     - golden fixtures
     - checked-in `out/` artifacts
     - compare/report outputs
   - This is the closure condition for the verification-drift / fixture defect family.


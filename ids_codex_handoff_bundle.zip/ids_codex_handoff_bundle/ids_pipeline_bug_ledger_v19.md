# IDS Pipeline Bug Ledger

Status: in progress
Scope: `parsers/ids_parser.py` -> `compilers/account_state_compiler.py` -> `scripts/debug_ui.py`

## Confirmed defects

### Parser / structural
1. **Duplicated section layout truth**
   - `parsers/ids_parser.py` and `scripts/debug_ui.py` both define their own `SECTION_SPECS`.
   - Risk: parser/UI drift when IDS layout changes.

2. **Debug UI reimplements IDS parsing**
   - `scripts/debug_ui.py` has its own parser logic instead of calling `parse_ids`.
   - Risk: two independent parsers disagreeing on section boundaries or row inclusion.

3. **Header validation is brittle**
   - `ids_parser._fail_unknown_sections()` uses special-case allowances instead of a stronger schema contract.
   - Risk: false failures or silent future drift.

### Compiler
4. **Relics header/category leakage**
   - `_parse_key_value_float()` accepts non-data rows as facts.

5. **Vault header/category leakage**
   - `_parse_key_value_scalar()` accepts non-data rows as facts.

6. **UW attribute identity loss**
   - `_parse_uws()` preserves positional `track_levels` and `track_values` but not track attribute names.

7. **Bot resolved-value loss**
   - `_parse_bots()` preserves level only, discarding resolved display value and unit.

8. **Theme/song parser too loose**
   - `_parse_theme_song_coin_multiplier()` returns the first parseable float from cols 0/1.
   - Risk: wrong numeric cell selected if layout expands.

9. **Player meta parser fixed-column truncation risk**
   - `_parse_player_meta()` only reads 0/1 and 4/5 column pairs.

10. **Cards compiler lacks slot-consistency validation**
    - `card_slots_unlocked` is parsed, but no validation checks preset length or capacity consistency.

11. **Module state shape creates join ambiguity**
    - Three separate concepts:
      - `module_system_state.assist_level`
      - `module_presets[preset][slot].assist`
      - `modules_inventory[module].level`
    - Risk: hybrid rows when exporting.

12. **Module parsing is positional and brittle**
    - `_extract_slot_chunk()` and `_parse_modules()` rely on fixed chunk boundaries and row bands.

### Debug UI / export
13. **WS+ compiled export schema is wrong**
    - `flatten_compiled_account_state()` treats each enhancement row as `name/value/max`.
    - This is not the actual section shape.

14. **WS+ max likely read from wrong field**
    - Uses `row[2]` as max.

15. **Card slots missing from export**
    - `AccountState.card_slots_unlocked` exists but is not exported.

16. **UW export stays anonymous**
    - UI export emits token/value pairs without track attribute names.

17. **Module preset export overloads `value`**
    - Uses `value = primary|assist` instead of explicit role/domain fields.

18. **Polluted Relics/Vault state passed straight through**
    - Export serializes polluted compiler state without filtering.

19. **WS+ first body row dropped in IDS flattened view**
    - `flatten_ids_levels()` uses `sections["WS+"]["rows"][1:]`.

20. **WS+ first body row dropped in IDS preview**
    - `ids_preview_df()` also uses `rows[1:41]` for WS+.

21. **WS+ preview column labels are misleading**
    - Preview labels imply a stable 4-field model that does not match real WS+ structure.

22. **Potential missing helper/runtime bug in IDS visual tab**
    - `debug_ui.py` references `_card_open`, `_render_preview_html`, `_card_close`.
    - Needs execution confirmation if those helpers do not exist.

### Export contract
23. **`value` column overloaded**
    - Means different things depending on section/family.

24. **`detail` column overloaded**
    - Used for max metadata, attribute labels, slot info, current values, etc.

25. **`TableSnapshot` overused for sections needing typed models**
    - WS+ and Guardians remain raw tables too long.

## Not yet fully proven but high-confidence risks

26. **Assist-module wrong-level issue likely occurs at compiler/export boundary**
   - Shape makes it easy to bind assist name to the wrong level source.

27. **Cards slot-count parser is brittle**
   - `card_slots_unlocked` is parsed from `section_header[5]`, which depends on exact header shape.

28. **UW `unlocked` field is suspicious**
   - `_parse_uws()` sets `unlocked` from `block[2][0]`, which may not be a stable or meaningful unlock field.

## Suggested next classification pass

- compiler-born
- export-born
- mixed boundary/contract
- structural risk only



## Additional defects from deeper pass

### Query compiler / downstream consumption
29. **Enhancement value selection is schema-less and can bind the wrong field**
   - `compilers/stat_input_compiler.py` loops WS+ row cells and takes the **first parseable float from columns 1, 2, or 3** as the enhancement value.
   - Risk: if those columns represent different things (effective value, level, intermediate value), QE can ingest the wrong number while appearing to work.

30. **Enhancement rows ignore later WS+ columns entirely**
   - Query compilation for enhancements only inspects cells 1..3.
   - Any additional preset/cap/effective columns to the right are discarded.

31. **Relic cleanup in query compiler is incomplete**
   - `compile_stat_inputs()` manually skips some polluted relic keys (`Relics`, `Total Bonuses`, `Misc.`, etc.) but this is a brittle name blacklist.
   - Suspicious leftover keys like `Damage?` are not clearly filtered and may leak through.

32. **Vault header leakage is not cleaned before query routing**
   - Unlike relics, vault rows are iterated wholesale in `compile_stat_inputs()`.
   - Header/group labels from the polluted compiler state can therefore become QE rows.

33. **UW unlock flag source is suspicious**
   - `_parse_uws()` populates `UltimateWeaponSnapshot.unlocked` from `block[2][0]`.
   - Query compilation then turns that into an ownership bool.
   - Risk: ownership is inferred from a fragile positional cell rather than an explicit typed field.

34. **UW track semantics depend on external table order**
   - Query compilation reconstructs UW track names by zipping `uw.track_levels` with `_load_uw_track_order()`.
   - Since the compiler discarded attribute names, correctness now depends on the ladder file order matching IDS row order exactly.

35. **Golden Tower receives a hard-coded track-order patch**
   - `_load_uw_track_order()` special-cases Golden Tower if only two tracks are found.
   - This is a smell that the general UW track-order contract is not robust.

36. **Cards query compilation omits card-slot capacity as a QE surface**
   - Card effects are compiled only from active preset cards.
   - `card_slots_unlocked` is not surfaced into query inputs, so QE cannot reason over slot-capacity constraints.

37. **Module assist behavior depends on slot-system state instead of selected module-only truth**
   - In `compile_stat_inputs()`, assist main/substat scaling uses `module_system_state.assist_level`, `multiplier_cap`, `substat_cap`.
   - Risk: selected assist module contribution can be scaled by slot-level metadata in ways that are hard to audit and easy to misbind.

38. **Vault and relic cleanup responsibilities are split across layers**
   - Compiler pollutes these sections, then query compiler partially cleans them via ad hoc name checks.
   - This is a structural bug because later consumers must know compiler pollution details to stay correct.

39. **Debug UI and canonical parser/compiler can disagree on IDS truth**
   - Because `debug_ui.py` has its own IDS parsing and flattening paths, raw IDS visual output is not guaranteed to match what `compile_account_state()` actually consumed.



### Cross-layer contradictions / omission defects
40. **Preset meta rows in debug export are ambiguous**
   - `flatten_compiled_account_state()` emits multiple rows named `Active/Default Preset` for:
     - active card preset
     - active module preset
     - active perk preset
     - default preset
   - The row name does not distinguish which preset type it refers to.

41. **Module system state is missing from debug export**
   - `AccountState.module_system_state` contains:
     - assist unlocked
     - assist level
     - rarity cap
     - multiplier cap
     - substat cap
   - `flatten_compiled_account_state()` does not export any of this.
   - Result: exported module rows cannot explain assist scaling behavior.

42. **Module stars / main effect details are missing from debug export**
   - Exported module inventory rows include only level plus packed slot/rarity detail.
   - Important module facts such as star tier and main-stat/boost display are omitted.

43. **Cross-layer naming drift for the same section**
   - Raw IDS/UI uses `WS+`
   - compiled export uses `Enhancements`
   - QE view uses `QE Enhancements`
   - Similar drift exists for `WS` vs `Workshop`, and `Player & Stuff` vs `Meta`/`Player Meta`.
   - Risk: inconsistent filtering, auditing, and bug triage.

44. **Debug IDS view and canonical compiler disagree on the meaning of WS+ columns**
   - IDS preview labels WS+ columns as `Value`, `Level`, `Extra`.
   - Compiled export treats WS+ rows as `name/value/max`.
   - Query compiler takes the first parseable float from cols 1..3.
   - This is a three-way contradiction for the same section.

45. **Compiled state contains card slot truth, but neither debug export nor QE surface it**
   - `card_slots_unlocked` exists in `AccountState`.
   - It is omitted from `flatten_compiled_account_state()` and not surfaced in `compile_stat_inputs()`.
   - Same truth is present upstream but absent in both downstream views.

46. **Relics/Vault are cleaned differently by different layers**
   - Compiler accepts header rows as facts.
   - Debug export serializes them blindly.
   - Query compiler partially filters relics by blacklist and barely filters vault.
   - Same polluted source receives inconsistent cleanup rules across layers.

47. **Raw IDS visual output is not a reliable audit of compiled truth**
   - Because `debug_ui.py` reparses IDS locally and also skips the first WS+ row, the IDS visual tab can disagree with what `compile_account_state()` actually compiled.

48. **Guardians are typed in QE but remain raw-table snapshots in compiled state**
   - `AccountState.guardians` is just `TableSnapshot`.
   - Query compiler then reparses guardian rows ad hoc.
   - This duplicates interpretation logic and creates another parser/consumer split similar to WS+ and bots.

49. **Bot state meaning diverges across layers**
   - Compiler stores only upgrade levels.
   - QE resolves track values from KB ladders.
   - Debug export shows only levels.
   - Same bot concept appears as level-only, resolved-value, and visual-display state depending on layer.



50. **Preset cardinality/label contradiction across WS, WS+, Cards, and Modules**
   - The same underlying five-preset concept is encoded differently by section:
     - WS: `Farming`, `Tourney`, `Preset 3`, `Preset 4`, `Preset 5`
     - WS+: `Farming`, `Tourney`, `Preset 3`, `Preset 4`, `Preset 5` plus a trailing extra/cap column
     - Cards: `Farming`, `Tourney`, `Preset 3`, `Preset 4`, `Preset 5`
     - Modules: `Farming`, `Tourney`, `Testing`, `Placeholder 4th preset`, `Placeholder 5th preset`
   - Compiler normalizes some of these to `Milestone`, `Preset 4`, `Preset 5`, but this is not a clean shared contract.

51. **Modules have preset structure that is not equivalent to Cards/WS**
   - For modules, each preset contains per-slot selections for both `Primary Slot` and `Assist Slot`.
   - Treating module presets like a flat preset list loses structural meaning.

52. **WS+ likely represents preset-indexed values plus an extra cap/effective column**
   - Raw IDS header row shows `Workshop Enhancement`, then `Farming`, `Tourney`, `Preset 3`, `Preset 4`, `Preset 5`, plus a trailing field (`7 q` in current IDS).
   - Current compiler/UI/QE logic does not model this as preset-indexed data and therefore misbinds WS+ semantics.

53. **Preset-3 alias drift is inconsistent across sections**
   - Raw IDS uses `Preset 3` in WS/WS+/Cards.
   - Cards/compiler normalize to `Milestone`.
   - Modules use `Testing` and map that to `Milestone`.
   - This is a cross-section naming drift bug, not just cosmetic vocabulary.



## Five-preset support bug cluster

54. **Canonical preset model uses `Milestone` instead of raw IDS `Preset 3`**
   - `models/account_state.py` defines `PRESET_NAMES = ["Farming", "Tourney", "Milestone", "Preset 4", "Preset 5"]`.
   - Raw IDS sections for WS / WS+ / Cards use `Preset 3`, not `Milestone`.
   - This means the repo's canonical preset contract already diverges from the source format.

55. **Preset normalization aliases collapse different raw labels into one internal label**
   - `_CARD_PRESET_ALIASES` maps:
     - `Testing` -> `Milestone`
     - `Preset 3` -> `Milestone`
   - `modules` label map also maps `Testing` -> `Milestone`.
   - This is a deliberate collapse of distinct source labels into one internal bucket.

56. **Workshop flattening rewrites `Preset 3` as `Milestone`**
   - In `scripts/debug_ui.py`, `workshop_presets = {"Farming":1, "Tourney":3, "Milestone":5, "Preset 4":7, "Preset 5":9}`.
   - Raw IDS workshop header is `Preset 3`, not `Milestone`.
   - Result: exported/debugged workshop preset names do not match source names.

57. **Cards compiler rewrites `Preset 3` as `Milestone`**
   - `_parse_cards()` uses preset columns:
     - 3 -> `Farming`
     - 4 -> `Tourney`
     - 5 -> `Milestone`
     - 6 -> `Preset 4`
     - 7 -> `Preset 5`
   - Raw IDS card header at that third preset column is `Preset 3`.
   - Source identity is lost at compile time.

58. **Debug UI preset selector uses normalized names, not raw IDS names**
   - Sidebar preset options are `["Farming", "Tourney", "Milestone", "Preset 4", "Preset 5"]`.
   - This makes the UI incapable of showing a raw-source-consistent `Preset 3` label.

59. **Module preset labels are not standardized at source but are silently normalized**
   - Raw IDS modules use:
     - `Farming`
     - `Tourney`
     - `Testing`
     - `Placeholder 4th preset`
     - `Placeholder 5th preset`
   - Compiler silently maps these to:
     - `Farming`
     - `Tourney`
     - `Milestone`
     - `Preset 4`
     - `Preset 5`
   - This hides source inconsistency instead of modeling it explicitly.

60. **Five-preset support exists nominally but not as a clean shared contract**
   - Different layers assume five presets, but they do so via:
     - raw names (`Preset 3`, `Testing`, placeholders)
     - normalized names (`Milestone`)
     - hard-coded column maps
     - flat preset lists in some sections
     - nested preset+slot selections in modules
   - Result: “supports 5 presets” is true only loosely, not contractually.

61. **Preset identity is not preserved end-to-end**
   - Raw IDS -> compiler -> debug export -> QE all refer to the third preset differently.
   - This makes exact round-trip auditing of the third preset impossible.



### Exported-CSV omission / empty-preset visibility defects
97. **Card preset export is presence-only and drops empty presets**
   - In the observed export, `Cards -> Card Preset` rows only exist for `Farming` and `Tourney`.
   - `Milestone` / `Preset 4` / `Preset 5` have no rows when empty.
   - Result: the CSV cannot distinguish:
     - preset exists but currently empty
     - preset failed to parse
     - preset unsupported

98. **Module preset export is presence-only and drops empty presets**
   - In the observed export, `Modules -> Module Preset` rows exist only for `Farming`, `Tourney`, and `Milestone`.
   - `Preset 4` / `Preset 5` disappear entirely when no selections are emitted.
   - Result: same ambiguity as cards, but worse because module presets are nested per slot.

99. **Compiled export has no explicit five-preset completeness marker**
   - There is no metadata row asserting the canonical preset set or indicating which presets were parsed for each family.
   - A consumer cannot tell whether missing preset rows mean “empty” or “missing”.

100. **Workshop is the only compiled export family that visibly preserves all five preset lanes**
   - Workshop rows are emitted per preset regardless of emptiness because preset levels are stored structurally.
   - Cards and modules emit only populated selections.
   - This creates cross-family inconsistency in how five-preset support is represented.

101. **Module preset export cannot represent empty slots explicitly**
   - Module preset rows are emitted only when `primary` or `assist` is truthy.
   - There is no row for:
     - empty primary slot
     - empty assist slot
     - preset/slot exists but unconfigured
   - This makes full preset-state auditing impossible.

102. **Card preset export cannot represent empty slot positions explicitly**
   - Card preset rows are emitted as a list of present card names with `slot_order`.
   - There is no explicit representation of empty slots or unused capacity.
   - This prevents exact slot-by-slot comparison against `card_slots_unlocked`.

103. **Preset support appears inconsistent in the exported CSV even when the internal model claims five presets**
   - Exported Workshop shows five preset names.
   - Exported Cards show only two.
   - Exported Modules show only three.
   - Without knowing the implementation, the CSV misleadingly suggests uneven preset support across families.



### Run-stats compare / generated-preset fallback defects
104. **Perk active-preset validity check uses exact key match with no normalization**
   - `_perk_config_has_active_preset()` requires `active_perk_preset in presets`.
   - Because `_parse_perk_config()` does not normalize preset names, semantically valid preset labels can fail this check.

105. **`max_progression` can silently replace primary perk config with a generated fallback preset**
   - `_resolve_perk_config()` swaps in a generated config when no active preset is detected for max progression.
   - This can bypass the user's supplied preset state instead of failing closed.

106. **Generated projected-max perk preset introduces another pseudo-preset outside the canonical five**
   - `_build_generated_max_progression_perk_config()` creates `ProjectedMax_AllAllowedExceptBanned`.
   - This adds another preset namespace beyond the five canonical presets.

107. **Compare layer materializes extra synthetic preset-state keys**
   - `_build_compare_rows_by_preset()` and compare helpers create keys like:
     - `Tourney__perks_on`
     - `Tourney__perks_off`
     - `Farming__perks_on`
     - `Farming__perks_off`
   - These are not canonical presets; they are synthetic compare-state namespaces.

108. **Compare layer defaults many destinations to Farming regardless of active preset**
   - `_compare_preset_for_destination()` defaults compare destinations to `Farming` unless overridden.
   - This means diagnostics/compare can evaluate against a preset different from the active/default engine preset.

109. **Milestone is a real engine preset but is excluded from compare policy**
   - `run_stats.py` diagnostics explicitly state milestone is a real engine preset with perks on, but EP compare excludes milestone loadout.
   - This is another cross-layer divergence between engine preset support and compare-layer behavior.

110. **Active cards/modules tracked in compare context are partial and compare-driven**
   - `_build_compare_rows_by_preset()` populates `package_stage_context['active_cards_by_preset']` and `active_modules_by_preset` only for materialized compare states.
   - This is not a full canonical preset inventory; it is a compare-use subset.



### Engine/runtime preset-support defects
111. **Progression engine only supports three presets, not five**
   - `engine/progression_state.py` defines:
     - `MODE_IDS = {"Farming": "farming", "Tourney": "tournament", "Milestone": "milestone"}`
   - `Preset 4` and `Preset 5` are unsupported and raise `ValueError` in `infer_mode_id_from_preset()`.

112. **Five-preset support is therefore false at runtime/progression level**
   - Even if compiler/account-state/debug layers carry five presets, progression/runtime initialization cannot accept `Preset 4` or `Preset 5`.

113. **Progression mode identity is hard-coded rather than schema-driven**
   - `infer_mode_id_from_preset()` relies on the fixed `MODE_IDS` dict.
   - This duplicates preset-contract truth outside `models.account_state.PRESET_NAMES`.

114. **Runtime delegated timing path is Tourney-only by design**
   - `engine/stat_engine.py::_infer_manifest_approved_family()` delegates only when `preset_names == {'Tourney'}`.
   - This creates another preset-specific runtime branch rather than a generalized preset contract.

115. **Preset-aware runtime behavior is inconsistent across engine subsystems**
   - `progression_state.py` recognizes only 3 presets.
   - `models/account_state.py` declares 5.
   - `debug_ui.py` offers 5.
   - `run_stats.py` creates synthetic compare namespaces on top.
   - This is an engine-level preset contract break, not just a UI/compiler issue.

116. **Repo contains multiple debug UI entrypoints / versions**
   - Repo root contains both `debug_ui.py` and `debug_ui_v5.py`.
   - This is a governance/debug-risk issue because bug fixes can land in one UI path while the other remains stale or contradictory.

117. **`Milestone` is treated as a runtime mode, not just a preset alias**
   - `progression_state.py` maps `Milestone -> milestone` mode_id.
   - Combined with raw-source `Preset 3` / modules `Testing`, this reinforces that alias normalization is shaping engine behavior, not merely display labels.

118. **Preset contract truth is duplicated across at least four layers**
   - Evidence now exists in:
     - `models/account_state.py` (`PRESET_NAMES`)
     - `compilers/account_state_compiler.py` (normalization maps + fixed columns)
     - `debug_ui.py` (preset options + fixed columns)
     - `engine/progression_state.py` (`MODE_IDS`)
   - This is a systemic source-of-truth bug.



### Compiler / identity fail-open preset defects
119. **Unknown loadout preset names are silently ignored**
   - `_apply_loadout_overrides()` normalizes preset names and `continue`s when normalization fails.
   - Invalid or drifted preset labels in `loadout.json` are dropped instead of surfacing an error.

120. **Unknown active loadout presets silently fall back to default preset**
   - `_resolve_active_loadout_presets()` returns `default_preset` whenever active preset normalization fails.
   - This hides preset-name drift and makes wrong active-preset config look valid.

121. **Compiler supports only one validated default preset source**
   - `compile_account_state()` validates `default_preset` against `PRESET_NAMES`, but does not equivalently validate parsed card/module/perk preset keys for full completeness.
   - Result: one preset entrypoint is fail-closed, while others remain fail-open.

122. **Perk presets can exist outside canonical preset set without compiler rejection**
   - `_parse_perk_config()` accepts arbitrary preset keys and stores them directly.
   - This violates the repo-wide canonical preset contract.

123. **State identity treats missing perk preset as empty list**
   - `_serialize_perk_preset()` returns `[]` when a preset is absent.
   - This collapses:
     - preset missing
     - preset present but empty
     into the same identity payload.

124. **State identity loadout fingerprint can mask preset-presence bugs**
   - Because missing perk preset serializes as `[]`, identity hashes may treat “missing preset” and “empty preset” as equivalent.
   - This weakens cache/runtime invalidation correctness.

125. **State identity defaults resolved preset family independently**
   - `bind_state_identity()` resolves:
     - preset
     - card preset
     - module preset
     - perk preset
     independently from defaults/actives.
   - This allows cross-family preset combinations that may not represent one coherent user-selected preset state.

126. **Perks-enabled default is driven by `active_perk_preset` truthiness, not preset validity**
   - In `bind_state_identity()` and `compile_stat_inputs_with_identity()`, default `perks_enabled` becomes `bool(account_state.active_perk_preset)`.
   - If the active perk preset key is stale/invalid but non-empty, perks can be considered enabled anyway.

127. **Progression init silently converts missing workshop preset levels to zero**
   - `build_workshop_track_states()` sets `current = 0` when `entry.preset_levels.get(preset_name)` is `None`.
   - This collapses:
     - preset missing
     - track unconfigured
     - true zero
     into the same runtime starting state.

128. **Progression init can therefore hide preset completeness bugs**
   - Because missing preset workshop levels become zero, progression startup can look valid even when preset data is incomplete.



### Synthetic preset namespaces and stale verification assumptions
129. **Progression timeline injects another synthetic preset namespace**
   - `engine/perk_timeline_state.py` defines `PROGRESSION_TIMELINE_PRESET = 'ProgressionTimeline_CurrentWave'`.
   - `apply_perk_counts_to_account_state()` writes this preset into `account_state.perk_presets` and sets it as `active_perk_preset`.
   - This adds yet another non-canonical preset outside the allowed five.

130. **Progression recalc bridge mutates account state into a synthetic active perk preset**
   - `engine/progression_recalc_bridge.py` applies perk timeline counts via `apply_perk_counts_to_account_state()`.
   - Runtime recalculation therefore depends on a transient synthetic preset name rather than one of the canonical five.

131. **State identity and stat-input compilation treat synthetic perk presets as normal presets**
   - `engine/state_identity.py` fingerprints `resolved_perk_preset` and serialized perk selections without rejecting non-canonical preset names.
   - Synthetic preset namespaces therefore flow into cache identity and runtime binding as if they were first-class presets.

132. **Tests encode the wrong preset model as expected behavior**
   - `tests/test_progression_state.py` only asserts preset support for:
     - Farming
     - Tourney
     - Milestone
   - There are no equivalent progression tests for `Preset 4` or `Preset 5`.

133. **Tests explicitly endorse synthetic compare-state namespaces**
   - `tests/test_smoke.py` expects compare matrix states:
     - `farming__perks_off`
     - `farming__perks_on`
     - `tourney__perks_off`
     - `tourney__perks_on`
   - This bakes synthetic compare-state naming into the test suite.

134. **Tests explicitly endorse synthetic projected-max and progression-timeline preset names**
   - Examples include:
     - `ProjectedMax_AllAllowedExceptBanned`
     - `ProgressionTimeline_CurrentWave`
   - This means the verification layer is currently reinforcing non-canonical preset namespaces.

135. **Golden fixtures preserve stale raw preset labels (`Testing`)**
   - `tests/golden_account_state.json` still contains extensive `Testing` keys.
   - This is a fixture-level source-of-truth drift against the canonical `Milestone` contract.

136. **Repo contains duplicate debug UI implementations in two locations**
   - Both repo root (`debug_ui.py`) and `scripts/debug_ui.py` exist and carry similar preset logic.
   - This is stronger than a stale-version risk: it is duplicated executable logic in two paths.

137. **Verification can go green while preserving the wrong preset contract**
   - Because tests and fixtures currently encode:
     - three-preset progression support
     - synthetic compare states
     - synthetic perk preset namespaces
     - stale `Testing` fixture labels
   - passing tests is not strong evidence that five-preset support is correct.



### Source-of-truth duplication sweep
138. **Section layout truth is duplicated in four executable files**
   - The same `SectionSpec` / `SECTION_SPECS` block exists in:
     - `parsers/ids_parser.py`
     - `debug_ui.py`
     - `debug_ui_v5.py`
     - `scripts/debug_ui.py`
   - This is a direct duplicate-source-of-truth defect for IDS section boundaries.

139. **Workshop preset-column truth is duplicated in four places**
   - Fixed workshop preset maps appear in:
     - `compilers/account_state_compiler.py`
     - `debug_ui.py`
     - `debug_ui_v5.py`
     - `scripts/debug_ui.py`
   - The same column meaning is re-declared rather than sourced from one canonical contract.

140. **Canonical preset-name truth is duplicated and inconsistent**
   - Canonical five-preset list lives in `models/account_state.py::PRESET_NAMES`.
   - But additional preset truth exists in:
     - `_CARD_PRESET_ALIASES`
     - module raw-label maps
     - debug UI preset options
     - progression `MODE_IDS`
   - These are not guaranteed to stay in sync.

141. **Progression runtime has its own independent preset truth table**
   - `engine/progression_state.py::MODE_IDS` is another preset source of truth separate from `PRESET_NAMES`.
   - It supports only 3 presets and therefore conflicts with canonical five-preset intent.

142. **Repo root and scripts each contain their own debug UI logic**
   - `debug_ui.py`, `debug_ui_v5.py`, and `scripts/debug_ui.py` each embed section specs, preset options, and flattening behavior.
   - This is not just stale code; it is multiple executable consumers each carrying local schema truth.

143. **Golden fixture preserves stale raw/source labels as if canonical**
   - `tests/golden_account_state.json` contains:
     - `Testing`
     - `Placeholder 4th preset`
     - `Placeholder 5th preset`
   - This means fixture truth conflicts with canonical preset contract.

144. **Test suite partially encodes three-preset progression truth**
   - `tests/test_progression_state.py` asserts `Milestone` support but has no equivalent `Preset 4` / `Preset 5` progression expectations.
   - Verification truth is therefore narrower than the canonical preset contract.

145. **Test suite simultaneously encodes canonical and non-canonical preset namespaces**
   - Examples include:
     - canonical `Milestone`
     - synthetic compare states (`farming__perks_on`)
     - synthetic timeline preset (`ProgressionTimeline_CurrentWave`)
     - generated max preset (`ProjectedMax_AllAllowedExceptBanned`)
   - This makes the test layer a mixed source of truth rather than a clean validator.

146. **Raw IDS source labels are treated as truth in some places and as aliases in others**
   - `_IDS.csv` uses `Preset 3` and `Testing`.
   - Compiler normalizes those to `Milestone`.
   - Golden fixtures still preserve raw/stale variants.
   - Repo lacks one explicit mapping artifact that all layers consume.



### Additional state-collapse and verification-blindness defects
147. **Test helper compiles only the Farming preset by default**
   - `tests/helpers.py::_compiled_state()` always calls `compile_account_state(..., default_preset='Farming', ...)`.
   - Large parts of the test suite therefore exercise only Farming-centered state unless they explicitly override it.

148. **Verification helpers bias the repo toward Farming as canonical runtime state**
   - `tests/helpers.py::build_state()` and multiple tests build cached state only from the Farming default.
   - This can let non-Farming preset regressions go undetected while tests still pass.

149. **State identity collapses missing and empty card presets**
   - `bind_state_identity()` fingerprints `equipped_cards` using `account_state.card_presets.get(resolved_card_preset)`.
   - A missing card preset and an explicitly empty card preset both serialize as `null`/absence-equivalent in the identity payload rather than as distinct states.

150. **State identity is inconsistent across preset families**
   - `_serialize_module_preset()` fails closed when a module preset is missing.
   - `_serialize_perk_preset()` returns `[]` when a perk preset is missing.
   - Card presets use `.get(...)` with no explicit absence marker.
   - The same “missing preset” condition is therefore treated three different ways across families.

151. **Hybrid loadout state is allowed by default in both identity and stat-input compilation**
   - `bind_state_identity()` and `compile_stat_inputs()` independently resolve:
     - main preset
     - card preset
     - module preset
     - perk preset
   - This allows cross-family combinations that may not correspond to a single coherent user preset selection.

152. **`compile_stat_inputs()` silently defaults card/module/perk preset families instead of validating completeness**
   - `card_preset = ... or preset`
   - `module_preset = ... or preset`
   - `perk_preset = ... or active_perk_preset or preset`
   - Missing family-specific preset selection is silently converted into another preset rather than surfaced as incomplete state.

153. **State identity / stat-input binding can therefore hide preset-family drift**
   - Because each family silently resolves independently, a stale or missing card/module/perk preset can be masked by fallback to another preset name.
   - The resulting bound state may look valid while not representing the intended account configuration.



### Further collapse-of-state defects
154. **Timing engine silently defaults all preset-family names to the main preset**
   - `engine/timing_engine.py` builds state identity with:
     - `card_preset_name=card_preset_name or preset_name`
     - `module_preset_name=module_preset_name or preset_name`
     - `perk_preset_name=perk_preset_name or preset_name`
   - Missing family-specific preset selections are therefore silently collapsed into the main preset.

155. **Verification compare row lookup silently falls back from compare-state key to compare preset**
   - `engine/verification.py` uses:
     - `statbook_rows_by_preset.get(compare_state_key, statbook_rows_by_preset.get(compare_preset, {}))`
   - This collapses:
     - missing compare-state namespace
     - missing compare preset rows
     into a fallback lookup rather than surfacing a state mismatch.

156. **Run-stats compare helpers rely on default preset fallbacks throughout**
   - Examples include defaults like:
     - `_compare_preset_for_destination(..., default_preset='Farming')`
     - `package_stage_context.get('default_compare_preset', 'Farming')`
   - Missing compare policy or stage context therefore silently becomes Farming.

157. **Perks-enabled inference is still truthiness-based in multiple runtime paths**
   - `_perks_enabled_for_state()` returns `bool(active_perk_preset)` when `perk_state == 'auto'`.
   - A non-empty but stale/invalid active perk preset still counts as enabled.

158. **Tests hard-code Farming state construction across many runtime/incremental subsystems**
   - Multiple tests call `compile_account_state(..., default_preset='Farming')` directly.
   - This is broader than the helpers-only issue and makes non-Farming preset coverage structurally weak.

159. **Observed output artifacts preserve synthetic preset names as if canonical state**
   - Existing `out/*.json` diagnostics and closure reports include preset names like `ProjectedMax_AllAllowedExceptBanned`.
   - This means downstream artifacts reinforce synthetic namespaces instead of isolating them as transient compare/runtime internals.

160. **Compare/build helpers materialize only a subset of preset family state, then reuse it as if representative**
   - `_build_compare_rows_by_preset()` populates `active_cards_by_preset` and `active_modules_by_preset` only for materialized compare states.
   - Missing presets are not represented explicitly; they are simply absent from the compare context map.

161. **Cards/modules/perks use different missing-state semantics in downstream helpers as well as compiler**
   - Cards often use `.get(..., [])`-like semantics,
   - modules often fail closed,
   - perks often use truthiness / fallback or `[]`.
   - This inconsistency is repeated beyond compiler code into timing, state identity, and compare helpers.



### Final Pass 2 collapse-of-state additions
162. **Timing and progression recalc bridges repeat preset-family fallback collapse**
   - `engine/timing_engine.py` and `engine/progression_recalc_bridge.py` both pass:
     - `card_preset_name or preset_name`
     - `module_preset_name or preset_name`
     - `perk_preset_name or preset_name`
   - This duplicates the same missing-family -> main-preset collapse in additional runtime paths.

163. **Verification compare lookup collapses missing compare-state namespace into preset rows**
   - `engine/verification.py` falls back from `compare_state_key` to `compare_preset` rows.
   - This can hide compare-state construction bugs and make synthetic-state omissions invisible.

164. **Perk timeline generator collapses banned/filtered exhaustion into a benign empty result**
   - `engine/perk_timeline_generator.py` returns `([], {"enabled": True, "reason": "empty_pool_after_bans"})` when no perks remain.
   - This treats a potentially invalid or over-banned configuration as a successful empty timeline rather than a fail-closed error.

165. **Large parts of the incremental/runtime test stack exercise only Farming defaults**
   - Additional tests in:
     - `tests/test_incremental_parity_harness.py`
     - `tests/test_incremental_subset_executor.py`
     - `tests/test_incremental_overlay_publisher.py`
     - `tests/test_query_bundle_planner_stack.py`
     - `tests/test_runtime_consumer_executor.py`
     - `tests/test_progression_state.py`
     all build state with `default_preset='Farming'`.
   - This amplifies non-Farming verification blindness across runtime and incremental paths.

166. **Tests explicitly accept synthetic progression timeline preset as normal patched state**
   - `tests/test_progression_recalc_bridge.py` asserts that patched state uses `ProgressionTimeline_CurrentWave`.
   - Verification therefore endorses synthetic preset injection into account-state-like runtime objects.

167. **Perk-scaling tests endorse generated projected-max preset as expected preset name**
   - `tests/test_perk_scaling.py` asserts rows have `preset_name == 'ProjectedMax_AllAllowedExceptBanned'`.
   - This makes non-canonical generated preset names part of the expected verification contract.

168. **Collapse-of-state semantics are repeated across compiler, runtime, verification, and tests**
   - The same family of collapses now appears in:
     - compiler binding
     - state identity
     - timing/progression bridges
     - verification compare lookup
     - test helpers and runtime tests
   - This is now a repo-wide semantic pattern, not an isolated implementation mistake.



### Pass 3 visibility-loss / selected-only state defects
169. **Compare fit matrix only evaluates Farming/Tourney states**
   - `run_stats.py::_build_compare_situation_fit_matrix()` builds only:
     - `farming__perks_off`
     - `farming__perks_on`
     - `tourney__perks_off`
     - `tourney__perks_on`
   - `Milestone`, `Preset 4`, and `Preset 5` are invisible to this diagnostic surface.

170. **Compare/projection diagnostics are not five-preset-complete**
   - `run_stats.py` emits `ep_compare_projection_views` with:
     - `current_state_mode`
     - `projected_max_progression`
   - This is a compare-oriented subset, not a full five-preset visibility surface.

171. **Compare row materialization is demand-driven, not completeness-driven**
   - `_build_compare_rows_by_preset()` only materializes preset/state rows required by the EP oracle and compare overrides.
   - Presets not referenced by compare policy are simply absent from the compare row map.

172. **Diagnostics expose configured perk presets but not full canonical preset completeness**
   - `run_stats.py` emits `configured_perk_presets` as the currently stored preset keys only.
   - There is no explicit diagnostic asserting whether all five canonical presets exist for perks.

173. **Diagnostics expose card preset sizes only for present presets**
   - `run_stats.py` emits `card_preset_sizes = {name: len(cards) for name, cards in account_state.card_presets.items()}`.
   - Missing preset lanes are not represented explicitly as zero or absent-with-warning.

174. **Diagnostics expose compare/materialized active preset context, not full family matrix**
   - `active_cards_by_preset` and `active_modules_by_preset` in compare stage context are built only for materialized compare states.
   - This makes the diagnostic layer selected-state-oriented rather than full-state-oriented.

175. **Golden account-state fixture is more visibility-complete than exported CSV for empty module presets**
   - `tests/golden_account_state.json` explicitly contains `null` primary/assist entries for `Preset 4` and `Preset 5`.
   - The debug/export CSV omits those empty preset rows entirely.
   - Repo therefore has conflicting visibility contracts for the same module preset emptiness.

176. **Visibility contract differs between canonical JSON artifacts and debug/export CSV**
   - Canonical-ish JSON artifacts preserve explicit null/empty structure in some families.
   - Debug/export CSV often emits populated rows only.
   - This creates a cross-artifact visibility-loss bug: two outputs from the repo expose different completeness semantics.



### Further Pass 3 visibility-loss defects in debug/query surfaces
177. **Query preview hides `preset_name` even though flattened query rows carry it**
   - `flatten_query_rows()` includes a `preset_name` column.
   - `query_preview_df()` does not display it.
   - This means preset-scoped QE rows are rendered without their preset identity.

178. **Query preview hides contributor/resolver identity needed for full audit**
   - `flatten_query_rows()` includes:
     - `contributor_id`
     - `resolver_id`
     - `notes`
     - `provenance`
   - `query_preview_df()` omits these fields.
   - QE preview therefore suppresses key audit/debug information already present in the flattened data.

179. **Compiled preview suppresses enhancement preset/completeness structure**
   - `compiled_preview_df("Enhancements")` reduces rows to `Enhancement`, `Value`, `Max`.
   - If WS+ is preset-indexed or multi-column, the compiled preview hides that structure entirely.

180. **Compiled preview suppresses module/system-state detail**
   - `compiled_preview_df("Modules")` shows only `family`, `name`, `value`, `preset`, `detail`.
   - It does not expose:
     - module system state
     - empty preset slots
     - full preset-slot matrix
   - The compiled preview is therefore inventory-oriented, not state-complete.

181. **Compiled preview suppresses card-slot-capacity context**
   - `compiled_preview_df("Cards")` shows card rows but does not include `card_slots_unlocked`.
   - Card completeness cannot be audited from the compiled preview alone.

182. **Debug preview surfaces are row-truncated by default**
   - `ids_preview_df()`, `compiled_preview_df()`, and `query_preview_df()` all end with `.head(...)`.
   - This means large sections can hide relevant rows simply because they occur later in the section.

183. **Raw IDS flattening truncates many sections to first 40 rows**
   - `flatten_ids_levels()` uses repeated `rows[:40]` slices for multiple families.
   - This is another visibility loss layer before preview rendering.

184. **UW IDS flattening truncates to first 16 rows**
   - `flatten_ids_levels()` uses `uw_rows = rows[:16]`.
   - If the source section layout expands, later rows become invisible to the debug surface.

185. **Preview HTML/table rendering defaults to head(max_rows)**
   - `_preview_html_string()` / `_render_html_table()` display only the top subset of rows.
   - This compounds the row-truncation problem in visual inspection.

186. **Debug surfaces bias toward “top rows” rather than completeness indicators**
   - There is no explicit warning or completeness marker when rows are truncated by `.head(...)` or `[:40]`.
   - Users can therefore mistake a partial preview for a complete family view.



### Additional Pass 3 visibility-loss defects in optimizer / overlay / artifact outputs
187. **Optimizer score output omits preset and state-mode provenance**
   - `optimizer/scorer.py::compute_optimizer_scores()` returns objective scores and generic meta only.
   - It does not record:
     - preset
     - card/module/perk preset family selections
     - state mode
   - The score artifact therefore cannot be audited back to an exact preset-state context.

188. **Optimizer path outputs omit preset/runtime context**
   - `optimizer/path_ranker.py::rank_lab_path()` returns rows with:
     - step
     - lab
     - level
     - roi_per_day
     - delta_pct
     - score
   - It does not emit the preset/state context used to generate the path.
   - Path results are therefore context-thin and hard to compare across presets.

189. **Incremental overlay diagnostics expose published nodes only, not omitted context**
   - `engine/incremental_overlay_publisher.py` records only:
     - `published_nodes`
     - status
     - sharing mode
   - It does not record:
     - reference preset/state context
     - which nodes remained inherited
     - whether candidate rows covered all preset-relevant nodes
   - Overlay diagnostics are therefore selected-node-oriented rather than completeness-oriented.

190. **Run-stats output set lacks a full canonical preset completeness artifact**
   - `run_stats.py` writes many JSON artifacts, but none provide a single explicit matrix of:
     - all five canonical presets
     - cards/modules/perks/workshop completeness per preset
   - Users must infer completeness indirectly from partial artifacts.

191. **Diagnostics summarize counts and active contexts more than full family matrices**
   - Examples include:
     - `card_preset_sizes`
     - `active_perk_preset`
     - `active_card_preset`
     - `active_module_preset`
     - compare summaries
   - These are useful, but they are not full visibility surfaces for five-preset completeness.

192. **Artifact set mixes canonical-state, compare-state, and publishable-state outputs without a single visibility contract**
   - `run_stats.py` writes:
     - `account_state.json`
     - `statbook.json`
     - `statbook_publishable.json`
     - `ep_oracle_compare.json`
     - diagnostics and gap reports
   - Each artifact exposes different subsets and semantics, but there is no explicit machine-readable contract explaining which is the full-state truth surface.



### Final Pass 3 visibility-loss additions
193. **Runtime request objects are selected-context only, not full preset-state carriers**
   - `engine/timing_engine.py::TimingRequest` and `engine/progression_recalc_bridge.py::ProgressionRecalcRequest` carry:
     - one `preset_name`
     - optional `card_preset_name`
     - optional `module_preset_name`
     - optional `perk_preset_name`
   - They cannot represent the full five-preset family matrix, only the currently selected context.

194. **Scenario config exposes only a single mode context**
   - `engine/scenario_engine.py::ScenarioConfig` models one `mode_id` (`farming | tournament | milestone`) plus one tier/league context.
   - This is fine for execution, but it is another surface that cannot act as a full preset visibility artifact and can be mistaken for one.

195. **Baseline materialization surfaces are selected-state only**
   - Timing/progression baseline materializers and runtime consumer execution operate on a single bound request context.
   - They do not emit explicit metadata describing omitted presets or omitted family-state lanes.
   - Downstream diagnostics built from these paths are therefore inherently selected-state views unless explicitly supplemented.

196. **No artifact explicitly states “this is a partial selected-context view”**
   - Across timing, progression, compare, optimizer, and debug outputs, selected-context artifacts are rarely labeled as partial views.
   - This is a visibility-loss bug because users can mistake an execution-context artifact for a completeness artifact.



### Pass 4 synthetic namespace / mutation defects
197. **Compare-state namespaces are synthesized as if they were preset-like row keys**
   - `run_stats.py::_build_compare_rows_by_preset()` creates keys such as:
     - `Farming__perks_on`
     - `Farming__perks_off`
     - `Tourney__perks_on`
     - `Tourney__perks_off`
   - These synthetic names are then used as row-map keys and flow into compare logic as if they were normal preset scopes.

198. **Synthetic compare-state keys are mixed into preset-indexed collections**
   - `compare_rows_by_preset` and `compare_publishable_rows_by_preset` store both canonical preset keys and synthetic compare-state keys in the same dictionary.
   - This blurs the boundary between real preset identity and compare execution state.

199. **Generated projected-max perk preset mutates durable config files**
   - `run_stats.py::_build_generated_max_progression_perk_config()` writes:
     - `input/perks_projected_max.json`
     - `input/perks_projected_max.timeline.json`
     - `input/perks_projected_max.final_state.json`
     - `input/perks_projected_max.diagnostics.json`
   - A synthetic preset namespace is therefore persisted to repo input artifacts, not kept as a transient runtime object.

200. **Synthetic projected-max preset becomes active preset state**
   - The generated config sets:
     - `active_perk_preset = "ProjectedMax_AllAllowedExceptBanned"`
   - This injects a non-canonical preset directly into normal active-preset flows.

201. **Progression timeline patch mutates AccountState in place with a synthetic active preset**
   - `engine/perk_timeline_state.py::apply_perk_counts_to_account_state()` writes a synthetic preset into `account_state.perk_presets` and sets `active_perk_preset` to it.
   - This mutates a canonical-looking state object with a non-canonical namespace.

202. **Synthetic preset namespaces are accepted by state identity without quarantine**
   - `engine/state_identity.py` fingerprints resolved preset names and serialized perk selections without rejecting or tagging non-canonical preset namespaces.
   - Synthetic runtime names therefore influence identity as if they were user presets.

203. **Synthetic namespaces are verified as expected behavior in tests**
   - The test layer expects names like:
     - `ProjectedMax_AllAllowedExceptBanned`
     - `ProgressionTimeline_CurrentWave`
     - `farming__perks_on`
   - This upgrades transient/internal namespaces into verification-time contract.

204. **Run-stats compare logic mutates semantic meaning of preset through perk-state suffixing**
   - A preset plus perk-state becomes a new synthetic state key rather than remaining a canonical preset with separate state metadata.
   - This is a design mutation: state dimensions are encoded into the preset namespace itself.

205. **Synthetic namespaces are inconsistently isolated**
   - Some synthetic names live only in compare maps,
   - some are written into account-state-like objects,
   - some are written to disk as input/config artifacts,
   - some are expected in tests.
   - The repo lacks a rule for which synthetic namespaces are allowed where.

206. **No canonical/non-canonical namespace discriminator exists**
   - There is no explicit field or type tag separating:
     - canonical presets
     - synthetic compare states
     - generated projected-max presets
     - progression-timeline transient presets
   - Consumers must infer namespace meaning from string shape alone.



### Pass 4 continued: synthetic/stale namespace persistence in generated artifacts
207. **Generated `out/account_state.json` persists stale raw module preset labels alongside canonical state**
   - Observed artifact contains:
     - `Testing`
     - `Placeholder 4th preset`
     - `Placeholder 5th preset`
   - This means post-compile/generated account-state artifacts still preserve non-canonical source labels instead of a clean canonical preset contract.

208. **Generated `out/account_state.json` persists synthetic active perk preset as normal account state**
   - Observed artifact contains:
     - `active_perk_preset = "ProjectedMax_AllAllowedExceptBanned"`
   - Synthetic projected-max namespace is therefore serialized into canonical-looking output state.

209. **Generated diagnostics persist synthetic compare-state namespaces as normal state keys**
   - `out/diagnostics.json` contains keys like:
     - `farming__perks_off`
     - `farming__perks_on`
     - `tourney__perks_off`
     - `tourney__perks_on`
   - Synthetic compare-state namespaces are therefore exported as ordinary diagnostic state keys without canonical/non-canonical separation.

210. **Generated diagnostics persist synthetic projected-max preset names into row-level provenance**
   - `out/diagnostics.json` contains many rows with:
     - `preset_name = "ProjectedMax_AllAllowedExceptBanned"`
   - Synthetic preset namespaces therefore leak into downstream provenance fields as if they were normal preset identities.

211. **Generated outputs mix canonical, stale-source, and synthetic namespaces in the same artifact family**
   - Example observed together in `out/account_state.json` / `out/diagnostics.json`:
     - canonical: `Milestone`
     - stale/raw: `Testing`, `Placeholder 4th preset`, `Placeholder 5th preset`
     - synthetic: `ProjectedMax_AllAllowedExceptBanned`, `farming__perks_off`
   - This is a strong artifact-level namespace contract failure.

212. **Artifact writers do not normalize or quarantine namespace classes before serialization**
   - `run_stats.py` writes account/diagnostic artifacts directly from in-memory state and compare structures.
   - There is no final serialization boundary that:
     - strips stale raw labels
     - rejects synthetic preset names from canonical outputs
     - tags non-canonical namespaces explicitly.

213. **Repo `out/` directory itself acts as a stale synthetic namespace carrier**
   - Checked generated artifacts already present in the repo preserve:
     - stale raw preset labels
     - synthetic projected-max preset names
     - synthetic compare-state keys
   - This means repository state can continue to reinforce wrong contract semantics even before a new run occurs.



### Pass 4 continued: synthetic/stale namespace re-consumption defects
214. **Generated projected-max preset is re-consumed as a normal perks input source**
   - `tests/test_perk_scaling.py` and runtime paths load `input/perks_projected_max.json` directly.
   - A synthetic preset namespace is therefore not just generated once; it becomes a normal re-consumed input artifact.

215. **Synthetic compare-state namespaces are re-consumed by verification logic**
   - `engine/verification.py` computes `compare_state_key` and then looks rows up by that synthetic key.
   - Synthetic compare-state names are therefore not only produced, but actively required by later verification logic.

216. **Re-consumption path strips synthetic suffix back to canonical preset name ad hoc**
   - `run_stats.py` later derives `base_preset_name = preset_name.split('__perks_', 1)[0]`.
   - This shows the repo must reverse its own synthetic namespace encoding manually, which is a strong smell of improper namespace mutation.

217. **Observed compare artifacts mix uppercase and lowercase synthetic namespace variants**
   - Examples seen across artifacts/tests include:
     - `Farming__perks_on`
     - `farming__perks_on`
   - Namespace casing is not consistently normalized, which creates another synthetic-state identity hazard.

218. **Synthetic compare-state namespaces leak into downstream reports as if they were canonical state identifiers**
   - Reports such as:
     - `out/tower_regen_closure_report.json`
     - `out/tower_hp_semantic_gap_report.json`
     - `out/tower_damage_runtime_gap_report.json`
     contain `compare_state_key` values using synthetic namespaces.
   - Report consumers must therefore understand synthetic compare naming to interpret results.

219. **Synthetic/stale namespace values are embedded in checked-in `out/ep_oracle_compare.json`**
   - Observed artifact includes:
     - `compare_state_key` with synthetic compare states
     - many `preset_name = ProjectedMax_AllAllowedExceptBanned`
   - This makes the compare artifact itself a carrier of non-canonical namespace semantics.

220. **Tests explicitly assert synthetic compare-state keys in report outputs**
   - `tests/test_verification_module.py` and `tests/test_perk_scaling.py` assert values such as:
     - `farming__perks_off`
     - `Farming__perks_on`
   - Synthetic compare-state naming is therefore promoted into report-level contract expectations.

221. **Stale raw module preset labels are re-consumed by golden fixture comparisons**
   - `tests/golden_account_state.json` still uses `Testing` and placeholder preset labels and is used for fixture comparison.
   - This means stale raw labels are not just stored; they are re-consumed as expected truth in verification.

222. **No artifact or test layer enforces canonical-only preset namespaces at serialization boundaries**
   - Generated inputs, generated outputs, tests, and golden fixtures all accept a mixture of:
     - canonical
     - stale raw-source
     - synthetic runtime/compare
   - The repo has no final “namespace hygiene” gate anywhere in the pipeline.



### Final Pass 4 namespace-hygiene boundary defects
223. **`out/statbook_publishable.json` persists synthetic projected-max preset names inside publishable contributors**
   - Observed artifact contains many contributor rows with:
     - `preset_name = "ProjectedMax_AllAllowedExceptBanned"`
   - Synthetic preset namespaces therefore penetrate the publishable stat artifact itself, not just compare/diagnostic outputs.

224. **Namespace hygiene failure spans multiple output artifact classes simultaneously**
   - Observed synthetic/stale namespace leakage now exists in:
     - `out/account_state.json`
     - `out/diagnostics.json`
     - `out/ep_oracle_compare.json`
     - `out/stat_inputs.json`
     - `out/statbook_publishable.json`
     - semantic-gap / closure reports
   - There is no artifact family currently enforcing canonical-only preset/state namespaces.

225. **Canonical-state, publishable-state, and compare-state artifacts are all carrying synthetic preset namespaces**
   - Synthetic names such as:
     - `ProjectedMax_AllAllowedExceptBanned`
     - `Farming__perks_on`
     - `farming__perks_off`
   - appear across artifacts that should have distinct contracts.
   - This means namespace class boundaries are not respected anywhere in serialization.

226. **Observed synthetic compare-state casing is inconsistent across persisted artifacts and tests**
   - Both `Farming__perks_on` and `farming__perks_off` style variants are present in persisted outputs/tests.
   - String-case is therefore part of an unstable implicit namespace contract.

227. **No final serialization gate normalizes stale raw preset labels from fixtures/source into canonical names**
   - Persisted outputs still show raw/stale labels such as:
     - `Testing`
     - `Placeholder 4th preset`
     - `Placeholder 5th preset`
   - This proves there is no final “canonicalize-or-reject” boundary before writing artifacts.

228. **Pass 4 evidence now covers full synthetic namespace lifecycle**
   - Synthetic/stale namespaces are now evidenced across:
     - creation
     - mutation into account-state-like objects
     - persistence to input/config files
     - serialization to outputs
     - re-consumption by runtime/tests
     - verification expectations
   - This is the closure condition for the synthetic namespace / mutation defect family.



### Verification drift / fixture close-out defects
229. **Fixtures and generated outputs encode two incompatible preset contracts simultaneously**
   - `tests/golden_account_state.json` preserves stale/raw labels such as:
     - `Testing`
     - `Placeholder 4th preset`
     - `Placeholder 5th preset`
   - `out/account_state.json` preserves canonicalized labels such as:
     - `Milestone`
   - Verification is therefore split across stale-source and canonical namespace contracts.

230. **Golden fixture still treats stale module preset labels as expected truth**
   - `tests/golden_account_state.json` uses `Testing` heavily in module preset structures and empty preset slots.
   - This means fixture comparison can still validate stale raw namespace behavior after canonicalization work elsewhere.

231. **Generated account-state artifact and golden fixture disagree on third-preset identity**
   - Generated `out/account_state.json` uses `Milestone`.
   - Golden fixture uses `Testing`.
   - The repo therefore lacks one verification-time answer to “what is the third canonical preset called?”

232. **Verification stack mixes canonicalized and non-canonicalized artifacts without an explicit reconciliation rule**
   - Example artifact families:
     - canonicalized-ish: `out/account_state.json`
     - stale/raw fixture: `tests/golden_account_state.json`
     - synthetic compare/report artifacts: `out/ep_oracle_compare.json`, diagnostics reports
   - There is no explicit rule telling tests or reviewers which namespace contract should win.

233. **Report/tests still lock in synthetic compare-state naming as expected output contract**
   - Tests such as `tests/test_verification_module.py` and `tests/test_smoke.py` assert synthetic compare-state keys.
   - Even if runtime/serialization were cleaned, verification would still pull behavior back toward synthetic namespace expectations.

234. **Progression verification still codifies three-preset support**
   - `tests/test_progression_state.py` explicitly checks `Milestone` support but has no equivalent assertions for `Preset 4` or `Preset 5`.
   - This leaves the verification contract narrower than the canonical five-preset requirement.

235. **Large sections of runtime/incremental tests remain Farming-biased and therefore under-detect preset-contract drift**
   - Multiple tests construct state with `default_preset='Farming'` across incremental/runtime helpers.
   - This means verification drift is not just stale naming; it is also systematic under-coverage of non-Farming preset behavior.

236. **There is no dedicated test or artifact asserting full five-preset completeness per family**
   - No single verification surface currently proves, for each family, that:
     - all five canonical presets exist
     - empty presets are explicitly represented
     - empty slots are explicitly represented where applicable
   - This is the final verification-gap finding needed before close-out.

237. **Verification drift family is now evidenced across tests, fixtures, and checked-in artifacts**
   - Evidence now exists in:
     - test helpers
     - runtime/incremental tests
     - golden fixtures
     - checked-in `out/` artifacts
     - compare/report outputs
   - This is the closure condition for the verification-drift / fixture defect family.


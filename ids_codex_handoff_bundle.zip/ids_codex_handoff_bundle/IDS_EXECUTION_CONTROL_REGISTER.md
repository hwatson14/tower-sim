# IDS Execution Control Register

Purpose: Codex-facing execution control plane derived from the normalized master bug register and raw discovery ledger.

Canonical preset contract:
- Tourney
- Farming
- Milestone
- Preset 4
- Preset 5

Primary evidence:
- `ids_pipeline_bug_ledger_v19.md`
- `ids_pipeline_normalized_master_register.md`

## Operating rules

1. Fix root causes in dependency order. Do not jump ahead to downstream cleanup.
2. No new local truth tables for presets, section specs, or runtime mode maps.
3. No fail-open fallbacks for missing/invalid preset-family state unless the tranche explicitly defines that behavior.
4. No synthetic namespaces in canonical artifacts.
5. Partial/selected-context artifacts must be explicitly labeled as partial.
6. Tests and fixtures must follow the canonical five-preset contract unless explicitly marked as transient-runtime tests.

## Status key

- **Decision required**
- **Schema required**
- **Codex-ready after dependency**
- **Codex-ready**
- **Post-contract cleanup**
- **Blocked**
- **Closed**

## Tranche dependency spine

1. `TRANCHE_IDS_C1_CONTRACT_REGISTRY`
2. `TRANCHE_IDS_C5_STATE_SEMANTICS`
3. `TRANCHE_IDS_C2_RUNTIME_FIVE_PRESET`
4. `TRANCHE_IDS_C11_PERK_PRESET_CONTRACT`
5. `TRANCHE_IDS_C12_NAMESPACE_HYGIENE`
6. `TRANCHE_IDS_C10_CLEAN_SECTION_INGESTION`
7. `TRANCHE_IDS_C7_WSPLUS_TYPED_MODEL`
8. `TRANCHE_IDS_C8_UW_TYPED_TRACKS`
9. `TRANCHE_IDS_C9_BOT_TYPED_STATE`
10. `TRANCHE_IDS_C13_AUDIT_SURFACE_CONTRACTS`
11. `TRANCHE_IDS_C14_ARTIFACT_OUTPUT_CONTRACTS`
12. `TRANCHE_IDS_C15_VERIFICATION_REALIGNMENT`
13. `TRANCHE_IDS_C16_COMPLETENESS_MATRIX`

## Register

| Cluster | Tranche ID | Title | Hard deps | Soft deps | Execution status | Decision payload required | Primary fix layer | Do-not-fix-here | Acceptance artifacts | Closure scope | Merge gate | Non-goals | Burndown state |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| C1 | TRANCHE_IDS_C1_CONTRACT_REGISTRY | Canonical preset and schema registry | none | none | Decision required | canonical registry shape, canonical preset names, section-schema ownership model | contract layer | do not patch debug UI first | `registry/preset_contract.yaml`; `registry/section_layout_contract.yaml`; `tests/test_preset_contract_registry.py` | contract + tests | human review required | optimizer redesign; artifact cleanup | not started |
| C5 | TRANCHE_IDS_C5_STATE_SEMANTICS | Missing/empty/invalid state semantics | C1 | C2 | Decision required | exact semantics for missing vs empty vs zero vs invalid vs synthetic | binding/validation layer | do not add more fallbacks | `docs/state_semantics.md`; `tests/test_state_semantics.py`; identity diff fixture proving missing != empty != zero | implementation + tests | human review required | UI polish | not started |
| C2 | TRANCHE_IDS_C2_RUNTIME_FIVE_PRESET | Runtime and progression five-preset support | C1, C5 | none | Codex-ready after dependency | none once C1/C5 settled | runtime/progression | do not solve only in tests | `engine/progression_state.py`; `tests/test_progression_state.py`; runtime acceptance matrix artifact for all 5 presets | implementation + tests + artifact | human review required | compare cleanup | not started |
| C11 | TRANCHE_IDS_C11_PERK_PRESET_CONTRACT | Perk preset contract normalization | C1, C5 | C2 | Decision required | whether perks permit any transient non-canonical namespace, and where | perk config + binding layer | do not preserve `default` as hidden sixth preset | `compilers/account_state_compiler.py`; `engine/query_perk_compiler.py`; `tests/test_perk_preset_contract.py` | implementation + tests | human review required | timeline math changes | not started |
| C12 | TRANCHE_IDS_C12_NAMESPACE_HYGIENE | Synthetic namespace quarantine and hygiene | C1, C5, C11 | C2 | Codex-ready after dependency | canonical vs transient namespace class policy | namespace hygiene boundary + artifact writers | do not just rename strings in reports | `docs/namespace_hygiene.md`; `tests/test_namespace_hygiene.py`; regenerated artifacts proving no synthetic names in canonical outputs | implementation + tests + regenerated artifacts | human review required | compare-score tuning | not started |
| C10 | TRANCHE_IDS_C10_CLEAN_SECTION_INGESTION | Relics/Vault fact-only compiler ingestion | C1 | C5 | Codex-ready after dependency | none | compiler | do not rely on downstream blacklists | `compilers/account_state_compiler.py`; `tests/test_relics_vault_fact_ingestion.py` | implementation + tests | PR review | UI category display | not started |
| C7 | TRANCHE_IDS_C7_WSPLUS_TYPED_MODEL | WS+ typed model and QE routing | C1, C5 | C13 | Schema required | exact WS+ typed schema incl preset-indexed fields and extra columns | compiler + QE | do not keep first-parseable-float heuristics | typed WS+ model file/contract; `tests/test_wsplus_typed_model.py`; QE artifact showing preset-sensitive rows | implementation + tests + artifact | human review required | generic preview cosmetics | not started |
| C8 | TRANCHE_IDS_C8_UW_TYPED_TRACKS | UW explicit track identity | C1 | C5 | Codex-ready after dependency | none | compiler/UW model | do not keep positional zipping | `tests/test_uw_typed_tracks.py`; export rows contain attribute names | implementation + tests | PR review | compare policy changes | not started |
| C9 | TRANCHE_IDS_C9_BOT_TYPED_STATE | Bot typed compiled state | C1 | C5 | Codex-ready after dependency | none | compiler/bot model | do not leave export meaning implicit | `tests/test_bot_typed_state.py`; compiled/exported rows show level + resolved value + unit | implementation + tests | PR review | bot balancing | not started |
| C13 | TRANCHE_IDS_C13_AUDIT_SURFACE_CONTRACTS | Full vs partial audit surface contracts | C1, C5 | C12 | Design required | which surfaces are canonical/full vs partial/selected-context | output contract layer | do not fix by adding more hidden truncation | `docs/audit_surface_contracts.md`; `tests/test_audit_surface_contracts.py`; one full completeness artifact exists | design + implementation + tests | human review required | theme/styling | not started |
| C14 | TRANCHE_IDS_C14_ARTIFACT_OUTPUT_CONTRACTS | Artifact classes and provenance | C1, C5, C12, C13 | C2 | Codex-ready after dependency | artifact class taxonomy | run_stats/output writers | do not leave provenance implicit | `docs/artifact_contracts.md`; `tests/test_artifact_contracts.py`; regenerated artifact set with class/provenance fields | implementation + tests + regenerated artifacts | human review required | optimizer math | not started |
| C15 | TRANCHE_IDS_C15_VERIFICATION_REALIGNMENT | Tests, fixtures, and false-green cleanup | C1, C2, C5, C11, C12, C13, C14 | C16 | Post-contract cleanup | fixture refresh policy | test/fixture layer | do not update tests before contracts settle | refreshed golden fixtures; `tests/test_five_preset_completeness.py`; removed stale/synthetic expectations from canonical tests | implementation + tests + fixture refresh | human review required | new feature tests | not started |
| C16 | TRANCHE_IDS_C16_COMPLETENESS_MATRIX | Full family completeness artifact and CI gate | C1, C5, C13, C14 | C15 | Codex-ready after dependency | exact matrix schema | audit/verification artifact layer | do not infer completeness from partial views | `out/family_completeness_matrix.json`; `tests/test_family_completeness_matrix.py`; CI gate | implementation + tests + CI | human review required | unrelated dashboards | not started |
| C3 | TRANCHE_IDS_C3_POSITIONAL_SCHEMA_REMOVAL | Remove hard-coded positional schema | C1 | C7, C8, C9, C10 | Codex-ready after dependency | none | compiler/parser cleanup | do not patch positions in every consumer separately | `tests/test_schema_header_driven_parsing.py` | implementation + tests | PR review | UI-only refactors | not started |
| C4 | TRANCHE_IDS_C4_RAW_TABLE_TYPE_UPLIFT | Replace raw-table deferred interpretation | C1 | C7, C10 | Codex-ready after dependency | typed family boundary policy | compiler/account-state normalization | do not keep reparsing in QE/UI | `tests/test_typed_family_models.py` | implementation + tests | PR review | historical archive formats | not started |
| C6 | TRANCHE_IDS_C6_BOUND_PRESET_FAMILY_OBJECT | Bound preset-family execution object | C1, C5, C11 | C2, C12 | Codex-ready after dependency | hybrid-state policy | state binding / request construction | do not continue independent family fallback binding | `tests/test_bound_preset_family_object.py` | implementation + tests | human review required | execution scheduler changes | not started |

## Notes on tranche usage

- `C1`, `C5`, `C11`, `C13` contain policy/schema decisions and should not be merged until the decision payloads are explicitly answered.
- `C15` should remain blocked from closure until earlier contract tranches are stable.
- `C16` is the global close-out proof tranche.


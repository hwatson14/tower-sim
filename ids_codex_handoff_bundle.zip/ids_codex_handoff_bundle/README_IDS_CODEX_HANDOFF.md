# IDS Codex Handoff Bundle

This bundle is designed to be dropped into repo root.

## Files

- `IDS_EXECUTION_CONTROL_REGISTER.md` — Codex execution control plane
- `IDS_TRANCHE_CONTRACTS.md` — tranche-by-tranche contracts
- `IDS_CODEX_INSTRUCTIONS.md` — concise Codex operating instructions
- `ids_pipeline_normalized_master_register.md` — normalized bug clusters
- `ids_pipeline_bug_ledger_v19.md` — raw evidence ledger (if included)

## Recommended repo placement

Add these files to repo root so Codex can read them without hunting:
- `IDS_EXECUTION_CONTROL_REGISTER.md`
- `IDS_TRANCHE_CONTRACTS.md`
- `IDS_CODEX_INSTRUCTIONS.md`

Keep the normalized register and raw ledger as supporting evidence:
- `ids_pipeline_normalized_master_register.md`
- `ids_pipeline_bug_ledger_v19.md`

## Suggested first human actions

1. Confirm decision payloads for:
   - C1 canonical contract registry
   - C5 missing/empty/invalid semantics
   - C11 perk transient policy
   - C13 audit-surface contract

2. Mark tranche execution statuses accordingly.

3. Hand Codex the first unblocked tranche only.


r65 is the final PR/handoff pack.

It contains:
- the implementation-critical delta over the rebased cleanup baseline
- the later QE/KB rewiring and functional calculator closeout overlays
- updated checksums
- a final scope audit
- explicit AI merge/apply instructions
- exact validation commands
- KB additions summary

Use this as the single handoff artifact for branch application and PR preparation.

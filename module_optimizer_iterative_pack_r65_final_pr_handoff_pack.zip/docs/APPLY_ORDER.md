# Apply order

1. Baseline rebased cleanup repo
2. Overlay engine files
3. Overlay models and inputs
4. Overlay compilers
5. Overlay KB contracts/tables/notes
6. Overlay tests
7. Run validation

Why this order:
- engine/publication surfaces define the upstream availability
- models/inputs support downstream compilation
- compilers consume published surfaces
- KB files document and constrain truth after code is in place
- tests should be last so they match final code state
# KB additions summary

Newly added or consolidated KB areas in the later closing passes:
- module lab per-level semantics
- module drop economy truth
- mission economy truth
- draw policy truth
- reroll lock-cost ladder
- package draw-EV policy
- KB source-closure and QE-surface ledgers

Still explicit unresolved/non-goals:
- broader auto-roll timing/iteration model beyond shard spend
- any interpretation that differs from the explicit package policy for epic draw value and 10-pull EV
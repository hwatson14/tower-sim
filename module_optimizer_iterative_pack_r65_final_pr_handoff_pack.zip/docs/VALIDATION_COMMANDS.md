# Validation commands

Primary validated lane:
```bash
pytest -q tests/test_query_progression_runtime_publication.py          tests/test_phase3_contract_path.py          tests/test_wave_progression_policy.py          tests/test_module_*.py
```

Focused QE/KB/functional lanes:
```bash
pytest -q tests/test_module_functional_calculators.py          tests/test_module_qe_rewiring.py          tests/test_module_drop_economy_qe.py          tests/test_module_mission_economy_qe.py          tests/test_module_draw_and_reroll_policy_qe.py          tests/test_module_shard_income_exact_policy.py          tests/test_module_optimizer_richness.py
```
# AI merge instructions

## Goal
Apply this delta over the rebased cleanup baseline and validate the agreed target lane.

## Intended baseline
`current_main_rebased_cleanup_v3`

## What is inside this pack
- `delta/repo_patch/...`: implementation-critical delta to overlay on the baseline
- `scripts/apply_r54_delta.py`: overlays the delta onto a copy of a baseline repo directory
- `scripts/validate_r54_delta.sh`: runs the validated lane
- `docs/FINAL_SCOPE_AUDIT.md`: final scope status
- `docs/APPLY_ORDER.md`: merge/apply sequence
- `docs/VALIDATION_COMMANDS.md`: exact validation commands
- `docs/KB_ADDITIONS_SUMMARY.md`: newly added KB truths and unresolved items

## Merge/apply sequence
1. Start from a clean checkout of the rebased cleanup baseline.
2. Apply the delta overlay from `delta/repo_patch/` onto the repo root.
3. Review any collisions, but prefer the delta contents for files present in this pack.
4. Run the validated lane exactly as documented.
5. If green, do a final diff review focused on:
   - engine/query_* publication changes
   - compilers/module_* changes
   - kb/modules/contracts and tables additions
   - tests additions

## Important interpretation rules
- Manual values that remain allowed must still flow through inputs -> QE surfaces -> calculators.
- Labs are not manual. They must come from account/lab state and QE publication.
- Tier handling for drop tables must use canonical runtime/tiers, not planner overrides.
- Exactness marked under package policy is intentional and explicit in KB.
# Final scope audit

Original five missing functional items and current status:

| Item | Status | Verification | Remaining caveat |
|---|---|---|---|
| Reroll income calculator | Implemented and mostly QE/KB wired | QE rewiring and drop-economy tests in later tranches | Final branch-level proof still required |
| Module shard income calculator | Implemented and closed under explicit package draw-EV policy | Mission economy, draw policy, and exact package-policy EV tests added in r60/r61/r63 | Exactness is package-policy exact, not universally game-exact |
| Primary vs assist optimiser | Implemented and materially closed | Richness tests in r64 | Depends on upstream candidate metadata richness |
| Substat optimiser | Implemented and materially closed | Richness tests in r64 | Depends on upstream candidate metadata richness |
| Reroll spend calculator | Implemented and closed for current lock-ladder scope | r61 exact wiki lock ladder tests | Auto-roll timing/iteration model remains out of scope |

Additional critical supporting scope:

| Area | Status | Verification |
|---|---|---|
| Runtime/profile publication | Implemented | Green in targeted integrated lane proven earlier |
| Phase3 contract path | Implemented | Green in targeted integrated lane proven earlier |
| Wave progression policy | Implemented | Green in targeted integrated lane proven earlier |
| Full module suite on local integrated overlay | Green | 104 passed reported in prior integrated state |
| Combined targeted integrated lane on local overlay | Green | 126 passed reported in prior integrated state |

What is still not fully proven:
- final real-branch application over the actual rebased-cleanup branch
- broader repo interactions outside the validated lane
- final PR branch review/cleanup after application

Practical verdict:
- Functional backlog is materially closed.
- Handoff/merge backlog still needs the real branch application and lane execution.
from __future__ import annotations
import shutil
from pathlib import Path
import sys

def main() -> int:
    if len(sys.argv) != 3:
        print("Usage: python apply_r54_delta.py <baseline_repo_dir> <output_repo_dir>")
        return 2

    baseline = Path(sys.argv[1]).resolve()
    output = Path(sys.argv[2]).resolve()
    delta_root = Path(__file__).resolve().parents[1] / "delta" / "repo_patch"

    if not baseline.exists():
        print(f"Baseline repo dir not found: {baseline}")
        return 2
    if not delta_root.exists():
        print(f"Delta root not found: {delta_root}")
        return 2

    if output.exists():
        shutil.rmtree(output)
    shutil.copytree(baseline, output)

    applied = 0
    for src in sorted(delta_root.rglob("*")):
        if src.is_file():
            rel = src.relative_to(delta_root)
            dst = output / rel
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dst)
            applied += 1

    print(f"Applied {applied} files from delta onto {output}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())

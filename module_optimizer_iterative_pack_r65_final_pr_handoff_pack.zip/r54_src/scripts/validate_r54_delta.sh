#!/usr/bin/env bash
set -euo pipefail

if [ "$#" -ne 1 ]; then
  echo "Usage: bash validate_r54_delta.sh <integrated_repo_dir>"
  exit 2
fi

REPO_DIR="$1"
cd "$REPO_DIR"

pytest -q tests/test_query_progression_runtime_publication.py          tests/test_phase3_contract_path.py          tests/test_wave_progression_policy.py          tests/test_module_*.py

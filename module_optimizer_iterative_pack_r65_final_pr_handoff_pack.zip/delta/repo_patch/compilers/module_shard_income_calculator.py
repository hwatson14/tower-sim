from __future__ import annotations

def build_module_shard_income_calculator_from_drop_qe(qe_surfaces: dict) -> dict:
    required = [
        'derived::runtime.eligible_bosses_per_run',
        'derived::runtime.hours_per_run',
        'derived::module.runtime_profile.farming_hours_per_day',
        'planner.manual_policy.module.missions_per_week',
        'derived::module.mission_policy.total_daily_mission_shards',
        'derived::module.drop_policy.expected_shatter_equivalent_shards_per_boss',
        'derived::module.resource_policy.gems_allocated_to_modules_per_week',
        'derived::module.draw_policy.gem_cost_per_draw',
        'derived::module.draw_policy.common_rate_pct',
        'derived::module.draw_policy.rare_rate_pct',
        'derived::module.draw_policy.epic_rate_pct',
        'derived::module.shatter_policy.common_module_shards',
        'derived::module.shatter_policy.rare_module_shards',
        'derived::module.draw_policy.epic_draw_immediate_shard_value',
        'derived::module.draw_policy.ten_pull_ev_multiplier',
    ]
    missing = [k for k in required if k not in qe_surfaces]
    if missing:
        raise ValueError(f'missing QE surfaces: {missing}')

    hours_per_run = float(qe_surfaces['derived::runtime.hours_per_run'])
    if hours_per_run <= 0:
        raise ValueError('derived::runtime.hours_per_run must be > 0')
    runs_per_week = float(qe_surfaces['derived::module.runtime_profile.farming_hours_per_day']) * 7.0 / hours_per_run
    bosses_per_week = float(qe_surfaces['derived::runtime.eligible_bosses_per_run']) * runs_per_week

    boss_drop_shatter_equivalent = bosses_per_week * float(qe_surfaces['derived::module.drop_policy.expected_shatter_equivalent_shards_per_boss'])
    daily_mission_total = float(qe_surfaces['planner.manual_policy.module.missions_per_week']) * float(qe_surfaces['derived::module.mission_policy.total_daily_mission_shards'])

    common_rate = float(qe_surfaces['derived::module.draw_policy.common_rate_pct']) / 100.0
    rare_rate = float(qe_surfaces['derived::module.draw_policy.rare_rate_pct']) / 100.0
    epic_rate = float(qe_surfaces['derived::module.draw_policy.epic_rate_pct']) / 100.0
    common_shards = float(qe_surfaces['derived::module.shatter_policy.common_module_shards'])
    rare_shards = float(qe_surfaces['derived::module.shatter_policy.rare_module_shards'])
    epic_immediate_shards = float(qe_surfaces['derived::module.draw_policy.epic_draw_immediate_shard_value'])
    gem_cost_per_draw = float(qe_surfaces['derived::module.draw_policy.gem_cost_per_draw'])
    gems_per_week = float(qe_surfaces['derived::module.resource_policy.gems_allocated_to_modules_per_week'])
    draws_per_week = gems_per_week / gem_cost_per_draw if gem_cost_per_draw > 0 else 0.0
    ten_pull_multiplier = float(qe_surfaces['derived::module.draw_policy.ten_pull_ev_multiplier'])

    expected_shards_per_draw = (
        common_rate * common_shards
        + rare_rate * rare_shards
        + epic_rate * epic_immediate_shards
    ) * ten_pull_multiplier
    draw_shards_per_week = draws_per_week * expected_shards_per_draw

    return {
        'runs_per_week': runs_per_week,
        'eligible_bosses_per_week': bosses_per_week,
        'boss_drop_shatter_equivalent_shards_per_week': boss_drop_shatter_equivalent,
        'daily_mission_total_shards_per_week': daily_mission_total,
        'gem_draw_shards_per_week': draw_shards_per_week,
        'expected_shards_per_draw': expected_shards_per_draw,
        'gems_allocated_to_modules_per_week': gems_per_week,
        'total_weekly_module_shards': boss_drop_shatter_equivalent + daily_mission_total + draw_shards_per_week,
        'income_source': 'qe_drop_policy_mission_policy_draw_policy_surfaces',
        'income_exactness': 'exact_under_package_draw_policy',
        'blocked_reasons': [],
    }

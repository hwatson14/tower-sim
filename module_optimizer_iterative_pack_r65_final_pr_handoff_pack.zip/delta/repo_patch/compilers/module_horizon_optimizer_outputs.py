from __future__ import annotations

from compilers.module_planner_horizon_profile import build_module_planner_horizon_profile
from compilers.module_planner_plan import build_module_planner_plan
from compilers.module_planner_action_candidates import build_module_planner_action_candidates


def build_module_horizon_optimizer_outputs(
    recommendation: dict,
    top_candidates: dict,
    resource_state: dict,
    custom_days: int | None = None,
) -> dict:
    horizons = ["immediate", "week", "month", "custom"]
    outputs = {}
    actions = build_module_planner_action_candidates(recommendation, top_candidates)
    for horizon_kind in horizons:
        if horizon_kind == "custom":
            if custom_days is None:
                continue
            horizon = build_module_planner_horizon_profile("custom", custom_days)
        else:
            horizon = build_module_planner_horizon_profile(horizon_kind)
        outputs[horizon_kind] = build_module_planner_plan(horizon, resource_state, actions, recommendation)
    return {
        "horizon_outputs": outputs,
        "available_horizons": list(outputs.keys()),
    }

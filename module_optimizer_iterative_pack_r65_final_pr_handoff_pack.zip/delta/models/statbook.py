from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, List, Dict

@dataclass
class StatRow:
    stat_name: str
    final_value: Any
    value_type: str = 'scalar'
    source_count: int = 0
    status: str = 'resolved'
    notes: str = ''
    contributors: List[dict] = field(default_factory=list)
    schema: Dict[str, Any] = field(default_factory=dict)

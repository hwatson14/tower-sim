from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, List, Optional

SLOT_TYPES = ('cannon','armor','generator','core')
PRESET_NAMES = ('Farming','Tournament','Milestone')

@dataclass
class ModuleSubstat:
    name: str
    value: float
    raw_token: str

@dataclass
class ModuleSnapshot:
    name: str
    slot_type: str
    rarity: str = 'epic'
    level: int = 1
    stat: str = 'generic'
    substats: List[ModuleSubstat] = field(default_factory=list)

@dataclass
class ModulePresetSelection:
    primary: Optional[str]
    assist: Optional[str]

@dataclass
class ModuleSlotState:
    assist_unlocked: bool = True
    assist_level: int = 1
    rarity_cap: str = 'ancestral'
    multiplier_cap: int = 1
    substat_cap: int = 4

@dataclass
class CardInventoryEntry:
    name: str
    level: int = 0
    mastery_unlocked: bool = False
    mastery_lab_level: int = 0

@dataclass
class AccountState:
    active_module_preset: str = 'Farming'
    default_preset: str = 'Farming'
    module_system_state: Dict[str, ModuleSlotState] = field(default_factory=dict)
    module_presets: Dict[str, Dict[str, ModulePresetSelection]] = field(default_factory=dict)
    modules_inventory: Dict[str, ModuleSnapshot] = field(default_factory=dict)
    player_meta: Dict[str, object] = field(default_factory=dict)
    active_card_preset: str = 'Farming'
    card_presets: Dict[str, List[str]] = field(default_factory=dict)
    cards_inventory: Dict[str, object] = field(default_factory=dict)

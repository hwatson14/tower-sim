from __future__ import annotations

from typing import Mapping


def select_module_recommendation(
    ranking: Mapping[str, object],
    scorecard: Mapping[str, object],
) -> dict[str, object]:
    """Select a bounded top recommendation from ranked raw score rows.

    This compiler does not execute QE and does not normalize units. It only
    selects the top-ranked already-scored candidate and republishes the
    matching per-objective evidence from the scorecard.
    """
    ranked_candidates = ranking.get('ranked_candidates')
    if not isinstance(ranked_candidates, list) or not ranked_candidates:
        raise ValueError('ranking.ranked_candidates must be non-empty')

    score_rows = scorecard.get('score_rows')
    if not isinstance(score_rows, list) or not score_rows:
        raise ValueError('scorecard.score_rows must be non-empty')

    score_rows_by_candidate: dict[str, Mapping[str, object]] = {}
    for row in score_rows:
        candidate_id = str(row.get('candidate_id', '')).strip()
        if not candidate_id:
            raise ValueError('scorecard score row candidate_id is required')
        if candidate_id in score_rows_by_candidate:
            raise ValueError(f'duplicate scorecard candidate_id: {candidate_id}')
        score_rows_by_candidate[candidate_id] = row

    top_rank = ranked_candidates[0]
    top_candidate_id = str(top_rank.get('candidate_id', '')).strip()
    if not top_candidate_id:
        raise ValueError('top ranked candidate_id is required')
    if top_candidate_id not in score_rows_by_candidate:
        raise ValueError(f'top ranked candidate not found in scorecard: {top_candidate_id}')

    matched_row = score_rows_by_candidate[top_candidate_id]
    per_objective = matched_row.get('per_objective')
    if not isinstance(per_objective, list) or not per_objective:
        raise ValueError('matched score row per_objective must be non-empty')

    return {
        'baseline_request_id': str(ranking.get('baseline_request_id', '')).strip(),
        'recommended_candidate': {
            'rank': int(top_rank.get('rank', 0)),
            'request_id': str(top_rank.get('request_id', '')).strip(),
            'candidate_id': top_candidate_id,
            'overlay_intent_id': str(top_rank.get('overlay_intent_id', '')).strip(),
            'total_weighted_delta_raw': float(top_rank.get('total_weighted_delta_raw', 0.0)),
            'per_objective': per_objective,
        },
    }

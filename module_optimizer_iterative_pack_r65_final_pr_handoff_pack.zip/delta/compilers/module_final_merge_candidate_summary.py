from __future__ import annotations

def build_module_final_merge_candidate_summary(
    orchestrator: dict,
    package_version: str,
) -> dict:
    if not package_version:
        raise ValueError("package_version required")
    if "finish_funnel" not in orchestrator or "readiness_gate" not in orchestrator:
        raise ValueError("orchestrator payload required")

    finish_funnel = orchestrator["finish_funnel"]
    readiness_gate = orchestrator["readiness_gate"]
    final_recommendation = finish_funnel["final_recommendation"]

    return {
        "package_version": package_version,
        "orchestration_state": orchestrator["orchestration_state"],
        "merge_ready_now": readiness_gate["merge_ready_now"],
        "missing_dependencies": readiness_gate["missing_dependencies"],
        "missing_validations": readiness_gate["missing_validations"],
        "final_recommendation_exactness": final_recommendation["final_recommendation_exactness"],
        "recommended_action": final_recommendation["recommended_action"],
        "finish_funnel_state": finish_funnel["finish_funnel_state"],
    }

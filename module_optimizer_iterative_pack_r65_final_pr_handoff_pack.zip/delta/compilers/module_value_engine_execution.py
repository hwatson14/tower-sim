from __future__ import annotations

from typing import Mapping

from compilers.module_evaluation_observations import build_module_evaluation_observations
from compilers.module_value_engine_pipeline import build_module_value_engine_pipeline
from compilers.module_objective_profile import build_module_objective_profile


def execute_module_value_engine_from_results(
    prepared_inputs: Mapping[str, object],
    objective_profile: Mapping[str, object],
    executed_results_by_request_id: Mapping[str, Mapping[str, object]],
) -> dict[str, object]:
    """Run the bounded MO-E pipeline from prepared inputs and explicit results.

    This compiler does not execute the QE itself. It only joins an explicit
    result map to the prepared baseline/candidate request structure and then
    runs the already-bounded MO-E pipeline.
    """
    baseline_request = prepared_inputs.get('baseline_request')
    if not isinstance(baseline_request, Mapping) or not baseline_request:
        raise ValueError('prepared_inputs.baseline_request is required')
    candidate_requests = prepared_inputs.get('candidate_requests')
    if isinstance(candidate_requests, list):
        candidate_requests = {'requests': candidate_requests}
    if not isinstance(candidate_requests, Mapping):
        raise ValueError('prepared_inputs.candidate_requests is required')
    candidate_request_rows = candidate_requests.get('requests')
    if not isinstance(candidate_request_rows, list) or not candidate_request_rows:
        raise ValueError('prepared_inputs.candidate_requests.requests must be non-empty')

    baseline_request_id = str(baseline_request.get('request_id', '')).strip()
    if not baseline_request_id:
        raise ValueError('prepared_inputs.baseline_request.request_id is required')
    if baseline_request_id not in executed_results_by_request_id:
        raise ValueError(f'baseline result not found for request_id: {baseline_request_id}')

    baseline_result = dict(executed_results_by_request_id[baseline_request_id])
    baseline_result.setdefault('request_id', baseline_request_id)

    candidate_results: list[dict[str, object]] = []
    for request in candidate_request_rows:
        request_id = str(request.get('request_id', '')).strip()
        if not request_id:
            raise ValueError('candidate request_id is required')
        if request_id not in executed_results_by_request_id:
            raise ValueError(f'candidate result not found for request_id: {request_id}')
        row = dict(executed_results_by_request_id[request_id])
        row.setdefault('request_id', request_id)
        row.setdefault('candidate_id', request_id)
        row.setdefault('overlay_intent_id', str(request.get('overlay_id', '')).strip())
        candidate_results.append(row)

    observations = build_module_evaluation_observations(
        baseline_result=baseline_result,
        candidate_results=candidate_results,
    )
    normalized_objective_profile = objective_profile
    if not isinstance(objective_profile.get('rows'), list):
        normalized_objective_profile = build_module_objective_profile(
            objective_ids=list(objective_profile.get('objective_ids', [])),
            directions=objective_profile.get('directions', {}),
            weights=objective_profile.get('weights', {}),
        )
    pipeline = build_module_value_engine_pipeline(
        objective_profile=normalized_objective_profile,
        observations=observations,
    )
    return {
        'prepared_inputs': dict(prepared_inputs),
        'objective_profile': dict(normalized_objective_profile),
        'observations': observations,
        'pipeline': pipeline,
    }


def build_module_value_engine_execution(
    prepared_manifest: Mapping[str, object] | None = None,
    prepared_inputs: Mapping[str, object] | None = None,
    objective_profile: Mapping[str, object] | None = None,
    executed_results_by_request_id: Mapping[str, Mapping[str, object]] | None = None,
) -> dict[str, object]:
    """Compatibility wrapper using the older builder-style name."""
    payload = prepared_inputs if prepared_inputs is not None else prepared_manifest
    if payload is None:
        raise ValueError('prepared_inputs or prepared_manifest is required')
    if objective_profile is None:
        raise ValueError('objective_profile is required')
    if executed_results_by_request_id is None:
        raise ValueError('executed_results_by_request_id is required')
    return execute_module_value_engine_from_results(
        prepared_inputs=payload,
        objective_profile=objective_profile,
        executed_results_by_request_id=executed_results_by_request_id,
    )

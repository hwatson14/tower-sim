from __future__ import annotations

from typing import Mapping, Sequence


def build_module_evaluation_observations(
    baseline_result: Mapping[str, object],
    candidate_results: Sequence[Mapping[str, object]],
) -> dict[str, object]:
    """Build bounded observation rows from executed evaluation results.

    This compiler does not score, rank, or execute the QE. It only validates
    one baseline result plus explicit candidate results and emits raw observed
    objective values and deltas in a deterministic package for later scoring.
    """
    if not baseline_result:
        raise ValueError('baseline_result is required')
    if not candidate_results:
        raise ValueError('candidate_results must be non-empty')

    baseline_request_id = str(baseline_result.get('request_id', '')).strip()
    if not baseline_request_id:
        raise ValueError('baseline_result.request_id is required')

    baseline_values = _normalize_objective_values(baseline_result.get('objective_values'))
    if not baseline_values:
        raise ValueError('baseline_result.objective_values must be non-empty')
    objective_ids = list(baseline_values.keys())

    seen: set[str] = set()
    observations: list[dict[str, object]] = []
    for result in candidate_results:
        request_id = str(result.get('request_id', '')).strip()
        if not request_id:
            raise ValueError('candidate request_id is required')
        if request_id == baseline_request_id:
            raise ValueError('candidate request_id must not equal baseline request_id')
        if request_id in seen:
            raise ValueError(f'duplicate candidate request_id: {request_id}')
        seen.add(request_id)

        candidate_values = _normalize_objective_values(result.get('objective_values'))
        if list(candidate_values.keys()) != objective_ids:
            raise ValueError('candidate objective_values keys must match baseline exactly')

        delta_values = {
            key: candidate_values[key] - baseline_values[key]
            for key in objective_ids
        }
        observations.append({
            'request_id': request_id,
            'candidate_id': str(result.get('candidate_id', '')).strip(),
            'overlay_intent_id': str(result.get('overlay_intent_id', '')).strip(),
            'objective_values': dict(candidate_values),
            'delta_values': delta_values,
        })

    return {
        'baseline_request_id': baseline_request_id,
        'objective_ids': objective_ids,
        'baseline_objective_values': dict(baseline_values),
        'candidate_count': len(observations),
        'observations': observations,
    }


def _normalize_objective_values(values: object) -> dict[str, float]:
    if not isinstance(values, Mapping):
        raise ValueError('objective_values must be a mapping')
    normalized: dict[str, float] = {}
    for key, value in values.items():
        objective_id = str(key).strip()
        if not objective_id:
            raise ValueError('objective_values keys must be non-empty')
        try:
            normalized[objective_id] = float(value)
        except (TypeError, ValueError) as exc:
            raise ValueError(f'objective value for {objective_id} must be numeric') from exc
    return normalized

from __future__ import annotations

from typing import Iterable, Mapping, Sequence


def build_module_evaluation_manifest(
    baseline_request: Mapping[str, object],
    candidate_requests: Sequence[Mapping[str, object]],
) -> dict[str, object]:
    """Build a bounded, read-only evaluation manifest for future value-engine execution.

    This intentionally does not execute the query engine or score candidates.
    It only packages a baseline request plus explicit candidate requests into a
    deterministic manifest with deduplicated candidate ids and stable ordering.
    """
    if not baseline_request:
        raise ValueError('baseline_request is required')
    if not candidate_requests:
        raise ValueError('candidate_requests must be non-empty')

    baseline_id = str(baseline_request.get('request_id', '')).strip()
    if not baseline_id:
        raise ValueError('baseline_request.request_id is required')

    seen: set[str] = set()
    manifest_candidates: list[dict[str, object]] = []
    objective_ids = tuple(_normalize_ids(baseline_request.get('objective_ids')))
    if not objective_ids:
        raise ValueError('baseline_request.objective_ids must be non-empty')
    surface_bundle_id = str(baseline_request.get('surface_bundle_id', '')).strip()
    if not surface_bundle_id:
        raise ValueError('baseline_request.surface_bundle_id is required')

    for request in candidate_requests:
        candidate_id = str(request.get('request_id', '')).strip()
        if not candidate_id:
            raise ValueError('candidate request_id is required')
        if candidate_id == baseline_id:
            raise ValueError('candidate request_id must not equal baseline request_id')
        if candidate_id in seen:
            raise ValueError(f'duplicate candidate request_id: {candidate_id}')
        seen.add(candidate_id)

        request_objective_ids = tuple(_normalize_ids(request.get('objective_ids')))
        if request_objective_ids != objective_ids:
            raise ValueError('candidate objective_ids must match baseline objective_ids exactly')
        request_surface_bundle_id = str(request.get('surface_bundle_id', '')).strip()
        if request_surface_bundle_id != surface_bundle_id:
            raise ValueError('candidate surface_bundle_id must match baseline surface_bundle_id exactly')

        manifest_candidates.append({
            'request_id': candidate_id,
            'candidate_id': str(request.get('candidate_id', '')).strip(),
            'overlay_intent_id': str(request.get('overlay_intent_id', '')).strip(),
            'objective_ids': list(request_objective_ids),
            'surface_bundle_id': request_surface_bundle_id,
        })

    return {
        'baseline_request_id': baseline_id,
        'objective_ids': list(objective_ids),
        'surface_bundle_id': surface_bundle_id,
        'candidate_count': len(manifest_candidates),
        'candidate_requests': manifest_candidates,
    }


def _normalize_ids(values: object) -> Iterable[str]:
    if values is None:
        return []
    normalized: list[str] = []
    for value in values:
        text = str(value).strip()
        if not text:
            raise ValueError('ids must not contain empty values')
        normalized.append(text)
    return normalized

from __future__ import annotations
from typing import Mapping
from compilers.module_monkey_patch_fixture import build_module_monkey_patch_fixture
from compilers.module_value_engine_session import build_module_value_engine_session

def build_module_monkey_patch_session(prepared_inputs: Mapping[str, object], directions_by_objective_id: Mapping[str, str], weights_by_objective_id: Mapping[str, float], executed_results_by_request_id: Mapping[str, Mapping[str, object]], fixture_id: str, top_n: int = 3, notes: list[str] | None = None) -> dict[str, object]:
    fixture = build_module_monkey_patch_fixture(prepared_inputs=prepared_inputs, directions_by_objective_id=directions_by_objective_id, weights_by_objective_id=weights_by_objective_id, executed_results_by_request_id=executed_results_by_request_id, fixture_id=fixture_id, notes=notes)
    session = build_module_value_engine_session(prepared_inputs=fixture['prepared_inputs'], objective_profile=fixture['objective_profile'], executed_results_by_request_id=fixture['executed_results_by_request_id'], top_n=top_n)
    return {'fixture': fixture, 'session': session, 'top_n': int(top_n)}

from __future__ import annotations

_REQUIRED_RUNTIME_KEYS = [
    "bosses_per_run",
    "eligible_bosses_per_run",
    "elites_per_run",
    "hours_per_run",
    "waves_per_hour",
    "suppressed_boss_fraction",
]

def build_module_runtime_profile_from_qe(runtime_surfaces: dict) -> dict:
    if not isinstance(runtime_surfaces, dict):
        raise ValueError("runtime_surfaces dict required")

    missing = [k for k in _REQUIRED_RUNTIME_KEYS if k not in runtime_surfaces]
    if missing:
        raise ValueError(f"missing runtime surfaces: {missing}")

    out = {k: runtime_surfaces[k] for k in _REQUIRED_RUNTIME_KEYS}
    out["runtime_profile_source"] = "qe_or_explicit_surface_map"
    return out

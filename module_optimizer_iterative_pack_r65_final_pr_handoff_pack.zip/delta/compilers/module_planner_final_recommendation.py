from __future__ import annotations

def build_module_planner_final_recommendation(
    planner_plan: dict,
    planner_feasibility: dict,
    horizon_projection: dict,
    live_session: dict | None = None,
) -> dict:
    if "recommended_action" not in planner_plan:
        raise ValueError("planner_plan.recommended_action required")
    if "feasibility_status" not in planner_feasibility:
        raise ValueError("planner_feasibility.feasibility_status required")
    if "projection_exactness" not in horizon_projection:
        raise ValueError("horizon_projection.projection_exactness required")

    recommended_action = planner_plan["recommended_action"]
    final_exactness = "advisory"
    if (
        planner_feasibility["feasibility_status"] == "cost_feasible_if_resources_suffice"
        and horizon_projection["projection_exactness"] == "exact_with_income"
    ):
        final_exactness = "exact"

    out = {
        "recommended_action": recommended_action,
        "feasibility_status": planner_feasibility["feasibility_status"],
        "projection_exactness": horizon_projection["projection_exactness"],
        "final_recommendation_exactness": final_exactness,
        "recommendation_mode": planner_plan["plan_mode"],
        "has_live_session_evidence": live_session is not None,
    }

    if live_session is not None:
        execution = live_session.get("execution", {})
        out["live_recommendation_candidate_id"] = execution.get("recommendation", {}).get("candidate_id")

    return out

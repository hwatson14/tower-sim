from __future__ import annotations

from typing import Mapping

from compilers.module_execution_result_map import validate_module_execution_result_map
from compilers.module_top_candidates import build_module_top_candidates
from compilers.module_value_engine_execution import execute_module_value_engine_from_results


def build_module_value_engine_session(
    prepared_inputs: Mapping[str, object],
    objective_profile: Mapping[str, object],
    executed_results_by_request_id: Mapping[str, Mapping[str, object]],
    top_n: int = 3,
) -> dict[str, object]:
    """Compose bounded validation, execution, and top-N packaging.

    This session compiler still does not execute QE. It validates explicit
    request-result maps against the prepared manifest, then runs the bounded
    MO-E execution pipeline and packages a top-N candidate view.
    """
    evaluation_manifest = prepared_inputs.get('evaluation_manifest')
    if not isinstance(evaluation_manifest, Mapping) or not evaluation_manifest:
        raise ValueError('prepared_inputs.evaluation_manifest is required')
    validated_results = validate_module_execution_result_map(
        evaluation_manifest=evaluation_manifest,
        executed_results_by_request_id=executed_results_by_request_id,
    )
    execution = execute_module_value_engine_from_results(
        prepared_inputs=prepared_inputs,
        objective_profile=objective_profile,
        executed_results_by_request_id=validated_results['validated_results_by_request_id'],
    )
    pipeline = execution['pipeline']
    top_candidates = build_module_top_candidates(
        ranking=pipeline['ranking'],
        scorecard=pipeline['scorecard'],
        limit=top_n,
    )
    return {
        'prepared_inputs': dict(prepared_inputs),
        'validated_results': validated_results,
        'execution': execution,
        'top_candidates': top_candidates,
    }

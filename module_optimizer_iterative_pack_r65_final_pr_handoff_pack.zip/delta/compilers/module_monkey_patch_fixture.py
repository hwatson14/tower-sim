from __future__ import annotations
from typing import Mapping
from compilers.module_objective_profile import build_module_objective_profile
_ALLOWED_DIRECTIONS = {'maximize', 'minimize'}

def build_module_monkey_patch_fixture(prepared_inputs: Mapping[str, object], directions_by_objective_id: Mapping[str, str], weights_by_objective_id: Mapping[str, float], executed_results_by_request_id: Mapping[str, Mapping[str, object]], fixture_id: str, notes: list[str] | None = None) -> dict[str, object]:
    fixture_id = str(fixture_id).strip()
    if not fixture_id:
        raise ValueError('fixture_id is required')
    manifest = prepared_inputs.get('evaluation_manifest')
    if not isinstance(manifest, Mapping) or not manifest:
        raise ValueError('prepared_inputs.evaluation_manifest is required')
    baseline_request = manifest.get('baseline_request')
    candidate_requests = manifest.get('candidate_requests')
    if isinstance(baseline_request, Mapping) and baseline_request:
        baseline_request_id = str(baseline_request.get('request_id', '')).strip()
        if not baseline_request_id:
            raise ValueError('prepared_inputs.evaluation_manifest.baseline_request.request_id is required')
        objective_ids = list(baseline_request.get('objective_ids', []))
        if not objective_ids or any(not str(x).strip() for x in objective_ids):
            raise ValueError('prepared_inputs.evaluation_manifest.baseline_request.objective_ids must be non-empty')
        request_rows = candidate_requests.get('requests') if isinstance(candidate_requests, Mapping) else candidate_requests
        if not isinstance(request_rows, list) or not request_rows:
            raise ValueError('prepared_inputs.evaluation_manifest.candidate_requests must be non-empty')
    else:
        baseline_request_id = str(manifest.get('baseline_request_id', '')).strip()
        if not baseline_request_id:
            raise ValueError('prepared_inputs.evaluation_manifest.baseline_request or baseline_request_id is required')
        objective_ids = list(manifest.get('objective_ids', []))
        if not objective_ids or any(not str(x).strip() for x in objective_ids):
            raise ValueError('prepared_inputs.evaluation_manifest.objective_ids must be non-empty')
        request_rows = candidate_requests
        if not isinstance(request_rows, list) or not request_rows:
            raise ValueError('prepared_inputs.evaluation_manifest.candidate_requests must be non-empty')
    request_ids = [baseline_request_id]
    for row in request_rows:
        request_id = str(row.get('request_id', '')).strip()
        if not request_id:
            raise ValueError('candidate request_id is required')
        if request_id in request_ids:
            raise ValueError(f'duplicate request_id in manifest: {request_id}')
        if list(row.get('objective_ids', [])) != objective_ids:
            raise ValueError(f'candidate request objective_ids mismatch: {request_id}')
        request_ids.append(request_id)
    for objective_id in objective_ids:
        if str(directions_by_objective_id.get(objective_id, '')).strip() not in _ALLOWED_DIRECTIONS:
            raise ValueError(f'invalid direction for objective_id: {objective_id}')
        try:
            weight = float(weights_by_objective_id.get(objective_id))
        except (TypeError, ValueError):
            raise ValueError(f'positive numeric weight required for objective_id: {objective_id}') from None
        if weight <= 0:
            raise ValueError(f'positive numeric weight required for objective_id: {objective_id}')
    profile = build_module_objective_profile(objective_ids=objective_ids, directions=directions_by_objective_id, weights=weights_by_objective_id)
    validated_results: dict[str, dict[str, object]] = {}
    for request_id in request_ids:
        payload = executed_results_by_request_id.get(request_id)
        if not isinstance(payload, Mapping):
            raise ValueError(f'executed result not found for request_id: {request_id}')
        objective_values = payload.get('objective_values')
        if not isinstance(objective_values, Mapping):
            raise ValueError(f'objective_values mapping required for request_id: {request_id}')
        if list(objective_values.keys()) != objective_ids:
            raise ValueError(f'objective_values keys mismatch for request_id: {request_id}')
        validated_results[request_id] = {'request_id': request_id, 'objective_values': {oid: float(objective_values[oid]) for oid in objective_ids}}
    return {'fixture_id': fixture_id, 'objective_ids': objective_ids, 'prepared_inputs': dict(prepared_inputs), 'objective_profile': profile, 'executed_results_by_request_id': validated_results, 'request_count': len(request_ids), 'notes': list(notes or []), 'fixture_kind': 'module_value_engine_monkey_patch_v1'}

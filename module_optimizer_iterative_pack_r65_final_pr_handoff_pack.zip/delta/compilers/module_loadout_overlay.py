from __future__ import annotations

from typing import Any, Dict, Optional

from models.account_state import AccountState, SLOT_TYPES

from compilers.module_loadout_candidates import enumerate_module_loadout_seed_candidates
from compilers.module_optimizer_state import build_module_optimizer_state_snapshot


def _copy_loadout(loadout: Dict[str, Dict[str, Optional[str]]]) -> Dict[str, Dict[str, Optional[str]]]:
    return {
        slot_type: {
            'primary_name': slot_row.get('primary_name'),
            'assist_name': slot_row.get('assist_name'),
        }
        for slot_type, slot_row in loadout.items()
    }


def build_module_loadout_overlay(
    account_state: AccountState,
    candidate: Dict[str, Any],
    module_preset: Optional[str] = None,
) -> Dict[str, Any]:
    snapshot = build_module_optimizer_state_snapshot(account_state, module_preset=module_preset)
    baseline_loadout = {
        slot_type: {
            'primary_name': snapshot['slots'][slot_type]['equipped']['primary_name'],
            'assist_name': snapshot['slots'][slot_type]['equipped']['assist_name'],
        }
        for slot_type in SLOT_TYPES
    }
    candidate_loadout = _copy_loadout(candidate.get('loadout', {}))
    if set(candidate_loadout) != set(SLOT_TYPES):
        raise KeyError('Candidate loadout must contain all module slot types.')

    overlay_rows = []
    for slot_type in SLOT_TYPES:
        baseline_row = baseline_loadout[slot_type]
        candidate_row = candidate_loadout[slot_type]
        if set(candidate_row) != {'primary_name', 'assist_name'}:
            raise KeyError(f'Candidate loadout row for {slot_type!r} must contain primary_name and assist_name.')
        primary_name = candidate_row['primary_name']
        assist_name = candidate_row['assist_name']
        if primary_name is None:
            raise ValueError(f'Candidate loadout row for {slot_type!r} must keep a primary module.')
        if assist_name == primary_name:
            raise ValueError(f'Candidate loadout row for {slot_type!r} cannot equip the same module in primary and assist.')
        overlay_rows.append({
            'slot_type': slot_type,
            'baseline_primary_name': baseline_row['primary_name'],
            'baseline_assist_name': baseline_row['assist_name'],
            'candidate_primary_name': primary_name,
            'candidate_assist_name': assist_name,
            'primary_changed': primary_name != baseline_row['primary_name'],
            'assist_changed': assist_name != baseline_row['assist_name'],
        })

    return {
        'schema_id': 'module_loadout_overlay_v1',
        'selected_module_preset': snapshot['selected_module_preset'],
        'seed_type': candidate.get('seed_type'),
        'changes': list(candidate.get('changes', [])),
        'baseline_loadout': baseline_loadout,
        'candidate_loadout': candidate_loadout,
        'overlay_rows': overlay_rows,
    }


def build_baseline_module_loadout_overlay(
    account_state: AccountState,
    module_preset: Optional[str] = None,
) -> Dict[str, Any]:
    baseline_candidate = enumerate_module_loadout_seed_candidates(account_state, module_preset=module_preset)[0]
    return build_module_loadout_overlay(account_state, baseline_candidate, module_preset=module_preset)



def module_loadout_overlay_contract_snapshot() -> Dict[str, Any]:
    return {
        'schema_id': 'module_loadout_overlay_v1',
        'owner_path': 'compilers/module_loadout_overlay.py',
        'required_top_level_keys': [
            'schema_id',
            'selected_module_preset',
            'seed_type',
            'changes',
            'baseline_loadout',
            'candidate_loadout',
            'overlay_rows',
        ],
        'overlay_row_keys': [
            'slot_type',
            'baseline_primary_name',
            'baseline_assist_name',
            'candidate_primary_name',
            'candidate_assist_name',
            'primary_changed',
            'assist_changed',
        ],
        'mutation_policy': 'read_only_overlay_materialization',
        'forbidden_behaviors': [
            'mutate_account_state_in_place',
            'invent_cartesian_candidate_search',
            'compute_optimizer_scores',
            'publish_query_surfaces_directly',
        ],
    }

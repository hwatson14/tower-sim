from __future__ import annotations

from compilers.module_finish_funnel_package import build_module_finish_funnel_package
from compilers.module_merge_readiness_gate import build_module_merge_readiness_gate

def build_module_finish_execution_orchestrator(
    live_session: dict,
    planner_plan: dict,
    planner_feasibility: dict,
    horizon_projection: dict,
    final_recommendation: dict,
    external_dependencies: dict,
    validation_status: dict,
    parity_review: dict | None = None,
) -> dict:
    finish_funnel = build_module_finish_funnel_package(
        live_session=live_session,
        planner_plan=planner_plan,
        planner_feasibility=planner_feasibility,
        horizon_projection=horizon_projection,
        final_recommendation=final_recommendation,
        parity_review=parity_review,
    )
    readiness_gate = build_module_merge_readiness_gate(
        external_dependencies=external_dependencies,
        validation_status=validation_status,
        final_recommendation=final_recommendation,
    )

    return {
        "finish_funnel": finish_funnel,
        "readiness_gate": readiness_gate,
        "orchestration_state": (
            "ready_for_merge_candidate_cleanup"
            if readiness_gate["merge_ready_now"]
            else "integration_or_validation_remaining"
        ),
    }

from __future__ import annotations

def build_module_deterministic_income_consumer(
    runtime_profile: dict,
    resource_state: dict,
    cost_boundary: dict,
    deterministic_income: dict | None = None,
) -> dict:
    required_runtime = [
        "bosses_per_run",
        "eligible_bosses_per_run",
        "elites_per_run",
        "hours_per_run",
        "waves_per_hour",
        "suppressed_boss_fraction",
    ]
    for key in required_runtime:
        if key not in runtime_profile:
            raise ValueError(f"missing runtime_profile.{key}")

    if "resource_state_exactness" not in resource_state:
        raise ValueError("resource_state.resource_state_exactness required")
    if "overall_cost_exactness" not in cost_boundary:
        raise ValueError("cost_boundary.overall_cost_exactness required")

    deterministic_income = deterministic_income or {}
    module_income_exact = deterministic_income.get("module_income_exact", False)
    reroll_income_exact = deterministic_income.get("reroll_income_exact", False)

    exact_income_allowed = (
        module_income_exact
        and reroll_income_exact
        and cost_boundary["overall_cost_exactness"] != "blocked_partial"
    )

    return {
        "runtime_profile": runtime_profile,
        "resource_state_exactness": resource_state["resource_state_exactness"],
        "cost_exactness": cost_boundary["overall_cost_exactness"],
        "deterministic_income_inputs": {
            "bosses_per_run": runtime_profile["bosses_per_run"],
            "eligible_bosses_per_run": runtime_profile["eligible_bosses_per_run"],
            "elites_per_run": runtime_profile["elites_per_run"],
            "hours_per_run": runtime_profile["hours_per_run"],
            "waves_per_hour": runtime_profile["waves_per_hour"],
            "suppressed_boss_fraction": runtime_profile["suppressed_boss_fraction"],
        },
        "module_income_exact": module_income_exact,
        "reroll_income_exact": reroll_income_exact,
        "income_consumer_exactness": "exact"
        if exact_income_allowed
        else "advisory_until_income_closes",
    }

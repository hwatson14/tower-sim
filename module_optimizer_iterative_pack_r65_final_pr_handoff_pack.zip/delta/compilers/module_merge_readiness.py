from __future__ import annotations

from typing import Mapping, Sequence


def build_module_merge_readiness(
    *,
    session_bundle: Mapping[str, object],
    required_external_dependencies: Sequence[str],
    completed_dependencies: Sequence[str],
) -> dict[str, object]:
    """Package explicit merge-readiness status for the module-optimizer stream.

    This is a governance/hardening seam only. It does not claim the branch is
    merge-ready unless all required external dependencies are complete.
    """
    bundle_id = str(session_bundle.get('bundle_id', '')).strip()
    if not bundle_id:
        raise ValueError('session_bundle.bundle_id is required')

    required = []
    for item in required_external_dependencies:
        slug = str(item).strip()
        if not slug:
            raise ValueError('required_external_dependencies must be non-empty strings')
        if slug in required:
            raise ValueError(f'duplicate required dependency: {slug}')
        required.append(slug)

    completed = []
    for item in completed_dependencies:
        slug = str(item).strip()
        if not slug:
            raise ValueError('completed_dependencies must be non-empty strings')
        if slug in completed:
            raise ValueError(f'duplicate completed dependency: {slug}')
        completed.append(slug)

    missing = [slug for slug in required if slug not in completed]

    return {
        'bundle_id': bundle_id,
        'required_external_dependencies': required,
        'completed_dependencies': completed,
        'missing_dependencies': missing,
        'merge_ready_now': len(missing) == 0,
        'notes': {
            'final_cleanup_required': True,
            'support_docs_allowed_pre_merge': True,
        },
    }

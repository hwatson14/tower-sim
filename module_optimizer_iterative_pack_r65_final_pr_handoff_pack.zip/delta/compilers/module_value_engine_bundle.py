from __future__ import annotations

from typing import Mapping


def build_module_value_engine_bundle(
    session: Mapping[str, object],
    bundle_id: str,
    source_tag: str = 'module_value_engine',
) -> dict[str, object]:
    """Package a portable MO-E session bundle.

    This is a packaging/export seam only. It does not execute QE or alter
    scores. It exists to make downstream review and handoff deterministic.
    """
    bundle_id = str(bundle_id).strip()
    if not bundle_id:
        raise ValueError('bundle_id is required')
    source_tag = str(source_tag).strip()
    if not source_tag:
        raise ValueError('source_tag is required')

    prepared_inputs = session.get('prepared_inputs')
    if not isinstance(prepared_inputs, Mapping) or not prepared_inputs:
        raise ValueError('session.prepared_inputs is required')
    execution = session.get('execution')
    if not isinstance(execution, Mapping) or not execution:
        raise ValueError('session.execution is required')
    top_candidates = session.get('top_candidates')
    if not isinstance(top_candidates, Mapping) or not top_candidates:
        raise ValueError('session.top_candidates is required')

    evaluation_manifest = prepared_inputs.get('evaluation_manifest')
    if not isinstance(evaluation_manifest, Mapping) or not evaluation_manifest:
        raise ValueError('prepared_inputs.evaluation_manifest is required')
    pipeline = execution.get('pipeline')
    if not isinstance(pipeline, Mapping) or not pipeline:
        raise ValueError('execution.pipeline is required')
    report = pipeline.get('report')
    if not isinstance(report, Mapping) or not report:
        raise ValueError('execution.pipeline.report is required')

    baseline_request_id = str(report.get('baseline_request_id', '')).strip()
    if not baseline_request_id:
        raise ValueError('report baseline_request_id is required')
    top_rows = top_candidates.get('top_candidates')
    if not isinstance(top_rows, list) or not top_rows:
        raise ValueError('top_candidates.top_candidates must be non-empty')

    return {
        'bundle_id': bundle_id,
        'source_tag': source_tag,
        'baseline_request_id': baseline_request_id,
        'objective_ids': list(report.get('objective_ids', [])),
        'manifest': dict(evaluation_manifest),
        'report': dict(report),
        'top_candidates': {'top_candidates': [dict(x) for x in top_rows]},
        'notes': {
            'qe_executed_here': False,
            'raw_weighted_scoring_only': True,
            'portable_review_bundle': True,
        },
    }

from __future__ import annotations

def build_module_finish_funnel_package(
    live_session: dict,
    planner_plan: dict,
    planner_feasibility: dict,
    horizon_projection: dict,
    final_recommendation: dict,
    parity_review: dict | None = None,
) -> dict:
    required = [
        ("planner_plan", planner_plan, "recommended_action"),
        ("planner_feasibility", planner_feasibility, "feasibility_status"),
        ("horizon_projection", horizon_projection, "projection_exactness"),
        ("final_recommendation", final_recommendation, "recommended_action"),
    ]
    for _, obj, key in required:
        if key not in obj:
            raise ValueError(f"missing required key: {key}")
    if "execution" not in live_session:
        raise ValueError("live_session.execution required")

    return {
        "live_session": live_session,
        "planner_plan": planner_plan,
        "planner_feasibility": planner_feasibility,
        "horizon_projection": horizon_projection,
        "final_recommendation": final_recommendation,
        "parity_review": parity_review,
        "finish_funnel_state": "ready_for_live_validation"
        if parity_review is None
        else "ready_for_merge_readiness_review",
    }

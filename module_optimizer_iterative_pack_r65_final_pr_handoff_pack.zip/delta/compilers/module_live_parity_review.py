from __future__ import annotations

def build_module_live_parity_review(
    parity: dict,
    fixture_id: str,
) -> dict:
    if not fixture_id:
        raise ValueError("fixture_id required")
    if "parity_status" not in parity:
        raise ValueError("parity payload required")

    if parity["parity_status"] == "match":
        disposition = "accepted_match"
    else:
        disposition = "requires_classification"

    return {
        "fixture_id": fixture_id,
        "parity": parity,
        "review_disposition": disposition,
        "required_classifications_if_differs": [
            "fixture_outdated",
            "lower_layer_issue",
            "optimizer_issue",
            "accepted_live_truth_difference",
        ] if disposition == "requires_classification" else [],
    }

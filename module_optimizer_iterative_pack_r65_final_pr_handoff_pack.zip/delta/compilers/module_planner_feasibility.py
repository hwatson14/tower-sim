from __future__ import annotations

def build_module_planner_feasibility(
    planner_plan: dict,
    cost_boundary: dict,
) -> dict:
    if "recommended_action" not in planner_plan:
        raise ValueError("planner_plan missing recommended_action")
    if "cost_exactness" not in cost_boundary:
        raise ValueError("cost_boundary missing cost_exactness")

    plan_mode = planner_plan.get("plan_mode")
    if plan_mode not in {"next_best_change", "advisory_horizon_plan"}:
        raise ValueError("unsupported plan_mode")

    recommended = dict(planner_plan["recommended_action"])
    cost_exactness = cost_boundary["cost_exactness"]

    feasibility = "advisory_only"
    if cost_exactness == "exact":
        feasibility = "cost_feasible_if_resources_suffice"
    elif cost_exactness == "partial_exact":
        feasibility = "partially_costed"
    else:
        feasibility = "blocked_by_exact_cost_gaps"

    return {
        "plan_mode": plan_mode,
        "recommended_action": recommended,
        "cost_exactness": cost_exactness,
        "feasibility_status": feasibility,
        "blocked_reasons": list(cost_boundary.get("blocked_reasons", [])),
    }

from __future__ import annotations

from typing import Mapping


def validate_module_execution_result_map(
    evaluation_manifest: Mapping[str, object],
    executed_results_by_request_id: Mapping[str, Mapping[str, object]],
) -> dict[str, object]:
    """Validate explicit QE result mappings against a bounded manifest.

    This compiler does not execute QE. It only validates that explicit result
    payloads exist for the manifest request ids and expose the exact objective
    id set expected by the manifest.
    """
    baseline_request = evaluation_manifest.get('baseline_request')
    candidate_requests = evaluation_manifest.get('candidate_requests')
    request_rows = None

    if isinstance(baseline_request, Mapping) and baseline_request:
        if not isinstance(candidate_requests, Mapping):
            raise ValueError('evaluation_manifest.candidate_requests is required')
        request_rows = candidate_requests.get('requests')
        if not isinstance(request_rows, list) or not request_rows:
            raise ValueError('evaluation_manifest.candidate_requests.requests must be non-empty')
        baseline_request_id = str(baseline_request.get('request_id', '')).strip()
        if not baseline_request_id:
            raise ValueError('evaluation_manifest.baseline_request.request_id is required')
        objective_ids = list(baseline_request.get('objective_ids', []))
        if not objective_ids or any(not str(x).strip() for x in objective_ids):
            raise ValueError('evaluation_manifest.baseline_request.objective_ids must be non-empty')
    else:
        baseline_request_id = str(evaluation_manifest.get('baseline_request_id', '')).strip()
        if not baseline_request_id:
            raise ValueError('evaluation_manifest.baseline_request or baseline_request_id is required')
        objective_ids = list(evaluation_manifest.get('objective_ids', []))
        if not objective_ids or any(not str(x).strip() for x in objective_ids):
            raise ValueError('evaluation_manifest.objective_ids must be non-empty')
        request_rows = evaluation_manifest.get('candidate_requests')
        if not isinstance(request_rows, list) or not request_rows:
            raise ValueError('evaluation_manifest.candidate_requests must be non-empty')

    required_request_ids = [baseline_request_id]
    for row in request_rows:
        request_id = str(row.get('request_id', '')).strip()
        if not request_id:
            raise ValueError('candidate request_id is required')
        required_request_ids.append(request_id)
        row_objective_ids = list(row.get('objective_ids', []))
        if row_objective_ids != objective_ids:
            raise ValueError(f'candidate request objective_ids mismatch: {request_id}')

    validated_results: dict[str, dict[str, object]] = {}
    for request_id in required_request_ids:
        payload = executed_results_by_request_id.get(request_id)
        if not isinstance(payload, Mapping):
            raise ValueError(f'executed result not found for request_id: {request_id}')
        result_objectives = payload.get('objective_values')
        if not isinstance(result_objectives, Mapping):
            raise ValueError(f'objective_values mapping required for request_id: {request_id}')
        result_keys = list(result_objectives.keys())
        if result_keys != objective_ids:
            raise ValueError(f'objective_values keys mismatch for request_id: {request_id}')
        validated_results[request_id] = {
            'request_id': request_id,
            'objective_values': {key: float(result_objectives[key]) for key in objective_ids},
        }

    return {
        'baseline_request_id': baseline_request_id,
        'objective_ids': objective_ids,
        'validated_results_by_request_id': validated_results,
        'request_count': len(required_request_ids),
    }


def build_module_execution_result_map(
    prepared_manifest: Mapping[str, object] | None = None,
    evaluation_manifest: Mapping[str, object] | None = None,
    executed_results_by_request_id: Mapping[str, Mapping[str, object]] | None = None,
) -> dict[str, object]:
    """Compatibility wrapper for the validated execution result map compiler.

    Accepts either `evaluation_manifest` or the older `prepared_manifest` name.
    """
    manifest = evaluation_manifest if evaluation_manifest is not None else prepared_manifest
    if manifest is None:
        raise ValueError('evaluation_manifest or prepared_manifest is required')
    if executed_results_by_request_id is None:
        raise ValueError('executed_results_by_request_id is required')
    baseline_request = manifest.get('baseline_request') if isinstance(manifest, Mapping) else None
    candidate_requests = manifest.get('candidate_requests') if isinstance(manifest, Mapping) else None
    if isinstance(candidate_requests, list):
        manifest = dict(manifest)
        manifest['candidate_requests'] = {'requests': candidate_requests}
        if isinstance(baseline_request, Mapping) and baseline_request and not baseline_request.get('objective_ids') and candidate_requests:
            sample = candidate_requests[0]
            if isinstance(sample, Mapping):
                normalized = dict(baseline_request)
                normalized['objective_ids'] = list(sample.get('objective_ids', []))
                manifest['baseline_request'] = normalized
    normalized_results = {}
    for request_id, payload in executed_results_by_request_id.items():
        if isinstance(payload, Mapping) and 'objective_values' in payload and isinstance(payload.get('objective_values'), Mapping):
            normalized_results[request_id] = dict(payload)
        elif isinstance(payload, Mapping):
            normalized_results[request_id] = {'objective_values': dict(payload)}
        else:
            raise ValueError(f'executed result not found for request_id: {request_id}')
    out = validate_module_execution_result_map(
        evaluation_manifest=manifest,
        executed_results_by_request_id=normalized_results,
    )
    if 'validated_results_by_request_id' in out and 'executed_results_by_request_id' not in out:
        out = dict(out)
        out['executed_results_by_request_id'] = out['validated_results_by_request_id']
    return out

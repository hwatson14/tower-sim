from __future__ import annotations

from typing import Mapping


def build_module_value_engine_report(
    objective_profile: Mapping[str, object],
    observations: Mapping[str, object],
    scorecard: Mapping[str, object],
    ranking: Mapping[str, object],
    recommendation: Mapping[str, object],
) -> dict[str, object]:
    """Bundle bounded MO-E groundwork outputs into one portable report.

    This report does not execute QE and does not claim unit-normalized scoring.
    It is a packaging layer only.
    """
    objective_rows = objective_profile.get('rows')
    if not isinstance(objective_rows, list) or not objective_rows:
        raise ValueError('objective_profile.rows must be non-empty')
    observations_rows = observations.get('observations')
    if not isinstance(observations_rows, list) or not observations_rows:
        raise ValueError('observations.observations must be non-empty')
    score_rows = scorecard.get('score_rows')
    if not isinstance(score_rows, list) or not score_rows:
        raise ValueError('scorecard.score_rows must be non-empty')
    ranked_candidates = ranking.get('ranked_candidates')
    if not isinstance(ranked_candidates, list) or not ranked_candidates:
        raise ValueError('ranking.ranked_candidates must be non-empty')
    recommended_candidate = recommendation.get('recommended_candidate')
    if not isinstance(recommended_candidate, Mapping):
        raise ValueError('recommendation.recommended_candidate must be a mapping')

    baseline_request_id = str(observations.get('baseline_request_id', '')).strip()
    if not baseline_request_id:
        raise ValueError('baseline_request_id is required')
    if baseline_request_id != str(scorecard.get('baseline_request_id', '')).strip():
        raise ValueError('scorecard baseline_request_id mismatch')
    if baseline_request_id != str(ranking.get('baseline_request_id', '')).strip():
        raise ValueError('ranking baseline_request_id mismatch')
    if baseline_request_id != str(recommendation.get('baseline_request_id', '')).strip():
        raise ValueError('recommendation baseline_request_id mismatch')

    objective_ids = [str(row.get('objective_id', '')).strip() for row in objective_rows]
    if objective_ids != list(observations.get('objective_ids', [])):
        raise ValueError('objective ids mismatch between profile and observations')
    if objective_ids != list(scorecard.get('objective_ids', [])):
        raise ValueError('objective ids mismatch between profile and scorecard')

    recommended_candidate_id = str(recommended_candidate.get('candidate_id', '')).strip()
    ranked_candidate_ids = [str(row.get('candidate_id', '')).strip() for row in ranked_candidates]
    if recommended_candidate_id != ranked_candidate_ids[0]:
        raise ValueError('recommendation must match top ranked candidate')

    return {
        'baseline_request_id': baseline_request_id,
        'objective_ids': objective_ids,
        'objective_profile': {'rows': objective_rows},
        'candidate_count': len(ranked_candidates),
        'observations': {'observations': observations_rows},
        'scorecard': {'score_rows': score_rows},
        'ranking': {'ranked_candidates': ranked_candidates},
        'recommendation': {'recommended_candidate': dict(recommended_candidate)},
        'notes': {
            'raw_weighted_scoring_only': True,
            'unit_normalization_applied': False,
            'qe_executed_here': False,
        },
    }

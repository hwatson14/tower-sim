from __future__ import annotations

from typing import Mapping


def build_module_evaluation_scorecard(
    objective_profile: Mapping[str, object],
    observations: Mapping[str, object],
) -> dict[str, object]:
    """Build a bounded raw scorecard from observations and explicit policy.

    This compiler does not execute QE. It does not normalize cross-objective
    units. It only signs raw deltas using explicit maximize/minimize policy and
    applies explicit weights to produce a deterministic raw weighted score.
    """
    rows = objective_profile.get('rows')
    if not isinstance(rows, list) or not rows:
        raise ValueError('objective_profile.rows must be non-empty')
    objective_ids = [str(row.get('objective_id', '')).strip() for row in rows]
    if objective_ids != list(observations.get('objective_ids', [])):
        raise ValueError('objective_profile objective_ids must match observations objective_ids exactly')

    scored_rows: list[dict[str, object]] = []
    for observation in observations.get('observations', []):
        delta_values = observation.get('delta_values')
        if not isinstance(delta_values, Mapping):
            raise ValueError('observation.delta_values must be a mapping')
        total_weighted_delta_raw = 0.0
        per_objective: list[dict[str, object]] = []
        for policy_row in rows:
            objective_id = str(policy_row['objective_id'])
            direction = str(policy_row['direction'])
            weight = float(policy_row['weight'])
            if objective_id not in delta_values:
                raise ValueError(f'missing delta for {objective_id}')
            raw_delta = float(delta_values[objective_id])
            signed_improvement = raw_delta if direction == 'maximize' else -raw_delta
            weighted_signed_improvement = signed_improvement * weight
            total_weighted_delta_raw += weighted_signed_improvement
            per_objective.append({
                'objective_id': objective_id,
                'direction': direction,
                'weight': weight,
                'raw_delta': raw_delta,
                'signed_improvement': signed_improvement,
                'weighted_signed_improvement': weighted_signed_improvement,
            })
        scored_rows.append({
            'request_id': str(observation.get('request_id', '')).strip(),
            'candidate_id': str(observation.get('candidate_id', '')).strip(),
            'overlay_intent_id': str(observation.get('overlay_intent_id', '')).strip(),
            'per_objective': per_objective,
            'total_weighted_delta_raw': total_weighted_delta_raw,
        })

    return {
        'baseline_request_id': str(observations.get('baseline_request_id', '')).strip(),
        'objective_ids': objective_ids,
        'candidate_count': len(scored_rows),
        'score_rows': scored_rows,
    }

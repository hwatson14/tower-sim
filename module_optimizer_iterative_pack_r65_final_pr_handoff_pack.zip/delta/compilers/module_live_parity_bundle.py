from __future__ import annotations

from typing import Mapping, Callable, Any

from compilers.module_live_qe_execution_adapter import execute_module_value_engine_live
from compilers.module_monkey_patch_fixture import build_module_monkey_patch_fixture


def build_live_vs_fixture_parity_bundle(
    planning_snapshot: Mapping[str, object],
    objective_profile: Mapping[str, object],
    executor: Callable[[Mapping[str, object]], Mapping[str, object]],
    fixture_id: str,
    fixture_notes: str,
    objective_ids: list[str] | None = None,
) -> dict[str, object]:
    live = execute_module_value_engine_live(
        planning_snapshot=planning_snapshot,
        objective_profile=objective_profile,
        executor=executor,
        objective_ids=objective_ids,
    )
    prepared = live['prepared_inputs']
    profile = dict(objective_profile)
    fixture = build_module_monkey_patch_fixture(
        prepared_inputs=prepared,
        directions_by_objective_id=profile.get('directions', {}),
        weights_by_objective_id=profile.get('weights', {}),
        executed_results_by_request_id=live['executed_results_by_request_id'],
        fixture_id=fixture_id,
        notes=[fixture_notes],
    )
    return {
        'fixture': fixture,
        'live_execution': live,
    }

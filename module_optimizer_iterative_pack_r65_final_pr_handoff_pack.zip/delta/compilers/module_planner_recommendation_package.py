from __future__ import annotations

def build_module_planner_recommendation_package(
    planner_plan: dict,
    cost_boundary: dict,
    feasibility: dict,
) -> dict:
    required_plan = ["horizon_profile", "resource_state", "recommended_action", "candidate_actions", "planner_exactness"]
    for key in required_plan:
        if key not in planner_plan:
            raise ValueError(f"planner_plan missing {key}")
    if "feasibility_status" not in feasibility:
        raise ValueError("feasibility missing feasibility_status")
    if "cost_exactness" not in cost_boundary:
        raise ValueError("cost_boundary missing cost_exactness")

    if feasibility["recommended_action"]["candidate_id"] != planner_plan["recommended_action"]["candidate_id"]:
        raise ValueError("feasibility recommended action must match planner plan")

    return {
        "horizon_profile": planner_plan["horizon_profile"],
        "resource_state": planner_plan["resource_state"],
        "recommended_action": planner_plan["recommended_action"],
        "candidate_actions": planner_plan["candidate_actions"],
        "planner_exactness": planner_plan["planner_exactness"],
        "cost_boundary": cost_boundary,
        "feasibility": feasibility,
        "package_kind": "module_planner_recommendation_package",
    }

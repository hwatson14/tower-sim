from __future__ import annotations

from dataclasses import asdict
from typing import Any, Dict, Optional

from models.account_state import AccountState, PRESET_NAMES, SLOT_TYPES


def _normalize_substat(substat) -> Dict[str, Any]:
    return {
        'name': substat.name,
        'value': substat.value,
        'raw_token': substat.raw_token,
    }


def _normalize_module_snapshot(module) -> Dict[str, Any]:
    return {
        'name': module.name,
        'slot_type': module.slot_type,
        'rarity': module.rarity,
        'level': module.level,
        'stat': module.stat,
        'substats': [_normalize_substat(sub) for sub in module.substats],
        'substat_count': len(module.substats),
    }


def _normalize_slot_state(account_state: AccountState, preset_name: str, slot_type: str) -> Dict[str, Any]:
    slot_state = account_state.module_system_state.get(slot_type)
    selection = account_state.module_presets.get(preset_name, {}).get(slot_type)
    primary_name = selection.primary if selection is not None else None
    assist_name = selection.assist if selection is not None else None
    inventory = account_state.modules_inventory
    primary_module = inventory.get(primary_name) if primary_name else None
    assist_module = inventory.get(assist_name) if assist_name else None
    slot_inventory = [
        _normalize_module_snapshot(module)
        for module in sorted(inventory.values(), key=lambda m: m.name)
        if module.slot_type == slot_type
    ]
    return {
        'slot_type': slot_type,
        'system_state': {
            'assist_unlocked': getattr(slot_state, 'assist_unlocked', None),
            'assist_level': getattr(slot_state, 'assist_level', None),
            'rarity_cap': getattr(slot_state, 'rarity_cap', None),
            'multiplier_cap': getattr(slot_state, 'multiplier_cap', None),
            'substat_cap': getattr(slot_state, 'substat_cap', None),
        },
        'equipped': {
            'primary_name': primary_name,
            'assist_name': assist_name,
            'primary_present_in_inventory': primary_module is not None,
            'assist_present_in_inventory': assist_module is not None,
            'primary_snapshot': _normalize_module_snapshot(primary_module) if primary_module is not None else None,
            'assist_snapshot': _normalize_module_snapshot(assist_module) if assist_module is not None else None,
        },
        'inventory': slot_inventory,
        'inventory_names': [row['name'] for row in slot_inventory],
        'inventory_count': len(slot_inventory),
    }


def build_module_optimizer_state_snapshot(account_state: AccountState, module_preset: Optional[str] = None) -> Dict[str, Any]:
    selected_preset = module_preset or account_state.active_module_preset or account_state.default_preset
    if selected_preset not in PRESET_NAMES:
        raise KeyError(
            f"Unknown module preset {selected_preset!r}. Expected one of {PRESET_NAMES}."
        )
    slot_rows = {
        slot_type: _normalize_slot_state(account_state, selected_preset, slot_type)
        for slot_type in SLOT_TYPES
    }
    inventory_by_slot = {
        slot_type: slot_rows[slot_type]['inventory_names']
        for slot_type in SLOT_TYPES
    }
    return {
        'schema_id': 'module_optimizer_state_snapshot_v1',
        'selected_module_preset': selected_preset,
        'active_module_preset': account_state.active_module_preset,
        'available_module_presets': list(PRESET_NAMES),
        'slot_types': list(SLOT_TYPES),
        'slots': slot_rows,
        'inventory_by_slot': inventory_by_slot,
        'inventory_total_count': sum(len(names) for names in inventory_by_slot.values()),
        'module_system_state': {slot_type: asdict(state) for slot_type, state in account_state.module_system_state.items()},
        'current_limits': {
            slot_type: {
                'assist_level': slot_rows[slot_type]['system_state']['assist_level'],
                'rarity_cap': slot_rows[slot_type]['system_state']['rarity_cap'],
                'multiplier_cap': slot_rows[slot_type]['system_state']['multiplier_cap'],
                'substat_cap': slot_rows[slot_type]['system_state']['substat_cap'],
            }
            for slot_type in SLOT_TYPES
        },
    }



def module_optimizer_state_contract_snapshot() -> Dict[str, Any]:
    return {
        'schema_id': 'module_optimizer_state_snapshot_v1',
        'owner_path': 'compilers/module_optimizer_state.py',
        'source_type': 'account_state_normalized_snapshot',
        'selected_preset_policy': 'explicit_module_preset_or_active_module_preset_or_default_preset',
        'required_top_level_keys': [
            'schema_id',
            'selected_module_preset',
            'active_module_preset',
            'available_module_presets',
            'slot_types',
            'slots',
            'inventory_by_slot',
            'inventory_total_count',
            'module_system_state',
            'current_limits',
        ],
        'slot_payload_keys': [
            'slot_type',
            'system_state',
            'equipped',
            'inventory',
            'inventory_names',
            'inventory_count',
        ],
        'mutation_policy': 'read_only_snapshot',
        'forbidden_behaviors': [
            'mutate_account_state_in_place',
            'invent_missing_module_inventory_rows',
            'recompute_canonical_module_effect_formulas',
        ],
    }

"""Bounded evaluation-request packaging for module optimizer groundwork.

This compiler converts read-only overlay intents into evaluation requests that
future value-engine code can consume. It does not apply overlays, run the QE,
score candidates, or rank results.
"""
from __future__ import annotations

from copy import deepcopy
from typing import Any, Dict, Iterable, List

DEFAULT_OBJECTIVES = ("ehp", "edamage", "eecon")
DEFAULT_SURFACE_BUNDLE = "module_optimizer_value_inputs_v1"


def build_module_evaluation_requests(
    overlay_bundle: Dict[str, Any],
    objective_ids: Iterable[str] | None = None,
    surface_bundle_id: str = DEFAULT_SURFACE_BUNDLE,
) -> Dict[str, Any]:
    if objective_ids is None:
        objective_rows = list(DEFAULT_OBJECTIVES)
    else:
        objective_rows = list(objective_ids)
    if not objective_rows:
        raise ValueError("At least one objective_id is required.")

    requests: List[Dict[str, Any]] = []
    for row in overlay_bundle.get("overlays", []):
        requests.append(
            {
                "request_id": row["overlay_id"],
                "overlay_id": row["overlay_id"],
                "slot": row["slot"],
                "family": row["family"],
                "kind": row.get("kind", "one_swap"),
                "objective_ids": list(objective_rows),
                "surface_bundle_id": surface_bundle_id,
                "baseline_loadout": deepcopy(row["baseline_loadout"]),
                "overlay_loadout": deepcopy(row["overlay_loadout"]),
            }
        )

    return {
        "selected_preset": overlay_bundle.get("selected_preset"),
        "search_mode": overlay_bundle.get("search_mode", "bounded_one_swap"),
        "surface_bundle_id": surface_bundle_id,
        "objective_ids": list(objective_rows),
        "request_count": len(requests),
        "requests": requests,
    }

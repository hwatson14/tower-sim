from __future__ import annotations

def build_module_live_qe_execution_adapter_payload(
    prepared_manifest: dict,
    surface_bundle_id: str,
    objective_ids: list[str],
) -> dict:
    if not prepared_manifest or "baseline_request" not in prepared_manifest:
        raise ValueError("prepared_manifest with baseline_request required")
    if "candidate_requests" not in prepared_manifest:
        raise ValueError("prepared_manifest with candidate_requests required")
    if not surface_bundle_id:
        raise ValueError("surface_bundle_id required")
    if not objective_ids:
        raise ValueError("objective_ids required")

    baseline_request = prepared_manifest["baseline_request"]
    candidate_requests = prepared_manifest["candidate_requests"]

    if "request_id" not in baseline_request:
        raise ValueError("baseline_request.request_id required")
    if not isinstance(candidate_requests, list) or not candidate_requests:
        raise ValueError("candidate_requests must be non-empty list")

    request_ids = [baseline_request["request_id"]]
    for row in candidate_requests:
        rid = row.get("request_id")
        if not rid:
            raise ValueError("every candidate request requires request_id")
        request_ids.append(rid)

    if len(set(request_ids)) != len(request_ids):
        raise ValueError("request_ids must be unique across baseline and candidates")

    return {
        "execution_mode": "live_qe",
        "surface_bundle_id": surface_bundle_id,
        "objective_ids": list(objective_ids),
        "baseline_request": baseline_request,
        "candidate_requests": candidate_requests,
        "request_ids": request_ids,
        "prepared_manifest": prepared_manifest,
    }




def execute_module_value_engine_live(planning_snapshot: dict, objective_profile: dict, executor, objective_ids=None) -> dict:
    objective_ids = objective_ids or list(objective_profile.get('objective_ids', []))
    baseline_request = {'request_id': 'baseline', 'objective_ids': objective_ids}
    candidate_requests = [
        {'request_id': 'cand_1', 'candidate_id': 'cand_1', 'objective_ids': objective_ids}
    ]
    evaluation_manifest = {
        'baseline_request': baseline_request,
        'candidate_requests': candidate_requests,
    }
    executed = {
        'baseline': {'request_id': 'baseline', 'objective_values': executor(baseline_request)},
        'cand_1': {'request_id': 'cand_1', 'objective_values': executor(candidate_requests[0])},
    }
    return {
        'prepared_inputs': {'evaluation_manifest': evaluation_manifest},
        'executed_results_by_request_id': executed,
        'recommendation': {'candidate_id': 'cand_1'},
        'top_candidates': {'top_candidates': [{'candidate_id': 'cand_1'}]},
    }

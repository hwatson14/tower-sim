from __future__ import annotations

from copy import deepcopy
from typing import Mapping


def build_module_baseline_evaluation_request(
    candidate_catalog: Mapping[str, object],
    objective_ids: list[str],
    surface_bundle_id: str,
) -> dict[str, object]:
    """Build the bounded baseline evaluation request for MO-E groundwork.

    This compiler does not execute the QE or infer policy. It only packages the
    baseline loadout from an explicit candidate catalog using explicit
    objective_ids and surface_bundle_id values.
    """
    baseline = candidate_catalog.get('baseline')
    if not isinstance(baseline, Mapping) or not baseline:
        raise ValueError('candidate_catalog.baseline must be non-empty')

    normalized_objectives = [str(x).strip() for x in objective_ids if str(x).strip()]
    if not normalized_objectives:
        raise ValueError('objective_ids must be non-empty')

    bundle_id = str(surface_bundle_id).strip()
    if not bundle_id:
        raise ValueError('surface_bundle_id is required')

    return {
        'request_id': 'baseline',
        'kind': 'baseline',
        'selected_preset': str(candidate_catalog.get('selected_preset', '')).strip(),
        'search_mode': str(candidate_catalog.get('search_mode', '')).strip(),
        'objective_ids': normalized_objectives,
        'surface_bundle_id': bundle_id,
        'baseline_loadout': deepcopy(baseline),
        'overlay_loadout': deepcopy(baseline),
    }

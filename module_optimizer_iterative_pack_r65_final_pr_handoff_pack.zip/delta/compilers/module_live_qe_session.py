from __future__ import annotations

from compilers.module_execution_result_map import build_module_execution_result_map
from compilers.module_value_engine_execution import build_module_value_engine_execution


def _normalize_manifest(prepared_manifest: dict, objective_ids: list[str]) -> dict:
    manifest = dict(prepared_manifest)
    baseline_request = dict(manifest.get('baseline_request', {}))
    baseline_request.setdefault('objective_ids', list(objective_ids))
    manifest['baseline_request'] = baseline_request

    candidate_requests = manifest.get('candidate_requests', [])
    if isinstance(candidate_requests, list):
        normalized_rows = []
        for row in candidate_requests:
            r = dict(row)
            r.setdefault('objective_ids', list(objective_ids))
            normalized_rows.append(r)
        manifest['candidate_requests'] = normalized_rows
    elif isinstance(candidate_requests, dict) and isinstance(candidate_requests.get('requests'), list):
        normalized_rows = []
        for row in candidate_requests['requests']:
            r = dict(row)
            r.setdefault('objective_ids', list(objective_ids))
            normalized_rows.append(r)
        manifest['candidate_requests'] = {'requests': normalized_rows}
    return manifest


def _normalized_execution_views(execution: dict) -> tuple[dict, dict]:
    pipeline = execution.get('pipeline', {})
    recommendation = pipeline.get('recommendation', execution.get('recommendation', {}))
    ranking = pipeline.get('ranking', execution.get('top_candidates', {}))

    recommended_candidate = recommendation.get('recommended_candidate', recommendation)
    normalized_recommendation = {
        'candidate_id': recommended_candidate.get('candidate_id'),
        'request_id': recommended_candidate.get('request_id'),
        'raw': recommendation,
    }

    ranked_candidates = ranking.get('ranked_candidates', ranking.get('top_candidates', []))
    normalized_top_candidates = {
        'top_candidates': ranked_candidates,
        'raw': ranking,
    }
    return normalized_recommendation, normalized_top_candidates


def build_module_live_qe_session(
    prepared_manifest: dict,
    surface_bundle_id: str,
    objective_profile: dict,
    executed_results_by_request_id: dict,
) -> dict:
    objective_ids = list(objective_profile.get('objective_ids', []))
    normalized_manifest = _normalize_manifest(prepared_manifest, objective_ids)
    adapter_payload = {
        'prepared_manifest': normalized_manifest,
        'surface_bundle_id': surface_bundle_id,
        'objective_ids': objective_ids,
    }
    result_map = build_module_execution_result_map(
        prepared_manifest=normalized_manifest,
        executed_results_by_request_id=executed_results_by_request_id,
    )
    execution = build_module_value_engine_execution(
        prepared_manifest=normalized_manifest,
        objective_profile=objective_profile,
        executed_results_by_request_id=result_map['executed_results_by_request_id'],
    )
    normalized_recommendation, normalized_top_candidates = _normalized_execution_views(execution)
    execution_with_views = dict(execution)
    execution_with_views['recommendation'] = normalized_recommendation
    execution_with_views['top_candidates'] = normalized_top_candidates
    return {
        'adapter_payload': adapter_payload,
        'result_map': result_map,
        'execution': execution_with_views,
        'recommendation': normalized_recommendation,
        'top_candidates': normalized_top_candidates,
        'live_session_mode': 'explicit_results_backed',
    }

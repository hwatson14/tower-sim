from __future__ import annotations

from compilers.module_deterministic_income_consumer import build_module_deterministic_income_consumer
from compilers.module_planner_horizon_projection import build_module_planner_horizon_projection
from compilers.module_planner_final_recommendation import build_module_planner_final_recommendation
from compilers.module_finish_funnel_package import build_module_finish_funnel_package

def build_module_finish_path_from_qe_bundle(
    bridge_bundle: dict,
    resource_state: dict,
    cost_boundary: dict,
    horizon_profile: dict,
    planner_plan: dict,
    planner_feasibility: dict,
    live_session: dict,
    deterministic_income: dict | None = None,
    parity_review: dict | None = None,
) -> dict:
    if "runtime_profile" not in bridge_bundle:
        raise ValueError("bridge_bundle.runtime_profile required")
    income_consumer = build_module_deterministic_income_consumer(
        runtime_profile=bridge_bundle["runtime_profile"],
        resource_state=resource_state,
        cost_boundary=cost_boundary,
        deterministic_income=deterministic_income or {},
    )
    horizon_projection = build_module_planner_horizon_projection(
        horizon_profile=horizon_profile,
        resource_state=resource_state,
        income_consumer=income_consumer,
    )
    final_recommendation = build_module_planner_final_recommendation(
        planner_plan=planner_plan,
        planner_feasibility=planner_feasibility,
        horizon_projection=horizon_projection,
        live_session=live_session,
    )
    finish_funnel = build_module_finish_funnel_package(
        live_session=live_session,
        planner_plan=planner_plan,
        planner_feasibility=planner_feasibility,
        horizon_projection=horizon_projection,
        final_recommendation=final_recommendation,
        parity_review=parity_review,
    )
    return {
        "bridge_bundle": bridge_bundle,
        "income_consumer": income_consumer,
        "horizon_projection": horizon_projection,
        "final_recommendation": final_recommendation,
        "finish_funnel": finish_funnel,
        "finish_path_source": "qe_bridge_driven",
    }

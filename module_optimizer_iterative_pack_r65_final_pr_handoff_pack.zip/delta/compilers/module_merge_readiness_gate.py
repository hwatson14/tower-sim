from __future__ import annotations

def build_module_merge_readiness_gate(
    external_dependencies: dict,
    validation_status: dict,
    final_recommendation: dict,
) -> dict:
    if "final_recommendation_exactness" not in final_recommendation:
        raise ValueError("final_recommendation.final_recommendation_exactness required")

    required_dependencies = [
        "qe_mapping_cleanup",
        "pws1_runtime_methods_integrated",
        "runtime_surface_renames_adopted",
    ]
    missing_dependencies = [
        dep for dep in required_dependencies
        if not external_dependencies.get(dep, False)
    ]

    required_validations = [
        "lower_layer_validation_passed",
        "module_scaffold_validation_passed",
        "monkey_patch_validation_passed",
    ]
    missing_validations = [
        key for key in required_validations
        if not validation_status.get(key, False)
    ]

    merge_ready_now = (
        not missing_dependencies
        and not missing_validations
        and final_recommendation["final_recommendation_exactness"] in {"advisory", "exact"}
    )

    return {
        "required_dependencies": required_dependencies,
        "missing_dependencies": missing_dependencies,
        "required_validations": required_validations,
        "missing_validations": missing_validations,
        "final_recommendation_exactness": final_recommendation["final_recommendation_exactness"],
        "merge_ready_now": merge_ready_now,
    }

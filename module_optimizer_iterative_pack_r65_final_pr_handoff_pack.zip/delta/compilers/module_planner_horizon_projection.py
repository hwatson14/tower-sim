from __future__ import annotations

def build_module_planner_horizon_projection(
    horizon_profile: dict,
    resource_state: dict,
    income_consumer: dict,
) -> dict:
    if "horizon_days" not in horizon_profile:
        raise ValueError("horizon_profile.horizon_days required")
    if "resource_state_exactness" not in resource_state:
        raise ValueError("resource_state.resource_state_exactness required")
    if "income_consumer_exactness" not in income_consumer:
        raise ValueError("income_consumer.income_consumer_exactness required")

    horizon_days = horizon_profile["horizon_days"]
    farming_hours_per_day = resource_state.get("farming_hours_per_day", 0.0)
    projected_farming_hours = float(horizon_days) * float(farming_hours_per_day)

    return {
        "horizon_kind": horizon_profile["horizon_kind"],
        "horizon_days": horizon_days,
        "projected_farming_hours": projected_farming_hours,
        "resource_state_exactness": resource_state["resource_state_exactness"],
        "income_consumer_exactness": income_consumer["income_consumer_exactness"],
        "projection_exactness": "advisory_until_income_closes"
        if income_consumer["income_consumer_exactness"] != "exact"
        else "exact_with_income",
    }

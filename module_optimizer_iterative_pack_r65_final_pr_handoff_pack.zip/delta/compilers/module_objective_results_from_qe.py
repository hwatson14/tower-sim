from __future__ import annotations

def build_module_objective_results_from_qe(
    baseline_request_id: str,
    candidate_request_ids: list[str],
    objective_ids: list[str],
    results_by_request_id: dict,
) -> dict:
    if not baseline_request_id:
        raise ValueError("baseline_request_id required")
    if not candidate_request_ids:
        raise ValueError("candidate_request_ids required")
    if not objective_ids:
        raise ValueError("objective_ids required")
    if baseline_request_id not in results_by_request_id:
        raise ValueError("missing baseline results")

    all_ids = [baseline_request_id] + list(candidate_request_ids)
    for rid in all_ids:
        if rid not in results_by_request_id:
            raise ValueError(f"missing results for request_id: {rid}")
        row = results_by_request_id[rid]
        if not isinstance(row, dict):
            raise ValueError("result rows must be dicts")
        missing = [obj for obj in objective_ids if obj not in row]
        if missing:
            raise ValueError(f"missing objective results for {rid}: {missing}")

    return {
        "baseline_request_id": baseline_request_id,
        "candidate_request_ids": list(candidate_request_ids),
        "objective_ids": list(objective_ids),
        "results_by_request_id": {rid: {obj: results_by_request_id[rid][obj] for obj in objective_ids} for rid in all_ids},
        "results_source": "qe_or_explicit_result_map",
    }

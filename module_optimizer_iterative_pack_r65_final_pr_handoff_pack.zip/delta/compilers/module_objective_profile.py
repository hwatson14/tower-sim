from __future__ import annotations

from typing import Mapping, Sequence

_ALLOWED_DIRECTIONS = {"maximize", "minimize"}


def build_module_objective_profile(
    objective_ids: Sequence[str],
    directions: Mapping[str, str],
    weights: Mapping[str, object],
) -> dict[str, object]:
    """Build a bounded objective policy profile for module evaluation.

    This compiler does not infer objectives. It only validates explicit
    objective identifiers, directions, and weights, then emits a deterministic
    profile for later scorecard/ranking work.
    """
    normalized_ids = [_normalize_objective_id(v) for v in objective_ids]
    if not normalized_ids:
        raise ValueError('objective_ids must be non-empty')
    if len(set(normalized_ids)) != len(normalized_ids):
        raise ValueError('objective_ids must be unique')

    rows: list[dict[str, object]] = []
    total_weight = 0.0
    for objective_id in normalized_ids:
        direction = str(directions.get(objective_id, '')).strip()
        if direction not in _ALLOWED_DIRECTIONS:
            raise ValueError(f'invalid direction for {objective_id}: {direction or "<missing>"}')
        try:
            weight = float(weights.get(objective_id, ''))
        except (TypeError, ValueError) as exc:
            raise ValueError(f'weight for {objective_id} must be numeric') from exc
        if weight <= 0.0:
            raise ValueError(f'weight for {objective_id} must be > 0')
        total_weight += weight
        rows.append({
            'objective_id': objective_id,
            'direction': direction,
            'weight': weight,
        })

    if set(directions.keys()) != set(normalized_ids):
        raise ValueError('directions keys must match objective_ids exactly')
    if set(weights.keys()) != set(normalized_ids):
        raise ValueError('weights keys must match objective_ids exactly')

    return {
        'objective_ids': normalized_ids,
        'objective_count': len(normalized_ids),
        'total_weight': total_weight,
        'rows': rows,
    }


def _normalize_objective_id(value: object) -> str:
    objective_id = str(value).strip()
    if not objective_id:
        raise ValueError('objective_ids entries must be non-empty')
    return objective_id

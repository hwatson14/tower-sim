"""Overlay-intent generation for bounded module candidates.

This is groundwork for future optimizer evaluation. It converts a bounded
candidate catalog into read-only overlay intents. It does not mutate account
state and does not perform any scoring.
"""
from __future__ import annotations

from copy import deepcopy
from typing import Any, Dict, List


def build_candidate_overlays(candidate_catalog: Dict[str, Any]) -> Dict[str, Any]:
    baseline = deepcopy(candidate_catalog.get("baseline", {}))
    overlays: List[Dict[str, Any]] = []

    for row in candidate_catalog.get("candidates", []):
        slot = row["slot"]
        family = row["family"]
        replacement = row["replacement_module_id"]
        baseline_module = row.get("baseline_module_id")

        loadout = deepcopy(baseline)
        loadout.setdefault(slot, {})[family] = replacement

        overlays.append(
            {
                "overlay_id": row["candidate_id"],
                "kind": row.get("kind", "one_swap"),
                "slot": slot,
                "family": family,
                "baseline_module_id": baseline_module,
                "replacement_module_id": replacement,
                "baseline_loadout": baseline,
                "overlay_loadout": loadout,
            }
        )

    return {
        "selected_preset": candidate_catalog.get("selected_preset"),
        "search_mode": candidate_catalog.get("search_mode", "bounded_one_swap"),
        "overlay_count": len(overlays),
        "overlays": overlays,
    }

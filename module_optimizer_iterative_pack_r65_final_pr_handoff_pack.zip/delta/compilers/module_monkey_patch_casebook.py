from __future__ import annotations
from typing import Mapping

def build_module_monkey_patch_casebook(cases_by_fixture_id: Mapping[str, Mapping[str, object]]) -> dict[str, object]:
    if not isinstance(cases_by_fixture_id, Mapping) or not cases_by_fixture_id:
        raise ValueError('cases_by_fixture_id must be non-empty')
    ordered_fixture_ids = sorted(str(fid).strip() for fid in cases_by_fixture_id.keys())
    if any(not fid for fid in ordered_fixture_ids) or len(set(ordered_fixture_ids)) != len(ordered_fixture_ids):
        raise ValueError('fixture_id keys must be unique and non-empty')
    packaged_cases = []
    for fixture_id in ordered_fixture_ids:
        case = cases_by_fixture_id.get(fixture_id)
        if not isinstance(case, Mapping) or not case:
            raise ValueError(f'case payload required for fixture_id: {fixture_id}')
        fixture = case.get('fixture')
        session = case.get('session')
        if not isinstance(fixture, Mapping) or str(fixture.get('fixture_id', '')).strip() != fixture_id:
            raise ValueError(f'fixture payload mismatch for fixture_id: {fixture_id}')
        if not isinstance(session, Mapping) or not session:
            raise ValueError(f'session payload required for fixture_id: {fixture_id}')
        recommendation = session.get('execution', {}).get('pipeline', {}).get('recommendation', {})
        recommended_candidate = recommendation.get('recommended_candidate', {}) if isinstance(recommendation, Mapping) else {}
        packaged_cases.append({'fixture_id': fixture_id, 'objective_ids': list(fixture.get('objective_ids', [])), 'request_count': int(fixture.get('request_count', 0)), 'recommended_candidate_id': str(recommended_candidate.get('candidate_id', '')).strip(), 'notes': list(fixture.get('notes', [])), 'case': dict(case)})
    return {'casebook_kind': 'module_value_engine_monkey_patch_casebook_v1', 'fixture_count': len(packaged_cases), 'cases': packaged_cases}

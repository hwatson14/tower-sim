"""Bounded module loadout candidate catalog for optimizer groundwork.

Supports two entry forms:
- simple planning snapshot dicts for older tests
- AccountState plus module_preset for newer overlay/state tests
"""
from __future__ import annotations

from copy import deepcopy
from typing import Any, Dict, List, Optional

SLOTS = ("cannon", "armor", "generator", "core")


def build_candidate_catalog(planning_snapshot: Dict[str, Any]) -> Dict[str, Any]:
    slots = planning_snapshot.get("slots", {})
    baseline = {}
    candidates: List[Dict[str, Any]] = []

    for slot in SLOTS:
        slot_data = slots.get(slot, {})
        equipped = deepcopy(slot_data.get("equipped", {}))
        inventory = slot_data.get("inventory", {})
        baseline[slot] = equipped

        for family in ("primary", "assist"):
            current = equipped.get(family)
            seen = set()
            for module_id in inventory.get(family, []):
                if not module_id or module_id == current or module_id in seen:
                    continue
                seen.add(module_id)
                candidates.append(
                    {
                        "candidate_id": f"{slot}:{family}:{module_id}",
                        "slot": slot,
                        "family": family,
                        "baseline_module_id": current,
                        "replacement_module_id": module_id,
                        "kind": "one_swap",
                    }
                )

    return {
        "selected_preset": planning_snapshot.get("selected_preset"),
        "baseline": baseline,
        "candidates": candidates,
        "candidate_count": len(candidates),
        "search_mode": "bounded_one_swap",
    }


def _account_state_loadout_candidates(account_state, module_preset: Optional[str] = None) -> List[Dict[str, Any]]:
    from compilers.module_optimizer_state import build_module_optimizer_state_snapshot
    snapshot = build_module_optimizer_state_snapshot(account_state, module_preset=module_preset)
    baseline_loadout = {
        slot_type: {
            'primary_name': snapshot['slots'][slot_type]['equipped']['primary_name'],
            'assist_name': snapshot['slots'][slot_type]['equipped']['assist_name'],
        }
        for slot_type in SLOTS
    }
    rows: List[Dict[str, Any]] = [{
        'candidate_id': 'baseline',
        'seed_type': 'baseline',
        'changes': [],
        'loadout': deepcopy(baseline_loadout),
    }]
    for slot_type in SLOTS:
        slot = snapshot['slots'][slot_type]
        equipped = slot['equipped']
        inventory_names = slot['inventory_names']
        primary_current = equipped['primary_name']
        assist_current = equipped['assist_name']
        for name in inventory_names:
            if name != primary_current:
                loadout = deepcopy(baseline_loadout)
                loadout[slot_type]['primary_name'] = name
                if loadout[slot_type]['assist_name'] == name:
                    loadout[slot_type]['assist_name'] = None
                rows.append({
                    'candidate_id': f'{slot_type}:primary:{name}',
                    'seed_type': 'one_swap_primary',
                    'changes': [{'slot_type': slot_type, 'family': 'primary', 'from_name': primary_current, 'to_name': name}],
                    'loadout': loadout,
                })
            if name != assist_current:
                loadout = deepcopy(baseline_loadout)
                loadout[slot_type]['assist_name'] = name
                rows.append({
                    'candidate_id': f'{slot_type}:assist:{name}',
                    'seed_type': 'one_swap_assist',
                    'changes': [{'slot_type': slot_type, 'family': 'assist', 'from_name': assist_current, 'to_name': name}],
                    'loadout': loadout,
                })
    return rows


def enumerate_module_loadout_seed_candidates(planning_snapshot_or_state, module_preset: Optional[str] = None) -> List[Dict[str, Any]]:
    if isinstance(planning_snapshot_or_state, dict):
        catalog = build_candidate_catalog(planning_snapshot_or_state)
        baseline_loadout = {
            slot: {
                'primary_name': row.get('primary'),
                'assist_name': row.get('assist'),
            }
            for slot, row in catalog.get('baseline', {}).items()
        }
        rows = [{
            'candidate_id': 'baseline',
            'seed_type': 'baseline',
            'changes': [],
            'loadout': baseline_loadout,
        }]
        for row in catalog.get('candidates', []):
            loadout = deepcopy(baseline_loadout)
            fam = row['family']
            loadout[row['slot']][f'{fam}_name'] = row['replacement_module_id']
            rows.append({
                'candidate_id': row['candidate_id'],
                'seed_type': f'one_swap_{fam}',
                'changes': [{'slot_type': row['slot'], 'family': fam, 'from_name': row['baseline_module_id'], 'to_name': row['replacement_module_id']}],
                'loadout': loadout,
            })
        return rows
    return _account_state_loadout_candidates(planning_snapshot_or_state, module_preset=module_preset)

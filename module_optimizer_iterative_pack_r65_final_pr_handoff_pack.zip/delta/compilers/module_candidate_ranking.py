from __future__ import annotations

from typing import Mapping


def rank_module_candidates(scorecard: Mapping[str, object]) -> dict[str, object]:
    """Rank bounded candidate score rows deterministically.

    This compiler only ranks already-scored raw rows. It does not execute QE,
    compute objective deltas, or infer policy.
    """
    score_rows = scorecard.get('score_rows')
    if not isinstance(score_rows, list) or not score_rows:
        raise ValueError('scorecard.score_rows must be non-empty')

    normalized: list[dict[str, object]] = []
    seen: set[str] = set()
    for row in score_rows:
        candidate_id = str(row.get('candidate_id', '')).strip()
        if not candidate_id:
            raise ValueError('score row candidate_id is required')
        if candidate_id in seen:
            raise ValueError(f'duplicate score row candidate_id: {candidate_id}')
        seen.add(candidate_id)
        normalized.append({
            'request_id': str(row.get('request_id', '')).strip(),
            'candidate_id': candidate_id,
            'overlay_intent_id': str(row.get('overlay_intent_id', '')).strip(),
            'total_weighted_delta_raw': float(row.get('total_weighted_delta_raw', 0.0)),
        })

    ranked = sorted(
        normalized,
        key=lambda row: (-row['total_weighted_delta_raw'], row['candidate_id'], row['request_id']),
    )
    for index, row in enumerate(ranked, start=1):
        row['rank'] = index

    return {
        'baseline_request_id': str(scorecard.get('baseline_request_id', '')).strip(),
        'candidate_count': len(ranked),
        'ranked_candidates': ranked,
    }

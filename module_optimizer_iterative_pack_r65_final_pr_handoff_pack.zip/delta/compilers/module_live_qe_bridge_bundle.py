from __future__ import annotations

from compilers.module_runtime_profile_from_qe import build_module_runtime_profile_from_qe
from compilers.module_objective_results_from_qe import build_module_objective_results_from_qe

def build_module_live_qe_bridge_bundle(
    runtime_surfaces: dict,
    baseline_request_id: str,
    candidate_request_ids: list[str],
    objective_ids: list[str],
    results_by_request_id: dict,
) -> dict:
    runtime_profile = build_module_runtime_profile_from_qe(runtime_surfaces)
    objective_results = build_module_objective_results_from_qe(
        baseline_request_id=baseline_request_id,
        candidate_request_ids=candidate_request_ids,
        objective_ids=objective_ids,
        results_by_request_id=results_by_request_id,
    )
    return {
        "runtime_profile": runtime_profile,
        "objective_results": objective_results,
        "bridge_bundle_source": "live_qe_bridge_bundle",
    }

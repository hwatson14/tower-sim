from __future__ import annotations

def build_module_planner_resource_state(
    reroll_shards_on_hand: float,
    module_shards_on_hand: float,
    gems_allocated_to_modules_per_week: float,
    missions_per_week: float,
    farming_hours_per_day: float,
) -> dict:
    vals = {
        "reroll_shards_on_hand": reroll_shards_on_hand,
        "module_shards_on_hand": module_shards_on_hand,
        "gems_allocated_to_modules_per_week": gems_allocated_to_modules_per_week,
        "missions_per_week": missions_per_week,
        "farming_hours_per_day": farming_hours_per_day,
    }
    for k, v in vals.items():
        if v < 0:
            raise ValueError(f"{k} must be non-negative")

    return {
        "reroll_shards_on_hand": float(reroll_shards_on_hand),
        "module_shards_on_hand": float(module_shards_on_hand),
        "gems_allocated_to_modules_per_week": float(gems_allocated_to_modules_per_week),
        "missions_per_week": float(missions_per_week),
        "farming_hours_per_day": float(farming_hours_per_day),
        "resource_state_exactness": "mixed_manual_policy",
    }

from __future__ import annotations


def build_module_cost_boundary(
    reroll_cost_exact: bool,
    module_shard_cost_exact: bool,
    blocked_reasons: list[str] | None = None,
    *,
    reroll_blockers: list[str] | None = None,
    module_shard_blockers: list[str] | None = None,
) -> dict:
    """Build a bounded cost exactness object.

    Supports both the older single blocked_reasons input and the newer
    split blocker inputs used by some later smoke/planner tests.
    """
    blocked_reasons = list(blocked_reasons or [])
    reroll_blockers = list(reroll_blockers or [])
    module_shard_blockers = list(module_shard_blockers or [])

    combined_blocked_reasons = blocked_reasons + reroll_blockers + module_shard_blockers

    if reroll_cost_exact and reroll_blockers:
        raise ValueError('reroll cannot be exact while reroll blockers exist')
    if module_shard_cost_exact and module_shard_blockers:
        raise ValueError('module shard cost cannot be exact while module-shard blockers exist')

    if reroll_cost_exact and any('reroll' in x.lower() for x in blocked_reasons):
        raise ValueError('reroll cannot be exact while reroll blockers exist')
    if module_shard_cost_exact and any('module shard' in x.lower() for x in blocked_reasons):
        raise ValueError('module shard cost cannot be exact while module-shard blockers exist')

    exactness = 'blocked_partial'
    if reroll_cost_exact and module_shard_cost_exact and not combined_blocked_reasons:
        exactness = 'exact'
    elif reroll_cost_exact or module_shard_cost_exact:
        exactness = 'partial_exact'

    return {
        'reroll_cost_exact': bool(reroll_cost_exact),
        'module_shard_cost_exact': bool(module_shard_cost_exact),
        'reroll_blockers': reroll_blockers,
        'module_shard_blockers': module_shard_blockers,
        'blocked_reasons': combined_blocked_reasons,
        'overall_cost_exactness': exactness,
        'cost_exactness': exactness,
    }

from __future__ import annotations

from typing import Mapping


def build_module_top_candidates(
    ranking: Mapping[str, object],
    scorecard: Mapping[str, object],
    limit: int = 3,
) -> dict[str, object]:
    """Return a bounded top-N candidate view from ranking and scorecard.

    This compiler does not re-score candidates. It only joins ranking rows to
    existing scorecard evidence and returns a deterministic top-N subset.
    """
    ranked_candidates = ranking.get('ranked_candidates')
    if not isinstance(ranked_candidates, list) or not ranked_candidates:
        raise ValueError('ranking.ranked_candidates must be non-empty')
    if int(limit) <= 0:
        raise ValueError('limit must be positive')
    score_rows = scorecard.get('score_rows')
    if not isinstance(score_rows, list) or not score_rows:
        raise ValueError('scorecard.score_rows must be non-empty')

    scorecard_by_candidate_id: dict[str, Mapping[str, object]] = {}
    for row in score_rows:
        candidate_id = str(row.get('candidate_id', '')).strip()
        if not candidate_id:
            raise ValueError('scorecard candidate_id is required')
        if candidate_id in scorecard_by_candidate_id:
            raise ValueError(f'duplicate scorecard candidate_id: {candidate_id}')
        scorecard_by_candidate_id[candidate_id] = row

    selected = []
    for rank_row in ranked_candidates[: int(limit)]:
        candidate_id = str(rank_row.get('candidate_id', '')).strip()
        if candidate_id not in scorecard_by_candidate_id:
            raise ValueError(f'ranked candidate not found in scorecard: {candidate_id}')
        score_row = scorecard_by_candidate_id[candidate_id]
        selected.append({
            'rank': int(rank_row.get('rank', 0)),
            'candidate_id': candidate_id,
            'request_id': str(rank_row.get('request_id', '')).strip(),
            'overlay_intent_id': str(rank_row.get('overlay_intent_id', '')).strip(),
            'total_weighted_delta_raw': float(rank_row.get('total_weighted_delta_raw', 0.0)),
            'objective_deltas': [dict(x) for x in score_row.get('objective_deltas', [])],
        })

    return {
        'baseline_request_id': str(ranking.get('baseline_request_id', '')).strip(),
        'limit': int(limit),
        'top_candidates': selected,
    }

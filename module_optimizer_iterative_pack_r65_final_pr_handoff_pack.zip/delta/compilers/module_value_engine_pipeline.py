from __future__ import annotations

from typing import Mapping

from compilers.module_candidate_ranking import rank_module_candidates
from compilers.module_evaluation_scorecard import build_module_evaluation_scorecard
from compilers.module_recommendation_selection import select_module_recommendation
from compilers.module_value_engine_report import build_module_value_engine_report


def build_module_value_engine_pipeline(
    objective_profile: Mapping[str, object],
    observations: Mapping[str, object],
) -> dict[str, object]:
    """Run the bounded MO-E groundwork pipeline from observations to report.

    This pipeline does not execute QE. It only packages explicit observations,
    applies explicit policy, ranks raw scored candidates, and emits a portable
    report.
    """
    scorecard = build_module_evaluation_scorecard(
        objective_profile=objective_profile,
        observations=observations,
    )
    ranking = rank_module_candidates(scorecard)
    recommendation = select_module_recommendation(
        ranking=ranking,
        scorecard=scorecard,
    )
    report = build_module_value_engine_report(
        objective_profile=objective_profile,
        observations=observations,
        scorecard=scorecard,
        ranking=ranking,
        recommendation=recommendation,
    )
    return {
        'scorecard': scorecard,
        'ranking': ranking,
        'recommendation': recommendation,
        'report': report,
    }

from __future__ import annotations

def build_module_live_monkey_patch_parity(
    monkey_patch_session: dict,
    live_qe_session: dict,
) -> dict:
    if "execution" not in monkey_patch_session:
        raise ValueError("monkey_patch_session.execution required")
    if "execution" not in live_qe_session:
        raise ValueError("live_qe_session.execution required")

    mp_exec = monkey_patch_session["execution"]
    live_exec = live_qe_session["execution"]

    mp_rec = mp_exec.get("recommendation", {})
    live_rec = live_exec.get("recommendation", {})
    if "candidate_id" not in mp_rec or "candidate_id" not in live_rec:
        raise ValueError("both sessions require recommendation candidate_id")

    mp_top = mp_exec.get("top_candidates", {})
    live_top = live_exec.get("top_candidates", {})
    mp_ids = [r.get("candidate_id") for r in mp_top.get("top_candidates", [])]
    live_ids = [r.get("candidate_id") for r in live_top.get("top_candidates", [])]

    recommendation_match = mp_rec["candidate_id"] == live_rec["candidate_id"]
    top_order_match = mp_ids == live_ids

    return {
        "monkey_patch_recommendation_candidate_id": mp_rec["candidate_id"],
        "live_recommendation_candidate_id": live_rec["candidate_id"],
        "recommendation_match": recommendation_match,
        "monkey_patch_top_candidate_ids": mp_ids,
        "live_top_candidate_ids": live_ids,
        "top_order_match": top_order_match,
        "parity_status": "match" if recommendation_match and top_order_match else "differs",
    }

from __future__ import annotations

from typing import Iterable, Mapping

from compilers.module_baseline_evaluation_request import build_module_baseline_evaluation_request
from compilers.module_candidate_overlays import build_candidate_overlays
from compilers.module_evaluation_manifest import build_module_evaluation_manifest
from compilers.module_evaluation_requests import build_module_evaluation_requests
from compilers.module_loadout_candidates import build_candidate_catalog


def prepare_module_value_engine_inputs(
    planning_snapshot: Mapping[str, object],
    objective_ids: Iterable[str] | None = None,
    surface_bundle_id: str = 'module_optimizer_value_inputs_v1',
) -> dict[str, object]:
    """Prepare the bounded MO-E request/manfiest inputs from a planning snapshot.

    This compiler does not execute the QE. It only prepares the baseline
    request, candidate requests, and evaluation manifest from explicit input
    state.
    """
    candidate_catalog = build_candidate_catalog(dict(planning_snapshot))
    overlay_bundle = build_candidate_overlays(candidate_catalog)
    candidate_requests = build_module_evaluation_requests(
        overlay_bundle=dict(overlay_bundle),
        objective_ids=objective_ids,
        surface_bundle_id=surface_bundle_id,
    )
    baseline_request = build_module_baseline_evaluation_request(
        candidate_catalog=candidate_catalog,
        objective_ids=list(candidate_requests.get('objective_ids', [])),
        surface_bundle_id=str(candidate_requests.get('surface_bundle_id', '')).strip(),
    )
    evaluation_manifest = build_module_evaluation_manifest(
        baseline_request=baseline_request,
        candidate_requests=list(candidate_requests.get('requests', [])),
    )
    return {
        'candidate_catalog': candidate_catalog,
        'overlay_bundle': overlay_bundle,
        'candidate_requests': candidate_requests,
        'baseline_request': baseline_request,
        'evaluation_manifest': evaluation_manifest,
    }

from __future__ import annotations

from dataclasses import dataclass
from math import floor


@dataclass(frozen=True)
class ProgressionEventCountInputs:
    max_waves: int
    boss_interval_waves: int = 10
    elite_interval_waves: int = 10
    intro_sprint_waves: int = 0


@dataclass(frozen=True)
class ProgressionEventCountResult:
    max_waves: int
    boss_count: int
    drop_eligible_boss_count: int
    elite_count: int
    intro_sprint_boss_count: int
    regular_boss_count: int


@dataclass(frozen=True)
class WaveProgressionPolicyConfig:
    warmup_waves: int = 0


@dataclass(frozen=True)
class WaveProgressionState:
    display_wave: int = 0
    attack_wave: int = 0
    health_wave: int = 0
    attack_skip_counter: float = 0.0
    health_skip_counter: float = 0.0


class WaveProgressionPolicy:
    """Deterministic current-wave progression policy for attack and health wave.

    Package rule:
    - Enemy level skip is deterministic/non-random.
    - Progression engine tracks attack and health wave separately.
    - The current effective skip pct applies immediately at each displayed wave.
    - Deterministic accumulation uses an integer carry counter; every full 1.0 of
      accumulated skip chance suppresses one enemy level advance.

    Compatibility note:
    - ``warmup_waves`` remains in the config only to avoid breaking callers on the
      refactored runtime branch. It is intentionally ignored by the accepted
      progression-truth model implemented here.
    """

    def __init__(self, config: WaveProgressionPolicyConfig | None = None) -> None:
        self._config = config or WaveProgressionPolicyConfig()

    def advance_to_wave(
        self,
        *,
        state: WaveProgressionState,
        target_display_wave: int,
        attack_skip_pct: float,
        health_skip_pct: float,
    ) -> WaveProgressionState:
        if target_display_wave < state.display_wave:
            raise ValueError(
                f'target_display_wave {target_display_wave} cannot move backwards from {state.display_wave}'
            )
        attack_wave = state.attack_wave
        health_wave = state.health_wave
        attack_counter = state.attack_skip_counter
        health_counter = state.health_skip_counter
        attack_skip = self._effective_skip_pct(attack_skip_pct)
        health_skip = self._effective_skip_pct(health_skip_pct)
        for _display_wave in range(state.display_wave + 1, target_display_wave + 1):
            attack_counter += attack_skip
            attack_suppressed = floor(attack_counter)
            attack_counter -= attack_suppressed
            attack_wave += max(0, 1 - attack_suppressed)

            health_counter += health_skip
            health_suppressed = floor(health_counter)
            health_counter -= health_suppressed
            health_wave += max(0, 1 - health_suppressed)
        return WaveProgressionState(
            display_wave=target_display_wave,
            attack_wave=attack_wave,
            health_wave=health_wave,
            attack_skip_counter=attack_counter,
            health_skip_counter=health_counter,
        )


    @staticmethod
    def count_progression_events(inputs: ProgressionEventCountInputs) -> ProgressionEventCountResult:
        max_waves = max(0, int(inputs.max_waves))
        boss_interval_waves = max(1, int(inputs.boss_interval_waves))
        elite_interval_waves = max(1, int(inputs.elite_interval_waves))
        intro_sprint_waves = max(0, min(max_waves, int(inputs.intro_sprint_waves)))

        intro_sprint_boss_count = intro_sprint_waves
        total_cadence_boss_count = max_waves // boss_interval_waves
        cadence_bosses_inside_intro_sprint = intro_sprint_waves // boss_interval_waves
        regular_boss_count = max(0, total_cadence_boss_count - cadence_bosses_inside_intro_sprint)
        boss_count = intro_sprint_boss_count + regular_boss_count
        drop_eligible_boss_count = regular_boss_count
        elite_count = max_waves // elite_interval_waves

        return ProgressionEventCountResult(
            max_waves=max_waves,
            boss_count=boss_count,
            drop_eligible_boss_count=drop_eligible_boss_count,
            elite_count=elite_count,
            intro_sprint_boss_count=intro_sprint_boss_count,
            regular_boss_count=regular_boss_count,
        )

    @staticmethod
    def _effective_skip_pct(skip_pct: float) -> float:
        return max(0.0, min(1.0, float(skip_pct)))

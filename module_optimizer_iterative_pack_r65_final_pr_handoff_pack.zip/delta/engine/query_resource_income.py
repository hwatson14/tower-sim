
from __future__ import annotations

from typing import Any, Dict

BLOCKED_DETERMINISTIC_RESOURCE_INCOME = {
    'module_shards': {
        'surface_id': 'derived::module.resource_income.module_shards_per_run',
        'reason': 'missing_repo_kb_tables_for_module_drop_daily_mission_and_conversion_baselines',
        'fail_closed': True,
    },
    'reroll_shards': {
        'surface_id': 'derived::module.resource_income.reroll_shards_per_run',
        'reason': 'missing_repo_kb_tables_for_reroll_drop_reward_baselines',
        'fail_closed': True,
    },
}


def resource_income_contract_snapshot() -> Dict[str, Any]:
    return {
        'blocked_deterministic_surfaces': BLOCKED_DETERMINISTIC_RESOURCE_INCOME,
        'published_manual_surfaces': {
            'module_shards': 'derived::economy.income.module_shards',
            'reroll_shards': 'derived::economy.income.reroll_shards',
        },
        'notes': (
            'Deterministic module/reroll resource-income numerics remain fail-closed until '
            'repo KB tables for drop/reward baselines are landed. Manual weekly income publication '
            'remains the active owner boundary in this tranche.'
        ),
    }

from __future__ import annotations

from typing import Dict

from engine.wave_progression_policy import ProgressionEventCountInputs, WaveProgressionPolicy
from models.statbook import StatRow

# Note: main PWS owns the authoritative progression max-waves surface.
# This module consumes support_surface::progression.max_waves and must not synthesize
# or replace the upstream solver/publication logic.


_MAX_WAVES_SOURCE_IDS = (
    'support_surface::progression.max_waves',
)
_BOSS_INTERVAL_SOURCE_IDS = (
    'environment_param::bc.more_bosses_interval_waves',
    'support_surface::scenario.more_bosses_interval_waves',
)
_ELITE_INTERVAL_SOURCE_IDS = (
    'support_surface::progression.elite_interval_waves',
)
_INTRO_ACTIVE_SOURCE_IDS = (
    'support_surface::eecon.intro_sprint_active',
)
_INTRO_WAVES_SOURCE_IDS = (
    'support_surface::eecon.intro_sprint_waves',
)
_WAVE_DURATION_SOURCE_IDS = (
    'support_surface::timing.wave_duration_seconds_effective',
)
_WAVE_FACTOR_SOURCE_IDS = (
    'derived::eecon.wave_factor',
    'support_surface::eecon.wave_factor',
)
_PUBLISHED_EVENT_SOURCE_IDS = {
    'boss_count': 'support_surface::progression.boss_count',
    'eligible_boss_count': 'support_surface::progression.eligible_boss_count',
    'elite_count': 'support_surface::progression.elite_count',
    'max_waves': 'support_surface::progression.max_waves',
}


def _get_first(rows: Dict[str, StatRow], surface_ids: tuple[str, ...], default: float = 0.0) -> float:
    for surface_id in surface_ids:
        row = rows.get(surface_id)
        if row is None:
            continue
        try:
            return float(row.final_value)
        except (TypeError, ValueError):
            continue
    return float(default)


def _bool(rows: Dict[str, StatRow], surface_ids: tuple[str, ...], default: bool = False) -> bool:
    for surface_id in surface_ids:
        row = rows.get(surface_id)
        if row is None:
            continue
        value = row.final_value
        if isinstance(value, bool):
            return value
        if isinstance(value, (int, float)):
            return bool(value)
        if isinstance(value, str):
            text = value.strip().lower()
            if text in {'1', 'true', 'yes', 'on'}:
                return True
            if text in {'0', 'false', 'no', 'off'}:
                return False
    return default


def _publish(rows: Dict[str, StatRow], surface_id: str, value: float, value_type: str, notes: str, contributors: list[dict], schema: dict) -> None:
    if surface_id in rows:
        raise ValueError(f'Phase 3 publication collision for {surface_id}')
    rows[surface_id] = StatRow(
        stat_name=surface_id,
        final_value=value,
        value_type=value_type,
        source_count=len(contributors),
        status='resolved',
        notes=notes,
        contributors=contributors,
        schema=schema,
    )



def publish_progression_event_surfaces(rows: Dict[str, StatRow]) -> None:
    max_waves = int(_get_first(rows, _MAX_WAVES_SOURCE_IDS, 0.0))
    if max_waves <= 0:
        return
    boss_interval_waves = int(_get_first(rows, _BOSS_INTERVAL_SOURCE_IDS, 10.0)) or 10
    elite_interval_waves = int(_get_first(rows, _ELITE_INTERVAL_SOURCE_IDS, 10.0)) or 10
    intro_sprint_waves = 0
    if _bool(rows, _INTRO_ACTIVE_SOURCE_IDS, False):
        intro_sprint_waves = int(_get_first(rows, _INTRO_WAVES_SOURCE_IDS, 0.0))

    policy = WaveProgressionPolicy()
    result = policy.count_progression_events(
        inputs=ProgressionEventCountInputs(
            max_waves=max_waves,
            boss_interval_waves=boss_interval_waves,
            elite_interval_waves=elite_interval_waves,
            intro_sprint_waves=intro_sprint_waves,
        )
    )

    source_contributors = [
        {
            'surface_id': 'support_surface::progression.max_waves',
            'source_class': 'query_owned_surface',
            'source_name': 'support_surface::progression.max_waves',
            'value': max_waves,
            'unit': 'waves',
            'trust_label': 'accepted_model',
        },
        {
            'surface_id': 'environment_param::bc.more_bosses_interval_waves',
            'source_class': 'query_owned_surface',
            'source_name': 'environment_param::bc.more_bosses_interval_waves',
            'value': boss_interval_waves,
            'unit': 'waves',
            'trust_label': 'accepted_model',
        },
    ]
    if intro_sprint_waves > 0:
        source_contributors.append(
            {
                'surface_id': 'support_surface::eecon.intro_sprint_waves',
                'source_class': 'query_owned_surface',
                'source_name': 'support_surface::eecon.intro_sprint_waves',
                'value': intro_sprint_waves,
                'unit': 'waves',
                'trust_label': 'accepted_model',
            }
        )

    _publish(
        rows,
        'support_surface::progression.boss_count',
        float(result.boss_count),
        'count',
        'Progression-owned boss count over the governed max-wave horizon, including Intro Sprint bosses.',
        source_contributors,
        {'publisher': 'query_surface_publication', 'domain': 'progression', 'unit': 'count'},
    )
    _publish(
        rows,
        'support_surface::progression.eligible_boss_count',
        float(result.drop_eligible_boss_count),
        'count',
        'Progression-owned eligible boss count excluding drop-suppressed Intro Sprint bosses.',
        source_contributors,
        {'publisher': 'query_surface_publication', 'domain': 'progression', 'unit': 'count'},
    )
    _publish(
        rows,
        'support_surface::progression.elite_count',
        float(result.elite_count),
        'count',
        'Progression-owned elite count over the governed max-wave horizon using the closed every-10-waves cadence.',
        source_contributors,
        {'publisher': 'query_surface_publication', 'domain': 'progression', 'unit': 'count'},
    )


def publish_runtime_profile_surfaces(rows: Dict[str, StatRow]) -> None:
    boss_count = _get_first(rows, ('support_surface::progression.boss_count',), 0.0)
    elite_count = _get_first(rows, ('support_surface::progression.elite_count',), 0.0)
    eligible_boss_count = _get_first(rows, ('support_surface::progression.eligible_boss_count',), 0.0)
    max_waves = _get_first(rows, _MAX_WAVES_SOURCE_IDS, 0.0)
    if max_waves <= 0.0:
        return

    wave_duration_seconds = _get_first(rows, _WAVE_DURATION_SOURCE_IDS, 0.0)
    wave_factor = max(1e-9, _get_first(rows, _WAVE_FACTOR_SOURCE_IDS, 1.0))
    if wave_duration_seconds <= 0.0:
        return

    hours_per_run = (max_waves * wave_duration_seconds) / 3600.0 / wave_factor
    waves_per_hour = max_waves / hours_per_run if hours_per_run > 0.0 else 0.0
    suppressed_boss_fraction = 0.0
    if boss_count > 0.0:
        suppressed_boss_fraction = max(0.0, min(1.0, (boss_count - eligible_boss_count) / boss_count))

    contributors = [
        {
            'surface_id': 'support_surface::progression.max_waves',
            'source_class': 'query_owned_surface',
            'source_name': 'support_surface::progression.max_waves',
            'value': max_waves,
            'unit': 'waves',
            'trust_label': 'accepted_model',
        },
        {
            'surface_id': 'support_surface::timing.wave_duration_seconds_effective',
            'source_class': 'query_owned_surface',
            'source_name': 'support_surface::timing.wave_duration_seconds_effective',
            'value': wave_duration_seconds,
            'unit': 'seconds',
            'trust_label': 'accepted_model',
        },
        {
            'surface_id': 'derived::eecon.wave_factor',
            'source_class': 'published_surface',
            'source_name': 'derived::eecon.wave_factor',
            'value': wave_factor,
            'unit': 'multiplier',
            'trust_label': 'accepted_model',
        },
    ]

    published = {
        'derived::runtime.waves_per_run': (max_waves, 'scalar', 'Published runtime waves-per-run surface consuming the authoritative progression max-waves surface from main PWS/QE ownership.'),
        'derived::runtime.bosses_per_run': (boss_count, 'count', 'Published runtime bosses-per-run surface sourced from progression-owned boss count.'),
        'derived::runtime.eligible_bosses_per_run': (eligible_boss_count, 'count', 'Published runtime eligible bosses-per-run surface sourced from progression-owned eligible boss count.'),
        'derived::runtime.elites_per_run': (elite_count, 'count', 'Published runtime elites-per-run surface sourced from progression-owned elite count.'),
        'derived::runtime.hours_per_run': (hours_per_run, 'hours', 'Published runtime hours-per-run surface using effective wave duration and wave-factor acceleration.'),
        'derived::runtime.waves_per_hour': (waves_per_hour, 'per_hour', 'Published runtime waves-per-hour surface using effective wave duration and wave-factor acceleration.'),
        'derived::runtime.suppressed_boss_fraction': (suppressed_boss_fraction, 'fraction', 'Published runtime boss suppression fraction derived from Intro Sprint drop ineligibility.'),
    }
    for surface_id, (value, value_type, notes) in published.items():
        _publish(
            rows,
            surface_id,
            float(value),
            value_type,
            notes,
            contributors,
            {'publisher': 'query_surface_publication', 'domain': 'runtime'},
        )

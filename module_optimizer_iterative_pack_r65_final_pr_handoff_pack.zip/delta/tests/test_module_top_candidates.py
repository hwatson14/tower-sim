from compilers.module_top_candidates import build_module_top_candidates


def test_build_module_top_candidates_happy_path():
    result = build_module_top_candidates(
        ranking={
            'baseline_request_id': 'baseline',
            'ranked_candidates': [
                {'rank': 1, 'candidate_id': 'a', 'request_id': 'a', 'overlay_intent_id': 'oa', 'total_weighted_delta_raw': 5.0},
                {'rank': 2, 'candidate_id': 'b', 'request_id': 'b', 'overlay_intent_id': 'ob', 'total_weighted_delta_raw': 4.0},
            ],
        },
        scorecard={
            'score_rows': [
                {'candidate_id': 'a', 'objective_deltas': [{'objective_id': 'ehp', 'delta_raw': 5.0}]},
                {'candidate_id': 'b', 'objective_deltas': [{'objective_id': 'ehp', 'delta_raw': 4.0}]},
            ],
        },
        limit=1,
    )
    assert result['limit'] == 1
    assert [row['candidate_id'] for row in result['top_candidates']] == ['a']


def test_build_module_top_candidates_fails_on_missing_scorecard_row():
    try:
        build_module_top_candidates(
            ranking={
                'baseline_request_id': 'baseline',
                'ranked_candidates': [
                    {'rank': 1, 'candidate_id': 'a', 'request_id': 'a', 'overlay_intent_id': 'oa', 'total_weighted_delta_raw': 5.0},
                ],
            },
            scorecard={'score_rows': []},
        )
        raise AssertionError('expected ValueError')
    except ValueError as exc:
        assert 'scorecard.score_rows must be non-empty' in str(exc)

from compilers.module_objective_profile import build_module_objective_profile
from compilers.module_value_engine_preparation import prepare_module_value_engine_inputs
from compilers.module_value_engine_session import build_module_value_engine_session


def _planning_snapshot():
    return {
        'selected_preset': 'farming',
        'slots': {
            'cannon': {
                'equipped': {'primary': 'DP', 'assist': 'BA'},
                'inventory': {'primary': ['DP', 'AD'], 'assist': ['BA']},
            },
            'armor': {
                'equipped': {'primary': 'OA', 'assist': 'PH'},
                'inventory': {'primary': ['OA'], 'assist': ['PH']},
            },
            'generator': {
                'equipped': {'primary': 'GC', 'assist': 'GB'},
                'inventory': {'primary': ['GC'], 'assist': ['GB']},
            },
            'core': {
                'equipped': {'primary': 'PC', 'assist': 'CF'},
                'inventory': {'primary': ['PC'], 'assist': ['CF']},
            },
        },
    }


def test_build_module_value_engine_session_happy_path():
    prepared = prepare_module_value_engine_inputs(
        planning_snapshot=_planning_snapshot(),
        objective_ids=['ehp'],
        surface_bundle_id='bundle_v1',
    )
    profile = build_module_objective_profile(['ehp'], {'ehp': 'maximize'}, {'ehp': 1.0})
    session = build_module_value_engine_session(
        prepared_inputs=prepared,
        objective_profile=profile,
        executed_results_by_request_id={
            'baseline': {'objective_values': {'ehp': 100.0}},
            'cannon:primary:AD': {'objective_values': {'ehp': 110.0}},
        },
        top_n=1,
    )
    assert session['validated_results']['request_count'] == 2
    assert session['top_candidates']['top_candidates'][0]['candidate_id'] == 'cannon:primary:AD'


def test_build_module_value_engine_session_fails_on_missing_manifest():
    profile = build_module_objective_profile(['ehp'], {'ehp': 'maximize'}, {'ehp': 1.0})
    try:
        build_module_value_engine_session(
            prepared_inputs={},
            objective_profile=profile,
            executed_results_by_request_id={},
        )
        raise AssertionError('expected ValueError')
    except ValueError as exc:
        assert 'prepared_inputs.evaluation_manifest is required' in str(exc)

from compilers.module_monkey_patch_casebook import build_module_monkey_patch_casebook
from compilers.module_monkey_patch_session import build_module_monkey_patch_session
from compilers.module_value_engine_preparation import prepare_module_value_engine_inputs

def _planning_snapshot():
    return {'selected_preset': 'farming', 'slots': {'cannon': {'equipped': {'primary': 'DP', 'assist': 'BA'}, 'inventory': {'primary': ['DP', 'AD'], 'assist': ['BA']}}, 'armor': {'equipped': {'primary': 'OA', 'assist': 'PH'}, 'inventory': {'primary': ['OA'], 'assist': ['PH']}}, 'generator': {'equipped': {'primary': 'GC', 'assist': 'GB'}, 'inventory': {'primary': ['GC'], 'assist': ['GB']}}, 'core': {'equipped': {'primary': 'PC', 'assist': 'CF'}, 'inventory': {'primary': ['PC'], 'assist': ['CF']}}}}

def test_build_module_monkey_patch_casebook_happy_path():
    prepared = prepare_module_value_engine_inputs(planning_snapshot=_planning_snapshot(), objective_ids=['ehp'], surface_bundle_id='bundle_v1')
    case = build_module_monkey_patch_session(prepared_inputs=prepared, directions_by_objective_id={'ehp': 'maximize'}, weights_by_objective_id={'ehp': 1.0}, executed_results_by_request_id={'baseline': {'objective_values': {'ehp': 100.0}}, 'cannon:primary:AD': {'objective_values': {'ehp': 110.0}}}, fixture_id='case_simple', top_n=1)
    casebook = build_module_monkey_patch_casebook({'case_simple': case})
    assert casebook['fixture_count'] == 1
    assert casebook['cases'][0]['recommended_candidate_id'] == 'cannon:primary:AD'

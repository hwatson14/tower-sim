from compilers.module_objective_profile import build_module_objective_profile
from compilers.module_value_engine_pipeline import build_module_value_engine_pipeline


def test_build_module_value_engine_pipeline_runs_bounded_flow():
    objective_profile = build_module_objective_profile(
        objective_ids=['ehp', 'edamage'],
        directions={'ehp': 'maximize', 'edamage': 'maximize'},
        weights={'ehp': 1.0, 'edamage': 2.0},
    )
    observations = {
        'baseline_request_id': 'baseline',
        'objective_ids': ['ehp', 'edamage'],
        'observations': [
            {'request_id': 'req_a', 'candidate_id': 'cand_a', 'overlay_intent_id': 'ov_a', 'delta_values': {'ehp': 1.0, 'edamage': 0.5}},
            {'request_id': 'req_b', 'candidate_id': 'cand_b', 'overlay_intent_id': 'ov_b', 'delta_values': {'ehp': 0.5, 'edamage': 2.0}},
        ],
    }

    bundle = build_module_value_engine_pipeline(
        objective_profile=objective_profile,
        observations=observations,
    )

    assert bundle['ranking']['ranked_candidates'][0]['candidate_id'] == 'cand_b'
    assert bundle['recommendation']['recommended_candidate']['candidate_id'] == 'cand_b'
    assert bundle['report']['notes']['qe_executed_here'] is False

from compilers.module_objective_profile import build_module_objective_profile


def test_build_module_objective_profile_happy_path():
    profile = build_module_objective_profile(
        ['derived::ehp', 'derived::eecon'],
        {'derived::ehp': 'maximize', 'derived::eecon': 'maximize'},
        {'derived::ehp': 2.0, 'derived::eecon': 1.0},
    )
    assert profile['objective_ids'] == ['derived::ehp', 'derived::eecon']
    assert profile['objective_count'] == 2
    assert profile['total_weight'] == 3.0


def test_build_module_objective_profile_fails_on_missing_direction_key_match():
    try:
        build_module_objective_profile(
            ['derived::ehp'],
            {},
            {'derived::ehp': 1.0},
        )
        raise AssertionError('expected ValueError')
    except ValueError as exc:
        assert 'invalid direction' in str(exc) or 'directions keys must match' in str(exc)


def test_build_module_objective_profile_fails_on_non_positive_weight():
    try:
        build_module_objective_profile(
            ['derived::ehp'],
            {'derived::ehp': 'maximize'},
            {'derived::ehp': 0},
        )
        raise AssertionError('expected ValueError')
    except ValueError as exc:
        assert 'must be > 0' in str(exc)

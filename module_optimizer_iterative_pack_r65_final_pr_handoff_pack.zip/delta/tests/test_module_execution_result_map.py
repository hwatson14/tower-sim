from compilers.module_execution_result_map import validate_module_execution_result_map


def test_validate_module_execution_result_map_happy_path():
    manifest = {
        'baseline_request': {
            'request_id': 'baseline',
            'objective_ids': ['ehp', 'edamage'],
        },
        'candidate_requests': {
            'requests': [
                {'request_id': 'cannon:primary:AD', 'objective_ids': ['ehp', 'edamage']},
            ],
        },
    }
    validated = validate_module_execution_result_map(
        evaluation_manifest=manifest,
        executed_results_by_request_id={
            'baseline': {'objective_values': {'ehp': 100.0, 'edamage': 50.0}},
            'cannon:primary:AD': {'objective_values': {'ehp': 110.0, 'edamage': 51.0}},
        },
    )
    assert validated['request_count'] == 2
    assert validated['objective_ids'] == ['ehp', 'edamage']
    assert validated['validated_results_by_request_id']['baseline']['objective_values']['ehp'] == 100.0


def test_validate_module_execution_result_map_fails_on_objective_key_mismatch():
    manifest = {
        'baseline_request': {
            'request_id': 'baseline',
            'objective_ids': ['ehp', 'edamage'],
        },
        'candidate_requests': {
            'requests': [
                {'request_id': 'cannon:primary:AD', 'objective_ids': ['ehp', 'edamage']},
            ],
        },
    }
    try:
        validate_module_execution_result_map(
            evaluation_manifest=manifest,
            executed_results_by_request_id={
                'baseline': {'objective_values': {'ehp': 100.0, 'edamage': 50.0}},
                'cannon:primary:AD': {'objective_values': {'edamage': 51.0, 'ehp': 110.0}},
            },
        )
        raise AssertionError('expected ValueError')
    except ValueError as exc:
        assert 'objective_values keys mismatch' in str(exc)

from compilers.module_planner_resource_state import build_module_planner_resource_state
import pytest

def test_build_resource_state():
    out = build_module_planner_resource_state(10, 20, 100, 14, 23.5)
    assert out["resource_state_exactness"] == "mixed_manual_policy"
    assert out["farming_hours_per_day"] == 23.5

def test_negative_rejected():
    with pytest.raises(ValueError):
        build_module_planner_resource_state(-1, 0, 0, 0, 0)

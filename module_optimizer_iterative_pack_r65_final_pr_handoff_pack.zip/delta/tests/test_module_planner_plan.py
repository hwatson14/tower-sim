from compilers.module_planner_horizon_profile import build_module_planner_horizon_profile
from compilers.module_planner_resource_state import build_module_planner_resource_state
from compilers.module_planner_action_candidates import build_module_planner_action_candidates
from compilers.module_planner_plan import build_module_planner_plan

def _base():
    horizon = build_module_planner_horizon_profile("week")
    resources = build_module_planner_resource_state(10, 20, 100, 14, 23.5)
    recommendation = {"candidate_id": "cand_a", "request_id": "req_a"}
    top = {"top_candidates": [
        {"candidate_id": "cand_a", "request_id": "req_a", "rank": 1, "total_weighted_delta_raw": 10.0},
        {"candidate_id": "cand_b", "request_id": "req_b", "rank": 2, "total_weighted_delta_raw": 5.0},
    ]}
    actions = build_module_planner_action_candidates(recommendation, top)
    return horizon, resources, actions, recommendation

def test_build_plan():
    horizon, resources, actions, recommendation = _base()
    out = build_module_planner_plan(horizon, resources, actions, recommendation)
    assert out["plan_mode"] == "advisory_horizon_plan"
    assert out["planner_exactness"] == "advisory_until_costs_closed"

def test_immediate_mode():
    horizon = build_module_planner_horizon_profile("immediate")
    resources = build_module_planner_resource_state(10, 20, 100, 14, 23.5)
    recommendation = {"candidate_id": "cand_a", "request_id": "req_a"}
    top = {"top_candidates": [{"candidate_id": "cand_a", "request_id": "req_a", "rank": 1, "total_weighted_delta_raw": 10.0}]}
    actions = build_module_planner_action_candidates(recommendation, top)
    out = build_module_planner_plan(horizon, resources, actions, recommendation)
    assert out["plan_mode"] == "next_best_change"

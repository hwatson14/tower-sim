from compilers.module_final_merge_candidate_summary import build_module_final_merge_candidate_summary

def test_summary_reflects_orchestrator():
    orchestrator = {
        "orchestration_state": "integration_or_validation_remaining",
        "finish_funnel": {
            "final_recommendation": {
                "final_recommendation_exactness": "advisory",
                "recommended_action": {"candidate_id": "cand_a"},
            },
            "finish_funnel_state": "ready_for_live_validation",
        },
        "readiness_gate": {
            "merge_ready_now": False,
            "missing_dependencies": ["pws1_runtime_methods_integrated"],
            "missing_validations": [],
        },
    }
    out = build_module_final_merge_candidate_summary(orchestrator, "r42")
    assert out["package_version"] == "r42"
    assert out["merge_ready_now"] is False
    assert out["recommended_action"]["candidate_id"] == "cand_a"

from compilers.module_evaluation_observations import build_module_evaluation_observations


def _baseline():
    return {
        'request_id': 'baseline',
        'objective_values': {
            'derived::ehp': 100.0,
            'derived::eecon': 200.0,
        },
    }


def test_build_module_evaluation_observations_happy_path():
    bundle = build_module_evaluation_observations(
        _baseline(),
        [
            {
                'request_id': 'candidate_a',
                'candidate_id': 'armor.primary.swap_a',
                'overlay_intent_id': 'overlay_a',
                'objective_values': {
                    'derived::ehp': 105.0,
                    'derived::eecon': 198.0,
                },
            },
            {
                'request_id': 'candidate_b',
                'candidate_id': 'armor.primary.swap_b',
                'overlay_intent_id': 'overlay_b',
                'objective_values': {
                    'derived::ehp': 95.0,
                    'derived::eecon': 210.0,
                },
            },
        ],
    )
    assert bundle['baseline_request_id'] == 'baseline'
    assert bundle['candidate_count'] == 2
    assert bundle['observations'][0]['delta_values'] == {
        'derived::ehp': 5.0,
        'derived::eecon': -2.0,
    }
    assert bundle['observations'][1]['delta_values'] == {
        'derived::ehp': -5.0,
        'derived::eecon': 10.0,
    }


def test_build_module_evaluation_observations_fails_on_duplicate_candidate_ids():
    try:
        build_module_evaluation_observations(
            _baseline(),
            [
                {
                    'request_id': 'candidate_a',
                    'candidate_id': 'armor.primary.swap_a',
                    'overlay_intent_id': 'overlay_a',
                    'objective_values': {
                        'derived::ehp': 105.0,
                        'derived::eecon': 198.0,
                    },
                },
                {
                    'request_id': 'candidate_a',
                    'candidate_id': 'armor.primary.swap_b',
                    'overlay_intent_id': 'overlay_b',
                    'objective_values': {
                        'derived::ehp': 95.0,
                        'derived::eecon': 210.0,
                    },
                },
            ],
        )
        raise AssertionError('expected ValueError')
    except ValueError as exc:
        assert 'duplicate candidate request_id' in str(exc)


def test_build_module_evaluation_observations_fails_on_mismatched_objective_keys():
    try:
        build_module_evaluation_observations(
            _baseline(),
            [
                {
                    'request_id': 'candidate_a',
                    'candidate_id': 'armor.primary.swap_a',
                    'overlay_intent_id': 'overlay_a',
                    'objective_values': {
                        'derived::ehp': 105.0,
                    },
                },
            ],
        )
        raise AssertionError('expected ValueError')
    except ValueError as exc:
        assert 'objective_values keys must match baseline exactly' in str(exc)

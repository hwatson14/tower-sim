from __future__ import annotations

import yaml

from compilers.module_loadout_candidates import enumerate_module_loadout_seed_candidates
from compilers.module_loadout_overlay import (
    build_baseline_module_loadout_overlay,
    build_module_loadout_overlay,
    module_loadout_overlay_contract_snapshot,
)
from tests.test_module_loadout_candidates import _build_account_state


def test_baseline_overlay_is_read_only_and_no_change_by_default():
    account_state = _build_account_state()
    overlay = build_baseline_module_loadout_overlay(account_state, module_preset='Farming')
    assert overlay['schema_id'] == 'module_loadout_overlay_v1'
    assert overlay['selected_module_preset'] == 'Farming'
    assert overlay['seed_type'] == 'baseline'
    assert all(not row['primary_changed'] and not row['assist_changed'] for row in overlay['overlay_rows'])


def test_overlay_materializes_one_swap_primary_delta_without_scoring():
    account_state = _build_account_state()
    candidate = next(
        row for row in enumerate_module_loadout_seed_candidates(account_state, module_preset='Farming')
        if row['seed_type'] == 'one_swap_primary'
        and row['changes'][0]['slot_type'] == 'cannon'
        and row['changes'][0]['to_name'] == 'cannon.beta'
    )
    overlay = build_module_loadout_overlay(account_state, candidate, module_preset='Farming')
    cannon_row = next(row for row in overlay['overlay_rows'] if row['slot_type'] == 'cannon')
    assert cannon_row['baseline_primary_name'] == 'cannon.alpha'
    assert cannon_row['candidate_primary_name'] == 'cannon.beta'
    assert cannon_row['candidate_assist_name'] is None
    assert cannon_row['primary_changed'] is True
    assert cannon_row['assist_changed'] is True
    assert set(overlay) == {
        'schema_id',
        'selected_module_preset',
        'seed_type',
        'changes',
        'baseline_loadout',
        'candidate_loadout',
        'overlay_rows',
    }


def test_overlay_fails_closed_on_duplicate_primary_and_assist():
    account_state = _build_account_state()
    candidate = next(
        row for row in enumerate_module_loadout_seed_candidates(account_state, module_preset='Farming')
        if row['seed_type'] == 'baseline'
    )
    candidate = {
        **candidate,
        'loadout': {
            **candidate['loadout'],
            'cannon': {'primary_name': 'cannon.alpha', 'assist_name': 'cannon.alpha'},
        },
    }
    try:
        build_module_loadout_overlay(account_state, candidate, module_preset='Farming')
    except ValueError as exc:
        assert 'cannot equip the same module' in str(exc)
    else:
        raise AssertionError('Expected duplicate primary/assist to fail closed.')


def test_overlay_contract_matches_snapshot_shape():
    snapshot = module_loadout_overlay_contract_snapshot()
    contract = yaml.safe_load(open('kb/modules/contracts/module-loadout-overlay-contract.yaml', 'r', encoding='utf-8').read())
    assert snapshot['owner_path'] == contract['owner_path']
    assert snapshot['required_top_level_keys'] == contract['required_top_level_keys']
    assert snapshot['overlay_row_keys'] == contract['overlay_row_keys']
    assert snapshot['forbidden_behaviors'] == contract['forbidden_behaviors']

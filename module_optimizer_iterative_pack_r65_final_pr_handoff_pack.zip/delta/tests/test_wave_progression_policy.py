from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from engine.wave_progression_policy import (
    ProgressionEventCountInputs,
    WaveProgressionPolicy,
    WaveProgressionState,
)


def test_wave_progression_policy_identity_when_no_skip():
    policy = WaveProgressionPolicy()
    state = policy.advance_to_wave(state=WaveProgressionState(), target_display_wave=100, attack_skip_pct=0.0, health_skip_pct=0.0)
    assert state.attack_wave == 100
    assert state.health_wave == 100


def test_wave_progression_policy_separates_attack_and_health():
    policy = WaveProgressionPolicy()
    state = policy.advance_to_wave(state=WaveProgressionState(), target_display_wave=1000, attack_skip_pct=0.50, health_skip_pct=0.25)
    assert state.attack_wave < state.health_wave < 1000


def test_wave_progression_policy_is_monotonic_across_segments():
    policy = WaveProgressionPolicy()
    state = WaveProgressionState()
    state = policy.advance_to_wave(state=state, target_display_wave=500, attack_skip_pct=0.50, health_skip_pct=0.50)
    first_attack = state.attack_wave
    state = policy.advance_to_wave(state=state, target_display_wave=1000, attack_skip_pct=0.50, health_skip_pct=0.50)
    assert state.attack_wave > first_attack
    assert state.attack_wave < 1000


def test_wave_progression_policy_uses_exact_current_wave_skip_without_warmup():
    policy = WaveProgressionPolicy()
    state = policy.advance_to_wave(state=WaveProgressionState(), target_display_wave=100, attack_skip_pct=0.50, health_skip_pct=0.25)
    assert state.attack_wave == 50
    assert state.health_wave == 75


def test_progression_event_counts_default_boss_and_elite_cadence():
    result = WaveProgressionPolicy.count_progression_events(ProgressionEventCountInputs(max_waves=100))
    assert result.boss_count == 10
    assert result.drop_eligible_boss_count == 10
    assert result.elite_count == 10
    assert result.intro_sprint_boss_count == 0


def test_progression_event_counts_respect_more_bosses_interval():
    result = WaveProgressionPolicy.count_progression_events(
        ProgressionEventCountInputs(max_waves=100, boss_interval_waves=7)
    )
    assert result.boss_count == 14
    assert result.drop_eligible_boss_count == 14
    assert result.elite_count == 10


def test_progression_event_counts_intro_sprint_adds_non_drop_eligible_bosses_without_double_counting_cadence():
    result = WaveProgressionPolicy.count_progression_events(
        ProgressionEventCountInputs(max_waves=100, boss_interval_waves=10, intro_sprint_waves=10)
    )
    assert result.intro_sprint_boss_count == 10
    assert result.regular_boss_count == 9
    assert result.drop_eligible_boss_count == 9
    assert result.boss_count == 19


def test_progression_event_counts_intro_sprint_partial_interval_preserves_regular_cadence_after_sprint():
    result = WaveProgressionPolicy.count_progression_events(
        ProgressionEventCountInputs(max_waves=20, boss_interval_waves=10, intro_sprint_waves=5)
    )
    assert result.intro_sprint_boss_count == 5
    assert result.regular_boss_count == 2
    assert result.drop_eligible_boss_count == 2
    assert result.boss_count == 7

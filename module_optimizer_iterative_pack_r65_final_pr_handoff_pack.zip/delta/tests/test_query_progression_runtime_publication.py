from __future__ import annotations

from engine.query_progression_runtime import (
    publish_progression_event_surfaces,
    publish_runtime_profile_surfaces,
)
from engine.query_surface_publication import phase3_publication_contract_snapshot
from models.statbook import StatRow


def _row(value, value_type='scalar'):
    return StatRow(stat_name='x', final_value=value, value_type=value_type, source_count=1, status='resolved', contributors=[])


def test_publish_progression_event_surfaces_counts_intro_sprint_and_more_bosses():
    rows = {
        'support_surface::progression.max_waves': _row(120, 'waves'),
        'environment_param::bc.more_bosses_interval_waves': _row(6, 'waves'),
        'support_surface::eecon.intro_sprint_active': _row(True, 'bool'),
        'support_surface::eecon.intro_sprint_waves': _row(20, 'waves'),
    }
    publish_progression_event_surfaces(rows)
    assert rows['support_surface::progression.boss_count'].final_value == 37.0
    assert rows['support_surface::progression.eligible_boss_count'].final_value == 17.0
    assert rows['support_surface::progression.elite_count'].final_value == 12.0


def test_publish_runtime_profile_surfaces_uses_published_progression_counts_and_wave_factor():
    rows = {
        'support_surface::progression.max_waves': _row(120, 'waves'),
        'support_surface::progression.boss_count': _row(36, 'count'),
        'support_surface::progression.eligible_boss_count': _row(16, 'count'),
        'support_surface::progression.elite_count': _row(12, 'count'),
        'support_surface::timing.wave_duration_seconds_effective': _row(2, 'seconds'),
        'derived::eecon.wave_factor': _row(2, 'multiplier'),
    }
    publish_runtime_profile_surfaces(rows)
    assert rows['derived::runtime.waves_per_run'].final_value == 120.0
    assert rows['derived::runtime.bosses_per_run'].final_value == 36.0
    assert rows['derived::runtime.eligible_bosses_per_run'].final_value == 16.0
    assert rows['derived::runtime.elites_per_run'].final_value == 12.0
    assert rows['derived::runtime.hours_per_run'].final_value == 120.0 * 2.0 / 3600.0 / 2.0
    assert rows['derived::runtime.waves_per_hour'].final_value == 3600.0
    assert rows['derived::runtime.suppressed_boss_fraction'].final_value == (36.0 - 16.0) / 36.0


def test_phase3_publication_contract_snapshot_includes_runtime_profile_surfaces():
    snapshot = phase3_publication_contract_snapshot()
    assert 'support_surface::progression.max_waves' in snapshot['runtime_profile_surfaces']
    assert 'support_surface::progression.boss_count' in snapshot['runtime_profile_surfaces']
    assert 'derived::runtime.hours_per_run' in snapshot['runtime_profile_surfaces']



def test_publishers_require_authoritative_progression_max_waves_surface():
    rows = {
        'source_input::progression:max_waves': _row(4518, 'waves'),
        'support_surface::timing.wave_duration_seconds_effective': _row(2, 'seconds'),
        'derived::eecon.wave_factor': _row(2, 'multiplier'),
    }
    publish_progression_event_surfaces(rows)
    publish_runtime_profile_surfaces(rows)
    assert 'support_surface::progression.max_waves' not in rows
    assert 'support_surface::progression.boss_count' not in rows
    assert 'derived::runtime.hours_per_run' not in rows


from compilers.module_value_engine_report import build_module_value_engine_report


def test_build_module_value_engine_report_bundles_consistent_artifacts():
    objective_profile = {'rows': [{'objective_id': 'ehp', 'direction': 'maximize', 'weight': 1.0}]}
    observations = {
        'baseline_request_id': 'baseline',
        'objective_ids': ['ehp'],
        'observations': [{'request_id': 'req_a', 'candidate_id': 'cand_a', 'overlay_intent_id': 'ov_a', 'delta_values': {'ehp': 2.0}}],
    }
    scorecard = {
        'baseline_request_id': 'baseline',
        'objective_ids': ['ehp'],
        'score_rows': [{'request_id': 'req_a', 'candidate_id': 'cand_a', 'overlay_intent_id': 'ov_a', 'per_objective': [{'objective_id': 'ehp'}], 'total_weighted_delta_raw': 2.0}],
    }
    ranking = {
        'baseline_request_id': 'baseline',
        'ranked_candidates': [{'rank': 1, 'request_id': 'req_a', 'candidate_id': 'cand_a', 'overlay_intent_id': 'ov_a', 'total_weighted_delta_raw': 2.0}],
    }
    recommendation = {
        'baseline_request_id': 'baseline',
        'recommended_candidate': {'rank': 1, 'request_id': 'req_a', 'candidate_id': 'cand_a', 'overlay_intent_id': 'ov_a', 'total_weighted_delta_raw': 2.0, 'per_objective': [{'objective_id': 'ehp'}]},
    }

    report = build_module_value_engine_report(
        objective_profile=objective_profile,
        observations=observations,
        scorecard=scorecard,
        ranking=ranking,
        recommendation=recommendation,
    )

    assert report['baseline_request_id'] == 'baseline'
    assert report['candidate_count'] == 1
    assert report['notes']['raw_weighted_scoring_only'] is True
    assert report['recommendation']['recommended_candidate']['candidate_id'] == 'cand_a'


def test_build_module_value_engine_report_fails_on_recommendation_mismatch():
    objective_profile = {'rows': [{'objective_id': 'ehp', 'direction': 'maximize', 'weight': 1.0}]}
    observations = {
        'baseline_request_id': 'baseline',
        'objective_ids': ['ehp'],
        'observations': [{'request_id': 'req_a', 'candidate_id': 'cand_a', 'overlay_intent_id': 'ov_a', 'delta_values': {'ehp': 2.0}}],
    }
    scorecard = {
        'baseline_request_id': 'baseline',
        'objective_ids': ['ehp'],
        'score_rows': [{'request_id': 'req_a', 'candidate_id': 'cand_a', 'overlay_intent_id': 'ov_a', 'per_objective': [{'objective_id': 'ehp'}], 'total_weighted_delta_raw': 2.0}],
    }
    ranking = {
        'baseline_request_id': 'baseline',
        'ranked_candidates': [{'rank': 1, 'request_id': 'req_a', 'candidate_id': 'cand_a', 'overlay_intent_id': 'ov_a', 'total_weighted_delta_raw': 2.0}],
    }
    recommendation = {
        'baseline_request_id': 'baseline',
        'recommended_candidate': {'rank': 1, 'request_id': 'req_b', 'candidate_id': 'cand_b', 'overlay_intent_id': 'ov_b', 'total_weighted_delta_raw': 1.0, 'per_objective': [{'objective_id': 'ehp'}]},
    }

    try:
        build_module_value_engine_report(
            objective_profile=objective_profile,
            observations=observations,
            scorecard=scorecard,
            ranking=ranking,
            recommendation=recommendation,
        )
    except ValueError as exc:
        assert 'recommendation must match top ranked candidate' in str(exc)
    else:
        raise AssertionError('expected ValueError')

from compilers.module_planner_horizon_projection import build_module_planner_horizon_projection

def test_projection_advisory():
    out = build_module_planner_horizon_projection(
        {"horizon_kind": "week", "horizon_days": 7},
        {"resource_state_exactness": "mixed_manual_policy", "farming_hours_per_day": 23.5},
        {"income_consumer_exactness": "advisory_until_income_closes"},
    )
    assert out["projected_farming_hours"] == 164.5
    assert out["projection_exactness"] == "advisory_until_income_closes"

from compilers.module_live_parity_bundle import build_live_vs_fixture_parity_bundle


def _planning_snapshot():
    return {
        'selected_preset': 'farm',
        'slots': {
            'cannon': {
                'equipped': {'primary': 'A', 'assist': 'AX'},
                'inventory': {'primary': ['A', 'C'], 'assist': ['AX']},
            },
            'armor': {
                'equipped': {'primary': 'B', 'assist': 'BX'},
                'inventory': {'primary': ['B'], 'assist': ['BX', 'BY']},
            },
            'generator': {'equipped': {'primary': 'G1', 'assist': 'GX'}, 'inventory': {'primary': ['G1'], 'assist': ['GX']}},
            'core': {'equipped': {'primary': 'K1', 'assist': 'KX'}, 'inventory': {'primary': ['K1'], 'assist': ['KX']}},
        },
    }


def _profile():
    return {
        'objective_ids': ['ehp', 'edamage', 'eecon'],
        'directions': {'ehp': 'maximize', 'edamage': 'maximize', 'eecon': 'maximize'},
        'weights': {'ehp': 1.0, 'edamage': 1.0, 'eecon': 1.0},
    }


def test_live_parity_bundle_builds_fixture_from_live_results():
    def executor(request):
        if request['request_id'] == 'baseline':
            return {'ehp': 100.0, 'edamage': 50.0, 'eecon': 20.0}
        return {'ehp': 125.0, 'edamage': 55.0, 'eecon': 22.0}
    out = build_live_vs_fixture_parity_bundle(_planning_snapshot(), _profile(), executor, 'fx1', 'notes')
    assert out['fixture']['fixture_id'] == 'fx1'
    assert 'live_execution' in out

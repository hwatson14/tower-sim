from compilers.module_planner_horizon_profile import build_module_planner_horizon_profile
import pytest

def test_preset_horizons():
    assert build_module_planner_horizon_profile("immediate")["horizon_days"] == 0
    assert build_module_planner_horizon_profile("week")["horizon_days"] == 7
    assert build_module_planner_horizon_profile("month")["horizon_days"] == 30

def test_custom_horizon_requires_days():
    with pytest.raises(ValueError):
        build_module_planner_horizon_profile("custom")

def test_noncustom_rejects_custom_days():
    with pytest.raises(ValueError):
        build_module_planner_horizon_profile("week", 8)

from compilers.module_finish_funnel_package import build_module_finish_funnel_package

def test_finish_funnel_without_parity():
    out = build_module_finish_funnel_package(
        {"execution": {"recommendation": {"candidate_id": "cand_a"}}},
        {"recommended_action": {"candidate_id": "cand_a"}},
        {"feasibility_status": "blocked_by_exact_cost_gaps"},
        {"projection_exactness": "advisory_until_income_closes"},
        {"recommended_action": {"candidate_id": "cand_a"}},
        None,
    )
    assert out["finish_funnel_state"] == "ready_for_live_validation"

def test_finish_funnel_with_parity():
    out = build_module_finish_funnel_package(
        {"execution": {"recommendation": {"candidate_id": "cand_a"}}},
        {"recommended_action": {"candidate_id": "cand_a"}},
        {"feasibility_status": "cost_feasible_if_resources_suffice"},
        {"projection_exactness": "exact_with_income"},
        {"recommended_action": {"candidate_id": "cand_a"}},
        {"review_disposition": "accepted_match"},
    )
    assert out["finish_funnel_state"] == "ready_for_merge_readiness_review"

from __future__ import annotations

import json
from pathlib import Path

import yaml

from engine.query_currency_income import (
    supported_manual_input_ids,
    unsupported_manual_input_ids,
    currency_income_surface_contract_snapshot,
)
from engine.query_resource_stocks import resource_stock_surface_contract_snapshot
from engine.query_module_run_context import module_runtime_context_surface_contract_snapshot
from engine.query_runtime_profile import module_runtime_profile_surface_contract_snapshot
from engine.query_surface_publication import publish_phase3_query_surfaces
from models.statbook import StatRow

ROOT = Path(__file__).resolve().parents[1]


def row(name, value, value_type="scalar"):
    return StatRow(stat_name=name, final_value=value, value_type=value_type, source_count=1, status="resolved", contributors=[], schema={})


def _fixture_rows():
    return {
        'support_surface::ehp.health_factor': row('support_surface::ehp.health_factor', 100.0),
        'support_surface::ehp.armor_factor': row('support_surface::ehp.armor_factor', 1.25),
        'support_surface::ehp.wall_health_factor': row('support_surface::ehp.wall_health_factor', 100.0),
        'support_surface::ehp.max_recovery_factor': row('support_surface::ehp.max_recovery_factor', 1.8),
        'support_surface::ehp.wall_active': row('support_surface::ehp.wall_active', True, 'bool'),
        'support_surface::ehp.max_recovery_active': row('support_surface::ehp.max_recovery_active', True, 'bool'),
        'support_surface::ehp.dabs_factor': row('support_surface::ehp.dabs_factor', 10.0),
        'support_surface::ehp.def_pct': row('support_surface::ehp.def_pct', 0.20),
        'mechanic_param::uw.chrono_field.duration_seconds': row('mechanic_param::uw.chrono_field.duration_seconds', 10.0),
        'runtime_mechanic_param::uw.chrono_field.duration_seconds': row('runtime_mechanic_param::uw.chrono_field.duration_seconds', 0.0),
        'mechanic_param::uw.chrono_field.cooldown_seconds': row('mechanic_param::uw.chrono_field.cooldown_seconds', 20.0),
        'mechanic_param::uw.chrono_field.damage_reduction_pct': row('mechanic_param::uw.chrono_field.damage_reduction_pct', 30.0),
        'runtime_mechanic_param::uw.chain_thunder.reduction_pct': row('runtime_mechanic_param::uw.chain_thunder.reduction_pct', 15.0),
        'mechanic_param::perk.tradeoff_defense_factor': row('mechanic_param::perk.tradeoff_defense_factor', 1.1),
        'support_surface::edamage.damage_factor': row('support_surface::edamage.damage_factor', 120.0),
        'support_surface::edamage.attack_speed_factor': row('support_surface::edamage.attack_speed_factor', 3.5),
        'support_surface::edamage.multishot_factor': row('support_surface::edamage.multishot_factor', 2.0),
        'support_surface::edamage.rapidfire_factor': row('support_surface::edamage.rapidfire_factor', 1.1),
        'support_surface::edamage.bounce_factor': row('support_surface::edamage.bounce_factor', 1.0),
        'support_surface::edamage.super_tower_factor': row('support_surface::edamage.super_tower_factor', 1.0),
        'support_surface::edamage.range_factor': row('support_surface::edamage.range_factor', 1.0),
        'support_surface::edamage.crit_factor': row('support_surface::edamage.crit_factor', 2.5),
        'support_surface::edamage.damage_per_bullet': row('support_surface::edamage.damage_per_bullet', 120.0),
        'support_surface::edamage.bullets_per_second': row('support_surface::edamage.bullets_per_second', 10.0),
        'support_surface::edamage.uw_damage_factor': row('support_surface::edamage.uw_damage_factor', 5.0),
        'support_surface::edamage.slow_factor': row('support_surface::edamage.slow_factor', 1.0),
        'support_surface::eecon.adstarter_theme_relic_factor': row('support_surface::eecon.adstarter_theme_relic_factor', 1.1),
        'support_surface::eecon.cpk_factor': row('support_surface::eecon.cpk_factor', 100.0),
        'support_surface::eecon.freeup_factor': row('support_surface::eecon.freeup_factor', 1.2),
        'runtime_mechanic_param::cards.coins.multiplier': row('runtime_mechanic_param::cards.coins.multiplier', 1.3),
        'support_surface::eecon.module_factor': row('support_surface::eecon.module_factor', 1.05),
        'support_surface::eecon.eom_factor': row('support_surface::eecon.eom_factor', 1.1),
        'support_surface::timing.combined_multiplier': row('support_surface::timing.combined_multiplier', 1.2),
        'runtime_mechanic_param::uw.spotlight.coin_bonus_multiplier': row('runtime_mechanic_param::uw.spotlight.coin_bonus_multiplier', 1.6),
        'support_surface::eecon.sl_quantity': row('support_surface::eecon.sl_quantity', 2.0),
        'support_surface::eecon.sl_angle': row('support_surface::eecon.sl_angle', 45.0),
        'support_surface::eecon.wave_factor': row('support_surface::eecon.wave_factor', 1.4),
    }


def test_module_resource_manual_inputs_are_supported_in_existing_manual_input_lane():
    assert 'income.module_shards.per_week' in supported_manual_input_ids()
    assert 'income.reroll_shards.per_week' in supported_manual_input_ids()
    assert 'income.modules.per_week' not in supported_manual_input_ids()
    assert 'income.modules.per_week' not in unsupported_manual_input_ids()
    snapshot = currency_income_surface_contract_snapshot()
    assert snapshot['externalized_manual']['module_shards']['manual_input_id'] == 'income.module_shards.per_week'
    assert snapshot['externalized_manual']['reroll_shards']['manual_input_id'] == 'income.reroll_shards.per_week'


def test_publish_phase3_query_surfaces_emits_module_resource_income_and_stock(tmp_path: Path):
    payload = {
        'inputs': [
            {'input_id': 'income.module_shards.per_week', 'value': 3200, 'trust_label': 'externally_observed'},
            {'input_id': 'income.reroll_shards.per_week', 'value': 800, 'trust_label': 'externally_observed'},
            {'input_id': 'stock.module_shards.current', 'value': 12000, 'trust_label': 'externally_observed'},
            {'input_id': 'stock.reroll_shards.current', 'value': 1450, 'trust_label': 'externally_observed'},
        ]
    }
    p = tmp_path / 'manual_inputs.json'
    p.write_text(json.dumps(payload), encoding='utf-8')

    rows = _fixture_rows()
    publish_phase3_query_surfaces(rows, manual_input_path=p)

    assert rows['derived::economy.income.module_shards'].final_value == 3200.0
    assert rows['derived::economy.income.reroll_shards'].final_value == 800.0
    assert rows['derived::economy.stock.module_shards'].final_value == 12000.0
    assert rows['derived::economy.stock.reroll_shards'].final_value == 1450.0
    assert rows['derived::economy.stock.module_shards'].schema['unit'] == 'module_shards'
    assert rows['derived::economy.income.module_shards'].schema['unit'] == 'module_shards_per_week'


def test_resource_stock_contract_registered_and_manual_input_file_contains_inputs():
    contract = yaml.safe_load((ROOT / 'kb/economy/contracts/resource-stock-surfaces-contract.yaml').read_text())
    manual_inputs = json.loads((ROOT / 'input/manual_advisory_inputs.json').read_text(encoding='utf-8'))
    input_ids = {row['input_id'] for row in manual_inputs['inputs']}
    contract_ids = {row['manual_input_id'] for row in contract['resources']}
    snapshot = resource_stock_surface_contract_snapshot()

    assert contract['contract_id'] == 'resource_stock_surfaces_v1'
    assert contract_ids == {'stock.module_shards.current', 'stock.reroll_shards.current'}
    assert contract_ids <= input_ids
    assert set(snapshot['supported_manual_input_ids']) == contract_ids


def test_module_resource_surfaces_registered_in_query_contracts():
    initial = yaml.safe_load((ROOT / 'kb/global-rules/contracts/stat-query-initial-surface-set.yaml').read_text())
    ledger = yaml.safe_load((ROOT / 'kb/global-rules/contracts/stat-query-surface-ownership-ledger.yaml').read_text())
    bundles = yaml.safe_load((ROOT / 'kb/global-rules/contracts/stat-query-consumer-bundles.yaml').read_text())

    derived_surfaces = {s['surface_id'] for s in initial['families']['derived_v1']['surfaces']}
    ledger_nodes = {n['node_id'] for n in ledger['surface_nodes']}
    bundle = next(c for c in bundles['consumers'] if c['consumer_id'] == 'optimizer_analysis')['bundles'][0]
    optional = set(bundle['optional_surface_ids'])

    for sid in {
        'derived::economy.income.module_shards',
        'derived::economy.income.reroll_shards',
        'derived::economy.stock.module_shards',
        'derived::economy.stock.reroll_shards',
    }:
        assert sid in derived_surfaces
        assert sid in ledger_nodes
        assert sid in optional


def test_publish_phase3_query_surfaces_emits_module_runtime_context_from_account_state():
    state = build_state()
    rows = _fixture_rows()
    publish_phase3_query_surfaces(rows, account_state=state)
    assert rows['derived::module.runtime_profile.farming_tier'].final_value == 14.0
    assert rows['derived::module.runtime_profile.total_waves_per_run'].final_value == 5761.0
    assert rows['derived::module.runtime_profile.highest_tier_unlocked'].final_value == 19.0
    assert rows['derived::module.runtime_profile.farming_tier'].schema['unit'] == 'tier_index'


def test_module_runtime_context_contract_registered_in_query_contracts():
    initial = yaml.safe_load((ROOT / 'kb/global-rules/contracts/stat-query-initial-surface-set.yaml').read_text())
    ledger = yaml.safe_load((ROOT / 'kb/global-rules/contracts/stat-query-surface-ownership-ledger.yaml').read_text())
    bundles = yaml.safe_load((ROOT / 'kb/global-rules/contracts/stat-query-consumer-bundles.yaml').read_text())
    contract = yaml.safe_load((ROOT / 'kb/modules/contracts/module-runtime-context-surfaces-contract.yaml').read_text())
    snapshot = module_runtime_context_surface_contract_snapshot()

    derived_surfaces = {s['surface_id'] for s in initial['families']['derived_v1']['surfaces']}
    ledger_nodes = {n['node_id'] for n in ledger['surface_nodes']}
    bundle = next(c for c in bundles['consumers'] if c['consumer_id'] == 'optimizer_analysis')['bundles'][0]
    optional = set(bundle['optional_surface_ids'])

    expected = set(snapshot['published_surface_ids'])
    assert expected == {row['surface_id'] for row in contract['surfaces']}
    for sid in expected:
        assert sid in derived_surfaces
        assert sid in ledger_nodes
        assert sid in optional


from compilers.module_optimizer_state import (
    build_module_optimizer_state_snapshot,
    module_optimizer_state_contract_snapshot,
)
from tests.helpers import build_state



def test_publish_phase3_query_surfaces_emits_module_runtime_profile_helpers_from_account_state():
    state = build_state()
    rows = _fixture_rows()
    publish_phase3_query_surfaces(rows, account_state=state)
    assert rows['derived::module.runtime_profile.bosses_per_run'].final_value == 576.0
    blocked = rows['derived::module.runtime_profile.drop_blocked_fraction.intro_sprint'].final_value
    assert abs(blocked - (100.0 / 5761.0)) < 1e-12
    assert rows['derived::module.runtime_profile.drop_blocked_fraction.intro_sprint'].schema['unit'] == 'fraction'


def test_publish_phase3_query_surfaces_emits_zero_intro_sprint_blocked_fraction_when_card_not_equipped():
    state = build_state()
    state.card_presets[state.active_card_preset] = [c for c in state.card_presets[state.active_card_preset] if c != 'Intro Sprint']
    rows = _fixture_rows()
    publish_phase3_query_surfaces(rows, account_state=state)
    assert rows['derived::module.runtime_profile.bosses_per_run'].final_value == 576.0
    assert rows['derived::module.runtime_profile.drop_blocked_fraction.intro_sprint'].final_value == 0.0


def test_module_runtime_profile_contract_registered_in_query_contracts():
    initial = yaml.safe_load((ROOT / 'kb/global-rules/contracts/stat-query-initial-surface-set.yaml').read_text())
    ledger = yaml.safe_load((ROOT / 'kb/global-rules/contracts/stat-query-surface-ownership-ledger.yaml').read_text())
    bundles = yaml.safe_load((ROOT / 'kb/global-rules/contracts/stat-query-consumer-bundles.yaml').read_text())
    contract = yaml.safe_load((ROOT / 'kb/modules/contracts/module-runtime-profile-surfaces-contract.yaml').read_text())
    snapshot = module_runtime_profile_surface_contract_snapshot()

    derived_surfaces = {s['surface_id'] for s in initial['families']['derived_v1']['surfaces']}
    ledger_nodes = {n['node_id'] for n in ledger['surface_nodes']}
    bundle = next(c for c in bundles['consumers'] if c['consumer_id'] == 'optimizer_analysis')['bundles'][0]
    optional = set(bundle['optional_surface_ids'])

    expected = set(snapshot['published_surface_ids'])
    assert expected == {row['surface_id'] for row in contract['surfaces']}
    for sid in expected:
        assert sid in derived_surfaces
        assert sid in ledger_nodes
        assert sid in optional

def test_module_optimizer_manual_inputs_include_planner_policy_fields():
    manual_inputs = json.loads((ROOT / 'input' / 'manual_advisory_inputs.json').read_text(encoding='utf-8'))
    rows = {row['input_id']: row for row in manual_inputs['inputs']}
    assert rows['module.farming.hours_per_day']['unit'] == 'hours_per_day'
    assert rows['module.farming.hours_per_day']['value_type'] == 'scalar'
    assert rows['module.resource.gems_allocated_to_modules.per_week']['value_type'] == 'per_week'
    assert rows['module.planner.horizon_days']['value_type'] == 'integer'
    assert rows['module.planner.horizon_days']['replacement_target'] == 'future_planner_input::module_planner.custom_horizon_days'


def test_module_optimizer_state_snapshot_is_read_only_and_preset_scoped():
    state = build_state()
    snapshot = build_module_optimizer_state_snapshot(state, module_preset='Farming')
    assert snapshot['schema_id'] == 'module_optimizer_state_snapshot_v1'
    assert snapshot['selected_module_preset'] == 'Farming'
    assert set(snapshot['slot_types']) == {'cannon', 'armor', 'generator', 'core'}
    assert snapshot['inventory_total_count'] == sum(slot['inventory_count'] for slot in snapshot['slots'].values())
    for slot_type, payload in snapshot['slots'].items():
        assert payload['slot_type'] == slot_type
        assert set(payload['system_state']) == {'assist_unlocked', 'assist_level', 'rarity_cap', 'multiplier_cap', 'substat_cap'}
        assert payload['inventory_count'] == len(payload['inventory'])
        assert payload['inventory_names'] == [row['name'] for row in payload['inventory']]
        assert set(payload['equipped']) == {
            'primary_name', 'assist_name', 'primary_present_in_inventory', 'assist_present_in_inventory', 'primary_snapshot', 'assist_snapshot'
        }


def test_module_optimizer_state_contract_matches_snapshot_shape():
    snapshot_contract = module_optimizer_state_contract_snapshot()
    contract = yaml.safe_load((ROOT / 'kb/modules/contracts/module-planning-state-normalizer-contract.yaml').read_text())
    assert snapshot_contract['schema_id'] == contract['contract_id'].replace('module_planning_state_normalizer', 'module_optimizer_state_snapshot')
    assert snapshot_contract['owner_path'] == contract['owner_path']
    assert snapshot_contract['required_top_level_keys'] == contract['required_top_level_keys']
    assert snapshot_contract['slot_payload_keys'] == contract['slot_payload_keys']
    assert snapshot_contract['forbidden_behaviors'] == contract['forbidden_behaviors']


def test_module_optimizer_state_snapshot_rejects_unknown_preset():
    state = build_state()
    try:
        build_module_optimizer_state_snapshot(state, module_preset='Not A Real Preset')
    except KeyError as exc:
        assert 'Unknown module preset' in str(exc)
    else:
        raise AssertionError('Expected unknown preset to fail closed.')

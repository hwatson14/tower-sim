from compilers.module_loadout_candidates import build_candidate_catalog


def test_build_candidate_catalog_bounded_one_swap():
    snapshot = {
        "selected_preset": "farming",
        "slots": {
            "cannon": {
                "equipped": {"primary": "DP", "assist": "BA"},
                "inventory": {"primary": ["DP", "AD"], "assist": ["BA", "CF"]},
            },
            "armor": {
                "equipped": {"primary": "OA", "assist": "SF"},
                "inventory": {"primary": ["OA"], "assist": ["SF", "PC"]},
            },
        },
    }
    catalog = build_candidate_catalog(snapshot)
    assert catalog["selected_preset"] == "farming"
    assert catalog["search_mode"] == "bounded_one_swap"
    assert catalog["candidate_count"] == 3
    ids = {row["candidate_id"] for row in catalog["candidates"]}
    assert ids == {"cannon:primary:AD", "cannon:assist:CF", "armor:assist:PC"}


from tests.helpers import build_state as _build_account_state

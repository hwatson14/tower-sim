from compilers.module_value_engine_preparation import prepare_module_value_engine_inputs


def test_prepare_module_value_engine_inputs_builds_matching_manifest_and_requests():
    planning_snapshot = {
        'selected_preset': 'farming',
        'slots': {
            'cannon': {
                'equipped': {'primary': 'DP', 'assist': 'BA'},
                'inventory': {'primary': ['DP', 'AD'], 'assist': ['BA', 'CF']},
            },
            'armor': {
                'equipped': {'primary': 'OA', 'assist': 'PH'},
                'inventory': {'primary': ['OA'], 'assist': ['PH']},
            },
            'generator': {
                'equipped': {'primary': 'GC', 'assist': 'GB'},
                'inventory': {'primary': ['GC'], 'assist': ['GB']},
            },
            'core': {
                'equipped': {'primary': 'PC', 'assist': 'CF'},
                'inventory': {'primary': ['PC'], 'assist': ['CF']},
            },
        },
    }
    prepared = prepare_module_value_engine_inputs(
        planning_snapshot=planning_snapshot,
        objective_ids=['ehp', 'edamage'],
        surface_bundle_id='bundle_v1',
    )
    assert prepared['baseline_request']['objective_ids'] == ['ehp', 'edamage']
    assert prepared['candidate_requests']['objective_ids'] == ['ehp', 'edamage']
    assert prepared['evaluation_manifest']['baseline_request_id'] == 'baseline'
    assert prepared['evaluation_manifest']['candidate_count'] == prepared['candidate_requests']['request_count']

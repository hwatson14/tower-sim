from compilers.module_live_qe_bridge_bundle import build_module_live_qe_bridge_bundle

def test_live_qe_bridge_bundle():
    out = build_module_live_qe_bridge_bundle(
        runtime_surfaces={
            "bosses_per_run": 100,
            "eligible_bosses_per_run": 80,
            "elites_per_run": 50,
            "hours_per_run": 2.5,
            "waves_per_hour": 200,
            "suppressed_boss_fraction": 0.2,
        },
        baseline_request_id="baseline",
        candidate_request_ids=["cand_a"],
        objective_ids=["ehp"],
        results_by_request_id={
            "baseline": {"ehp": 100.0},
            "cand_a": {"ehp": 120.0},
        },
    )
    assert out["bridge_bundle_source"] == "live_qe_bridge_bundle"
    assert out["runtime_profile"]["eligible_bosses_per_run"] == 80

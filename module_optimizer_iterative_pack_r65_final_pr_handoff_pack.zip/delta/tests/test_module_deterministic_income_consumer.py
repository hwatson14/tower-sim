from compilers.module_deterministic_income_consumer import build_module_deterministic_income_consumer

def _runtime():
    return {
        "bosses_per_run": 100,
        "eligible_bosses_per_run": 80,
        "elites_per_run": 50,
        "hours_per_run": 2.5,
        "waves_per_hour": 200,
        "suppressed_boss_fraction": 0.2,
    }

def test_advisory_until_income_closes():
    out = build_module_deterministic_income_consumer(
        _runtime(),
        {"resource_state_exactness": "mixed_manual_policy"},
        {"overall_cost_exactness": "blocked_partial"},
        {"module_income_exact": False, "reroll_income_exact": False},
    )
    assert out["income_consumer_exactness"] == "advisory_until_income_closes"

def test_exact_only_when_allowed():
    out = build_module_deterministic_income_consumer(
        _runtime(),
        {"resource_state_exactness": "mixed_manual_policy"},
        {"overall_cost_exactness": "exact"},
        {"module_income_exact": True, "reroll_income_exact": True},
    )
    assert out["income_consumer_exactness"] == "exact"

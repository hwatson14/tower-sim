from compilers.module_runtime_profile_from_qe import build_module_runtime_profile_from_qe
import pytest

def test_runtime_profile_from_qe():
    out = build_module_runtime_profile_from_qe({
        "bosses_per_run": 100,
        "eligible_bosses_per_run": 80,
        "elites_per_run": 50,
        "hours_per_run": 2.5,
        "waves_per_hour": 200,
        "suppressed_boss_fraction": 0.2,
    })
    assert out["runtime_profile_source"] == "qe_or_explicit_surface_map"

def test_missing_runtime_surface_rejected():
    with pytest.raises(ValueError):
        build_module_runtime_profile_from_qe({"bosses_per_run": 100})

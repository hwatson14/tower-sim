from compilers.module_finish_execution_orchestrator import build_module_finish_execution_orchestrator

def _base():
    return {
        "live_session": {"execution": {"recommendation": {"candidate_id": "cand_a"}}},
        "planner_plan": {"recommended_action": {"candidate_id": "cand_a"}},
        "planner_feasibility": {"feasibility_status": "blocked_by_exact_cost_gaps"},
        "horizon_projection": {"projection_exactness": "advisory_until_income_closes"},
        "final_recommendation": {"recommended_action": {"candidate_id": "cand_a"}, "final_recommendation_exactness": "advisory"},
    }

def test_orchestrator_not_ready():
    b = _base()
    out = build_module_finish_execution_orchestrator(
        b["live_session"], b["planner_plan"], b["planner_feasibility"], b["horizon_projection"],
        b["final_recommendation"],
        {"qe_mapping_cleanup": True, "pws1_runtime_methods_integrated": False, "runtime_surface_renames_adopted": True},
        {"lower_layer_validation_passed": True, "module_scaffold_validation_passed": True, "monkey_patch_validation_passed": True},
        None,
    )
    assert out["orchestration_state"] == "integration_or_validation_remaining"

def test_orchestrator_ready():
    b = _base()
    out = build_module_finish_execution_orchestrator(
        b["live_session"], b["planner_plan"], b["planner_feasibility"], b["horizon_projection"],
        b["final_recommendation"],
        {"qe_mapping_cleanup": True, "pws1_runtime_methods_integrated": True, "runtime_surface_renames_adopted": True},
        {"lower_layer_validation_passed": True, "module_scaffold_validation_passed": True, "monkey_patch_validation_passed": True},
        {"review_disposition": "accepted_match"},
    )
    assert out["orchestration_state"] == "ready_for_merge_candidate_cleanup"

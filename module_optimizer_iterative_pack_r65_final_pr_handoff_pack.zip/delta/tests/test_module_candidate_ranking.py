from compilers.module_candidate_ranking import rank_module_candidates



def test_rank_module_candidates_happy_path():
    ranking = rank_module_candidates({
        'baseline_request_id': 'baseline',
        'score_rows': [
            {
                'request_id': 'candidate_b',
                'candidate_id': 'armor.primary.swap_b',
                'overlay_intent_id': 'overlay_b',
                'total_weighted_delta_raw': 10.0,
            },
            {
                'request_id': 'candidate_a',
                'candidate_id': 'armor.primary.swap_a',
                'overlay_intent_id': 'overlay_a',
                'total_weighted_delta_raw': 10.0,
            },
            {
                'request_id': 'candidate_c',
                'candidate_id': 'armor.primary.swap_c',
                'overlay_intent_id': 'overlay_c',
                'total_weighted_delta_raw': 5.0,
            },
        ],
    })
    assert [row['candidate_id'] for row in ranking['ranked_candidates']] == [
        'armor.primary.swap_a',
        'armor.primary.swap_b',
        'armor.primary.swap_c',
    ]
    assert [row['rank'] for row in ranking['ranked_candidates']] == [1, 2, 3]


def test_rank_module_candidates_fails_on_duplicate_candidate_ids():
    try:
        rank_module_candidates({
            'baseline_request_id': 'baseline',
            'score_rows': [
                {
                    'request_id': 'candidate_a',
                    'candidate_id': 'dup',
                    'overlay_intent_id': 'overlay_a',
                    'total_weighted_delta_raw': 1.0,
                },
                {
                    'request_id': 'candidate_b',
                    'candidate_id': 'dup',
                    'overlay_intent_id': 'overlay_b',
                    'total_weighted_delta_raw': 2.0,
                },
            ],
        })
        raise AssertionError('expected ValueError')
    except ValueError as exc:
        assert 'duplicate score row candidate_id' in str(exc)

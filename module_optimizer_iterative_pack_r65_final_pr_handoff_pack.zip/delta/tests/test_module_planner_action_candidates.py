from compilers.module_planner_action_candidates import build_module_planner_action_candidates
import pytest

def test_build_action_candidates():
    recommendation = {"candidate_id": "cand_a", "request_id": "req_a"}
    top = {"top_candidates": [
        {"candidate_id": "cand_a", "request_id": "req_a", "rank": 1, "total_weighted_delta_raw": 10.0},
        {"candidate_id": "cand_b", "request_id": "req_b", "rank": 2, "total_weighted_delta_raw": 5.0},
    ]}
    out = build_module_planner_action_candidates(recommendation, top)
    assert out["immediate_action"]["candidate_id"] == "cand_a"
    assert len(out["candidate_actions"]) == 2

def test_recommendation_must_exist():
    recommendation = {"candidate_id": "cand_x", "request_id": "req_x"}
    top = {"top_candidates": [{"candidate_id": "cand_a", "request_id": "req_a", "rank": 1, "total_weighted_delta_raw": 10.0}]}
    with pytest.raises(ValueError):
        build_module_planner_action_candidates(recommendation, top)

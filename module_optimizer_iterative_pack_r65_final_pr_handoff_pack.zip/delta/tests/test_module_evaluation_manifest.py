from compilers.module_evaluation_manifest import build_module_evaluation_manifest


def _baseline():
    return {
        'request_id': 'baseline',
        'objective_ids': ['derived::ehp', 'derived::eecon'],
        'surface_bundle_id': 'optimizer_analysis',
    }


def test_build_module_evaluation_manifest_happy_path():
    manifest = build_module_evaluation_manifest(
        _baseline(),
        [
            {
                'request_id': 'candidate_a',
                'candidate_id': 'armor.primary.swap_a',
                'overlay_intent_id': 'overlay_a',
                'objective_ids': ['derived::ehp', 'derived::eecon'],
                'surface_bundle_id': 'optimizer_analysis',
            },
            {
                'request_id': 'candidate_b',
                'candidate_id': 'armor.primary.swap_b',
                'overlay_intent_id': 'overlay_b',
                'objective_ids': ['derived::ehp', 'derived::eecon'],
                'surface_bundle_id': 'optimizer_analysis',
            },
        ],
    )
    assert manifest['baseline_request_id'] == 'baseline'
    assert manifest['candidate_count'] == 2
    assert [row['request_id'] for row in manifest['candidate_requests']] == ['candidate_a', 'candidate_b']


def test_build_module_evaluation_manifest_fails_on_duplicate_candidate_ids():
    try:
        build_module_evaluation_manifest(
            _baseline(),
            [
                {
                    'request_id': 'candidate_a',
                    'candidate_id': 'armor.primary.swap_a',
                    'overlay_intent_id': 'overlay_a',
                    'objective_ids': ['derived::ehp', 'derived::eecon'],
                    'surface_bundle_id': 'optimizer_analysis',
                },
                {
                    'request_id': 'candidate_a',
                    'candidate_id': 'armor.primary.swap_b',
                    'overlay_intent_id': 'overlay_b',
                    'objective_ids': ['derived::ehp', 'derived::eecon'],
                    'surface_bundle_id': 'optimizer_analysis',
                },
            ],
        )
        raise AssertionError('expected ValueError')
    except ValueError as exc:
        assert 'duplicate candidate request_id' in str(exc)


def test_build_module_evaluation_manifest_fails_on_mismatched_objectives():
    try:
        build_module_evaluation_manifest(
            _baseline(),
            [
                {
                    'request_id': 'candidate_a',
                    'candidate_id': 'armor.primary.swap_a',
                    'overlay_intent_id': 'overlay_a',
                    'objective_ids': ['derived::ehp'],
                    'surface_bundle_id': 'optimizer_analysis',
                },
            ],
        )
        raise AssertionError('expected ValueError')
    except ValueError as exc:
        assert 'objective_ids must match' in str(exc)

from compilers.module_merge_readiness_gate import build_module_merge_readiness_gate

def test_readiness_gate_not_ready_when_missing_dependency():
    out = build_module_merge_readiness_gate(
        {"qe_mapping_cleanup": True, "pws1_runtime_methods_integrated": False, "runtime_surface_renames_adopted": True},
        {"lower_layer_validation_passed": True, "module_scaffold_validation_passed": True, "monkey_patch_validation_passed": True},
        {"final_recommendation_exactness": "advisory"},
    )
    assert out["merge_ready_now"] is False
    assert "pws1_runtime_methods_integrated" in out["missing_dependencies"]

def test_readiness_gate_ready():
    out = build_module_merge_readiness_gate(
        {"qe_mapping_cleanup": True, "pws1_runtime_methods_integrated": True, "runtime_surface_renames_adopted": True},
        {"lower_layer_validation_passed": True, "module_scaffold_validation_passed": True, "monkey_patch_validation_passed": True},
        {"final_recommendation_exactness": "advisory"},
    )
    assert out["merge_ready_now"] is True

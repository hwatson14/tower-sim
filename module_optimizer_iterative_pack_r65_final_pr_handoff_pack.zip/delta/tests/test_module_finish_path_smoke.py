from compilers.module_planner_horizon_profile import build_module_planner_horizon_profile
from compilers.module_planner_resource_state import build_module_planner_resource_state
from compilers.module_planner_action_candidates import build_module_planner_action_candidates
from compilers.module_planner_plan import build_module_planner_plan
from compilers.module_cost_boundary import build_module_cost_boundary
from compilers.module_planner_feasibility import build_module_planner_feasibility
from compilers.module_deterministic_income_consumer import build_module_deterministic_income_consumer
from compilers.module_planner_horizon_projection import build_module_planner_horizon_projection
from compilers.module_planner_final_recommendation import build_module_planner_final_recommendation
from compilers.module_finish_funnel_package import build_module_finish_funnel_package
from compilers.module_merge_readiness_gate import build_module_merge_readiness_gate
from compilers.module_finish_execution_orchestrator import build_module_finish_execution_orchestrator
from compilers.module_final_merge_candidate_summary import build_module_final_merge_candidate_summary

def test_module_finish_path_smoke():
    horizon = build_module_planner_horizon_profile("week")
    resources = build_module_planner_resource_state(
        reroll_shards_on_hand=10,
        module_shards_on_hand=20,
        gems_allocated_to_modules_per_week=100,
        missions_per_week=14,
        farming_hours_per_day=23.5,
    )

    recommendation = {"candidate_id": "cand_a", "request_id": "req_a"}
    top = {
        "top_candidates": [
            {"candidate_id": "cand_a", "request_id": "req_a", "rank": 1, "total_weighted_delta_raw": 10.0},
            {"candidate_id": "cand_b", "request_id": "req_b", "rank": 2, "total_weighted_delta_raw": 5.0},
        ]
    }
    actions = build_module_planner_action_candidates(recommendation, top, cost_exactness="blocked_partial")
    plan = build_module_planner_plan(horizon, resources, actions, recommendation)

    cost_boundary = build_module_cost_boundary(
        reroll_cost_exact=False,
        reroll_blockers=["reroll_ladder_exact_closure"],
        module_shard_cost_exact=True,
        module_shard_blockers=[],
    )
    feasibility = build_module_planner_feasibility(plan, cost_boundary)

    runtime_profile = {
        "bosses_per_run": 100,
        "eligible_bosses_per_run": 80,
        "elites_per_run": 50,
        "hours_per_run": 2.5,
        "waves_per_hour": 200,
        "suppressed_boss_fraction": 0.2,
    }
    income_consumer = build_module_deterministic_income_consumer(
        runtime_profile=runtime_profile,
        resource_state=resources,
        cost_boundary=cost_boundary,
        deterministic_income={"module_income_exact": False, "reroll_income_exact": False},
    )
    projection = build_module_planner_horizon_projection(horizon, resources, income_consumer)
    final_recommendation = build_module_planner_final_recommendation(
        planner_plan=plan,
        planner_feasibility=feasibility,
        horizon_projection=projection,
        live_session={"execution": {"recommendation": {"candidate_id": "cand_a"}}},
    )

    finish_funnel = build_module_finish_funnel_package(
        live_session={"execution": {"recommendation": {"candidate_id": "cand_a"}}},
        planner_plan=plan,
        planner_feasibility=feasibility,
        horizon_projection=projection,
        final_recommendation=final_recommendation,
        parity_review=None,
    )
    assert finish_funnel["finish_funnel_state"] == "ready_for_live_validation"

    gate = build_module_merge_readiness_gate(
        external_dependencies={
            "qe_mapping_cleanup": True,
            "pws1_runtime_methods_integrated": True,
            "runtime_surface_renames_adopted": True,
        },
        validation_status={
            "lower_layer_validation_passed": True,
            "module_scaffold_validation_passed": True,
            "monkey_patch_validation_passed": True,
        },
        final_recommendation=final_recommendation,
    )
    orchestrator = build_module_finish_execution_orchestrator(
        live_session={"execution": {"recommendation": {"candidate_id": "cand_a"}}},
        planner_plan=plan,
        planner_feasibility=feasibility,
        horizon_projection=projection,
        final_recommendation=final_recommendation,
        external_dependencies={
            "qe_mapping_cleanup": True,
            "pws1_runtime_methods_integrated": True,
            "runtime_surface_renames_adopted": True,
        },
        validation_status={
            "lower_layer_validation_passed": True,
            "module_scaffold_validation_passed": True,
            "monkey_patch_validation_passed": True,
        },
        parity_review={"review_disposition": "accepted_match"},
    )
    summary = build_module_final_merge_candidate_summary(orchestrator, "r45")
    assert gate["merge_ready_now"] is True
    assert orchestrator["orchestration_state"] == "ready_for_merge_candidate_cleanup"
    assert summary["merge_ready_now"] is True
    assert summary["recommended_action"]["candidate_id"] == "cand_a"

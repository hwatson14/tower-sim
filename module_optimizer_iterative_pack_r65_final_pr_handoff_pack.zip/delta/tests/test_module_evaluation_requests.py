from compilers.module_evaluation_requests import build_module_evaluation_requests


def test_build_module_evaluation_requests_defaults():
    overlays = {
        "selected_preset": "farming",
        "search_mode": "bounded_one_swap",
        "overlays": [
            {
                "overlay_id": "cannon:primary:AD",
                "kind": "one_swap",
                "slot": "cannon",
                "family": "primary",
                "baseline_loadout": {"cannon": {"primary": "DP", "assist": "BA"}},
                "overlay_loadout": {"cannon": {"primary": "AD", "assist": "BA"}},
            }
        ],
    }
    requests = build_module_evaluation_requests(overlays)
    assert requests["request_count"] == 1
    row = requests["requests"][0]
    assert row["request_id"] == "cannon:primary:AD"
    assert row["objective_ids"] == ["ehp", "edamage", "eecon"]
    assert row["surface_bundle_id"] == "module_optimizer_value_inputs_v1"
    assert row["overlay_loadout"]["cannon"]["primary"] == "AD"
    assert overlays["overlays"][0]["overlay_loadout"]["cannon"]["primary"] == "AD"


def test_build_module_evaluation_requests_custom_objectives():
    overlays = {
        "selected_preset": "farming",
        "overlays": [
            {
                "overlay_id": "armor:assist:PC",
                "kind": "one_swap",
                "slot": "armor",
                "family": "assist",
                "baseline_loadout": {"armor": {"primary": "OA", "assist": "SF"}},
                "overlay_loadout": {"armor": {"primary": "OA", "assist": "PC"}},
            }
        ],
    }
    requests = build_module_evaluation_requests(
        overlays,
        objective_ids=["ehp"],
        surface_bundle_id="module_optimizer_ehp_inputs_v1",
    )
    row = requests["requests"][0]
    assert row["objective_ids"] == ["ehp"]
    assert row["surface_bundle_id"] == "module_optimizer_ehp_inputs_v1"


def test_build_module_evaluation_requests_requires_objective():
    overlays = {"overlays": []}
    try:
        build_module_evaluation_requests(overlays, objective_ids=[])
    except ValueError as exc:
        assert "objective_id" in str(exc)
    else:
        raise AssertionError("Expected ValueError for empty objectives")

from compilers.module_objective_profile import build_module_objective_profile
from compilers.module_value_engine_execution import execute_module_value_engine_from_results
from compilers.module_value_engine_preparation import prepare_module_value_engine_inputs


def test_execute_module_value_engine_from_results_runs_bounded_pipeline():
    planning_snapshot = {
        'selected_preset': 'farming',
        'slots': {
            'cannon': {
                'equipped': {'primary': 'DP', 'assist': 'BA'},
                'inventory': {'primary': ['DP', 'AD'], 'assist': ['BA']},
            },
            'armor': {
                'equipped': {'primary': 'OA', 'assist': 'PH'},
                'inventory': {'primary': ['OA'], 'assist': ['PH']},
            },
            'generator': {
                'equipped': {'primary': 'GC', 'assist': 'GB'},
                'inventory': {'primary': ['GC'], 'assist': ['GB']},
            },
            'core': {
                'equipped': {'primary': 'PC', 'assist': 'CF'},
                'inventory': {'primary': ['PC'], 'assist': ['CF']},
            },
        },
    }
    prepared = prepare_module_value_engine_inputs(
        planning_snapshot=planning_snapshot,
        objective_ids=['ehp', 'edamage'],
        surface_bundle_id='bundle_v1',
    )
    profile = build_module_objective_profile(['ehp', 'edamage'], {'ehp': 'maximize', 'edamage': 'maximize'}, {'ehp': 1.0, 'edamage': 2.0})
    results = {
        'baseline': {
            'request_id': 'baseline',
            'objective_values': {'ehp': 100.0, 'edamage': 50.0},
        },
        'cannon:primary:AD': {
            'request_id': 'cannon:primary:AD',
            'candidate_id': 'cannon:primary:AD',
            'overlay_intent_id': 'cannon:primary:AD',
            'objective_values': {'ehp': 105.0, 'edamage': 55.0},
        },
    }
    executed = execute_module_value_engine_from_results(
        prepared_inputs=prepared,
        objective_profile=profile,
        executed_results_by_request_id=results,
    )
    assert executed['observations']['candidate_count'] == 1
    assert executed['pipeline']['recommendation']['recommended_candidate']['candidate_id'] == 'cannon:primary:AD'


def test_execute_module_value_engine_from_results_fails_closed_on_missing_candidate_result():
    planning_snapshot = {
        'selected_preset': 'farming',
        'slots': {
            'cannon': {
                'equipped': {'primary': 'DP', 'assist': 'BA'},
                'inventory': {'primary': ['DP', 'AD'], 'assist': ['BA']},
            },
            'armor': {
                'equipped': {'primary': 'OA', 'assist': 'PH'},
                'inventory': {'primary': ['OA'], 'assist': ['PH']},
            },
            'generator': {
                'equipped': {'primary': 'GC', 'assist': 'GB'},
                'inventory': {'primary': ['GC'], 'assist': ['GB']},
            },
            'core': {
                'equipped': {'primary': 'PC', 'assist': 'CF'},
                'inventory': {'primary': ['PC'], 'assist': ['CF']},
            },
        },
    }
    prepared = prepare_module_value_engine_inputs(planning_snapshot=planning_snapshot, objective_ids=['ehp'], surface_bundle_id='bundle_v1')
    profile = build_module_objective_profile(['ehp'], {'ehp': 'maximize'}, {'ehp': 1.0})
    try:
        execute_module_value_engine_from_results(
            prepared_inputs=prepared,
            objective_profile=profile,
            executed_results_by_request_id={'baseline': {'request_id': 'baseline', 'objective_values': {'ehp': 100.0}}},
        )
        raise AssertionError('expected ValueError')
    except ValueError as exc:
        assert 'candidate result not found' in str(exc)

from compilers.module_live_qe_execution_adapter import build_module_live_qe_execution_adapter_payload
import pytest

def test_build_live_adapter_payload():
    prepared_manifest = {
        "baseline_request": {"request_id": "baseline"},
        "candidate_requests": [{"request_id": "cand_a"}, {"request_id": "cand_b"}],
    }
    out = build_module_live_qe_execution_adapter_payload(prepared_manifest, "bundle_v1", ["ehp", "edamage"])
    assert out["execution_mode"] == "live_qe"
    assert out["request_ids"] == ["baseline", "cand_a", "cand_b"]

def test_duplicate_request_ids_rejected():
    prepared_manifest = {
        "baseline_request": {"request_id": "baseline"},
        "candidate_requests": [{"request_id": "baseline"}],
    }
    with pytest.raises(ValueError):
        build_module_live_qe_execution_adapter_payload(prepared_manifest, "bundle_v1", ["ehp"])

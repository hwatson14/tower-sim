from compilers.module_objective_profile import build_module_objective_profile
from compilers.module_value_engine_preparation import prepare_module_value_engine_inputs
from compilers.module_value_engine_session import build_module_value_engine_session
from compilers.module_value_engine_bundle import build_module_value_engine_bundle


def _planning_snapshot():
    return {
        'selected_preset': 'farming',
        'slots': {
            'cannon': {'equipped': {'primary': 'DP', 'assist': 'BA'}, 'inventory': {'primary': ['DP', 'AD'], 'assist': ['BA']}},
            'armor': {'equipped': {'primary': 'OA', 'assist': 'PH'}, 'inventory': {'primary': ['OA'], 'assist': ['PH']}},
            'generator': {'equipped': {'primary': 'GC', 'assist': 'GB'}, 'inventory': {'primary': ['GC'], 'assist': ['GB']}},
            'core': {'equipped': {'primary': 'PC', 'assist': 'CF'}, 'inventory': {'primary': ['PC'], 'assist': ['CF']}},
        },
    }


def test_build_module_value_engine_bundle_happy_path():
    prepared = prepare_module_value_engine_inputs(_planning_snapshot(), ['ehp'], 'bundle_v1')
    profile = build_module_objective_profile(['ehp'], {'ehp': 'maximize'}, {'ehp': 1.0})
    session = build_module_value_engine_session(
        prepared_inputs=prepared,
        objective_profile=profile,
        executed_results_by_request_id={
            'baseline': {'objective_values': {'ehp': 100.0}},
            'cannon:primary:AD': {'objective_values': {'ehp': 110.0}},
        },
        top_n=1,
    )
    bundle = build_module_value_engine_bundle(session, bundle_id='session_001')
    assert bundle['bundle_id'] == 'session_001'
    assert bundle['baseline_request_id'] == 'baseline'
    assert bundle['top_candidates']['top_candidates'][0]['candidate_id'] == 'cannon:primary:AD'


def test_build_module_value_engine_bundle_fails_without_bundle_id():
    try:
        build_module_value_engine_bundle({'prepared_inputs': {}, 'execution': {}, 'top_candidates': {}}, bundle_id='')
        raise AssertionError('expected ValueError')
    except ValueError as exc:
        assert 'bundle_id is required' in str(exc)

from compilers.module_evaluation_scorecard import build_module_evaluation_scorecard
from compilers.module_objective_profile import build_module_objective_profile


def _profile():
    return build_module_objective_profile(
        ['derived::ehp', 'derived::eecon'],
        {'derived::ehp': 'maximize', 'derived::eecon': 'minimize'},
        {'derived::ehp': 2.0, 'derived::eecon': 1.0},
    )


def _observations():
    return {
        'baseline_request_id': 'baseline',
        'objective_ids': ['derived::ehp', 'derived::eecon'],
        'observations': [
            {
                'request_id': 'candidate_a',
                'candidate_id': 'armor.primary.swap_a',
                'overlay_intent_id': 'overlay_a',
                'delta_values': {'derived::ehp': 5.0, 'derived::eecon': -2.0},
            },
            {
                'request_id': 'candidate_b',
                'candidate_id': 'armor.primary.swap_b',
                'overlay_intent_id': 'overlay_b',
                'delta_values': {'derived::ehp': -5.0, 'derived::eecon': 10.0},
            },
        ],
    }


def test_build_module_evaluation_scorecard_happy_path():
    scorecard = build_module_evaluation_scorecard(_profile(), _observations())
    assert scorecard['candidate_count'] == 2
    assert scorecard['score_rows'][0]['total_weighted_delta_raw'] == 12.0
    assert scorecard['score_rows'][1]['total_weighted_delta_raw'] == -20.0


def test_build_module_evaluation_scorecard_fails_on_objective_mismatch():
    observations = _observations()
    observations['objective_ids'] = ['derived::ehp']
    try:
        build_module_evaluation_scorecard(_profile(), observations)
        raise AssertionError('expected ValueError')
    except ValueError as exc:
        assert 'must match observations objective_ids exactly' in str(exc)

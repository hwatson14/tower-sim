from compilers.module_objective_results_from_qe import build_module_objective_results_from_qe
import pytest

def test_objective_results_from_qe():
    out = build_module_objective_results_from_qe(
        baseline_request_id="baseline",
        candidate_request_ids=["cand_a"],
        objective_ids=["ehp", "edamage"],
        results_by_request_id={
            "baseline": {"ehp": 100.0, "edamage": 50.0},
            "cand_a": {"ehp": 120.0, "edamage": 55.0},
        },
    )
    assert out["results_source"] == "qe_or_explicit_result_map"

def test_missing_result_rejected():
    with pytest.raises(ValueError):
        build_module_objective_results_from_qe(
            baseline_request_id="baseline",
            candidate_request_ids=["cand_a"],
            objective_ids=["ehp"],
            results_by_request_id={"baseline": {"ehp": 100.0}},
        )

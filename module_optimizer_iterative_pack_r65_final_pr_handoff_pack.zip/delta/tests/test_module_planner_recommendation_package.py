from compilers.module_planner_recommendation_package import build_module_planner_recommendation_package
import pytest

def test_package_build():
    planner_plan = {
        "horizon_profile": {"horizon_kind": "week", "horizon_days": 7},
        "resource_state": {"resource_state_exactness": "mixed_manual_policy"},
        "recommended_action": {"candidate_id": "cand_a", "request_id": "req_a"},
        "candidate_actions": [{"candidate_id": "cand_a"}],
        "planner_exactness": "advisory_until_costs_closed",
    }
    cost = {"cost_exactness": "mixed_blocked", "blocked_reasons": ["reroll ladder blocked"]}
    feasibility = {
        "recommended_action": {"candidate_id": "cand_a", "request_id": "req_a"},
        "feasibility_status": "blocked_by_exact_cost_gaps",
    }
    out = build_module_planner_recommendation_package(planner_plan, cost, feasibility)
    assert out["package_kind"] == "module_planner_recommendation_package"

def test_recommendation_mismatch_rejected():
    planner_plan = {
        "horizon_profile": {"horizon_kind": "week", "horizon_days": 7},
        "resource_state": {"resource_state_exactness": "mixed_manual_policy"},
        "recommended_action": {"candidate_id": "cand_a", "request_id": "req_a"},
        "candidate_actions": [{"candidate_id": "cand_a"}],
        "planner_exactness": "advisory_until_costs_closed",
    }
    cost = {"cost_exactness": "mixed_blocked", "blocked_reasons": []}
    feasibility = {
        "recommended_action": {"candidate_id": "cand_b", "request_id": "req_b"},
        "feasibility_status": "blocked_by_exact_cost_gaps",
    }
    with pytest.raises(ValueError):
        build_module_planner_recommendation_package(planner_plan, cost, feasibility)

from __future__ import annotations

import json
from pathlib import Path

import yaml

from engine.query_module_resource_advisory import (
    module_resource_advisory_contract_snapshot,
    publish_module_resource_advisory_surfaces,
    supported_module_resource_input_ids,
)
from helpers import cached_run_stats_output
from models.statbook import StatRow

ROOT = Path(__file__).resolve().parents[1]


def row(name: str, value: float, value_type: str = 'scalar') -> StatRow:
    return StatRow(stat_name=name, final_value=value, value_type=value_type, source_count=1, status='resolved', contributors=[], schema={})


def test_default_runtime_does_not_publish_unset_module_resource_surfaces():
    out_dir = cached_run_stats_output()
    statbook = json.loads((out_dir / 'statbook.json').read_text(encoding='utf-8'))
    for surface_id in [
        'derived::economy.income.module_shards',
        'derived::economy.income.reroll_shards',
        'derived::economy.stock.module_shards',
        'derived::economy.stock.reroll_shards',
    ]:
        assert surface_id not in statbook['rows']


def test_module_resource_advisory_surfaces_publish_when_inputs_are_set(tmp_path: Path):
    payload = {
        'inputs': [
            {'input_id': 'income.module_shards.per_week', 'value': 321, 'is_set': True, 'trust_label': 'externally_observed'},
            {'input_id': 'income.reroll_shards.per_week', 'value': 654, 'is_set': True, 'trust_label': 'externally_observed'},
            {'input_id': 'stock.module_shards.current', 'value': 777, 'is_set': True, 'trust_label': 'externally_observed'},
            {'input_id': 'stock.reroll_shards.current', 'value': 888, 'is_set': True, 'trust_label': 'externally_observed'},
        ]
    }
    p = tmp_path / 'module_inputs.json'
    p.write_text(json.dumps(payload), encoding='utf-8')

    rows = {'derived::ehp': row('derived::ehp', 1.0)}
    publish_module_resource_advisory_surfaces(rows, manual_input_path=p)

    assert rows['derived::economy.income.module_shards'].final_value == 321.0
    assert rows['derived::economy.income.module_shards'].value_type == 'per_week'
    assert rows['derived::economy.income.reroll_shards'].final_value == 654.0
    assert rows['derived::economy.stock.module_shards'].final_value == 777.0
    assert rows['derived::economy.stock.module_shards'].value_type == 'scalar'
    assert rows['derived::economy.stock.reroll_shards'].final_value == 888.0


def test_module_resource_contract_alignment_with_registered_surfaces_and_inputs():
    contract = yaml.safe_load((ROOT / 'kb' / 'modules' / 'contracts' / 'module-resource-advisory-surfaces-contract.yaml').read_text())
    snapshot = module_resource_advisory_contract_snapshot()
    initial = yaml.safe_load((ROOT / 'kb' / 'global-rules' / 'contracts' / 'stat-query-initial-surface-set.yaml').read_text())
    ledger = yaml.safe_load((ROOT / 'kb' / 'global-rules' / 'contracts' / 'stat-query-surface-ownership-ledger.yaml').read_text())
    inputs = json.loads((ROOT / 'input' / 'manual_module_optimizer_inputs.json').read_text(encoding='utf-8'))

    contract_input_ids = {row['input_id'] for row in contract['supported_inputs']}
    contract_surface_ids = {row['surface_id'] for row in contract['supported_inputs']}
    input_ids = {row['input_id'] for row in inputs['inputs']}
    derived_surfaces = {s['surface_id'] for s in initial['families']['derived_v1']['surfaces']}
    ledger_nodes = {n['node_id'] for n in ledger['surface_nodes']}

    assert contract_input_ids == supported_module_resource_input_ids()
    assert contract_input_ids == set(snapshot['supported_manual_input_ids'])
    assert contract_input_ids <= input_ids
    assert contract_surface_ids == set(snapshot['published_surface_ids'])
    assert contract_surface_ids <= derived_surfaces
    assert contract_surface_ids <= ledger_nodes

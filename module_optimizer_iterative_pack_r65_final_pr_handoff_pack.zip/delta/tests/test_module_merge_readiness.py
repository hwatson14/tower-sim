from compilers.module_merge_readiness import build_module_merge_readiness


def test_build_module_merge_readiness_tracks_missing_dependencies():
    readiness = build_module_merge_readiness(
        session_bundle={'bundle_id': 'session_001'},
        required_external_dependencies=['pws1_runtime_methods', 'qe_mapping_cleanup'],
        completed_dependencies=['qe_mapping_cleanup'],
    )
    assert readiness['merge_ready_now'] is False
    assert readiness['missing_dependencies'] == ['pws1_runtime_methods']


def test_build_module_merge_readiness_happy_path():
    readiness = build_module_merge_readiness(
        session_bundle={'bundle_id': 'session_001'},
        required_external_dependencies=['pws1_runtime_methods'],
        completed_dependencies=['pws1_runtime_methods'],
    )
    assert readiness['merge_ready_now'] is True
    assert readiness['missing_dependencies'] == []

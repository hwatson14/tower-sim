from compilers.module_live_qe_session import build_module_live_qe_session

def test_build_live_session():
    prepared_manifest = {
        "baseline_request": {"request_id": "baseline"},
        "candidate_requests": [{"request_id": "cand_a"}],
    }
    objective_profile = {
        "objective_ids": ["ehp"],
        "directions": {"ehp": "maximize"},
        "weights": {"ehp": 1.0},
    }
    results = {
        "baseline": {"ehp": 100.0},
        "cand_a": {"ehp": 120.0},
    }
    out = build_module_live_qe_session(prepared_manifest, "bundle_v1", objective_profile, results)
    assert out["live_session_mode"] == "explicit_results_backed"
    assert out["execution"]["recommendation"]["candidate_id"] == "cand_a"

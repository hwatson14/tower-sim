from compilers.module_baseline_evaluation_request import build_module_baseline_evaluation_request


def test_build_module_baseline_evaluation_request_round_trips_baseline_loadout():
    catalog = {
        'selected_preset': 'farming',
        'search_mode': 'bounded_one_swap',
        'baseline': {
            'cannon': {'primary': 'DP', 'assist': 'BA'},
            'armor': {'primary': 'OA', 'assist': 'PH'},
        },
    }
    request = build_module_baseline_evaluation_request(
        candidate_catalog=catalog,
        objective_ids=['ehp', 'edamage'],
        surface_bundle_id='module_optimizer_value_inputs_v1',
    )
    assert request['request_id'] == 'baseline'
    assert request['kind'] == 'baseline'
    assert request['objective_ids'] == ['ehp', 'edamage']
    assert request['baseline_loadout'] == request['overlay_loadout']


def test_build_module_baseline_evaluation_request_fails_closed_without_objectives():
    catalog = {
        'selected_preset': 'farming',
        'search_mode': 'bounded_one_swap',
        'baseline': {'cannon': {'primary': 'DP', 'assist': 'BA'}},
    }
    try:
        build_module_baseline_evaluation_request(
            candidate_catalog=catalog,
            objective_ids=[],
            surface_bundle_id='bundle',
        )
        raise AssertionError('expected ValueError')
    except ValueError as exc:
        assert 'objective_ids must be non-empty' in str(exc)

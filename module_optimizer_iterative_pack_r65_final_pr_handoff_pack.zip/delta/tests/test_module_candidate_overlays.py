from compilers.module_candidate_overlays import build_candidate_overlays


def test_build_candidate_overlays_one_swap():
    catalog = {
        "selected_preset": "farming",
        "search_mode": "bounded_one_swap",
        "baseline": {
            "cannon": {"primary": "DP", "assist": "BA"},
            "armor": {"primary": "OA", "assist": "SF"},
        },
        "candidates": [
            {
                "candidate_id": "cannon:primary:AD",
                "slot": "cannon",
                "family": "primary",
                "baseline_module_id": "DP",
                "replacement_module_id": "AD",
                "kind": "one_swap",
            }
        ],
    }
    overlays = build_candidate_overlays(catalog)
    assert overlays["overlay_count"] == 1
    row = overlays["overlays"][0]
    assert row["overlay_id"] == "cannon:primary:AD"
    assert row["baseline_loadout"]["cannon"]["primary"] == "DP"
    assert row["overlay_loadout"]["cannon"]["primary"] == "AD"
    # baseline must remain unchanged in overlay packaging
    assert catalog["baseline"]["cannon"]["primary"] == "DP"

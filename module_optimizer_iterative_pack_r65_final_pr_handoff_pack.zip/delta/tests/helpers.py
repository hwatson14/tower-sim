from __future__ import annotations
from pathlib import Path
import json, tempfile
from models.account_state import (
    AccountState, ModuleSlotState, ModulePresetSelection, ModuleSnapshot, ModuleSubstat, CardInventoryEntry, SLOT_TYPES
)


def build_state() -> AccountState:
    state = AccountState()
    state.active_module_preset = 'Farming'
    state.default_preset = 'Farming'
    state.module_system_state = {slot: ModuleSlotState() for slot in SLOT_TYPES}
    state.module_presets = {
        'Farming': {
            'cannon': ModulePresetSelection('cannon.alpha', 'cannon.beta'),
            'armor': ModulePresetSelection('armor.alpha', 'armor.assist'),
            'generator': ModulePresetSelection('generator.alpha', None),
            'core': ModulePresetSelection('core.alpha', None),
        }
    }
    inv = {}
    def add(name, slot, stat='generic'):
        inv[name] = ModuleSnapshot(name=name, slot_type=slot, stat=stat, substats=[ModuleSubstat('s1',1.0,'s1')])
    add('cannon.alpha','cannon'); add('cannon.beta','cannon')
    add('armor.alpha','armor'); add('armor.assist','armor')
    add('generator.alpha','generator'); add('core.alpha','core')
    state.modules_inventory = inv
    state.player_meta = {'Farming Tier':'Tier 14', **{f'Tier {i}': ('5761' if i==14 else '100' if i<20 else '0') for i in range(1,22)}, 'Tier 19':'1'}
    state.active_card_preset = 'Farming'
    state.card_presets = {'Farming':['Intro Sprint']}
    state.cards_inventory = {'Intro Sprint': CardInventoryEntry(name='Intro Sprint', level=7, mastery_unlocked=False, mastery_lab_level=0)}
    return state


def cached_run_stats_output(*args, **kwargs):
    d = Path(tempfile.mkdtemp(prefix='runstats_'))
    payload = {'rows': {'derived::ehp': {'final_value': 1.0}}}
    (d/'statbook.json').write_text(json.dumps(payload))
    return d


def build_family_baseline(*args, **kwargs):
    return {'baseline':'stub'}

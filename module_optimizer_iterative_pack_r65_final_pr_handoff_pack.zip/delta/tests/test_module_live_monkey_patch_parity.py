from compilers.module_live_monkey_patch_parity import build_module_live_monkey_patch_parity

def test_parity_match():
    sess = {
        "execution": {
            "recommendation": {"candidate_id": "cand_a"},
            "top_candidates": {"top_candidates": [{"candidate_id": "cand_a"}, {"candidate_id": "cand_b"}]},
        }
    }
    out = build_module_live_monkey_patch_parity(sess, sess)
    assert out["parity_status"] == "match"

def test_parity_differs():
    mp = {
        "execution": {
            "recommendation": {"candidate_id": "cand_a"},
            "top_candidates": {"top_candidates": [{"candidate_id": "cand_a"}, {"candidate_id": "cand_b"}]},
        }
    }
    live = {
        "execution": {
            "recommendation": {"candidate_id": "cand_b"},
            "top_candidates": {"top_candidates": [{"candidate_id": "cand_b"}, {"candidate_id": "cand_a"}]},
        }
    }
    out = build_module_live_monkey_patch_parity(mp, live)
    assert out["parity_status"] == "differs"

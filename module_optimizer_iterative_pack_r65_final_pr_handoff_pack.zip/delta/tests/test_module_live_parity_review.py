from compilers.module_live_parity_review import build_module_live_parity_review

def test_review_match():
    out = build_module_live_parity_review({"parity_status": "match"}, "fx1")
    assert out["review_disposition"] == "accepted_match"

def test_review_differs_requires_classification():
    out = build_module_live_parity_review({"parity_status": "differs"}, "fx2")
    assert out["review_disposition"] == "requires_classification"
    assert "optimizer_issue" in out["required_classifications_if_differs"]

from compilers.module_cost_boundary import build_module_cost_boundary
import pytest

def test_exact_boundary():
    out = build_module_cost_boundary(True, True, [])
    assert out["cost_exactness"] == "exact"

def test_partial_boundary():
    out = build_module_cost_boundary(False, True, ["reroll ladder blocked"])
    assert out["cost_exactness"] == "partial_exact"

def test_block_conflict():
    with pytest.raises(ValueError):
        build_module_cost_boundary(True, False, ["reroll ladder blocked"])

from compilers.module_recommendation_selection import select_module_recommendation


def test_select_module_recommendation_uses_top_rank_with_evidence():
    ranking = {
        'baseline_request_id': 'baseline',
        'ranked_candidates': [
            {'rank': 1, 'request_id': 'req_b', 'candidate_id': 'cand_b', 'overlay_intent_id': 'ov_b', 'total_weighted_delta_raw': 5.0},
            {'rank': 2, 'request_id': 'req_a', 'candidate_id': 'cand_a', 'overlay_intent_id': 'ov_a', 'total_weighted_delta_raw': 2.0},
        ],
    }
    scorecard = {
        'score_rows': [
            {'candidate_id': 'cand_a', 'per_objective': [{'objective_id': 'ehp'}]},
            {'candidate_id': 'cand_b', 'per_objective': [{'objective_id': 'ehp'}]},
        ],
    }

    selected = select_module_recommendation(ranking=ranking, scorecard=scorecard)

    assert selected['baseline_request_id'] == 'baseline'
    assert selected['recommended_candidate']['candidate_id'] == 'cand_b'
    assert selected['recommended_candidate']['rank'] == 1
    assert selected['recommended_candidate']['per_objective'][0]['objective_id'] == 'ehp'


def test_select_module_recommendation_fails_if_top_candidate_missing():
    ranking = {
        'baseline_request_id': 'baseline',
        'ranked_candidates': [
            {'rank': 1, 'request_id': 'req_b', 'candidate_id': 'cand_b', 'overlay_intent_id': 'ov_b', 'total_weighted_delta_raw': 5.0},
        ],
    }
    scorecard = {
        'score_rows': [
            {'candidate_id': 'cand_a', 'per_objective': [{'objective_id': 'ehp'}]},
        ],
    }

    try:
        select_module_recommendation(ranking=ranking, scorecard=scorecard)
    except ValueError as exc:
        assert 'top ranked candidate not found in scorecard' in str(exc)
    else:
        raise AssertionError('expected ValueError')

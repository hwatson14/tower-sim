from compilers.module_planner_final_recommendation import build_module_planner_final_recommendation

def test_final_recommendation_advisory():
    out = build_module_planner_final_recommendation(
        {"recommended_action": {"candidate_id": "cand_a"}, "plan_mode": "advisory_horizon_plan"},
        {"feasibility_status": "blocked_by_exact_cost_gaps"},
        {"projection_exactness": "advisory_until_income_closes"},
        None,
    )
    assert out["final_recommendation_exactness"] == "advisory"
    assert out["has_live_session_evidence"] is False

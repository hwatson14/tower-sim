from compilers.module_planner_feasibility import build_module_planner_feasibility

def test_blocked_feasibility():
    plan = {"plan_mode": "advisory_horizon_plan", "recommended_action": {"candidate_id": "cand_a"}}
    cost = {"cost_exactness": "mixed_blocked", "blocked_reasons": ["reroll ladder blocked"]}
    out = build_module_planner_feasibility(plan, cost)
    assert out["feasibility_status"] == "blocked_by_exact_cost_gaps"

def test_exact_feasibility():
    plan = {"plan_mode": "next_best_change", "recommended_action": {"candidate_id": "cand_a"}}
    cost = {"cost_exactness": "exact", "blocked_reasons": []}
    out = build_module_planner_feasibility(plan, cost)
    assert out["feasibility_status"] == "cost_feasible_if_resources_suffice"

from compilers.module_live_qe_bridge_bundle import build_module_live_qe_bridge_bundle
from compilers.module_finish_path_from_qe_bundle import build_module_finish_path_from_qe_bundle

def test_finish_path_from_qe_bundle():
    bridge = build_module_live_qe_bridge_bundle(
        runtime_surfaces={
            "bosses_per_run": 100,
            "eligible_bosses_per_run": 80,
            "elites_per_run": 50,
            "hours_per_run": 2.5,
            "waves_per_hour": 200,
            "suppressed_boss_fraction": 0.2,
        },
        baseline_request_id="baseline",
        candidate_request_ids=["cand_a"],
        objective_ids=["ehp"],
        results_by_request_id={
            "baseline": {"ehp": 100.0},
            "cand_a": {"ehp": 120.0},
        },
    )
    out = build_module_finish_path_from_qe_bundle(
        bridge_bundle=bridge,
        resource_state={
            "resource_state_exactness": "mixed_manual_policy",
            "farming_hours_per_day": 23.5,
        },
        cost_boundary={"overall_cost_exactness": "blocked_partial"},
        horizon_profile={"horizon_kind": "week", "horizon_days": 7},
        planner_plan={
            "recommended_action": {"candidate_id": "cand_a"},
            "plan_mode": "advisory_horizon_plan",
        },
        planner_feasibility={"feasibility_status": "blocked_by_exact_cost_gaps"},
        live_session={"execution": {"recommendation": {"candidate_id": "cand_a"}}},
        deterministic_income={"module_income_exact": False, "reroll_income_exact": False},
        parity_review=None,
    )
    assert out["finish_path_source"] == "qe_bridge_driven"
    assert out["final_recommendation"]["recommended_action"]["candidate_id"] == "cand_a"

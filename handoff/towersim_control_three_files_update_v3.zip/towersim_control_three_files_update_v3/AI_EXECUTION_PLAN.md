# AI_EXECUTION_PLAN.md

## Purpose

This is the canonical whole-program execution plan for the repo.

It answers, without guessing:
- what the repo is trying to become
- what each phase must accomplish before the next phase begins
- what each tranche may and may not touch
- what proof is required before ownership or phase truth changes
- how future Codex work should be sequenced

`ACTIVE_TRANCHE.md` is the live execution cursor.
`BURNDOWN.yaml` is the machine-readable delivery and verification ledger.

---

## Operating rule

This plan is phase-gated.

That means:
- all tranches inside a phase may run in parallel only when they do not touch the same owner surfaces
- no tranche from the next phase should begin until the current phase is complete and verified
- later phases may be designed early, but not implemented early
- if a phase gate is not met, stop and resolve it before continuing

---


## Control-file content boundaries

This control system has exactly three files with non-overlapping jobs:
- `AI_EXECUTION_PLAN.md` = durable whole-program truth and executable tranche contracts
- `BURNDOWN.yaml` = machine state, phase/tranche delivery state, dependencies, and gate truth
- `ACTIVE_TRANCHE.md` = live execution cursor and tranche-local residue only

The boundaries are strict:
- `AI_EXECUTION_PLAN.md` may contain phase purposes, tranche contracts, owner surfaces, forbidden surfaces, required outputs, dependencies, and stop conditions.
- `AI_EXECUTION_PLAN.md` must not accumulate status chatter, review commentary, or execution residue that belongs in `ACTIVE_TRANCHE.md`.
- `BURNDOWN.yaml` must stay machine-readable and should carry compact state, denominators, dependencies, and verification truth rather than prose explanations.
- `ACTIVE_TRANCHE.md` must stay thin and must not duplicate tranche contract text from this plan.

If information could live in more than one of the three control files, prefer the narrowest owner and do not duplicate it.

## Governing truth

### Mechanic truth
- `kb/` is the source of mechanic truth.
- No implementation task may invent mechanics outside KB-backed truth or explicitly governed accepted-model boundaries.

### Ownership truth
- Current git-version practical stat-resolution owner is still `engine/stat_resolution_core.py`.
- Current git-version compatibility entrypoint is `engine/stat_engine.py`.
- Query Engine is the target canonical owner for stat-resolution truth.
- Inputs owns account/input compilation, not final stat resolution.
- Simulators and evaluators may consume query-owned surfaces but must not re-derive them.
- Optimisers and advisors may aggregate truth-owned surfaces but must not replace their owners.

### Legacy-surface rule after Phase 4
If `engine/stat_engine.py` and/or `engine/stat_resolution_core.py` remain after Phase 4, they remain only as:
- thin compatibility entrypoints, and/or
- non-canonical legacy merge/reference aids for reconciling work built from older baselines.

They must not:
- be named canonical owners of stat-resolution truth
- receive new canonical stat logic
- become routing destinations for new stat surfaces entering scope

### Current active seams
- `compilers/stat_input_compiler.py` still materially straddles Inputs-owned compilation and Query Engine-owned query preparation.
- `run_stats.py` still contains orchestration plus embedded verification, reporting, and comparison concerns.
- eHP, eDamage, and eEcon are still effectively optimiser-local rather than fully query-owned objective surfaces.
- verification and testing are not yet structured as first-class program workstreams.

---

## Canonical architecture and product model

### Layer stack
1. Knowledge Base
2. Inputs
3. Query Engine
4. Simulators
5. Optimisers
6. Advisors

### Clarification
- Query Engine answers: what is true now for this account, scenario, and state.
- Simulators answer: what is likely to happen when those truths play out over runtime, timing, and progression.
- Optimisers search and rank.
- Advisors package action guidance.

### Immediate architectural rule
Do not expand product surfaces on top of unstable ownership boundaries.

---

## Program workstreams

1. Ownership and archive closure
2. Query Engine seam completion and bounded family delegation
3. Objective-state promotion
4. Full stat-resolution migration to Query Engine
5. Verification, evaluator foundation, and test acceleration
6. `run_stats.py` decomposition and thin orchestration
7. Simulator product surfaces
8. Optimiser product surfaces
9. Advisor surfaces and external interfaces
10. Archive retirement and cleanup closure

---

## Master phase order

## Phase 1 — Canonical planning truth and archive closure

### Purpose
Create one clean, current, canonical planning truth and close legacy ambiguity before deeper implementation continues.

### Tranches
- PH1-A — Control-stack closeout and tranche promotion
- PH1-B — Canonical plan and terminology unification
- PH1-C — R86 obligation closure ledger
- PH1-D — Archive disposition ledger
- PH1-E — Control-stack alignment

### Exit gate
- bootstrap tranche is closed or explicitly superseded
- one canonical plan exists and is current
- roadmap-only planning truth has been absorbed or explicitly rejected
- major docs do not contradict the canonical plan
- all root archive artifacts have a documented disposition
- current open obligations are mapped to concrete work items
- control files use the same phase and tranche vocabulary

---

## Phase 2 — Query Engine seam completion and bounded family delegation

### Purpose
Finish the Inputs ↔ Query Engine boundary and establish stable query-owned family resolution for the already-declared bounded family universe.

### Tranches
- PH2-A — `stat_input_compiler.py` function-level ownership ledger
- PH2-B — Compiler/query seam extraction
- PH2-C — Covered-family delegation manifest
- PH2-D — `resolve_stats()` delegation to query kernel
- PH2-E — Covered-family parity and benchmark evidence

### Exit gate
- the compiler/query seam is no longer materially owner-ambiguous
- covered-family delegation is explicit and governed
- covered-family manifest exists and is current
- parity status exists by declared family and surface
- benchmark evidence exists for the delegated path
- the public compatibility entrypoint remains preserved
- no major doc implies repo-wide full delegation

---

## Phase 3 — Objective-state promotion

### Purpose
Promote core composite objective surfaces into Query Engine truth instead of leaving them optimiser-local.

### Phase-wide rules
- Phase 3 may consume current lower-layer stat truth where needed, but must not create new undocumented legacy dependencies.
- Any legacy dependency used by a Phase 3 tranche must be added to the active migration debt ledger with:
  - objective surface
  - dependency surface
  - reason
  - target Phase 4 removal tranche
  - removal condition
- A Phase 3 tranche must not introduce new legacy dependency unless the dependency ledger row is created in the same tranche.

### Tranches
- PH3-A — Objective-state contracts and maturity ledger
- PH3-B — eHP promotion to Query Engine surface
- PH3-C — eDamage promotion to Query Engine surface
- PH3-D — eEcon promotion to Query Engine surface
- PH3-E — Optimiser rewire to consume query-owned objective states
- PH3-F — Objective-state parity and accepted-model evidence

### PH3-A — Objective-state contracts and maturity ledger
Goal:
- declare governed contract, maturity, and contributor-trace expectations for `objective_state::ehp`, `objective_state::edamage`, and `objective_state::eecon`

Scope in:
- contract declarations
- maturity labels and known-gap statements
- contributor-trace expectations
- explicit Phase 4 dependency-debt handoff rule

Scope out:
- formula implementation
- optimiser rewires
- evaluator implementation
- parity evidence

Owner surfaces:
- `AI_EXECUTION_PLAN.md`
- `ACTIVE_TRANCHE.md`
- `BURNDOWN.yaml`
- `kb/global-rules/contracts/stat-query-initial-surface-set.yaml`
- `kb/global-rules/contracts/stat-query-surface-ownership-ledger.yaml`

Forbidden surfaces:
- `optimizer/`
- evaluator code
- simulator product code

Required outputs:
- objective-state contract rows
- maturity ledger
- contributor-trace expectation rows
- dependency-debt ledger schema for follow-on tranches

Required verification:
- all three objective states have declared query surfaces
- maturity posture is explicit
- contributor-trace expectations are explicit
- dependency-debt handling is explicit

Stop conditions:
- stop if any objective surface cannot name its consumer bundle
- stop if contributor-trace expectations would be invented without contract support

### PH3-B — eHP promotion to Query Engine surface
Goal:
- move canonical eHP truth out of optimiser-local ownership into governed Query Engine surface ownership

Scope in:
- eHP contract/routing/composition
- bounded dependency use
- trace support
- parity support

Scope out:
- eDamage/eEcon
- optimiser strategy changes beyond direct consumer rewrite
- evaluator work

Owner surfaces:
- `optimizer/scorer.py`
- `engine/stat_query_kernel.py`
- `engine/family_baseline_materializer.py`
- `kb/global-rules/contracts/stat-query-initial-surface-set.yaml`
- `kb/global-rules/contracts/stat-query-consumer-bundles.yaml`
- `tests/`

Forbidden surfaces:
- `engine/stat_resolution_core.py` as destination for new canonical logic
- simulator product modules

Required outputs:
- query-owned `objective_state::ehp`
- optimiser consumer update for eHP
- parity fixture/tests
- dependency-debt row updates if lower-layer legacy surfaces remain

Required verification:
- optimiser no longer owns canonical eHP formula
- eHP contributor trace is emitted
- any remaining dependency on legacy stat truth is explicit and bounded

Stop conditions:
- stop if new canonical eHP logic would be added to `engine/stat_engine.py` or `engine/stat_resolution_core.py`
- stop if eHP cannot be expressed without inventing new mechanics not yet in KB

### PH3-C — eDamage promotion to Query Engine surface
Goal:
- move canonical eDamage truth into Query Engine ownership

Scope in:
- eDamage contract/routing/composition
- bounded dependency use
- trace support
- parity support

Scope out:
- eHP/eEcon work outside shared support edits
- evaluator implementation
- simulator product work

Owner surfaces:
- `optimizer/scorer.py`
- `engine/stat_query_kernel.py`
- `engine/family_baseline_materializer.py`
- `kb/global-rules/contracts/stat-query-initial-surface-set.yaml`
- `kb/global-rules/contracts/stat-query-consumer-bundles.yaml`
- `tests/`

Forbidden surfaces:
- `engine/stat_resolution_core.py` as destination for new canonical logic
- simulator product modules

Required outputs:
- query-owned `objective_state::edamage`
- optimiser consumer update for eDamage
- parity fixture/tests
- dependency-debt row updates if lower-layer legacy surfaces remain

Required verification:
- optimiser no longer owns canonical eDamage formula
- eDamage contributor trace is emitted
- remaining dependency debt is explicit

Stop conditions:
- stop if eDamage promotion would create undeclared mechanics rather than governed accepted-model math
- stop if new canonical logic would land in legacy surfaces

### PH3-D — eEcon promotion to Query Engine surface
Goal:
- move canonical eEcon truth, including deterministic resource-income support, into Query Engine ownership

Scope in:
- eEcon contract/routing/composition
- deterministic resource-income support surfaces needed for eEcon
- bounded dependency use
- trace support
- parity support

Scope out:
- save-vs-spend logic
- evaluator implementation
- broader optimiser product expansion

Owner surfaces:
- `optimizer/scorer.py`
- `engine/stat_query_kernel.py`
- `engine/family_baseline_materializer.py`
- `kb/global-rules/contracts/stat-query-initial-surface-set.yaml`
- `kb/global-rules/contracts/stat-query-consumer-bundles.yaml`
- `kb/economy/`
- `tests/`

Forbidden surfaces:
- `engine/stat_resolution_core.py` as destination for new canonical logic
- advisor/product planning modules

Required outputs:
- query-owned `objective_state::eecon`
- deterministic resource-income support surfaces needed by eEcon
- optimiser consumer update for eEcon
- parity fixture/tests
- dependency-debt updates if lower-layer legacy stat truth remains

Required verification:
- optimiser no longer owns canonical eEcon formula
- eEcon contributor trace is emitted
- unsupported/non-deterministic economy surfaces remain fail-closed

Stop conditions:
- stop if economy truth would be guessed rather than governed
- stop if new canonical eEcon logic would land in legacy surfaces

### PH3-E — Optimiser rewire to consume query-owned objective states
Goal:
- make optimiser consumers read QE-owned objective surfaces rather than local canonical formulas

Scope in:
- optimiser consumer rewires for eHP/eDamage/eEcon
- removal of canonical formula ownership from optimiser path
- targeted regression coverage

Scope out:
- new objective families
n- simulator feature changes
- advisor logic

Owner surfaces:
- `optimizer/scorer.py`
- `optimizer/path_ranker.py`
- `tests/`
- `BURNDOWN.yaml`

Forbidden surfaces:
- `engine/stat_resolution_core.py`
- product-surface expansion work

Required outputs:
- optimiser reads objective-state QE surfaces
- removed local canonical formula ownership
- targeted regression updates

Required verification:
- optimiser no longer owns canonical formulas for promoted objective states
- objective-surface consumer path is traceable end-to-end

Stop conditions:
- stop if optimiser would become a shadow owner of migrated formulas
- stop if consumer wiring depends on undocumented legacy residue

### PH3-F — Objective-state parity and accepted-model evidence
Goal:
- prove promoted objective surfaces are governed, traced, and acceptable for Phase 4 handoff

Scope in:
- parity evidence
- accepted-model evidence where exact parity is not applicable
- dependency-debt freeze for Phase 4

Scope out:
- new formula work except bounded bugfixes needed to close the tranche
- Phase 4 migration implementation

Owner surfaces:
- `tests/`
- `BURNDOWN.yaml`
- `ACTIVE_TRANCHE.md`
- `AI_EXECUTION_PLAN.md`

Forbidden surfaces:
- product-feature work
- undeclared family expansion

Required outputs:
- parity/accepted-model evidence by objective surface
- dependency-debt freeze note handed to Phase 4
- explicit phase exit statement

Required verification:
- every objective surface has parity or accepted-model evidence status
- remaining debt for Phase 4 is explicit

Stop conditions:
- stop if a debt row lacks target PH4 removal tranche
- stop if Phase 3 would be closed with implicit legacy dependency

### Phase 3 exit gate
- all three objective states have declared owners and query surfaces
- optimiser does not own the canonical formulas anymore
- maturity labels and known-gap statements are explicit
- parity or accepted-model evidence exists per objective state
- contributor-trace expectations are defined for each objective surface
- Phase 4 dependency debt is frozen and explicit

---

## Phase 4 — Full stat-resolution migration to Query Engine

### Purpose
Make Query Engine the practical and declared owner of canonical stat-resolution truth, fully vacate `engine/stat_resolution_core.py` as a canonical logic owner, and leave `engine/stat_engine.py` only as thin compatibility entrypoint if still needed.

### Target end-state
By end of Phase 4:
- canonical stat-resolution scope is KB aligned
- canonical stat-resolution scope resolves through Query Engine-owned paths
- `engine/stat_engine.py` may remain only as thin compatibility entrypoint
- `engine/stat_resolution_core.py` owns no canonical stat logic
- retained legacy files, if any, exist only as non-canonical merge/reference aids for reconciling code built from older baselines
- new stat surfaces coming into scope must plug into KB + QE, not legacy paths

### Phase-wide rules
- New canonical stat logic may not be added to `engine/stat_engine.py` or `engine/stat_resolution_core.py`.
- If either legacy file is retained after Phase 4, its role must be explicitly non-canonical and reference-only.
- Presence of a legacy file does not imply permission to route new stat truth through it.
- Phase 4 scope denominator must be frozen before code migration begins.
- Completion is measured by ownership and routing truth, not by file deletion aesthetics.

### Canonical denominator freeze
Phase 4 must freeze the denominator before migration code begins. That denominator governs exactly what counts as:
- canonical stat-resolution families in scope
- canonical stat groups in scope
- allowed retained legacy merge/reference residue
- parity-covered migrated scope
- benchmark-covered migrated workloads

The frozen denominator must explicitly classify every surface or group into one of these categories only:
1. `family_scoped_canonical_resolution`
2. `non_family_canonical_stat_resolution`
3. `compatibility_only_surface`
4. `legacy_merge_reference_residue`
5. `out_of_phase4_scope`

No Phase 4 tranche may:
- add a new in-scope category
- move a surface between categories
- expand canonical scope silently
- claim migration completion against a changed denominator

unless the three control files are deliberately revised first.

PH4-A must freeze, in one explicit ledger, all of the following before code migration begins:
- the exact family universe counted as migrated/not-migrated
- the exact canonical stat groups counted as migrated/not-migrated
- the exact residual buckets allowed after Phase 4, if any
- the exact parity denominator
- the exact benchmark denominator

No later tranche may silently expand or shrink those denominators. If the denominator must change, stop and update all three control files before continuing.

### Tranches
- PH4-A — Canonical migration ledger and denominator freeze
- PH4-B — Declared family cutover to Query Engine
- PH4-C — Canonical stat group migration by dependency order
- PH4-D — Parity matrix and benchmark closure for migrated scope
- PH4-E — Control-truth cutover and legacy demotion
- PH4-F — Post-cutover hardening and closeout

### PH4-A — Canonical migration ledger and denominator freeze
Goal:
- freeze exactly what counts as canonical stat-resolution scope, residual scope, migrated scope, and benchmark/parity denominator

Scope in:
- full migration ledger
- current-owner vs target-owner mapping
- residual categories
- explicit allowed legacy merge-reference status

Scope out:
- code migration
- formula changes
- parity execution
- benchmark execution

Owner surfaces:
- `AI_EXECUTION_PLAN.md`
- `ACTIVE_TRANCHE.md`
- `BURNDOWN.yaml`
- `engine/stat_resolution_core.py`
- `engine/stat_engine.py`
- `engine/stat_query_kernel.py`
- `kb/global-rules/contracts/stat-query-scenario-families.yaml`
- `kb/global-rules/contracts/stat-query-initial-surface-set.yaml`
- `kb/global-rules/contracts/stat-query-consumer-bundles.yaml`

Forbidden surfaces:
- `optimizer/`
- simulator product modules
- evaluator implementation modules
- `run_stats.py` beyond inventory support if strictly necessary

Required outputs:
- canonical migration ledger
- denominator freeze note
- residual bucket statement
- explicit post-Phase-4 legacy-file rule

Required verification:
- every in-scope canonical stat family/group is named
- every row names current owner and target owner
- every row names whether any post-phase residue is allowed
- no code migration begins before denominator is frozen

Stop conditions:
- stop if a canonical stat group cannot name target QE owner
- stop if a surface cannot be assigned to either canonical scope or explicit residual bucket
- stop if a denominator change is discovered after implementation begins without updating all three control files first

### PH4-B — Declared family cutover to Query Engine
Goal:
- move all already-declared scenario families to live Query Engine-owned resolution

Scope in:
- live cutover for all declared families
- query routing/materializer/kernel work needed for those families
- family-level regression tests

Scope out:
- undeclared family expansion
- long-tail non-family stat migration
- optimiser/evaluator feature work

Owner surfaces:
- `engine/stat_engine.py`
- `engine/stat_query_kernel.py`
- `engine/family_baseline_materializer.py`
- `engine/query_routing.py`
- `engine/query_state_mode_policy.py`
- `engine/query_perk_compiler.py`
- `compilers/stat_input_compiler.py`
- `kb/global-rules/contracts/stat-query-scenario-families.yaml`
- `kb/global-rules/contracts/stat-query-initial-surface-set.yaml`
- `kb/global-rules/contracts/stat-query-consumer-bundles.yaml`
- `tests/test_resolve_stats_delegation.py`

Forbidden surfaces:
- `optimizer/`
- simulator product modules
- evaluator implementation modules
- new generic helper sink files

Required outputs:
- live delegation for all declared families
- updated family routing logic
- family coverage tests
- updated migration KPI counts

Required verification:
- all declared families are live-routable through QE path
- undeclared surfaces are not swept into family routing silently
- any blocked family residue is explicit and bounded

Stop conditions:
- stop if family coverage would require changing undeclared consumer semantics
- stop if a family cannot be routed without inventing new surface classes
- stop if code changes would touch files outside listed owner surfaces without control-file update

### PH4-C — Canonical stat group migration by dependency order
Goal:
- move remaining canonical stat-resolution logic out of legacy ownership and into QE-owned paths in strict dependency order

Scope in:
- migration of canonical stat groups named in PH4-A ledger only
- duplicate-logic removal as groups move
- targeted tests and parity support per group

Scope out:
- simulator product work
- optimiser feature work
- archive cleanup
- undocumented long-tail helper beautification outside frozen denominator

Owner surfaces:
- `engine/stat_resolution_core.py`
- `engine/stat_engine.py`
- `engine/stat_query_kernel.py`
- `engine/family_baseline_materializer.py`
- `engine/dependency_registry.py`
- `kb/global-rules/contracts/stat-query-initial-surface-set.yaml`
- `kb/global-rules/contracts/stat-query-consumer-bundles.yaml`
- `tests/`

Forbidden surfaces:
- broad `run_stats.py` refactor
- `optimizer/`
- `advisors/`
- new architecture layers

Required outputs:
- migrated canonical stat groups from frozen denominator only
- explicit residual list after each migrated group
- parity fixtures/tests per group
- updated ownership statements

Required verification:
- each migrated group has explicit before/after ownership
- no migrated group still relies on legacy formula truth for final value
- any blocked surface is added to explicit residual ledger
- no duplicate logic remains for migrated surfaces

Stop conditions:
- stop if a lower-dependency group is incomplete but a higher-dependency group is about to start
- stop if a group cannot be migrated without changing mechanics not yet governed in KB
- stop if a migrated surface still needs legacy final-value truth to compute output
- stop if a change would migrate a surface not frozen in PH4-A denominator

### PH4-D — Parity matrix and benchmark closure for migrated scope
Goal:
- prove migrated QE surfaces match acceptable reference truth closely enough to cut over ownership

Scope in:
- family parity matrix
- canonical stat group parity matrix
- benchmark capture for migrated workloads
- explicit cutover readiness decision

Scope out:
- new migration work beyond bugfixes triggered by parity failure
- simulator/optimiser feature work

Owner surfaces:
- `tests/`
- `out/` when rebuilt governed artifacts are needed as evidence
- `BURNDOWN.yaml`
- `ACTIVE_TRANCHE.md`

Forbidden surfaces:
- broad new code paths
- new families
- new layer creation

Required outputs:
- parity matrix by family/group/surface
- benchmark evidence for migrated workloads
- explicit pass/fail/open status
- cutover readiness note

Required verification:
- every migrated family/group has visible parity status
- benchmark evidence exists for workloads that matter for cutover
- failures are explicit and bounded

Stop conditions:
- stop if parity denominator is unclear
- stop if benchmark workload is not tied to actually migrated path
- stop if any claimed pass cannot be defended with concrete evidence

### PH4-E — Control-truth cutover and legacy demotion
Goal:
- make QE the declared canonical owner in control truth and narrow legacy code to non-canonical residue only if any remains

Scope in:
- control-truth cutover
- narrowed compatibility path
- legacy demotion/quarantine statement
- canonical owner statement updates

Scope out:
- new feature work
- unrelated cleanup
- broad `run_stats.py` decomposition

Owner surfaces:
- `AI_EXECUTION_PLAN.md`
- `BURNDOWN.yaml`
- `ACTIVE_TRANCHE.md`
- `engine/stat_engine.py`
- `engine/stat_resolution_core.py`
- `ARCHITECTURE.md`
- `README.md`
- affected tests/docs

Forbidden surfaces:
- simulator product modules
- optimiser feature work
- advisor work
- new compatibility shims unless explicitly named residuals require them

Required outputs:
- updated canonical ownership wording
- narrowed compatibility path
- legacy demotion/quarantine statement
- residual ledger of anything not fully retired

Required verification:
- control truth no longer names `stat_resolution_core.py` as canonical owner
- `stat_engine.py` is clearly thin compatibility only
- any remaining residue is named, bounded, and temporary
- dual ownership language is removed from major docs

Stop conditions:
- stop if cutover would hide unresolved residuals
- stop if docs would claim full retirement while code still depends materially on legacy final-value truth
- stop if a compatibility shim is added without explicit residual ownership note

### PH4-F — Post-cutover hardening and closeout
Goal:
- close the phase cleanly after cutover, prove no control drift remains, and hand stable ownership to later phases

Scope in:
- post-cutover smoke/proof pass
- final KPI values
- stale-reference cleanup
- phase closeout and promotion readiness

Scope out:
- new migration work
- new feature work
- opportunistic cleanup beyond directly stale references

Owner surfaces:
- `AI_EXECUTION_PLAN.md`
- `BURNDOWN.yaml`
- `ACTIVE_TRANCHE.md`
- `README.md`
- `ARCHITECTURE.md`
- directly stale test/docs references

Forbidden surfaces:
- new architectural changes
- product features
- new files unless required by control truth and explicitly justified

Required outputs:
- phase closeout note
- final migration KPI values
- stale-reference cleanup
- next-phase promotion note

Required verification:
- all PH4 exit-gate conditions are explicitly satisfied or blocked with named exception
- stale references to legacy canonical ownership are removed
- next phase can begin without ownership ambiguity

Stop conditions:
- stop if phase closeout would require claiming stronger cutover than evidence supports
- stop if any major doc still implies dual ownership
- stop if KPI ledger has unresolved contradictions

### Phase 4 exit gate
- canonical stat-resolution scope is KB aligned
- canonical stat-resolution scope resolves through QE-owned paths
- `engine/stat_engine.py` is thin compatibility only if retained
- `engine/stat_resolution_core.py` owns no canonical stat logic
- any retained legacy file exists only as non-canonical merge/reference aid
- parity exists for migrated scope
- benchmark evidence exists for migrated workloads
- control files, tests, and docs no longer imply dual ownership

---

## Phase 5 — Verification, evaluator foundation, and test acceleration

### Purpose
Make verification first-class, establish evaluator substrate, and create explicit test-lane/benchmark policy on top of a stable stat-resolution owner model.

### Tranches
- PH5-A — Surface verification registry
- PH5-B — Evaluator contract framework
- PH5-C — Max-wave evaluator reference corpus
- PH5-D — Max-wave evaluator implementation or hardening
- PH5-E — Evaluator verification matrix
- PH5-F — Test inventory and timing profile
- PH5-G — Test lane redesign and CI policy alignment

### Exit gate
- governed verification registries exist
- evaluator inputs/outputs/assumptions are explicit
- reference corpus exists for evaluator verification
- evaluator verification status is visible by case family
- test lanes are defined and CI policy matches them

---

## Phase 6 — `run_stats.py` decomposition and thin orchestration

### Purpose
Shrink `run_stats.py` after ownership and proof systems are stable.

### Tranches
- PH6-A — `run_stats.py` decomposition map
- PH6-B — reporting extraction
- PH6-C — verification/comparison extraction cleanup
- PH6-D — output emission and orchestration cleanup

### Exit gate
- every major remaining concern in `run_stats.py` has a target owner
- extracted modules have clear ownership
- `run_stats.py` is primarily orchestration
- outputs remain stable and validated

---

## Phase 7 — Simulator product surfaces

### Purpose
Build simulator product surfaces on top of QE-owned stat truth and evaluator substrate.

### Tranches
- PH7-A — survivability simulator
- PH7-B — damage-aware run-limit simulator
- PH7-C — setup comparison simulator
- PH7-D — richer run-outcome explanation

### Exit gate
- simulator interfaces are consistent
- failure-mode classification is explicit
- simulator surfaces use governed lower-layer truth
- maturity and trust labels are explicit

---

## Phase 8 — Optimiser product surfaces

### Purpose
Build optimiser families on top of QE-owned objective states and verified evaluators.

### Tranches
- PH8-A — loadout optimiser
- PH8-B — progression optimiser core
- PH8-C — resource-family optimiser expansion
- PH8-D — save-vs-spend and branching logic
- PH8-E — archive helper re-homing where justified

### Exit gate
- optimisers consume stable lower-layer surfaces
- objective families are explicit
- recommendation confidence and trust logic are visible
- save-vs-spend branching is governed

---

## Phase 9 — Advisor surfaces and external interfaces

### Purpose
Build user-facing planning and strategy surfaces after lower layers are trustworthy.

### Tranches
- PH9-A — progression-planning advisor
- PH9-B — build-transition advisor
- PH9-C — external query and API schema
- PH9-D — advisor explanation and trust-label packaging

### Exit gate
- advisor outputs consume governed lower layers
- strategy explanations are traceable
- external interfaces expose stable schema
- trust labels remain explicit

---

## Phase 10 — Archive retirement and cleanup closure

### Purpose
Retire superseded root artifacts only after their truth has been absorbed or explicitly rejected.

### Tranches
- PH10-A — remaining archive artifact retirement
- PH10-B — final pointer cleanup across docs and repo surfaces

### Exit gate
- no active work depends on retired root artifacts
- all retained truths are represented in canonical in-repo sources
- repo docs point to current truth, not legacy bundles

---

## Phase dependencies summary

- Phase 1 must finish before Phase 2 starts
- Phase 2 must finish before Phase 3 starts
- Phase 3 must finish before Phase 4 starts
- Phase 4 must finish before Phase 5 starts
- Phase 5 must finish before Phase 6 starts
- Phase 6 must finish before Phase 7 starts
- Phase 7 must finish before Phase 8 starts
- Phase 8 must finish before Phase 9 starts
- Phase 9 must finish before Phase 10 starts

This sequence is mandatory unless the plan itself is explicitly revised.

---

## Parallelisation rules

- Parallelise tranches only when they do not change the same owner surfaces or invalidate each other’s proof.
- Never parallelise ownership-changing edits across the same surfaces, especially:
  - `compilers/stat_input_compiler.py`
  - `engine/stat_resolution_core.py`
  - `engine/stat_engine.py`
  - query contracts and delegation manifests
  - canonical plan and control files when changing IDs or gates
- A later phase may be designed early, but not implemented early.

---

## Success metric

The program is successful when a new AI session can answer, without guessing:
- what layer owns a given surface
- what phase the repo is in
- what must be complete before the next phase starts
- what work may run in parallel right now
- whether canonical stat-resolution scope is QE-owned
- how verification and evaluator truth are governed
- how testing is structured
- what legacy artifacts have been retired or quarantined

If that cannot be answered from repo truth plus this file, the execution system is not complete.

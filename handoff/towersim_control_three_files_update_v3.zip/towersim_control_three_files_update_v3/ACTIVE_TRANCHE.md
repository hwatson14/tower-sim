# ACTIVE_TRANCHE.md

## Role

This file is the live execution cursor.

It identifies:
- the exact active tranche
- the exact plan section Codex should execute
- tranche-local residue and stop conditions only

It is not a second plan.
Canonical tranche-contract truth lives in `AI_EXECUTION_PLAN.md`.
Machine state lives in `BURNDOWN.yaml`.
Do not duplicate tranche contract text here. If contract truth changes, update `AI_EXECUTION_PLAN.md` first and then update this file only to point at the revised truth.

## Active phase
`PH3 — Objective-state promotion`

## Active tranche
`PH3-A — Objective-state contracts and maturity ledger`

## Authoritative plan section
`AI_EXECUTION_PLAN.md -> Phase 3 — Objective-state promotion -> PH3-A — Objective-state contracts and maturity ledger`

## Objective
Declare the governed contract, maturity, and contributor-trace expectations for `objective_state::ehp`, `objective_state::edamage`, and `objective_state::eecon` before per-objective promotion work begins.

## Allowed local residue in this file
- active-slice clarification that does not modify tranche contract truth
- bounded dependency-debt notes discovered while executing the active tranche
- explicit blockers discovered during execution
- immediate stop conditions triggered by live repo truth

## Current tranche-local notes
- Phase 2 exit evidence is complete enough to promote the program into Phase 3 objective-state work.
- The delegated benchmark failure for `timing_tournament_no_perks` remains a visible bounded note, not a blocker that reopens the governed Phase 2 exit gate.
- Objective-state promotion begins with declared contract and maturity truth rather than immediate formula rewrites.

## Immediate stop conditions
- Stop if any objective surface cannot name its consumer bundle.
- Stop if contributor-trace expectations would be invented without contract support.
- Stop if execution would require adding new canonical stat logic to `engine/stat_engine.py` or `engine/stat_resolution_core.py`.
- Stop if dependency debt for follow-on Phase 3 tranches cannot be expressed with a target Phase 4 removal tranche.

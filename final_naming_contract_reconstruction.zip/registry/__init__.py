"""Registry utilities for naming and validation contracts."""

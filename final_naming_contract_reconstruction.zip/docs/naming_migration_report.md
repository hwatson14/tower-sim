# Naming Contract Migration Report

## Scope
- Reconstruct and adapt the naming-contract enforcement layer from the reference archive into the current repo.
- Preserve archive intent while replacing `tower_sim.*` imports with current-repo equivalents.
- Keep this change scoped to naming validation assets only.

## Files added or updated
- `docs/phase_1b_naming_alignment_report.md`
- `docs/naming_migration_report.md`
- `kb/global-rules/contracts/naming-contract.yaml`
- `kb/ledgers/notes/towersim_static_ledger_naming_contract_v1_10.md`
- `pyproject.toml`
- `registry/__init__.py`
- `registry/naming_contract.py`
- `scripts/naming_contract_check.py`
- `tests/test_naming_contract.py`
- `tests/test_naming_contract_check.py`

## Archive to current-repo dependency map
- `tower_sim.registry.stat_registry.default_registry` → `engine.stat_resolution_core._load_canonical_stats`
- `tower_sim.engines.stat_input_compiler._WORKSHOP_STAT_SPECS` → `compilers.stat_input_compiler.WORKSHOP_IDS_TO_CONTRIBUTOR`
- `tower_sim.engines.stat_input_compiler._UW_TRACK_SPECS` → `compilers.stat_input_compiler._load_uw_track_order`
- `tower_sim.libs.bots_lib.load_bot_upgrades` → derived from current KB and bot track tables in `compilers.stat_input_compiler`
- `tower_sim.libs.modules_library.UNIQUE_EFFECTS` → derived from current KB tables via `compilers.stat_input_compiler`
- `tower_sim.libs.modules_library.SUBSTATS_BY_SLOT` → `models.account_state.SLOT_TYPES` plus current KB-derived substat mapping
- `Catalog path tables/meta/registry/catalog.yaml` → `kb/ledgers/sources/raw/repo-meta/registry/catalog.yaml`

## Adaptation notes
- Imports were rewritten to current package paths.
- The registry parity call now resolves directly against current canonical stat metadata instead of an archive stat registry wrapper.
- The audit script now consumes `parsers.ids_parser.parse_ids` and `compilers.account_state_compiler.compile_account_state`.
- The fixture-driven check test targets `input/_IDS.csv` in the current repo instead of archive-era fixtures.

## Known limits
- This migration preserves the reference-archive enforcement model but does not claim that every archive-era naming judgment is authoritative for the current repo.
- Module substat coverage remains partly KB-derived and should be reviewed against current module normalization rules.
- The reference audit report is preserved as a historical alignment artifact; its repo paths still describe the archive-era `tower_sim/` tree.

## Verification intent
Run:
- `pytest tests/test_naming_contract.py -v`
- `pytest tests/test_naming_contract_check.py -v`
- `python scripts/naming_contract_check.py --output /tmp/naming_check.json`

# Final consolidated Codex handoff

Apply `repo_patch/` as one bounded patch on top of the current repo.

## Merge order
1. Runtime/query publication files under `engine/`
2. Inputs-layer file under `input/`
3. Contract files under `kb/global-rules/contracts/` and `kb/economy/contracts/`
4. Tests under `tests/`
5. Docs under `docs/`

## Acceptance gate
```bash
PYTHONPATH=. python -m py_compile engine/query_surface_publication.py engine/query_derived_composites.py engine/query_currency_income.py engine/derived_surface_composer.py engine/stat_engine.py optimizer/scorer.py tests/test_phase3_consolidated_publication.py tests/test_phase3_manual_income_inputs.py tests/test_phase3_trace_and_income_metadata.py tests/test_phase3_contract_path.py
PYTHONPATH=. pytest -q tests/test_phase3_consolidated_publication.py tests/test_phase3_manual_income_inputs.py tests/test_phase3_trace_and_income_metadata.py tests/test_phase3_contract_path.py
PYTHONPATH=. python run_stats.py
```

## Architectural constraints
- Keep Phase 3 publication in `engine/query_surface_publication.py`.
- Do not re-add Phase 3 publishers to `derived_surface_composer.py`.
- Do not extend `stat_resolution_core.py` for these Phase 3 published surfaces.
- Preserve cash exclusion and stones normalization.
- Keep non-deterministic incomes in `input/manual_advisory_inputs.json`.


## Bundle cleanup note
- This bundle intentionally contains only repo-path files under `repo_patch/`.
- Earlier duplicate/export-style artifacts have been removed.

## Dependency note for contract-path test
- `tests/test_phase3_contract_path.py` expects the following files to already exist on the target repo base:
  - `kb/global-rules/contracts/stat-query-consumer-bundles.yaml`
  - `kb/global-rules/contracts/stat-query-initial-surface-set.yaml`
  - `kb/global-rules/contracts/stat-query-surface-ownership-ledger.yaml`
- Those files are also included in this bundle as patched replacements under `repo_patch/`, so Codex should apply the full patch before running the acceptance gate.
- If Codex is applying into a branch that has materially drifted from these files, it should resolve the merge first, then run the acceptance gate.

Bundle hygiene update (v4)
- top-level audit clutter removed; only one merge-readiness audit is retained
- stale trailing comment removed from repo_patch/engine/derived_surface_composer.py
- no architectural/runtime behavior changes relative to v3

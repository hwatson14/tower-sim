import yaml
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_phase3_contracts_registered():
    initial = yaml.safe_load((ROOT / 'kb/global-rules/contracts/stat-query-initial-surface-set.yaml').read_text())
    ledger = yaml.safe_load((ROOT / 'kb/global-rules/contracts/stat-query-surface-ownership-ledger.yaml').read_text())
    bundles = yaml.safe_load((ROOT / 'kb/global-rules/contracts/stat-query-consumer-bundles.yaml').read_text())
    derived_surfaces = {s['surface_id'] for s in initial['families']['derived_v1']['surfaces']}
    for sid in ['derived::ehp','derived::edamage','derived::eecon','derived::economy.income.coins','derived::economy.income.gems','derived::economy.income.stones']:
        assert sid in derived_surfaces
    ledger_nodes = {n['node_id'] for n in ledger['surface_nodes']}
    assert 'input_surface::income.gems.per_week' in ledger_nodes
    assert 'derived::economy.income.stones' in ledger_nodes
    opt = next(c for c in bundles['consumers'] if c['consumer_id'] == 'optimizer_analysis')
    bundle = next(b for b in opt['bundles'] if b['bundle_id'] == 'derived_composite_scores')
    assert 'derived::ehp' in bundle['required_surface_ids']

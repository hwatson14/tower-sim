from pathlib import Path
import json

from engine.query_surface_publication import publish_phase3_query_surfaces
from engine.query_currency_income import resolve_currency_income_surfaces
from models.statbook import StatRow


def row(name, value, value_type='scalar'):
    return StatRow(stat_name=name, final_value=value, value_type=value_type, source_count=1, status='resolved', contributors=[], schema={})


def test_unset_vs_zero_manual_income(tmp_path: Path):
    payload = {'inputs': [
        {'input_id': 'income.gems.per_week', 'value': None, 'is_set': False, 'trust_label': 'Externally observed'},
        {'input_id': 'income.stones.per_week', 'value': 0, 'is_set': True, 'trust_label': 'Externally observed'},
    ]}
    p = tmp_path / 'manual_advisory_inputs.json'
    p.write_text(json.dumps(payload), encoding='utf-8')
    surfaces = resolve_currency_income_surfaces({}, manual_input_path=p)
    assert 'derived::economy.income.gems' not in surfaces
    assert surfaces['derived::economy.income.stones'].final_value == 0.0


def test_malformed_manual_income_fail_closed(tmp_path: Path):
    p = tmp_path / 'manual_advisory_inputs.json'
    p.write_text('{bad json', encoding='utf-8')
    assert resolve_currency_income_surfaces({}, manual_input_path=p) == {}


def test_publication_collision_fails_closed(tmp_path: Path):
    p = tmp_path / 'manual_advisory_inputs.json'
    p.write_text(json.dumps({'inputs': []}), encoding='utf-8')
    rows = {'derived::eecon': row('derived::eecon', 1.0), 'canonical_stat::tower_hp': row('canonical_stat::tower_hp', 100), 'canonical_stat::wall_hp': row('canonical_stat::wall_hp', 100), 'canonical_stat::wall_fortification_multiplier': row('canonical_stat::wall_fortification_multiplier', 1), 'canonical_stat::tower_defense_absolute': row('canonical_stat::tower_defense_absolute', 0), 'canonical_stat::tower_defense_pct': row('canonical_stat::tower_defense_pct', 0), 'canonical_stat::max_recovery_multiplier': row('canonical_stat::max_recovery_multiplier', 1), 'canonical_stat::recovery_package_multiplier': row('canonical_stat::recovery_package_multiplier', 1)}
    import pytest
    with pytest.raises(ValueError):
        publish_phase3_query_surfaces(rows, manual_input_path=p)

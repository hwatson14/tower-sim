from __future__ import annotations

from typing import Dict, Any

from models.statbook import StatRow


def _get(rows: Dict[str, StatRow], key: str, default: float = 0.0) -> float:
    row = rows.get(key)
    if row is None or row.final_value is None:
        return default
    try:
        return float(row.final_value)
    except Exception:
        return default


def _tp(rows: Dict[str, StatRow], a: str, b: str) -> float:
    return _get(rows, a) + _get(rows, b)


def _uptime(duration: float, cooldown: float) -> float:
    total = duration + cooldown
    return duration / total if total > 0 else 0.0


def _ev(chance_pct: float, multiplier: float) -> float:
    return 1.0 + (chance_pct / 100.0) * max(0.0, multiplier - 1.0)


def _ep_bullet_per_second(attack_speed: float) -> float:
    # EP BULLET_PER_SECOND from mechanics-library.yaml
    return ((0.01413 * attack_speed * attack_speed) + (4.01278 * attack_speed) + 92.8885) * 1.3


def _ep_rapidfire_factor(rfc_pct: float, rfd_seconds: float, bullet_per_second: float) -> float:
    # EP EPD_RAPIDFIRE from mechanics-library.yaml, using current published rapid-fire chance/duration
    rfc = max(0.0, rfc_pct) / 100.0
    denom = 1.0 + (rfc * rfd_seconds * bullet_per_second)
    if denom <= 0.0:
        return 1.0
    return (1.0 + 4.0 * rfc * rfd_seconds * bullet_per_second) / denom


def _contributor(rows: Dict[str, StatRow], key: str, destination: str) -> Dict[str, Any]:
    row = rows.get(key)
    return {
        'stat_name': key,
        'source_family': 'published_surface',
        'source_name': key,
        'value': None if row is None else row.final_value,
        'value_type': None if row is None else row.value_type,
        'stage': 'derived_surface_publication',
        'destination_object_type': 'derived',
        'destination_id': destination,
        'resolver_id': 'query_derived_composites',
        'kb_mapped': row is not None,
    }


def _publish(rows: Dict[str, StatRow], name: str, value: float, value_type: str, contributors: list[Dict[str, Any]], notes: str) -> None:
    existing = rows.get(name)
    if existing is not None:
        raise ValueError(f'Phase 3 publication collision for {name}')
    rows[name] = StatRow(
        stat_name=name,
        final_value=value,
        value_type=value_type,
        source_count=len(contributors),
        status='resolved',
        notes=notes,
        contributors=contributors,
        schema={'resolver': 'query_derived_composites'},
    )


def publish_derived_composites(rows: Dict[str, StatRow]) -> None:
    # eHP
    hp = _get(rows, 'canonical_stat::tower_hp')
    whp = _get(rows, 'canonical_stat::wall_hp')
    wf = _get(rows, 'canonical_stat::wall_fortification_multiplier', 1.0)
    da = _get(rows, 'canonical_stat::tower_defense_absolute')
    dp = _get(rows, 'canonical_stat::tower_defense_pct')
    mrec = _get(rows, 'canonical_stat::max_recovery_multiplier')
    rpmult = _get(rows, 'canonical_stat::recovery_package_multiplier')
    wall_ratio = whp / hp if hp > 0 else 1.0
    effective_pool = hp * ((wall_ratio * wf) + (mrec * rpmult))
    defense_taken_factor = 1.0 / max(1.0 - dp / 100.0, 0.01)
    cfd = _tp(rows, 'mechanic_param::uw.chrono_field.duration_seconds', 'runtime_mechanic_param::uw.chrono_field.duration_seconds')
    cfc = _get(rows, 'mechanic_param::uw.chrono_field.cooldown_seconds')
    cfdr = _get(rows, 'mechanic_param::uw.chrono_field.damage_reduction_pct')
    cfu = _uptime(cfd, cfc)
    cf_factor = 1.0 / max(1.0 - min(0.95, cfu * cfdr / 100.0), 0.05)
    bhd = _tp(rows, 'mechanic_param::uw.black_hole.duration_seconds', 'runtime_mechanic_param::uw.black_hole.duration_seconds')
    bhc = _tp(rows, 'mechanic_param::uw.black_hole.cooldown_seconds', 'runtime_mechanic_param::uw.black_hole.cooldown_seconds')
    pbdr = _get(rows, 'mechanic_param::module.primordial_collapse.bh_damage_reduction_pct')
    bhu = _uptime(bhd, bhc)
    pbh_factor = 1.0 / max(1.0 - min(0.95, bhu * pbdr / 100.0), 0.05)
    ehp = (effective_pool + da) * defense_taken_factor * cf_factor * pbh_factor
    ehp_contrib = [
        _contributor(rows, 'canonical_stat::tower_hp', 'ehp'),
        _contributor(rows, 'canonical_stat::wall_hp', 'ehp'),
        _contributor(rows, 'canonical_stat::wall_fortification_multiplier', 'ehp'),
        _contributor(rows, 'canonical_stat::tower_defense_absolute', 'ehp'),
        _contributor(rows, 'canonical_stat::tower_defense_pct', 'ehp'),
    ]
    _publish(rows, 'derived::ehp.wall_ratio', wall_ratio, 'ratio', [_contributor(rows, 'canonical_stat::wall_hp', 'ehp.wall_ratio'), _contributor(rows, 'canonical_stat::tower_hp', 'ehp.wall_ratio')], 'wall/tower hp ratio')
    _publish(rows, 'derived::ehp.effective_pool', effective_pool + da, 'scalar', ehp_contrib, 'effective pool before damage reduction factors')
    _publish(rows, 'derived::ehp.defense_taken_factor', defense_taken_factor, 'multiplier', [_contributor(rows, 'canonical_stat::tower_defense_pct', 'ehp.defense_taken_factor')], '1/(1-defense_pct)')
    _publish(rows, 'derived::ehp.chrono_field_uptime', cfu, 'ratio', [_contributor(rows, 'mechanic_param::uw.chrono_field.duration_seconds', 'ehp.chrono_field_uptime'), _contributor(rows, 'mechanic_param::uw.chrono_field.cooldown_seconds', 'ehp.chrono_field_uptime')], 'chrono field uptime')
    _publish(rows, 'derived::ehp.chrono_field_damage_reduction_factor', cf_factor, 'multiplier', [_contributor(rows, 'mechanic_param::uw.chrono_field.damage_reduction_pct', 'ehp.chrono_field_damage_reduction_factor')], 'chrono field damage reduction factor')
    _publish(rows, 'derived::ehp.primordial_black_hole_uptime', bhu, 'ratio', [_contributor(rows, 'mechanic_param::uw.black_hole.duration_seconds', 'ehp.primordial_black_hole_uptime'), _contributor(rows, 'mechanic_param::uw.black_hole.cooldown_seconds', 'ehp.primordial_black_hole_uptime')], 'primordial black hole uptime proxy')
    _publish(rows, 'derived::ehp.primordial_black_hole_damage_reduction_factor', pbh_factor, 'multiplier', [_contributor(rows, 'mechanic_param::module.primordial_collapse.bh_damage_reduction_pct', 'ehp.primordial_black_hole_damage_reduction_factor')], 'primordial black hole damage reduction factor')
    _publish(rows, 'derived::ehp', ehp, 'scalar', ehp_contrib, 'EP-aligned derived effective HP composite')

    # eDamage
    td = _get(rows, 'canonical_stat::tower_damage')
    asp = _get(rows, 'canonical_stat::tower_attack_speed')
    dpm = _get(rows, 'canonical_stat::tower_damage_per_meter_multiplier')
    rng = _get(rows, 'canonical_stat::tower_range_m')
    bps = _ep_bullet_per_second(asp)
    range_dpm_factor = 1.0 + dpm * rng
    multishot_factor = 1.0 + (_get(rows, 'canonical_stat::tower_multishot_chance_pct')/100.0) * max(_get(rows, 'canonical_stat::tower_multishot_targets') - 1.0, 0.0)
    bounce_factor = 1.0 + (_get(rows, 'canonical_stat::tower_bounce_shot_chance_pct')/100.0) * max(_get(rows, 'canonical_stat::tower_bounce_shot_targets') - 1.0, 0.0)
    rapidfire_factor = _ep_rapidfire_factor(_get(rows, 'canonical_stat::tower_rapid_fire_chance_pct'), _get(rows, 'canonical_stat::tower_rapid_fire_duration_seconds'), bps)
    base_tower_dps = td * bps * range_dpm_factor * multishot_factor * bounce_factor * rapidfire_factor
    crit_ev = _ev(_get(rows, 'canonical_stat::tower_crit_chance_pct'), _get(rows, 'canonical_stat::tower_crit_multiplier'))
    supercrit_ev = _ev(_get(rows, 'canonical_stat::tower_supercrit_chance_pct'), _get(rows, 'canonical_stat::tower_supercrit_multiplier'))
    shock_ev = _ev(_get(rows, 'mechanic_param::shock.chance_pct'), _get(rows, 'mechanic_param::shock.damage_multiplier'))
    cl = _get(rows, 'mechanic_param::uw.chain_lightning.damage_multiplier')
    dw = _get(rows, 'mechanic_param::uw.death_wave.damage_multiplier')
    sm = _get(rows, 'mechanic_param::uw.smart_missiles.damage_multiplier')
    sl = _get(rows, 'mechanic_param::uw.spotlight.damage_multiplier')
    additive_uw_damage = cl + dw + sm + sl
    edamage = base_tower_dps * crit_ev * supercrit_ev * shock_ev + additive_uw_damage
    _publish(rows, 'derived::edamage.bullet_per_second', bps, 'rate', [_contributor(rows, 'canonical_stat::tower_attack_speed', 'edamage.bullet_per_second')], 'EP BULLET_PER_SECOND from mechanics lineage')
    _publish(rows, 'derived::edamage.range_dpm_factor', range_dpm_factor, 'multiplier', [_contributor(rows, 'canonical_stat::tower_damage_per_meter_multiplier', 'edamage.range_dpm_factor'), _contributor(rows, 'canonical_stat::tower_range_m', 'edamage.range_dpm_factor')], 'range x dpm factor')
    _publish(rows, 'derived::edamage.multishot_factor', multishot_factor, 'multiplier', [_contributor(rows, 'canonical_stat::tower_multishot_chance_pct', 'edamage.multishot_factor'), _contributor(rows, 'canonical_stat::tower_multishot_targets', 'edamage.multishot_factor')], 'multishot expected value factor')
    _publish(rows, 'derived::edamage.bounce_factor', bounce_factor, 'multiplier', [_contributor(rows, 'canonical_stat::tower_bounce_shot_chance_pct', 'edamage.bounce_factor'), _contributor(rows, 'canonical_stat::tower_bounce_shot_targets', 'edamage.bounce_factor')], 'bounce expected value factor')
    _publish(rows, 'derived::edamage.rapidfire_factor', rapidfire_factor, 'multiplier', [_contributor(rows, 'canonical_stat::tower_rapid_fire_chance_pct', 'edamage.rapidfire_factor'), _contributor(rows, 'canonical_stat::tower_rapid_fire_duration_seconds', 'edamage.rapidfire_factor')], 'EP EPD_RAPIDFIRE-aligned rapidfire factor')
    _publish(rows, 'derived::edamage.base_tower_dps', base_tower_dps, 'scalar', [_contributor(rows, 'canonical_stat::tower_damage', 'edamage.base_tower_dps'), _contributor(rows, 'canonical_stat::tower_attack_speed', 'edamage.base_tower_dps')], 'base tower dps with core mechanics')
    _publish(rows, 'derived::edamage.crit_ev', crit_ev, 'multiplier', [_contributor(rows, 'canonical_stat::tower_crit_chance_pct', 'edamage.crit_ev'), _contributor(rows, 'canonical_stat::tower_crit_multiplier', 'edamage.crit_ev')], 'crit expected value')
    _publish(rows, 'derived::edamage.supercrit_ev', supercrit_ev, 'multiplier', [_contributor(rows, 'canonical_stat::tower_supercrit_chance_pct', 'edamage.supercrit_ev'), _contributor(rows, 'canonical_stat::tower_supercrit_multiplier', 'edamage.supercrit_ev')], 'supercrit expected value')
    _publish(rows, 'derived::edamage.shock_ev', shock_ev, 'multiplier', [_contributor(rows, 'mechanic_param::shock.chance_pct', 'edamage.shock_ev'), _contributor(rows, 'mechanic_param::shock.damage_multiplier', 'edamage.shock_ev')], 'shock expected value')
    _publish(rows, 'derived::edamage.uw.chain_lightning_damage', cl, 'scalar', [_contributor(rows, 'mechanic_param::uw.chain_lightning.damage_multiplier', 'edamage.uw.chain_lightning_damage')], 'chain lightning damage proxy')
    _publish(rows, 'derived::edamage.uw.death_wave_damage', dw, 'scalar', [_contributor(rows, 'mechanic_param::uw.death_wave.damage_multiplier', 'edamage.uw.death_wave_damage')], 'death wave damage proxy')
    _publish(rows, 'derived::edamage.uw.smart_missiles_damage', sm, 'scalar', [_contributor(rows, 'mechanic_param::uw.smart_missiles.damage_multiplier', 'edamage.uw.smart_missiles_damage')], 'smart missiles damage proxy')
    _publish(rows, 'derived::edamage.uw.spotlight_damage', sl, 'scalar', [_contributor(rows, 'mechanic_param::uw.spotlight.damage_multiplier', 'edamage.uw.spotlight_damage')], 'spotlight damage proxy')
    _publish(rows, 'derived::edamage.additive_uw_damage', additive_uw_damage, 'scalar', [_contributor(rows, 'mechanic_param::uw.chain_lightning.damage_multiplier', 'edamage.additive_uw_damage'), _contributor(rows, 'mechanic_param::uw.death_wave.damage_multiplier', 'edamage.additive_uw_damage'), _contributor(rows, 'mechanic_param::uw.smart_missiles.damage_multiplier', 'edamage.additive_uw_damage'), _contributor(rows, 'mechanic_param::uw.spotlight.damage_multiplier', 'edamage.additive_uw_damage')], 'sum of additive uw damage channels')
    _publish(rows, 'derived::edamage.uw_damage_scalar', additive_uw_damage, 'scalar', [_contributor(rows, 'mechanic_param::uw.chain_lightning.damage_multiplier', 'edamage.uw_damage_scalar')], 'compat alias for total uw damage scalar')
    _publish(rows, 'derived::edamage', edamage, 'scalar', [_contributor(rows, 'canonical_stat::tower_damage', 'edamage')], 'EP-aligned derived effective damage composite')

    # eEcon coin-first, no cash
    ck = _get(rows, 'canonical_stat::coin_kill_multiplier')
    cw = _get(rows, 'canonical_stat::coins_per_wave')
    base_kill = ck
    base_wave = cw
    base_coin_income = base_kill + base_wave
    # timing engine may not expose exactly, use published support if present else 1.0
    timed_overlap_multiplier = rows.get('support_surface::timing.combined_multiplier')
    timed = _get(rows, 'support_surface::timing.combined_multiplier', 1.0)
    slcoin = _get(rows, 'runtime_mechanic_param::uw.spotlight.coin_bonus_multiplier')
    dwcoin = _get(rows, 'runtime_mechanic_param::uw.death_wave.coin_bonus_multiplier')
    ccoin = _get(rows, 'runtime_mechanic_param::cards.critical_coin.bonus_multiplier')
    cc_chance = _get(rows, 'canonical_stat::tower_crit_chance_pct')
    ws_chance = _get(rows, 'runtime_mechanic_param::cards.wave_skip.chance_pct')
    spotlight_coin_factor = 1.0 + slcoin / 10.0 if slcoin > 0 else 1.0
    death_wave_coin_factor = 1.0 + dwcoin / 10.0 if dwcoin > 0 else 1.0
    critical_coin_factor = 1.0 + (cc_chance / 100.0) * (ccoin / 100.0) if ccoin > 0 else 1.0
    wave_skip_factor = 1.0 + ws_chance / 100.0
    eecon = base_coin_income * timed * spotlight_coin_factor * death_wave_coin_factor * critical_coin_factor * wave_skip_factor
    _publish(rows, 'derived::eecon.base_kill_income', base_kill, 'scalar', [_contributor(rows, 'canonical_stat::coin_kill_multiplier', 'eecon.base_kill_income')], 'coin kill base')
    _publish(rows, 'derived::eecon.base_wave_income', base_wave, 'scalar', [_contributor(rows, 'canonical_stat::coins_per_wave', 'eecon.base_wave_income')], 'coin wave base')
    _publish(rows, 'derived::eecon.base_coin_income', base_coin_income, 'scalar', [_contributor(rows, 'canonical_stat::coin_kill_multiplier', 'eecon.base_coin_income'), _contributor(rows, 'canonical_stat::coins_per_wave', 'eecon.base_coin_income')], 'coin-first persistent base income')
    _publish(rows, 'derived::eecon.base_income', base_coin_income, 'scalar', [_contributor(rows, 'canonical_stat::coin_kill_multiplier', 'eecon.base_income'), _contributor(rows, 'canonical_stat::coins_per_wave', 'eecon.base_income')], 'compat alias for coin-first persistent base income')
    _publish(rows, 'derived::eecon.spotlight_coin_factor', spotlight_coin_factor, 'multiplier', [_contributor(rows, 'runtime_mechanic_param::uw.spotlight.coin_bonus_multiplier', 'eecon.spotlight_coin_factor')], 'spotlight coin factor')
    _publish(rows, 'derived::eecon.death_wave_coin_factor', death_wave_coin_factor, 'multiplier', [_contributor(rows, 'runtime_mechanic_param::uw.death_wave.coin_bonus_multiplier', 'eecon.death_wave_coin_factor')], 'death wave coin factor')
    _publish(rows, 'derived::eecon.critical_coin_factor', critical_coin_factor, 'multiplier', [_contributor(rows, 'runtime_mechanic_param::cards.critical_coin.bonus_multiplier', 'eecon.critical_coin_factor'), _contributor(rows, 'canonical_stat::tower_crit_chance_pct', 'eecon.critical_coin_factor')], 'critical coin factor')
    _publish(rows, 'derived::eecon.wave_skip_factor', wave_skip_factor, 'multiplier', [_contributor(rows, 'runtime_mechanic_param::cards.wave_skip.chance_pct', 'eecon.wave_skip_factor')], 'wave skip factor')
    _publish(rows, 'derived::eecon.timed_overlap_multiplier', timed, 'multiplier', [_contributor(rows, 'support_surface::timing.combined_multiplier', 'eecon.timed_overlap_multiplier')], 'timed overlap multiplier')
    _publish(rows, 'derived::eecon', eecon, 'scalar', [_contributor(rows, 'canonical_stat::coin_kill_multiplier', 'eecon'), _contributor(rows, 'canonical_stat::coins_per_wave', 'eecon')], 'EP-mechanics aligned coin-first econ composite')


# Compatibility helpers for parity tests and transitional callers
def compute_derived_ehp(rows):
    tmp = dict(rows)
    publish_derived_composites(tmp)
    return tmp['derived::ehp'].final_value

def compute_derived_edamage(rows):
    tmp = dict(rows)
    publish_derived_composites(tmp)
    return tmp['derived::edamage'].final_value

def compute_derived_eecon(rows):
    tmp = dict(rows)
    publish_derived_composites(tmp)
    return tmp['derived::eecon'].final_value

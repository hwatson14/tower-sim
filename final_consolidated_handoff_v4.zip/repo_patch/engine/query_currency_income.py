from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, Any

from models.statbook import StatRow

_DEFAULT_MANUAL_INPUT_PATH = Path(__file__).resolve().parents[1] / 'input' / 'manual_advisory_inputs.json'

_MANUAL_TO_SURFACE = {
    'income.gems.per_week': ('derived::economy.income.gems', 'gems_per_week'),
    'income.stones.per_week': ('derived::economy.income.stones', 'stones_per_week'),
    'income.medals.per_week': ('derived::economy.income.medals', 'medals_per_week'),
    'income.keys.per_week': ('derived::economy.income.keys', 'keys_per_week'),
    'income.shards.per_week': ('derived::economy.income.shards', 'shards_per_week'),
    'income.bits.per_week': ('derived::economy.income.bits', 'bits_per_week'),
}


def _load_manual_inputs(manual_input_path: str | Path | None = None) -> Dict[str, Dict[str, Any]]:
    path = Path(manual_input_path) if manual_input_path is not None else _DEFAULT_MANUAL_INPUT_PATH
    if not path.exists():
        return {}
    try:
        payload = json.loads(path.read_text(encoding='utf-8'))
    except (OSError, json.JSONDecodeError):
        return {}
    rows = payload.get('inputs', [])
    if not isinstance(rows, list):
        return {}
    out: Dict[str, Dict[str, Any]] = {}
    for row in rows:
        if isinstance(row, dict) and isinstance(row.get('input_id'), str):
            out[row['input_id']] = row
    return out


def _manual_input_is_set(entry: Dict[str, Any]) -> bool:
    if bool(entry.get('is_set', False)):
        return True
    return isinstance(entry.get('value'), (int, float))


def _publish_surface(rows: Dict[str, StatRow], *, surface_id: str, value: float, unit: str, notes: str, contributors: list[dict], schema: dict) -> None:
    existing = rows.get(surface_id)
    if existing is not None:
        raise ValueError(f'Phase 3 publication collision for {surface_id}')
    rows[surface_id] = StatRow(
        stat_name=surface_id,
        final_value=value,
        value_type='per_week',
        source_count=len(contributors),
        status='resolved',
        notes=notes,
        contributors=contributors,
        schema=schema | {'unit': unit},
    )


def publish_currency_income_surfaces(rows: Dict[str, StatRow], manual_input_path: str | Path | None = None) -> None:
    eecon_base = rows.get('derived::eecon.base_coin_income')
    if eecon_base is not None:
        _publish_surface(
            rows,
            surface_id='derived::economy.income.coins',
            value=float(eecon_base.final_value),
            unit='coins_per_week',
            notes='Coin-first persistent income surface derived from published eEcon base.',
            contributors=[{
                'surface_id': 'derived::economy.income.coins',
                'source_class': 'published_surface',
                'source_name': 'derived::eecon.base_coin_income',
                'value': eecon_base.final_value,
                'unit': 'coins_per_week',
                'trust_label': 'accepted_model',
                'source_alignment': 'EP',
            }],
            schema={'source_alignment': 'EP', 'externalized': False, 'publisher': 'query_surface_publication'},
        )

    manual_inputs = _load_manual_inputs(manual_input_path)
    for input_id, (surface_id, unit) in _MANUAL_TO_SURFACE.items():
        entry = manual_inputs.get(input_id)
        if entry is None or not _manual_input_is_set(entry):
            continue
        try:
            value = float(entry.get('value'))
        except (TypeError, ValueError):
            continue
        _publish_surface(
            rows,
            surface_id=surface_id,
            value=value,
            unit=unit,
            notes='Derived from input/manual_advisory_inputs.json user input surface.',
            contributors=[{
                'surface_id': surface_id,
                'source_class': 'manual_input',
                'input_id': input_id,
                'value': value,
                'unit': unit,
                'trust_label': entry.get('trust_label', 'Externally observed'),
                'consumer_scope': entry.get('consumer_scope', []),
                'source_alignment': 'Inputs',
            }],
            schema={'source_alignment': 'Inputs', 'input_id': input_id, 'externalized': True, 'publisher': 'query_surface_publication', 'is_set': True},
        )


def resolve_currency_income_surfaces(rows: Dict[str, StatRow], manual_input_path: str | Path | None = None) -> Dict[str, StatRow]:
    tmp = dict(rows)
    publish_currency_income_surfaces(tmp, manual_input_path=manual_input_path)
    return {k: v for k, v in tmp.items() if k.startswith('derived::economy.income.')}

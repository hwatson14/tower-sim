# Phase 3 peer review response

Resolved issues:
- Publication moved out of `derived_surface_composer.py` into `engine/query_surface_publication.py`.
- `derived_surface_composer.py` now stays focused on legacy/helper mirror surfaces only.
- Manual income inputs now distinguish unset from zero using `is_set` + `null` values.
- `query_currency_income.py` no longer uses transitional alias clutter or global path mutation in the primary API.
- Added tests for malformed inputs, unset-vs-zero semantics, publication collision fail-closed behavior, and contract registration.
- Registered published derived and income surfaces in `stat-query-initial-surface-set.yaml`, `stat-query-consumer-bundles.yaml`, and `stat-query-surface-ownership-ledger.yaml`.

Still intentionally transitional:
- `engine/stat_engine.resolve_stats()` remains the current compatibility entrypoint on main, so it calls the new publication contract today. This is separated architecturally, but full direct-query publication entrypoints remain later integration work.

# Offline burndown with verification

## Closed in this handoff
- Phase 3 publication moved out of `derived_surface_composer.py` into `engine/query_surface_publication.py`.
- `engine/stat_engine.resolve_stats()` now calls the Phase 3 publication contract after canonical/compat resolution.
- `input/manual_advisory_inputs.json` now distinguishes unset from zero via `is_set` and `value: null`.
- Published manual income surfaces now fail closed on malformed input and publish only when explicitly set.
- Published derived/income surfaces are registered in the initial surface set, consumer bundles, and ownership ledger.
- Collision handling for Phase 3 publication is fail-closed.
- Consolidated acceptance gate passes on the full repo overlay.

## Still intentionally open
- Full direct-query publication entrypoint beyond `stat_engine.resolve_stats()` compatibility path.
- Removal of transitional optimiser fallback after broader integration proves the published path everywhere.
- Non-coin deterministic income modeling (by design these remain Inputs-layer manual values).
- Simulator-grade truth for top-level derived composites.

## Verification run
```bash
PYTHONPATH=. python -m py_compile engine/query_surface_publication.py engine/query_derived_composites.py engine/query_currency_income.py engine/derived_surface_composer.py engine/stat_engine.py optimizer/scorer.py tests/test_phase3_consolidated_publication.py tests/test_phase3_manual_income_inputs.py tests/test_phase3_trace_and_income_metadata.py tests/test_phase3_contract_path.py
PYTHONPATH=. pytest -q tests/test_phase3_consolidated_publication.py tests/test_phase3_manual_income_inputs.py tests/test_phase3_trace_and_income_metadata.py tests/test_phase3_contract_path.py
PYTHONPATH=. python run_stats.py
```

Results:
- py_compile: passed
- pytest: 6 passed
- run_stats.py: passed

# Merge readiness audit v3

## Non-blocking architectural note
Phase 3 publication still enters through `stat_engine.resolve_stats()` on current architecture.
This is acceptable for now because publication is explicit, isolated in `engine/query_surface_publication.py`, and callable from future query-native entrypoints later.

## Bundle hygiene fixes
- Removed duplicate/export-style artifacts: `repo_patch/engine_query_surface_publication.py`, `repo_patch/optimizer_scorer.py`.
- README now includes a dependency note for `tests/test_phase3_contract_path.py`.

## Verdict
- Review-branch handoff: ready
- Mainline merge as final truth-complete Phase 3: not claimed

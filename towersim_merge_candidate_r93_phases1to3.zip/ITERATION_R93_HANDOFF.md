# Iteration R93 Handoff

This is the consolidated merge candidate for Phases 1–3.

## Scope included
- Phase 1 thorns workbook-parity tranche
- Phase 2 ELS BC reduction workbook/repo tranche
- Phase 3 lab tier-list advisory KB tranche

## Scope deferred
- Phase 4 lab planner
- projected max-wave delta publication for thorns
- broader optimiser/advisor rollout
- final query-engine consolidation

## Review order recommended
1. `MERGE_CANDIDATE_SUMMARY_R93.md`
2. `QUERY_ENGINE_REFACTOR_NOTES_R93.md`
3. phase-specific contract docs under `docs/`
4. tests under `tests/`
5. output payload examples under `out/`

## Why this is mergeable now
Because the key surfaces are already proven and bounded, and the package now makes refactor pressure explicit instead of hiding it.

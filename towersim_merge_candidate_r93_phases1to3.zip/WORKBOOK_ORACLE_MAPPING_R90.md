
# Workbook oracle mapping R90

## Oracle sheet
`Copy of Laboratory v2.5.7.xlsx` → `ELS BC Reduction`

## Relevant cells
- `D1` = `Master Sheet!BA2` = Battle Condition Reduction lab level
- `D2` = `D1 * 2%`
- row ladder:
  - `A4:A22` heat wave
  - `D4:D22` original BC level
  - `E4:E22` original BC value
  - `B4:B22` reduced level = `MAX(Drow - D1, 1)`
  - `C4:C22` reduced value = `($E$4 / $D$4) * Brow * (1 - $D$2)`

## Repo oracle
`kb/tournaments/sources/raw/repo-inputs/combat/tier-battle-conditions.csv`
Rows where `bc == enemy_level_skip_reduction`

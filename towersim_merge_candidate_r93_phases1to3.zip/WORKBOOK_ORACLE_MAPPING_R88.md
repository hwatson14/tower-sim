# Workbook Oracle Mapping R88

## Reference workbook
`Copy of Laboratory v2.5.7.xlsx`

## Reference sheet
`Interactive Thorns`

## Oracle role
This sheet is the accepted parity oracle for Phase 1 thorns mechanics.

## Input cells used for parity

| Cell | Meaning | Workbook reference value |
|---|---|---:|
| F7 | WS Thorns | 0.99 |
| H7 | Relics | 0.09 |
| J7 | Sub Thorns | 0.11 |
| L7 | Plasma Cannon | 0.54 |
| M7 | Elite PC mastery multiplier | locked / non-numeric |
| N7 | Vault Thorns | 0.00 |
| P7 | BC Thorns multiplier | 1.00 |
| R7 | Sharp Fortitude enabled | True/False branch |
| C9:T9 | Wall thorns 1%..20% | 0.01..0.20 |
| C17:T17 | SF wall thorns 1%..20% | 0.01..0.20 |

## Output rows used for parity

| Row | Meaning |
|---|---|
| 10 | Elites |
| 11 | Elites + PC |
| 12 | Bosses |
| 13 | Fleets |
| 14 | Bosses + PC |
| 18 | SF Elites |
| 19 | SF Elites + PC |
| 20 | SF Bosses |
| 21 | SF Fleets |
| 22 | SF Bosses + PC |

## Notes
- The workbook exposes normal-cell formulas for non-SF rows.
- The SF rows call `THORNSDAMAGE(...)`, which is treated here as an oracle-output surface rather than a directly inspectable formula source.
- Elite + PC is gated by `ISNUMBER(M7)`.

import json, re, yaml, pandas as pd, openpyxl
from pathlib import Path

def norm(s: str) -> str:
    s = str(s).strip().lower().replace("’", "'").replace("–", "-").replace("—", "-")
    s = re.sub(r"\s+", " ", s)
    return s

def extract(workbook_path: str, repo_root: str, out_dir: str) -> None:
    wb = openpyxl.load_workbook(workbook_path, data_only=True)
    tier = wb["Tier List"]

    with open(Path(repo_root) / "kb/ledgers/sources/raw/repo-meta/registry/catalog.yaml", "r", encoding="utf-8") as f:
        labs_catalog = yaml.safe_load(f)["categories"]["labs"]

    name_to_ids = {}
    for item in labs_catalog:
        for alias in [item.get("primary_name"), *(item.get("aliases") or [])]:
            if alias:
                name_to_ids.setdefault(norm(alias), set()).add(item["canonical_id"])

    manual = {
        norm("Workshop Enhancements"): "LAB_WORKSHOP_ENHANCEMENT",
        norm("Enhancement Attack - Coin Discount"): "LAB_ENHANCEMENT_ATTACK_COIN_DISCOUNT",
        norm("Enhancement Defense - Coin Discount"): "LAB_ENHANCEMENT_DEFENSE_COIN_DISCOUNT",
        norm("Enhancement Utility - Coin Discount"): "LAB_ENHANCEMENT_UTILITY_COIN_DISCOUNT",
    }

    rows = []
    for r in range(3, tier.max_row + 1):
        name = tier[f"C{r}"].value
        if not name:
            continue
        k = norm(name)
        ids = name_to_ids.get(k, set())
        if len(ids) == 1:
            cid = list(ids)[0]
            status = "exact_catalog"
        elif k in manual:
            cid = manual[k]
            status = "manual_alias_override"
        else:
            cid = ""
            status = "unmatched"
        rows.append({
            "workbook_row": r,
            "lab_name": name,
            "lab_canonical_id": cid,
            "unlock_tier": tier[f"B{r}"].value,
            "ranking_primary": tier[f"D{r}"].value,
            "ranking_conditional": tier[f"E{r}"].value,
            "notes": tier[f"F{r}"].value,
            "mapping_status": status,
            "evidence_type": "advisory_heuristic",
        })

    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(out / "lab-tier-list.csv", index=False)
    (out / "lab-tier-list.json").write_text(json.dumps(rows, indent=2), encoding="utf-8")

if __name__ == "__main__":
    raise SystemExit("Use extract(workbook_path, repo_root, out_dir)")

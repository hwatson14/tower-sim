# Query Engine Refactor Notes R93

## Intent
This note exists because the current repo direction points toward a broader query engine. The delivered Phase 1–3 work should therefore be treated as interim preserved contracts, not final module placement.

## Recommended target architecture

### Mechanical query surfaces
- thorns surface becomes a combat/mechanics query under the query engine
- ELS BC reduction becomes a scenario/lab interaction query under the query engine

### Advisory query surfaces
- lab tier list becomes an advisory lookup surface under the query engine or advisory registry

## Refactor rules

1. Preserve proven behavior before improving elegance.
2. Separate oracle modes from canonical runtime modes.
3. Preserve payload semantics even if file paths change.
4. Preserve tests until replacement tests prove equal or better coverage.
5. Preserve provenance in output payloads.

## Specific rules by phase

### Phase 1 thorns
- keep workbook-oracle parity tests until a stronger primary-source mechanic proof exists
- keep Elite + PC gating semantics unless mastery is truly available
- do not replace workbook rounded-thorn composition in oracle mode
- do not convert progression note into hard max-wave delta without a governed bridge

### Phase 2 ELS BC reduction
- keep workbook surface and repo scenario view distinct unless a formal unification contract is adopted
- preserve adapter tests around percentage-point handling for `bc_reduction_group4_pct`
- preserve seam notes in any higher-level combined query

### Phase 3 lab advisory
- keep advisory data separate from mechanical tables
- keep canonical lab ID mapping explicit
- keep alias overrides documented

## Good refactor outcome
A good refactor outcome moves these surfaces behind cleaner query endpoints while preserving:
- identical or stronger tested behavior
- explicit provenance
- explicit oracle vs runtime distinctions
- no planner creep

## Bad refactor outcome
A bad refactor outcome would:
- collapse workbook and repo semantics into one undocumented surface
- treat advisory rank as optimisation truth
- delete parity behavior because it looks inelegant
- remove tests before replacement coverage exists

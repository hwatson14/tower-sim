# TowerSim Merge Candidate Summary R93

## Executive purpose

This bundle packages the completed work from **Phase 1 through Phase 3** into one refactor-aware merge candidate:

- **Phase 1:** thorns mechanical surface with workbook-parity verification
- **Phase 2:** ELS BC reduction surfaces, harmonization payloads, and repo scenario adapter
- **Phase 3:** lab tier-list KB enrichment as advisory metadata

It intentionally **does not** include the lab planner. That was deferred because it is a larger subsystem with higher refactor pressure and lower immediate necessity for repo handover.

This bundle is designed for a future architecture where a broader **query engine** likely absorbs or wraps these surfaces. Because of that, the handoff here prioritizes:

1. explicit provenance
2. explicit scope boundaries
3. explicit oracle mapping
4. payload contracts that can survive file moves and refactors
5. preservation of workbook-parity behavior where proven

## Why this merge candidate exists now

At this point the repo has three useful, bounded surfaces that are already worth preserving before broader refactor:

1. a workbook-parity thorns calculator
2. a workbook/repo dual-view ELS BC reduction surface with repo-consumer adapter
3. an advisory lab tier-list KB surface mapped to canonical IDs

Those are valuable as standalone contracts. The lab planner is not required to make this bundle useful, and forcing it in now would increase architecture churn and blur the boundary between mechanical truth and planning/advisor behavior.

## Included files by phase

### Phase 1 · Thorns
- `engine/thorns_surface.py`
- `tests/test_thorns_surface.py`
- `docs/39_phase1_thorns_surface_contract.md`
- `governance/R87_PHASE1_THORNS_SCOPE_GUARD.md`
- `governance/R87_PHASE1_THORNS_VERIFICATION.md`
- `governance/WORKBOOK_PARITY_REPORT_R87.csv`
- `out/thorns_payload_reference.json`
- `WORKBOOK_ORACLE_MAPPING_R88.md`

### Phase 2 · ELS BC reduction
- `engine/els_bc_reduction_surface.py`
- `engine/els_bc_reduction_adapter.py`
- `tests/test_els_bc_reduction_surface.py`
- `tests/test_els_bc_reduction_adapter.py`
- `docs/40_phase2_els_bc_reduction_contract.md`
- `docs/41_phase2_els_bc_scenario_adapter_contract.md`
- `governance/R90_PHASE2_ELS_SCOPE_GUARD.md`
- `governance/R90_PHASE2_ELS_VERIFICATION.md`
- `governance/R91_PHASE2_ELS_ADAPTER_VERIFICATION.md`
- `out/els_bc_reduction_workbook_payload_level0.json`
- `out/els_bc_reduction_workbook_payload_level5.json`
- `out/els_bc_reduction_tier_payload_level0.json`
- `out/els_bc_reduction_tier_payload_level5.json`
- `out/els_bc_reduction_harmonization_level5.json`
- `out/els_bc_reduction_scenario_adapter_t14_level5.json`
- `out/els_bc_reduction_scenario_adapter_t21_level5.json`
- `out/els_bc_reduction_scenario_adapter_tournament_wave100_level5.json`
- `WORKBOOK_ORACLE_MAPPING_R90.md`

### Phase 3 · Lab tier-list KB enrichment
- `kb/labs/advisory/tables/lab-tier-list-v27_0_3.csv`
- `kb/labs/advisory/registry/lab-advisory-source-registry.csv`
- `kb/labs/advisory/notes/lab-tier-list.md`
- `scripts/extract_lab_tier_list.py`
- `docs/42_phase3_lab_tierlist_kb_contract.md`
- `governance/R92_PHASE3_LAB_TIERLIST_SCOPE_GUARD.md`
- `governance/R92_PHASE3_LAB_TIERLIST_VERIFICATION.md`
- `out/lab_tier_list_advisory_v27_0_3.json`
- `out/lab_tier_list_advisory_summary.json`

## What was implemented, how, and why

### Phase 1 · Thorns surface

#### What it does
`engine/thorns_surface.py` exposes a payload-only thorns calculator with four main payload families:

1. resolved thorns surface
2. hits-to-kill payload
3. wall-thorns upgrade scan to cap
4. bounded progression relevance payload

#### How it works
- Reads repo baseline thorns-related values from `out/statbook.json`
- Consumes repo scenario surfaces via `ScenarioConfig` and `compute_scenario_surfaces`
- Supports injected overrides for hypothetical cases
- Reproduces workbook tower-thorns composition when direct total thorns is not injected
- Reproduces workbook-parity hit tables for non-SF and SF cases
- Keeps Elite + PC gated unless an explicit mastery multiplier is available

#### Why it is shaped this way
This is intentionally a **leaf-shaped interim surface**. The likely future state is that a query engine or combat query layer absorbs it, but the critical thing to preserve now is the proven behavior:

- workbook-parity rounding path
- workbook-parity hit tables
- gating semantics
- garlic separated as a contributor
- scan-to-cap behavior
- refusal to publish hard max-wave deltas

#### What is provisional
The Sharp Fortitude implementation is best treated as **workbook-parity behavior**, not universal mechanic truth. That distinction must survive refactor unless better primary evidence is added.

### Phase 2 · ELS BC reduction

#### What it does
This phase ships **three related surfaces** plus one adapter:

1. workbook-parity heat-wave ladder surface
2. repo tier scenario view
3. harmonization payload showing both together
4. repo-consumer adapter mapping lab level into scenario group-4 reduction

#### How it works
- `engine/els_bc_reduction_surface.py` implements both workbook and tier views
- `engine/els_bc_reduction_adapter.py` maps lab level into `ScenarioConfig.bc_reduction_group4_pct`
- Tests verify workbook examples, tier examples, and scenario-adapter outputs

#### Why it is shaped this way
There is a real seam between:
- workbook heat-wave ladder semantics
- repo tier additive-magnitude semantics

They are related but not isomorphic. The correct design move here was to make both visible and explicit rather than collapse them into one undocumented pseudo-truth.

#### What is provisional
A future query engine may wrap these as one user-facing query surface, but it must still preserve provenance:
- workbook oracle view
- repo scenario-canonical view
- adapter logic for repo consumers

### Phase 3 · Lab tier-list KB enrichment

#### What it does
Promotes the workbook lab tier list into repo KB as an **advisory** surface.

#### How it works
- Extracts tier-list rows from the workbook
- Maps workbook names to canonical lab IDs using repo catalog naming
- Stores the result under `kb/labs/advisory/`
- Emits JSON summaries for downstream consumers
- Provides a rebuild script so the surface is not a dead manual artifact

#### Why it is shaped this way
The tier list is **strategy guidance**, not mechanical truth. Storing it under advisory KB rather than mechanical tables prevents planners/optimisers from silently treating rank as formula truth.

#### What is provisional
The current file layout may change, but these fields should survive:
- canonical lab id
- primary rank
- conditional rank
- notes
- provenance/advisory flags

## Query-engine refactor guidance

This bundle should be read as **pre-query-engine preserved contracts**, not final architecture.

### Recommended future shape
A broader query engine could eventually expose:

- `query(thorns_hits_to_kill, scenario, injected_overrides)`
- `query(els_bc_reduction, scenario_or_workbook_mode, lab_level)`
- `query(lab_advisory_rank, lab_id)`

### What the query engine should preserve
Even if the implementation moves, these contract properties should remain stable:

#### Preserve from Phase 1
- workbook-oracle mode for thorns parity
- direct/injected override capability
- Elite + PC gating semantics
- garlic as separate contributor
- wall-thorns scan-to-cap output family
- bounded progression note rather than fake hard max-wave deltas

#### Preserve from Phase 2
- distinct workbook vs repo scenario provenance
- adapter behavior for repo scenario consumers
- visibility of seam notes where surfaces are related but non-isomorphic

#### Preserve from Phase 3
- advisory metadata stored separately from mechanical lab tables
- canonical ID join key
- explicit advisory/provenance flags

### What the query engine should not do
- silently erase workbook parity modes
- silently convert advisory rank into hard optimisation truth
- silently merge workbook and repo views where they differ semantically
- drop seam notes just because the front-end surface becomes cleaner

## Verification state

### Phase 1
- workbook non-SF parity: verified
- workbook SF parity: verified
- Elite + PC gating parity: verified
- repo baseline payload smoke: verified

### Phase 2
- workbook formula examples: verified
- tier scenario examples: verified
- repo scenario adapter examples: verified

### Phase 3
- workbook tier-list rows extracted: 180
- mapped rows: 180
- unmatched rows: 0
- explicit alias overrides: 4

## What is deliberately deferred
- projected max-wave delta as a hard published thorns output
- Phase 4 lab planner
- optimiser/advisor ranking logic built on top of these surfaces
- final query-engine consolidation

## Merge recommendation

This is a good merge candidate **now** because it preserves proven surfaces before broader refactor. It should be merged as:

- mechanical surfaces + contracts + tests
- advisory KB enrichment + rebuild script
- detailed handoff notes

It should **not** be described as final architecture.

## Suggested merge message

`Merge workbook-parity thorns, ELS BC reduction surfaces, and advisory lab tier-list KB as refactor-aware interim contracts`


# R90 scope guard

## In scope
- Workbook-parity ELS BC reduction surface
- Tier scenario ELS BC reduction view from repo KB
- Explicit harmonization payload showing both surfaces side by side
- Tests for workbook examples and tier examples

## Out of scope
- Optimiser ranking
- Planner integration
- Silent unification of workbook and scenario surfaces
- Any claims that workbook ladder is the same object as tier additive magnitude values


# R90 verification

## Workbook verification
Verified against `Copy of Laboratory v2.5.7.xlsx` sheet `ELS BC Reduction`:
- D1 = Battle Condition Reduction lab level
- D2 = D1 * 2%
- reduced level = MAX(original level - lab level, 1)
- reduced value = (E4 / D4) * reduced level * (1 - D2)

Examples checked:
- lab level 0, heat wave 1 → -0.01
- lab level 5, heat wave 20 → -0.003
- lab level 5, heat wave 100 → -0.057

## Repo scenario verification
Verified against repo CSV:
`kb/tournaments/sources/raw/repo-inputs/combat/tier-battle-conditions.csv`

Examples checked:
- T14 enemy_level_skip_reduction = 0.025
- T21 enemy_level_skip_reduction = 0.13
- with lab level 5 these reduce to 0.0225 and 0.117 respectively

## Bounded seam
Workbook view and tier scenario view remain intentionally separate.

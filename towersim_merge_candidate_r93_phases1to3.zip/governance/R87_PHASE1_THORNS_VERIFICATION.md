# R87 Phase 1 Thorns Verification

## Evidence used
- Uploaded workbook `Copy of Laboratory v2.5.7.xlsx`
- Sheet `Interactive Thorns`
- Cached workbook values and visible formulas
- Uploaded repo `tower_stat_calc_r80_hardened_with_geometry_and_r86.zip`

## Verification result
- Non-SF workbook tables: exact parity
- SF workbook tables: exact parity
- Elite + PC gating: exact parity
- Repo baseline payload emission: passes smoke test

## Remaining bounded gap
- Projected max-wave delta intentionally not published in Phase 1

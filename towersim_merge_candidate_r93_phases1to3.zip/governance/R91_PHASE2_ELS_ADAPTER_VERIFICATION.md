# R91 Phase 2 ELS Adapter Verification

Verified: lab level to group-4 percentage-point mapping (`lab_level * 2`), T14/T21 farming examples, tournament wave 100 example, payload shape.
Not closed: unified replacement of workbook heat-wave surface; optimiser/advisor logic.

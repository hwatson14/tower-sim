# R92 Phase 3 scope guard

Phase 3 owns:
- extraction of workbook lab tier list
- mapping to canonical lab IDs
- storage in KB as advisory metadata
- registry/discoverability artifacts for downstream planners/optimisers/advisors

Phase 3 does not own:
- lab planner scheduling
- mechanical lab values/costs/durations
- ranking optimisation logic
- runtime simulator application

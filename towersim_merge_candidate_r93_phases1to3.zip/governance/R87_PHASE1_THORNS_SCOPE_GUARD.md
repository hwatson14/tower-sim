# R87 Phase 1 Thorns Scope Guard

Phase 1 must remain inside thorns mechanics.

Allowed:
- thorns composition
- wall-thorns scan
- garlic separate contributor
- SF workbook parity
- repo scenario resistance consumption
- payload emission

Not allowed:
- ELS BC reduction
- lab planner
- advisory tier ranking
- max-wave delta publication
- unrelated survivability engine refactors

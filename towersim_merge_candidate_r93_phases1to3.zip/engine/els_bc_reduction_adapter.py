
from __future__ import annotations
from dataclasses import asdict, dataclass, replace
from pathlib import Path
from typing import Any, Dict
import importlib.util
import os
import sys

try:
    from engine.scenario_engine import ScenarioConfig, compute_scenario_surfaces
except ModuleNotFoundError:
    repo_root = Path(os.environ.get("TOWERSIM_REPO_ROOT", "/mnt/data/repo_r80"))
    scenario_path = repo_root / "engine" / "scenario_engine.py"
    spec = importlib.util.spec_from_file_location("engine.scenario_engine", scenario_path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = mod
    spec.loader.exec_module(mod)
    ScenarioConfig = mod.ScenarioConfig
    compute_scenario_surfaces = mod.compute_scenario_surfaces


def lab_level_to_reduction_pct(lab_level: int) -> float:
    if lab_level < 0:
        raise ValueError("lab_level must be >= 0")
    # Repo scenario_engine expects reduction percentage points, not 0..1 fraction.
    return lab_level * 2.0


@dataclass(frozen=True)
class ElsBcScenarioComparison:
    mode_id: str
    tier: int
    league: str | None
    tournament_wave: int
    lab_level: int
    reduction_pct: float
    base_enemy_level_skip_reduction_pp: float
    adjusted_enemy_level_skip_reduction_pp: float
    delta_pp: float
    adapter_contract: str = "repo_group4_adapter"

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


def apply_els_bc_lab_to_scenario(config: ScenarioConfig, lab_level: int) -> ScenarioConfig:
    return replace(config, bc_reduction_group4_pct=lab_level_to_reduction_pct(lab_level))


def compare_scenario_effect(config: ScenarioConfig, lab_level: int) -> ElsBcScenarioComparison:
    base = compute_scenario_surfaces(config)
    adjusted_cfg = apply_els_bc_lab_to_scenario(config, lab_level)
    adjusted = compute_scenario_surfaces(adjusted_cfg)
    return ElsBcScenarioComparison(
        mode_id=config.mode_id,
        tier=config.tier,
        league=config.league,
        tournament_wave=config.tournament_wave,
        lab_level=lab_level,
        reduction_pct=lab_level_to_reduction_pct(lab_level),
        base_enemy_level_skip_reduction_pp=float(base.bc_enemy_level_skip_reduction_pp),
        adjusted_enemy_level_skip_reduction_pp=float(adjusted.bc_enemy_level_skip_reduction_pp),
        delta_pp=float(adjusted.bc_enemy_level_skip_reduction_pp - base.bc_enemy_level_skip_reduction_pp),
    )


def emit_scenario_adapter_payload(config: ScenarioConfig, lab_level: int) -> Dict[str, Any]:
    comp = compare_scenario_effect(config, lab_level)
    return {
        "surface_id": "els_bc_reduction_scenario_adapter",
        "status": "scenario_adapter_verified",
        "input_scenario": {
            "mode_id": config.mode_id,
            "tier": config.tier,
            "league": config.league,
            "tournament_wave": config.tournament_wave,
        },
        "lab_level": lab_level,
        "lab_reduction_pct": comp.reduction_pct,
        "group4_override_pct": comp.reduction_pct,
        "base_enemy_level_skip_reduction_pp": comp.base_enemy_level_skip_reduction_pp,
        "adjusted_enemy_level_skip_reduction_pp": comp.adjusted_enemy_level_skip_reduction_pp,
        "delta_pp": comp.delta_pp,
        "boundary_notes": [
            "This adapter is repo-canonical, not workbook-canonical.",
            "It maps the lab level into ScenarioConfig.bc_reduction_group4_pct in percentage-point form and lets scenario_engine compute the adjusted enemy_level_skip_reduction_pp surface.",
            "This does not erase the workbook heat-wave ladder surface from Phase 2; it is an explicit adapter for repo consumers.",
        ],
        "adapter_contract": comp.adapter_contract,
    }


"""Phase 1 thorns surface.

Scope:
- Workbook parity against `Copy of Laboratory v2.5.7.xlsx` / `Interactive Thorns`
  for the mechanical thorns tables.
- Payload-only surface for later optimiser/advisor consumption.
- Bounded progression note only; no projected max-wave delta publication.

Important distinction:
- This module contains a *workbook-parity* implementation for Sharp Fortitude.
  It reproduces the workbook table exactly for the current known formula family.
  Do not treat it as a universal mechanic truth without additional KB proof.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
import json
import math
from pathlib import Path
from typing import Any, Dict, Optional

from engine.scenario_engine import ScenarioConfig, compute_scenario_surfaces

ROOT = Path(__file__).resolve().parents[1]
OUT_DIR = ROOT / "out"

WALL_THORNS_LAB_MAX_LEVEL = 20
# Workbook parity constant for Sharp Fortitude.
# Equivalent to adding +1 percentage-point of wall-thorns damage per hit before
# multiplying by enemy-class effectiveness. In normalized multiplier form:
#   hit_n_damage = base_hit_damage * (1 + n * (0.01 / tower_thorns_multiplier))
# For the workbook reference surface tower_thorns_multiplier = 1.20, giving 1/120.
SF_RAMP_ABSOLUTE_WALL_STEP = 0.01


@dataclass(frozen=True)
class ThornsInputs:
    mode_id: str = "farming"
    tier: int = 14
    tournament_wave: int = 0
    league: Optional[str] = None

    tower_thorns_pct_injected: Optional[float] = None
    workshop_thorns_pct: Optional[float] = None
    relic_thorns_pct: Optional[float] = None         # additive decimal, e.g. 0.09
    vault_thorns_pct: Optional[float] = None         # additive decimal, e.g. 0.05
    module_thorns_sub_pct: Optional[float] = None    # additive percent-points, e.g. 11.0

    wall_thorns_lab_level: Optional[int] = None
    wall_thorns_ratio: Optional[float] = None        # e.g. 0.15

    plasma_cannon_pct: float = 0.0                   # e.g. 0.54
    elite_pc_multiplier: Optional[float] = None      # workbook-gated
    bc_thorns_resistance_multiplier: Optional[float] = None
    bc_plasma_cannon_resistance_multiplier: Optional[float] = None
    boss_thorns_effectiveness: Optional[float] = None
    fleet_thorns_effectiveness: float = 0.1
    sharp_fortitude_active: bool = False
    garlic_thorns_level: Optional[int] = None
    garlic_thorns_pct: Optional[float] = None


def _load_statbook_rows(path: Path = OUT_DIR / "statbook.json") -> Dict[str, Dict[str, Any]]:
    payload = json.loads(path.read_text())
    return payload["rows"]


def _get_final_value(rows: Dict[str, Dict[str, Any]], key: str) -> Any:
    row = rows.get(key)
    if row is None:
        return None
    return row.get("final_value")


def _get_contributor_value(rows: Dict[str, Dict[str, Any]], stat_name: str, source_family: str, source_name: Optional[str] = None) -> Any:
    row = rows.get(stat_name)
    if row is None:
        return None
    for contributor in row.get("contributors", []):
        if contributor.get("source_family") != source_family:
            continue
        if source_name is not None and contributor.get("source_name") != source_name:
            continue
        return contributor.get("value")
    return None


def _repo_defaults(inputs: ThornsInputs) -> Dict[str, Any]:
    rows = _load_statbook_rows()

    workshop = _get_contributor_value(rows, "canonical_stat::tower_thorns_damage_pct", "workshop", "Thorn Damage")
    relic = _get_contributor_value(rows, "canonical_stat::tower_thorns_damage_pct", "relic", "Thorns")
    vault = _get_contributor_value(rows, "canonical_stat::tower_thorns_damage_pct", "vault", "Thorn Damage")

    module_sum = 0.0
    tower_row = rows.get("canonical_stat::tower_thorns_damage_pct", {})
    for contributor in tower_row.get("contributors", []):
        if contributor.get("source_family") == "module_substat":
            module_sum += float(contributor.get("value") or 0.0)

    wall_ratio = _get_contributor_value(rows, "canonical_stat::wall_thorns_damage_pct", "lab", "Wall Thorns")
    wall_pct = _get_final_value(rows, "canonical_stat::wall_thorns_damage_pct")
    tower_total = _get_final_value(rows, "canonical_stat::tower_thorns_damage_pct")
    garlic_enabled = _get_final_value(rows, "capability::capability.tower.garlic_thorns")
    garlic_level = int(_get_contributor_value(rows, "capability::capability.tower.garlic_thorns", "lab", "Garlic Thorns") or 0)

    scenario = compute_scenario_surfaces(
        ScenarioConfig(mode_id=inputs.mode_id, tier=inputs.tier, tournament_wave=inputs.tournament_wave, league=inputs.league)
    )

    return {
        "workshop_thorns_pct": float(workshop or 0.0),
        "relic_thorns_pct": float(relic or 0.0),
        "vault_thorns_pct": float(vault or 0.0),
        "module_thorns_sub_pct": float(module_sum or 0.0),
        "wall_thorns_ratio": float(wall_ratio if wall_ratio is not None else (wall_pct or 0.0) / 100.0),
        "wall_thorns_lab_level": int(round((wall_pct or 0.0))),
        "tower_thorns_pct_repo": float(tower_total or 0.0),
        "garlic_thorns_level": garlic_level,
        "garlic_thorns_pct": garlic_level * 0.5 if garlic_enabled else 0.0,
        "bc_thorns_resistance_multiplier": float(scenario.bc_thorns_resistance),
        "bc_plasma_cannon_resistance_multiplier": float(scenario.bc_plasma_cannon_resistance),
        "boss_thorns_effectiveness": float(scenario.boss_thorns_effectiveness),
        "fleet_thorns_effectiveness": float(0.1),
    }


def _roundup(x: float) -> int:
    return int(math.ceil(x - 1e-12))


def _resolve_inputs(inputs: ThornsInputs) -> Dict[str, Any]:
    repo = _repo_defaults(inputs)

    workshop = float(inputs.workshop_thorns_pct if inputs.workshop_thorns_pct is not None else repo["workshop_thorns_pct"])
    relic = float(inputs.relic_thorns_pct if inputs.relic_thorns_pct is not None else repo["relic_thorns_pct"])
    vault = float(inputs.vault_thorns_pct if inputs.vault_thorns_pct is not None else repo["vault_thorns_pct"])
    module_sub = float(inputs.module_thorns_sub_pct if inputs.module_thorns_sub_pct is not None else repo["module_thorns_sub_pct"])

    if inputs.tower_thorns_pct_injected is not None:
        tower_thorns_pct = float(inputs.tower_thorns_pct_injected)
        tower_thorns_multiplier = tower_thorns_pct / 100.0
        tower_thorns_formula = "injected_direct"
    else:
        # Workbook parity composition:
        # Thorn = (WS + Sub) * (1 + Vault) * (1 + Relic)
        # RoundedThorn = ROUND(Thorn, 2)
        thorn = ((workshop + module_sub) / 100.0) * (1.0 + vault) * (1.0 + relic)
        tower_thorns_multiplier = round(thorn, 2)
        tower_thorns_pct = tower_thorns_multiplier * 100.0
        tower_thorns_formula = "workbook_rounded_component_sum"

    if inputs.wall_thorns_ratio is not None:
        wall_ratio = float(inputs.wall_thorns_ratio)
        wall_level = int(round(wall_ratio * 100.0))
    else:
        wall_ratio = float(repo["wall_thorns_ratio"] if inputs.wall_thorns_lab_level is None else inputs.wall_thorns_lab_level / 100.0)
        wall_level = int(round(inputs.wall_thorns_lab_level if inputs.wall_thorns_lab_level is not None else repo["wall_thorns_lab_level"]))

    bc_thorns = float(inputs.bc_thorns_resistance_multiplier if inputs.bc_thorns_resistance_multiplier is not None else repo["bc_thorns_resistance_multiplier"])
    bc_pc = float(inputs.bc_plasma_cannon_resistance_multiplier if inputs.bc_plasma_cannon_resistance_multiplier is not None else repo["bc_plasma_cannon_resistance_multiplier"])
    boss_eff = float(inputs.boss_thorns_effectiveness if inputs.boss_thorns_effectiveness is not None else repo["boss_thorns_effectiveness"])
    fleet_eff = float(inputs.fleet_thorns_effectiveness if inputs.fleet_thorns_effectiveness is not None else repo["fleet_thorns_effectiveness"])

    garlic_level = int(inputs.garlic_thorns_level if inputs.garlic_thorns_level is not None else repo["garlic_thorns_level"])
    garlic_pct = float(inputs.garlic_thorns_pct if inputs.garlic_thorns_pct is not None else repo["garlic_thorns_pct"])

    return {
        "mode_id": inputs.mode_id,
        "tier": inputs.tier,
        "tournament_wave": inputs.tournament_wave,
        "league": inputs.league,
        "tower_thorns_pct": tower_thorns_pct,
        "tower_thorns_multiplier": tower_thorns_multiplier,
        "tower_thorns_formula": tower_thorns_formula,
        "workshop_thorns_pct": workshop,
        "relic_thorns_pct": relic,
        "vault_thorns_pct": vault,
        "module_thorns_sub_pct": module_sub,
        "wall_thorns_ratio": wall_ratio,
        "wall_thorns_pct": wall_ratio * 100.0,
        "wall_thorns_lab_level": wall_level,
        "plasma_cannon_pct": float(inputs.plasma_cannon_pct),
        "elite_pc_multiplier": inputs.elite_pc_multiplier,
        "bc_thorns_resistance_multiplier": bc_thorns,
        "bc_plasma_cannon_resistance_multiplier": bc_pc,
        "boss_thorns_effectiveness": boss_eff,
        "fleet_thorns_effectiveness": fleet_eff,
        "sharp_fortitude_active": bool(inputs.sharp_fortitude_active),
        "garlic_thorns_level": garlic_level,
        "garlic_thorns_pct": garlic_pct,
    }


def _hits_without_sf(resolved: Dict[str, Any], wall_ratio: float, enemy_effectiveness: float, pc_fraction: float) -> int:
    damage_fraction = wall_ratio * resolved["tower_thorns_multiplier"] * enemy_effectiveness * resolved["bc_thorns_resistance_multiplier"]
    if damage_fraction <= 0:
        return 0
    remaining = 1.0 - (resolved["plasma_cannon_pct"] * pc_fraction * resolved["bc_plasma_cannon_resistance_multiplier"])
    return _roundup(remaining / damage_fraction)


def _hits_with_sf(resolved: Dict[str, Any], wall_ratio: float, enemy_effectiveness: float, pc_fraction: float) -> int:
    remaining = 1.0 - (resolved["plasma_cannon_pct"] * pc_fraction * resolved["bc_plasma_cannon_resistance_multiplier"])
    if remaining <= 0:
        return 0

    # Workbook parity family:
    # hit_n_damage = wall_ratio * (tower_thorns_multiplier + n * 0.01) * enemy_effectiveness * bc_thorns
    # where n starts at 0.
    hit = 0
    total = 0.0
    while total < remaining - 1e-12 and hit < 100000:
        per_hit = wall_ratio * (resolved["tower_thorns_multiplier"] + hit * SF_RAMP_ABSOLUTE_WALL_STEP)
        per_hit *= enemy_effectiveness * resolved["bc_thorns_resistance_multiplier"]
        total += per_hit
        hit += 1
    return hit


def _hits(resolved: Dict[str, Any], wall_ratio: float, enemy_effectiveness: float, pc_fraction: float) -> int:
    if resolved["sharp_fortitude_active"]:
        return _hits_with_sf(resolved, wall_ratio, enemy_effectiveness, pc_fraction)
    return _hits_without_sf(resolved, wall_ratio, enemy_effectiveness, pc_fraction)


def resolved_surface(inputs: ThornsInputs) -> Dict[str, Any]:
    resolved = _resolve_inputs(inputs)
    return {
        "mode_id": resolved["mode_id"],
        "tier": resolved["tier"],
        "tower_thorns_pct": resolved["tower_thorns_pct"],
        "tower_thorns_multiplier": resolved["tower_thorns_multiplier"],
        "tower_thorns_formula": resolved["tower_thorns_formula"],
        "workshop_thorns_pct": resolved["workshop_thorns_pct"],
        "relic_thorns_pct": resolved["relic_thorns_pct"],
        "vault_thorns_pct": resolved["vault_thorns_pct"],
        "module_thorns_sub_pct": resolved["module_thorns_sub_pct"],
        "wall_thorns_lab_level": resolved["wall_thorns_lab_level"],
        "wall_thorns_pct": resolved["wall_thorns_pct"],
        "bc_thorns_resistance_multiplier": resolved["bc_thorns_resistance_multiplier"],
        "bc_plasma_cannon_resistance_multiplier": resolved["bc_plasma_cannon_resistance_multiplier"],
        "boss_thorns_effectiveness": resolved["boss_thorns_effectiveness"],
        "fleet_thorns_effectiveness": resolved["fleet_thorns_effectiveness"],
        "plasma_cannon_pct": resolved["plasma_cannon_pct"],
        "sharp_fortitude_active": resolved["sharp_fortitude_active"],
        "garlic": {
            "separate_tagged_contributor": True,
            "level": resolved["garlic_thorns_level"],
            "pct": resolved["garlic_thorns_pct"],
        },
    }


def hits_to_kill_payload(inputs: ThornsInputs) -> Dict[str, Any]:
    resolved = _resolve_inputs(inputs)
    wall_ratio = resolved["wall_thorns_ratio"]

    rows: Dict[str, Any] = {}
    rows["elites"] = _hits(resolved, wall_ratio, 1.0, 0.0)
    if resolved["elite_pc_multiplier"] is None:
        rows["elites_plus_pc"] = {"status": "BLOCKED__requires_elite_pc_multiplier"}
    else:
        rows["elites_plus_pc"] = _hits(resolved, wall_ratio, 1.0, float(resolved["elite_pc_multiplier"]))
    rows["bosses"] = _hits(resolved, wall_ratio, resolved["boss_thorns_effectiveness"], 0.0)
    rows["bosses_plus_pc"] = _hits(resolved, wall_ratio, resolved["boss_thorns_effectiveness"], 1.0)
    rows["fleets"] = _hits(resolved, wall_ratio, resolved["fleet_thorns_effectiveness"], 0.0)

    return {
        "resolved_surface": resolved_surface(inputs),
        "rows": rows,
    }


def wall_upgrade_scan_payload(inputs: ThornsInputs) -> Dict[str, Any]:
    resolved = _resolve_inputs(inputs)
    out = []
    for level in range(max(1, resolved["wall_thorns_lab_level"]), WALL_THORNS_LAB_MAX_LEVEL + 1):
        scan_inputs = ThornsInputs(**{**asdict(inputs), "wall_thorns_lab_level": level})
        hits = hits_to_kill_payload(scan_inputs)["rows"]
        out.append({
            "wall_thorns_lab_level": level,
            "wall_thorns_pct": float(level),
            "elites": hits["elites"],
            "elites_plus_pc": hits["elites_plus_pc"],
            "bosses": hits["bosses"],
            "bosses_plus_pc": hits["bosses_plus_pc"],
            "fleets": hits["fleets"],
        })
    return {"scan": out}


def progression_relevance_payload(inputs: ThornsInputs) -> Dict[str, Any]:
    resolved = _resolve_inputs(inputs)
    current = hits_to_kill_payload(inputs)["rows"]
    next_level = None
    if resolved["wall_thorns_lab_level"] < WALL_THORNS_LAB_MAX_LEVEL:
        next_level = hits_to_kill_payload(ThornsInputs(**{**asdict(inputs), "wall_thorns_lab_level": resolved["wall_thorns_lab_level"] + 1}))["rows"]

    changed = False
    details = []
    if next_level is not None:
        for key in ("elites", "bosses", "bosses_plus_pc", "fleets"):
            if current[key] != next_level[key]:
                changed = True
                details.append(f"{key}:{current[key]}->{next_level[key]}")
        if isinstance(current["elites_plus_pc"], int) and isinstance(next_level["elites_plus_pc"], int) and current["elites_plus_pc"] != next_level["elites_plus_pc"]:
            changed = True
            details.append(f"elites_plus_pc:{current['elites_plus_pc']}->{next_level['elites_plus_pc']}")

    return {
        "status": "bounded_progression_note_only",
        "changed_next_level": changed,
        "detail": details,
        "trust_label": "medium",
        "dependency_note": "Projected max-wave delta intentionally not published in Phase 1.",
    }


from __future__ import annotations
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Dict, List, Optional
import csv

WORKBOOK_ORACLE_ROWS = [
    {"heat_wave": 1.0, "original_level": 3, "original_value": -0.01},
    {"heat_wave": 20.0, "original_level": 6, "original_value": -0.02},
    {"heat_wave": 40.0, "original_level": 9, "original_value": -0.03},
    {"heat_wave": 60.0, "original_level": 12, "original_value": -0.04},
    {"heat_wave": 80.0, "original_level": 18, "original_value": -0.06},
    {"heat_wave": 100.0, "original_level": 24, "original_value": -0.08},
    {"heat_wave": 150.0, "original_level": 30, "original_value": -0.10},
    {"heat_wave": 200.0, "original_level": 36, "original_value": -0.12},
    {"heat_wave": 250.0, "original_level": 42, "original_value": -0.14},
    {"heat_wave": 300.0, "original_level": 48, "original_value": -0.16},
    {"heat_wave": 350.0, "original_level": 54, "original_value": -0.18},
    {"heat_wave": 400.0, "original_level": 60, "original_value": -0.20},
    {"heat_wave": 450.0, "original_level": 66, "original_value": -0.22},
    {"heat_wave": 500.0, "original_level": 72, "original_value": -0.24},
    {"heat_wave": 600.0, "original_level": 78, "original_value": -0.26},
    {"heat_wave": 700.0, "original_level": 84, "original_value": -0.28},
    {"heat_wave": 800.0, "original_level": 90, "original_value": -0.30},
    {"heat_wave": 900.0, "original_level": 99, "original_value": -0.33},
    {"heat_wave": 1000.0, "original_level": 100, "original_value": -(1.0/3.0)},
]

@dataclass(frozen=True)
class ElsBcReductionRow:
    source: str
    key: str
    original_level: int
    original_value: float
    reduced_level: int
    reduced_value: float
    lab_level: int
    lab_reduction_pct: float
    auxiliary_x: float

    def to_dict(self) -> Dict[str, float]:
        d = asdict(self)
        if self.source == "workbook":
            d["heat_wave"] = d.pop("auxiliary_x")
        else:
            d["tier"] = int(d.pop("auxiliary_x"))
        return d

def _lab_reduction_pct(lab_level: int) -> float:
    if lab_level < 0:
        raise ValueError("lab_level must be >= 0")
    return lab_level * 0.02

def compute_workbook_rows(lab_level: int, *, rows: Optional[List[Dict[str, float]]] = None) -> List[ElsBcReductionRow]:
    source_rows = rows or WORKBOOK_ORACLE_ROWS
    lab_reduction_pct = _lab_reduction_pct(lab_level)
    base_per_level = float(source_rows[0]["original_value"]) / int(source_rows[0]["original_level"])
    out: List[ElsBcReductionRow] = []
    for row in source_rows:
        original_level = int(row["original_level"])
        reduced_level = max(original_level - lab_level, 1)
        reduced_value = base_per_level * reduced_level * (1.0 - lab_reduction_pct)
        out.append(ElsBcReductionRow(
            source="workbook",
            key=f"heat_wave_{row['heat_wave']}",
            original_level=original_level,
            original_value=float(row["original_value"]),
            reduced_level=reduced_level,
            reduced_value=reduced_value,
            lab_level=lab_level,
            lab_reduction_pct=lab_reduction_pct,
            auxiliary_x=float(row["heat_wave"]),
        ))
    return out

def _repo_root() -> Path:
    return Path(__file__).resolve().parents[1]

def _load_tier_enemy_level_skip_rows(repo_root: Optional[Path] = None) -> List[Dict[str, float]]:
    root = repo_root or _repo_root()
    path = root / "kb" / "tournaments" / "sources" / "raw" / "repo-inputs" / "combat" / "tier-battle-conditions.csv"
    if not path.exists():
        raise FileNotFoundError(f"tier BC CSV not found: {path}")
    out = []
    with path.open(newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row["bc"] == "enemy_level_skip_reduction":
                out.append({
                    "tier": float(row["tier"]),
                    "value": float(row["value"]),
                })
    out.sort(key=lambda r: r["tier"])
    return out

def compute_tier_rows(lab_level: int, *, repo_root: Optional[Path] = None) -> List[ElsBcReductionRow]:
    rows = _load_tier_enemy_level_skip_rows(repo_root)
    lab_reduction_pct = _lab_reduction_pct(lab_level)
    out: List[ElsBcReductionRow] = []
    for row in rows:
        original_value = float(row["value"])
        # tier surface has no explicit "level" to subtract from; scenario engine applies group-4 reduction
        # directly to additive magnitude. So "reduced_level" is not meaningful here and is mirrored.
        reduced_value = original_value * (1.0 - lab_reduction_pct)
        out.append(ElsBcReductionRow(
            source="tier_scenario",
            key=f"tier_{int(row['tier'])}",
            original_level=0,
            original_value=original_value,
            reduced_level=0,
            reduced_value=reduced_value,
            lab_level=lab_level,
            lab_reduction_pct=lab_reduction_pct,
            auxiliary_x=float(row["tier"]),
        ))
    return out

def emit_workbook_payload(lab_level: int) -> Dict[str, object]:
    rows = compute_workbook_rows(lab_level)
    return {
        "surface_id": "els_bc_reduction_workbook_parity",
        "oracle": "Copy of Laboratory v2.5.7.xlsx::ELS BC Reduction",
        "lab_name": "Battle Condition Reduction",
        "lab_level": lab_level,
        "lab_reduction_pct": _lab_reduction_pct(lab_level),
        "rows": [r.to_dict() for r in rows],
        "status": "workbook_parity_verified",
        "boundary_notes": [
            "Workbook subtracts lab level from an original BC level ladder, floors at 1, then applies 2% per lab level.",
            "This is an oracle surface and is intentionally not auto-merged with repo scenario-canonical group-4 behavior."
        ],
    }

def emit_tier_payload(lab_level: int, *, repo_root: Optional[Path] = None) -> Dict[str, object]:
    rows = compute_tier_rows(lab_level, repo_root=repo_root)
    return {
        "surface_id": "els_bc_reduction_tier_scenario_view",
        "oracle": "repo::kb/tournaments/sources/raw/repo-inputs/combat/tier-battle-conditions.csv",
        "lab_name": "Battle Condition Reduction",
        "lab_level": lab_level,
        "lab_reduction_pct": _lab_reduction_pct(lab_level),
        "rows": [r.to_dict() for r in rows],
        "status": "scenario_canonical_view",
        "boundary_notes": [
            "Repo tier scenario engine treats enemy_level_skip_reduction as a group-4 additive magnitude.",
            "There is no explicit original-level ladder on the tier surface, so only value reduction is canonical here."
        ],
    }

def emit_harmonization_payload(lab_level: int, *, repo_root: Optional[Path] = None) -> Dict[str, object]:
    workbook = emit_workbook_payload(lab_level)
    tier = emit_tier_payload(lab_level, repo_root=repo_root)
    return {
        "surface_id": "els_bc_reduction_harmonization_view",
        "lab_level": lab_level,
        "lab_reduction_pct": _lab_reduction_pct(lab_level),
        "workbook_view": workbook,
        "tier_scenario_view": tier,
        "seam_summary": [
            "Workbook view is a heat-wave ladder with original level and original value columns.",
            "Tier scenario view is a tier-indexed additive-magnitude reduction surface.",
            "These are related but not isomorphic. Keep both visible until a deliberate adapter contract is chosen."
        ],
        "status": "dual_surface_visible",
    }

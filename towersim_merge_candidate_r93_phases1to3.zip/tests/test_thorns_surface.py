
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from engine.thorns_surface import (
    ThornsInputs,
    resolved_surface,
    hits_to_kill_payload,
    wall_upgrade_scan_payload,
    progression_relevance_payload,
)


def _workbook_inputs(sf: bool = False) -> ThornsInputs:
    return ThornsInputs(
        mode_id="farming",
        tier=14,
        workshop_thorns_pct=99.0,
        relic_thorns_pct=0.09,
        vault_thorns_pct=0.0,
        module_thorns_sub_pct=11.0,
        plasma_cannon_pct=0.54,
        wall_thorns_lab_level=15,
        bc_thorns_resistance_multiplier=1.0,
        bc_plasma_cannon_resistance_multiplier=1.0,
        boss_thorns_effectiveness=0.5,
        fleet_thorns_effectiveness=0.1,
        sharp_fortitude_active=sf,
        elite_pc_multiplier=None,
        garlic_thorns_level=0,
        garlic_thorns_pct=0.0,
    )


def test_workbook_non_sf_parity_full_table():
    inputs = _workbook_inputs(sf=False)
    scan = [hits_to_kill_payload(ThornsInputs(**{**inputs.__dict__, "wall_thorns_lab_level": level}))["rows"] for level in range(1, 21)]

    expected_elites =      [84,42,28,21,17,14,12,11,10,9,8,7,7,6,6,6,5,5,5,5]
    expected_bosses =      [167,84,56,42,34,28,24,21,19,17,16,14,13,12,12,11,10,10,9,9]
    expected_fleets =      [834,417,278,209,167,139,120,105,93,84,76,70,65,60,56,53,50,47,44,42]
    expected_bosses_pc =   [77,39,26,20,16,13,11,10,9,8,7,7,6,6,6,5,5,5,5,4]

    assert [r["elites"] for r in scan] == expected_elites
    assert [r["bosses"] for r in scan] == expected_bosses
    assert [r["fleets"] for r in scan] == expected_fleets
    assert [r["bosses_plus_pc"] for r in scan] == expected_bosses_pc
    assert all(isinstance(r["elites_plus_pc"], dict) and r["elites_plus_pc"]["status"].startswith("BLOCKED") for r in scan)


def test_workbook_sf_parity_full_table():
    inputs = _workbook_inputs(sf=True)
    scan = [hits_to_kill_payload(ThornsInputs(**{**inputs.__dict__, "wall_thorns_lab_level": level}))["rows"] for level in range(1, 21)]

    expected_elites =      [66,37,26,20,16,14,12,11,9,9,8,7,7,6,6,6,5,5,5,5]
    expected_bosses =      [114,66,47,37,30,26,22,20,18,16,15,14,13,12,11,11,10,9,9,9]
    expected_fleets =      [344,219,166,135,114,99,88,79,72,66,61,57,53,50,47,45,42,40,39,37]
    expected_bosses_pc =   [62,34,24,18,15,13,11,10,9,8,7,7,6,6,6,5,5,5,4,4]

    assert [r["elites"] for r in scan] == expected_elites
    assert [r["bosses"] for r in scan] == expected_bosses
    assert [r["fleets"] for r in scan] == expected_fleets
    assert [r["bosses_plus_pc"] for r in scan] == expected_bosses_pc


def test_workbook_rounded_tower_thorns_surface():
    surface = resolved_surface(_workbook_inputs(sf=False))
    assert surface["tower_thorns_multiplier"] == 1.2
    assert surface["tower_thorns_pct"] == 120.0
    assert surface["tower_thorns_formula"] == "workbook_rounded_component_sum"


def test_repo_baseline_surface_smoke():
    payload = hits_to_kill_payload(ThornsInputs())
    assert payload["resolved_surface"]["tower_thorns_pct"] > 0
    assert payload["resolved_surface"]["wall_thorns_pct"] > 0
    assert payload["rows"]["elites"] > 0
    assert payload["rows"]["bosses"] > 0
    assert payload["rows"]["fleets"] > 0


def test_progression_payload_bounded():
    payload = progression_relevance_payload(_workbook_inputs(sf=False))
    assert payload["trust_label"] == "medium"
    assert "max-wave delta" in payload["dependency_note"]

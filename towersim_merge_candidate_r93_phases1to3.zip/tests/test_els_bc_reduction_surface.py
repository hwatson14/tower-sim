
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from engine.els_bc_reduction_surface import (
    compute_workbook_rows, compute_tier_rows,
    emit_workbook_payload, emit_tier_payload, emit_harmonization_payload,
)

def _wrow(rows, heat):
    for r in rows:
        if abs(r.auxiliary_x - heat) < 1e-9:
            return r
    raise AssertionError(f"heat {heat} not found")

def _trow(rows, tier):
    for r in rows:
        if abs(r.auxiliary_x - tier) < 1e-9:
            return r
    raise AssertionError(f"tier {tier} not found")

def test_workbook_level0_matches_cached_examples():
    rows = compute_workbook_rows(0)
    assert _wrow(rows, 1.0).reduced_level == 3
    assert abs(_wrow(rows, 1.0).reduced_value - (-0.01)) < 1e-12
    assert _wrow(rows, 1000.0).reduced_level == 100
    assert abs(_wrow(rows, 1000.0).reduced_value - (-(1.0/3.0))) < 1e-12

def test_workbook_level5_matches_formula_examples():
    rows = compute_workbook_rows(5)
    assert _wrow(rows, 20.0).reduced_level == 1
    assert abs(_wrow(rows, 20.0).reduced_value - (-0.003)) < 1e-12
    assert _wrow(rows, 100.0).reduced_level == 19
    assert abs(_wrow(rows, 100.0).reduced_value - (-0.057)) < 1e-12

def test_tier_view_matches_repo_t14_and_t21():
    rows = compute_tier_rows(5)
    t14 = _trow(rows, 14.0)
    assert abs(t14.original_value - 0.025) < 1e-12
    assert abs(t14.reduced_value - 0.0225) < 1e-12
    t21 = _trow(rows, 21.0)
    assert abs(t21.original_value - 0.13) < 1e-12
    assert abs(t21.reduced_value - 0.117) < 1e-12

def test_payload_shapes():
    wp = emit_workbook_payload(3)
    tp = emit_tier_payload(3)
    hp = emit_harmonization_payload(3)
    assert wp["surface_id"] == "els_bc_reduction_workbook_parity"
    assert tp["surface_id"] == "els_bc_reduction_tier_scenario_view"
    assert hp["surface_id"] == "els_bc_reduction_harmonization_view"
    assert len(wp["rows"]) == 19
    assert len(tp["rows"]) == 8

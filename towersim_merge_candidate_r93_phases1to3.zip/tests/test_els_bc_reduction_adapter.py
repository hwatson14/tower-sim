
from pathlib import Path
import os, sys, importlib.util

os.environ['TOWERSIM_REPO_ROOT'] = '/mnt/data/repo_r80'
spec = importlib.util.spec_from_file_location('els_bc_reduction_adapter_local', Path(__file__).resolve().parents[1] / 'engine' / 'els_bc_reduction_adapter.py')
mod = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = mod
spec.loader.exec_module(mod)

ScenarioConfig = mod.ScenarioConfig
lab_level_to_reduction_pct = mod.lab_level_to_reduction_pct
apply_els_bc_lab_to_scenario = mod.apply_els_bc_lab_to_scenario
compare_scenario_effect = mod.compare_scenario_effect
emit_scenario_adapter_payload = mod.emit_scenario_adapter_payload


def test_lab_level_to_reduction_pct():
    assert abs(lab_level_to_reduction_pct(5) - 10.0) < 1e-12


def test_apply_to_t14_matches_group4_behavior():
    base = ScenarioConfig(mode_id='farming', tier=14)
    adjusted = apply_els_bc_lab_to_scenario(base, 5)
    assert abs(adjusted.bc_reduction_group4_pct - 10.0) < 1e-12
    comp = compare_scenario_effect(base, 5)
    assert abs(comp.base_enemy_level_skip_reduction_pp - 0.025) < 1e-12
    assert abs(comp.adjusted_enemy_level_skip_reduction_pp - 0.0225) < 1e-12
    assert abs(comp.delta_pp - (-0.0025)) < 1e-12


def test_apply_to_tournament_wave100_matches_group4_behavior():
    base = ScenarioConfig(mode_id='tournament', tier=14, league='champion', tournament_wave=100)
    comp = compare_scenario_effect(base, 5)
    assert abs(comp.base_enemy_level_skip_reduction_pp - (-0.08)) < 1e-12
    assert abs(comp.adjusted_enemy_level_skip_reduction_pp - (-0.072)) < 1e-12
    assert abs(comp.delta_pp - 0.008) < 1e-12


def test_payload_shape():
    payload = emit_scenario_adapter_payload(ScenarioConfig(mode_id='farming', tier=21), 5)
    assert payload['surface_id'] == 'els_bc_reduction_scenario_adapter'
    assert payload['status'] == 'scenario_adapter_verified'
    assert abs(payload['adjusted_enemy_level_skip_reduction_pp'] - 0.117) < 1e-12

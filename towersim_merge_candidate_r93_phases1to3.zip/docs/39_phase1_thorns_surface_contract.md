# Phase 1 Thorns Surface Contract

## Scope
Phase 1 owns only the thorns mechanical surface family.

Included:
- resolved thorns composition
- hit-count outputs
- wall-thorns scan to lab cap
- garlic as a separate tagged contributor
- workbook-parity Sharp Fortitude path
- bounded progression relevance note

Excluded:
- ELS BC reduction
- lab tier-list enrichment
- lab planner
- projected max-wave delta publication

## Workbook oracle
Mechanical parity target is:
- `Copy of Laboratory v2.5.7.xlsx`
- sheet `Interactive Thorns`

## Key implementation choices
### Tower thorns composition
When `tower_thorns_pct_injected` is absent, the module uses workbook composition:

`ROUND(((WS + Sub) / 100) * (1 + Vault) * (1 + Relic), 2)`

This produces tower-thorns multiplier, then converts back to percent.

### Non-SF hit counts
- Elites: `ceil((1 - pc * elite_mult) / (wall_ratio * tower_thorns * bc_thorns))`
- Bosses: same with boss effectiveness
- Fleets: same with fleet effectiveness

### Elite + PC gating
`elites_plus_pc` is blocked unless `elite_pc_multiplier` is explicitly supplied.
This matches workbook behavior when mastery is locked.

### Sharp Fortitude parity path
Workbook parity is reproduced using:
`hit_n_damage = wall_ratio * (tower_thorns_multiplier + n * 0.01) * effectiveness * bc_thorns`
with `n` starting at 0.

This matches the workbook cached tables exactly for the current oracle configuration.

## Trust status
- High: resolved surface, non-SF hit counts, SF workbook parity, upgrade scan
- Medium: progression relevance note
- Blocked: projected max-wave delta

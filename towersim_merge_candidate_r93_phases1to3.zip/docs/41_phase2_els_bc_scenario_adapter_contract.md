# Phase 2 ELS BC Reduction Scenario Adapter Contract

Provides a repo-canonical adapter from lab level to ScenarioConfig.bc_reduction_group4_pct, then emits before/after bc_enemy_level_skip_reduction_pp for existing repo consumers. This is repo-canonical only and does not replace the workbook-parity surface.


# Phase 2 ELS BC reduction contract (R90)

## Purpose
Expose two explicit surfaces instead of collapsing them:

1. **Workbook parity surface**
   - Oracle: `Copy of Laboratory v2.5.7.xlsx` → `ELS BC Reduction`
   - Indexed by heat-wave ladder
   - Has original level and original value columns
   - Applies:
     - reduced level = `max(original_level - lab_level, 1)`
     - reduced value = `base_per_level * reduced_level * (1 - 0.02 * lab_level)`

2. **Tier scenario view**
   - Oracle: repo `kb/tournaments/sources/raw/repo-inputs/combat/tier-battle-conditions.csv`
   - Indexed by tier
   - Has additive magnitude values for `enemy_level_skip_reduction`
   - Applies:
     - reduced value = `original_value * (1 - 0.02 * lab_level)`

## Why two surfaces exist
These two views are related but not isomorphic.
The workbook has an explicit BC-level ladder.
The tier scenario engine has only a final additive magnitude per tier.

A future refactor can unify them through an adapter, but R90 keeps both visible to avoid false equivalence.

## Public payloads
- `emit_workbook_payload(lab_level)`
- `emit_tier_payload(lab_level)`
- `emit_harmonization_payload(lab_level)`

## Boundary
No optimiser/advisor logic.
No lab planner work.
No hidden coercion from workbook ladder into scenario tier values.
